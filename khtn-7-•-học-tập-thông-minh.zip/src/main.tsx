import {createRoot} from 'react-dom/client';
import {registerSW} from 'virtual:pwa-register';
import App from './App.tsx';
import './index.css';

// Immediately check for new deployed builds (e.g., updated student roster on Netlify)
registerSW({
  immediate: true,
  onRegisteredSW(_swUrl, registration) {
    if (registration) {
      registration.update().catch(() => {
        // ignore offline update check error
      });
    }
  },
});

createRoot(document.getElementById('root')!).render(<App />);
