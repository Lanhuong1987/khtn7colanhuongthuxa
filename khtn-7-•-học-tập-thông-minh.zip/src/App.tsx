/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Home,
  BookOpen,
  ClipboardCheck,
  Award,
  Gamepad2,
  FolderOpen,
  RotateCcw,
  BarChart3,
  FileDown,
  Settings,
  KeyRound,
  Sparkles,
  CheckCircle2,
  ChevronRight,
  Menu,
  X,
  Users,
  Camera,
  Table2,
  Check,
  RefreshCw,
  Upload,
  Lock,
  AlertTriangle,
  Plus,
  Flame,
  FlaskConical,
  Bell,
} from 'lucide-react';

import { ALL_KNTT_LESSONS, LESSON_BANK_STATS } from './data/allLessons';
import {
  DEFAULT_STUDENTS,
  StudentProfile,
  WeeklyAssignment,
  loadWeeklyAssignments,
  saveWeeklyAssignments,
  calculateStudentGradeMetrics,
  SavedWordExamDoc,
  loadSavedWordDocs,
  saveWordDocsToStorage,
  findStudentByNameOrCode,
  normalizeStudentNameNFC,
  suggestStudentsByPartialName,
} from './data/classStore';
import { PracticeView } from './components/PracticeView';
import { TheoryView } from './components/TheoryView';
import { SimulationsView } from './components/SimulationsView';
import { ExamView } from './components/ExamView';
import { GamesView } from './components/GamesView';
import { WrongAnswersView } from './components/WrongAnswersView';
import { WeeklyTrackerView } from './components/WeeklyTrackerView';
import { LibraryAndWordView } from './components/LibraryAndWordView';
import { ClassAdminView } from './components/ClassAdminView';
import { PeriodicTableModal } from './components/PeriodicTableModal';
import { StudentProfileModal } from './components/StudentProfileModal';
import { FlashcardsView } from './components/FlashcardsView';
import { ClassroomToolsModal } from './components/ClassroomToolsModal';
import {
  DailySprintAndCertificateModal,
  loadStreakData,
  StreakData,
} from './components/DailySprintAndCertificateModal';
import {
  Khtn7BrandLogo,
  PWAInstallButton,
  PWAInstallModal,
  OfflineIndicator,
} from './components/PWAInstallModal';
import { ParentPortalView } from './components/ParentPortalView';
import {
  HomeworkReminderModal,
  loadReminderSchedule,
  loadTeacherReminderLogs,
  computeActiveStudentWeekHomeworkGap,
  HomeworkReminderSchedule,
  TeacherHomeworkReminderLog,
} from './components/HomeworkReminderModal';
import { SubSubject } from './data/khtn7Data';

export type NavSectionId =
  | 'home'
  | 'lessons'
  | 'practice'
  | 'exam'
  | 'games'
  | 'parent_portal'
  | 'library'
  | 'wrong_answers'
  | 'weekly_tracker'
  | 'word_download'
  | 'admin';

const STUDENTS_STORAGE_KEY = 'khtn7_class_students_v4_official';
const DELETED_STUDENTS_KEY = 'khtn7_deleted_student_names_v4';
const ACTIVE_STUDENT_STORAGE_KEY = 'khtn7_active_student_v4';
const ACTIVE_WEEK_STORAGE_KEY = 'khtn7_active_week_v2';

function loadDeletedStudentNames(): Set<string> {
  try {
    const raw = localStorage.getItem(DELETED_STUDENTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return new Set(parsed.map((n: string) => normalizeStudentNameNFC(n)));
      }
    }
  } catch {
    // ignore
  }
  return new Set();
}

function saveDeletedStudentNames(deletedSet: Set<string>): void {
  try {
    localStorage.setItem(DELETED_STUDENTS_KEY, JSON.stringify(Array.from(deletedSet)));
  } catch {
    // ignore
  }
}

function loadStudentsFromStorage(): StudentProfile[] {
  const deletedNames = loadDeletedStudentNames();

  // Check if URL has a shared roster parameter (?roster=...) from teacher link
  let urlRosterEntries: { fullName: string; className: string; code?: string }[] = [];
  try {
    const params = new URLSearchParams(window.location.search);
    const encodedRoster = params.get('roster');
    if (encodedRoster) {
      const decodedJson = decodeURIComponent(escape(atob(encodedRoster)));
      const parsedUrl = JSON.parse(decodedJson);
      if (Array.isArray(parsedUrl)) {
        urlRosterEntries = parsedUrl;
      }
    }
  } catch {
    // ignore malformed URL param
  }

  let savedList: StudentProfile[] = [];
  try {
    const raw = localStorage.getItem(STUDENTS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        savedList = parsed;
      }
    }
  } catch {
    // ignore
  }

  // Merge official DEFAULT_STUDENTS + savedList so the 19 official students are always available on Netlify & all devices
  const mergedMap = new Map<string, StudentProfile>();
  const defaultIdsInSaved = new Set(savedList.map((s) => s?.id).filter(Boolean));

  // 1. Seed with DEFAULT_STUDENTS (unless explicitly deleted OR renamed in savedList)
  for (const defStudent of DEFAULT_STUDENTS) {
    const key = normalizeStudentNameNFC(defStudent.fullName);
    if (!deletedNames.has(key) && !defaultIdsInSaved.has(defStudent.id)) {
      mergedMap.set(key, defStudent);
    }
  }

  // 2. Overlay any saved customizations or additional students from localStorage
  for (const savedSt of savedList) {
    if (!savedSt || !savedSt.fullName) continue;
    const key = normalizeStudentNameNFC(savedSt.fullName);
    if (!deletedNames.has(key)) {
      mergedMap.set(key, {
        ...savedSt,
        fullName: savedSt.fullName.normalize('NFC').trim().toUpperCase(),
      });
    }
  }

  // 3. Overlay any students shared via URL parameter (?roster=...)
  for (let i = 0; i < urlRosterEntries.length; i++) {
    const item = urlRosterEntries[i];
    if (!item || !item.fullName) continue;
    const key = normalizeStudentNameNFC(item.fullName);
    if (!mergedMap.has(key)) {
      const num = mergedMap.size + 1;
      mergedMap.set(key, {
        id: `hs-shared-${i + 1}`,
        code: item.code || `KHTN7_HS${String(num).padStart(2, '0')}`,
        fullName: item.fullName.normalize('NFC').trim().toUpperCase(),
        className: item.className || 'Lớp 7A1',
        avatarColor: 'bg-teal-600',
        absorptionLevel: 'Khá',
        baselineWeeksCompleted: [1, 2, 3, 4, 5],
        baselineMcqDone: 135,
        baselineMcqCorrect: 115,
        baselineTfDone: 22,
        baselineEssayDone: 20,
        baselineExamScore: 8.3,
        baselineGameScore: 510,
        scores: {
          tx1: 7.75,
          tx2: 8.25,
          tx3: 8.5,
          tx4: null,
          tx5: null,
          dggk: 8.25,
          dgck: null,
        },
        commendationPoints: 15,
        teacherComments: [],
      });
    }
  }

  const finalRoster = Array.from(mergedMap.values());
  const result = finalRoster.length > 0 ? finalRoster : DEFAULT_STUDENTS;

  try {
    localStorage.setItem(STUDENTS_STORAGE_KEY, JSON.stringify(result));
  } catch {
    // ignore
  }

  return result;
}

function loadActiveStudentFromStorage(roster: StudentProfile[]): StudentProfile {
  try {
    const raw = localStorage.getItem(ACTIVE_STUDENT_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      const match =
        roster.find((s) => s.id === parsed.id || s.code === parsed.code) ||
        findStudentByNameOrCode(roster, parsed.fullName || '');
      if (match) return match;
    }
  } catch {
    // ignore
  }
  return roster[0] || DEFAULT_STUDENTS[0];
}

export default function App() {
  const [activeNav, setActiveNav] = useState<NavSectionId>('home');
  const [role, setRole] = useState<'student' | 'teacher'>('student');
  const [portalTab, setPortalTab] = useState<'student' | 'parent' | 'teacher'>('student');
  const [isTeacherAuthenticated, setIsTeacherAuthenticated] = useState<boolean>(false);
  const [teacherPinInput, setTeacherPinInput] = useState<string>('');
  const [teacherPinError, setTeacherPinError] = useState<string>('');

  const [students, setStudents] = useState<StudentProfile[]>(() => loadStudentsFromStorage());
  const [currentStudent, setCurrentStudent] = useState<StudentProfile>(() =>
    loadActiveStudentFromStorage(loadStudentsFromStorage())
  );
  // Whether the student is currently verified into the class
  const [isStudentVerified, setIsStudentVerified] = useState<boolean>(true);
  const [studentNameInput, setStudentNameInput] = useState('');
  const [loginError, setLoginError] = useState('');

  // Parent Portal lookup state (requires exact student name in class)
  const [verifiedParentChild, setVerifiedParentChild] = useState<StudentProfile | null>(null);
  const [parentChildNameInput, setParentChildNameInput] = useState('');
  const [parentLoginError, setParentLoginError] = useState('');

  // Saved Word Exams & Materials
  const [savedWordDocs, setSavedWordDocs] = useState<SavedWordExamDoc[]>(() =>
    loadSavedWordDocs()
  );
  const [lastSyncedRosterAt, setLastSyncedRosterAt] = useState<string>(() => {
    try {
      return localStorage.getItem('khtn7_roster_sync_time_v2') || 'Hôm nay, 08:00';
    } catch {
      return 'Hôm nay, 08:00';
    }
  });

  // Weekly Assignments & Active Synced Week (Matching Image 1 & Image 3)
  const [weeklyAssignments, setWeeklyAssignments] = useState<WeeklyAssignment[]>(() =>
    loadWeeklyAssignments()
  );
  const [activeWeek, setActiveWeek] = useState<number>(() => {
    try {
      const saved = Number(localStorage.getItem(ACTIVE_WEEK_STORAGE_KEY));
      if (saved >= 1) return saved;
    } catch {
      // ignore
    }
    return 6; // Default to Tuần 6 (HK1) matching Image 3
  });
  const [weekSyncNotice, setWeekSyncNotice] = useState<string | null>(null);

  // Sub-view states
  const [practiceLessonId, setPracticeLessonId] = useState<string>(ALL_KNTT_LESSONS[0].id);
  const [lessonTabMode, setLessonTabMode] = useState<'catalog' | 'flashcards' | 'theory' | 'simulations'>('catalog');
  const [homeSubjectFilter, setHomeSubjectFilter] = useState<'all' | SubSubject>('all');
  const [showHandbookModal, setShowHandbookModal] = useState(false);
  const [showStudentModal, setShowStudentModal] = useState(false);
  const [classroomModalTab, setClassroomModalTab] = useState<'picker' | 'leaderboard' | 'tree' | null>(null);
  const [sprintCertModalTab, setSprintCertModalTab] = useState<'sprint' | 'certificate' | null>(null);
  const [streakData, setStreakData] = useState<StreakData>(() => loadStreakData());
  const [showPWAInstallModal, setShowPWAInstallModal] = useState(false);
  const [showReminderModal, setShowReminderModal] = useState(false);
  const [reminderSchedule, setReminderSchedule] = useState<HomeworkReminderSchedule>(() =>
    loadReminderSchedule()
  );
  const [reminderLogs, setReminderLogs] = useState<TeacherHomeworkReminderLog[]>(() =>
    loadTeacherReminderLogs()
  );
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showUxAnalysisModal, setShowUxAnalysisModal] = useState(false);

  // Theory, Exam, and Game state
  const [masteredTopicIds, setMasteredTopicIds] = useState<string[]>(['chem-1', 'phys-1']);
  const [bestExamScore, setBestExamScore] = useState<number | null>(9.2);
  const [gameHighScore, setGameHighScore] = useState<number>(680);

  // Live progress summary across localStorage
  const [progressStats, setProgressStats] = useState({
    mcqAnswered: 0,
    mcqCorrect: 0,
    tfAnswered: 0,
    tfCorrect: 0,
    essayCompleted: 0,
    wrongCount: 0,
  });

  const refreshGlobalStats = () => {
    try {
      const savedMcq = JSON.parse(localStorage.getItem('khtn7_kntt_mcq_v2') || '{}');
      const savedTf = JSON.parse(localStorage.getItem('khtn7_kntt_tf_v2') || '{}');
      const savedEssay = JSON.parse(localStorage.getItem('khtn7_kntt_essay_v2') || '{}');

      let mcqAnswered = 0;
      let mcqCorrect = 0;
      let tfAnswered = 0;
      let tfCorrect = 0;
      let essayCompleted = 0;
      let wrongCount = 0;

      for (const lesson of ALL_KNTT_LESSONS) {
        for (const q of lesson.mcqs) {
          const key = `${lesson.id}:${q.id}`;
          if (savedMcq[key] !== undefined) {
            mcqAnswered++;
            if (savedMcq[key] === q.correctIndex) {
              mcqCorrect++;
            } else {
              wrongCount++;
            }
          }
        }
        for (const tf of lesson.trueFalseList) {
          for (const st of tf.statements) {
            const key = `${lesson.id}:${tf.id}:${st.id}`;
            if (savedTf[key] !== undefined) {
              tfAnswered++;
              if (savedTf[key] === st.isTrue) {
                tfCorrect++;
              } else {
                wrongCount++;
              }
            }
          }
        }
        for (const es of lesson.essays) {
          const key = `${lesson.id}:${es.id}`;
          const sub = savedEssay[key];
          if (
            sub &&
            (sub.textAnswer?.trim() || (sub.attachedImages && sub.attachedImages.length > 0))
          ) {
            essayCompleted++;
          }
        }
      }

      setProgressStats({
        mcqAnswered,
        mcqCorrect,
        tfAnswered,
        tfCorrect,
        essayCompleted,
        wrongCount,
      });
    } catch {
      // ignore storage errors
    }
  };

  useEffect(() => {
    refreshGlobalStats();
  }, [activeNav]);

  const handleSelectStudent = (student: StudentProfile) => {
    setCurrentStudent(student);
    setIsStudentVerified(true);
    try {
      localStorage.setItem(ACTIVE_STUDENT_STORAGE_KEY, JSON.stringify(student));
    } catch {
      // ignore
    }
    setStudentNameInput('');
    setLoginError('');
  };

  const recordSyncTimestamp = () => {
    try {
      const nowStr = new Date().toLocaleTimeString('vi-VN', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      const stamp = `Hôm nay lúc ${nowStr}`;
      setLastSyncedRosterAt(stamp);
      localStorage.setItem('khtn7_roster_sync_time_v2', stamp);
    } catch {
      // ignore
    }
  };

  const handleUpdateSingleStudent = (updated: StudentProfile) => {
    const normalizedUpdated: StudentProfile = {
      ...updated,
      fullName: updated.fullName.normalize('NFC').trim().toUpperCase(),
    };
    setStudents((prevStudents) => {
      const nextList = prevStudents.map((s) =>
        s.id === normalizedUpdated.id ? normalizedUpdated : s
      );
      try {
        localStorage.setItem(STUDENTS_STORAGE_KEY, JSON.stringify(nextList));
      } catch {
        // ignore
      }
      return nextList;
    });
    if (currentStudent.id === normalizedUpdated.id) {
      setCurrentStudent(normalizedUpdated);
      try {
        localStorage.setItem(ACTIVE_STUDENT_STORAGE_KEY, JSON.stringify(normalizedUpdated));
      } catch {
        // ignore
      }
    }
    if (verifiedParentChild && verifiedParentChild.id === normalizedUpdated.id) {
      setVerifiedParentChild(normalizedUpdated);
    }
    recordSyncTimestamp();
  };

  const handleAddStudent = (fullName: string, className: string) => {
    const cleanFullName = fullName.normalize('NFC').trim().toUpperCase();
    if (!cleanFullName) return;

    // Remove from deleted set if re-adding a previously deleted student
    const deletedSet = loadDeletedStudentNames();
    deletedSet.delete(normalizeStudentNameNFC(cleanFullName));
    saveDeletedStudentNames(deletedSet);

    let selectedTarget: StudentProfile | null = null;

    setStudents((prevStudents) => {
      const existing = prevStudents.find(
        (s) => normalizeStudentNameNFC(s.fullName) === normalizeStudentNameNFC(cleanFullName)
      );
      if (existing) {
        const updatedExisting: StudentProfile = {
          ...existing,
          fullName: cleanFullName,
          className: className || existing.className || 'Lớp 7A1',
        };
        selectedTarget = updatedExisting;
        const nextList = prevStudents.map((s) =>
          s.id === existing.id ? updatedExisting : s
        );
        try {
          localStorage.setItem(STUDENTS_STORAGE_KEY, JSON.stringify(nextList));
        } catch {
          // ignore
        }
        return nextList;
      }

      const nextIdx = prevStudents.length + 1;
      const code = `KHTN7_HS${String(nextIdx).padStart(2, '0')}`;
      const newStudent: StudentProfile = {
        id: `hs-${Date.now()}`,
        code,
        fullName: cleanFullName,
        className: className || 'Lớp 7A1',
        avatarColor: 'bg-teal-600',
        absorptionLevel: 'Khá',
        baselineWeeksCompleted: [1, 2, 3, 4, 5],
        baselineMcqDone: 130,
        baselineMcqCorrect: 112,
        baselineTfDone: 20,
        baselineEssayDone: 18,
        baselineExamScore: 8.2,
        baselineGameScore: 480,
        scores: {
          tx1: 8.0,
          tx2: 8.25,
          tx3: 8.5,
          tx4: null,
          tx5: null,
          dggk: 8.25,
          dgck: null,
        },
        commendationPoints: 15,
        teacherComments: [],
      };
      selectedTarget = newStudent;
      const updated = [...prevStudents, newStudent];
      try {
        localStorage.setItem(STUDENTS_STORAGE_KEY, JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });

    if (selectedTarget) {
      handleSelectStudent(selectedTarget);
    }
    recordSyncTimestamp();
  };

  const handleBulkImportStudents = (
    entries: { fullName: string; className: string; code?: string }[],
    replaceExisting: boolean
  ) => {
    const palette = [
      'bg-emerald-600',
      'bg-blue-600',
      'bg-amber-600',
      'bg-indigo-600',
      'bg-teal-600',
      'bg-rose-600',
      'bg-purple-600',
    ];

    const deletedSet = replaceExisting ? new Set<string>() : loadDeletedStudentNames();
    const importedKeys = new Set(
      entries.map((e) => normalizeStudentNameNFC(e.fullName || '')).filter(Boolean)
    );
    if (replaceExisting) {
      for (const defSt of DEFAULT_STUDENTS) {
        const defKey = normalizeStudentNameNFC(defSt.fullName);
        if (!importedKeys.has(defKey)) {
          deletedSet.add(defKey);
        }
      }
    } else {
      for (const e of entries) {
        if (e.fullName) {
          deletedSet.delete(normalizeStudentNameNFC(e.fullName));
        }
      }
    }
    saveDeletedStudentNames(deletedSet);

    let firstStudent: StudentProfile | null = null;

    setStudents((prevStudents) => {
      const baseList = replaceExisting ? [] : [...prevStudents];
      const existingNamesMap = new Map<string, StudentProfile>();
      for (const st of baseList) {
        existingNamesMap.set(normalizeStudentNameNFC(st.fullName), st);
      }

      entries.forEach((entry, idx) => {
        const cleanName = (entry.fullName || '').normalize('NFC').trim().toUpperCase();
        if (!cleanName) return;
        const normKey = normalizeStudentNameNFC(cleanName);
        const existing = existingNamesMap.get(normKey);
        if (existing) {
          existingNamesMap.set(normKey, {
            ...existing,
            fullName: cleanName,
            className: entry.className || existing.className || 'Lớp 7A1',
            code: entry.code || existing.code,
          });
        } else {
          const num = existingNamesMap.size + 1;
          existingNamesMap.set(normKey, {
            id: `hs-${Date.now()}-${idx}`,
            code: entry.code || `KHTN7_HS${String(num).padStart(2, '0')}`,
            fullName: cleanName,
            className: entry.className || 'Lớp 7A1',
            avatarColor: palette[num % palette.length],
            absorptionLevel: 'Khá',
            baselineWeeksCompleted: [1, 2, 3, 4, 5],
            baselineMcqDone: 135,
            baselineMcqCorrect: 115,
            baselineTfDone: 22,
            baselineEssayDone: 20,
            baselineExamScore: 8.2,
            baselineGameScore: 480,
            scores: {
              tx1: 7.75,
              tx2: 8.0,
              tx3: 8.5,
              tx4: null,
              tx5: null,
              dggk: 8.0,
              dgck: null,
            },
            commendationPoints: 15,
            teacherComments: [],
          });
        }
      });

      const combined = Array.from(existingNamesMap.values());
      if (combined.length > 0) {
        firstStudent = combined[0];
      }
      try {
        localStorage.setItem(STUDENTS_STORAGE_KEY, JSON.stringify(combined));
      } catch {
        // ignore
      }
      return combined;
    });

    if (firstStudent) {
      handleSelectStudent(firstStudent);
    }
    recordSyncTimestamp();
  };

  const handleDeleteStudent = (studentId: string) => {
    setStudents((prevStudents) => {
      if (prevStudents.length <= 1) return prevStudents;
      const target = prevStudents.find((s) => s.id === studentId);
      if (target) {
        const deletedSet = loadDeletedStudentNames();
        deletedSet.add(normalizeStudentNameNFC(target.fullName));
        saveDeletedStudentNames(deletedSet);
      }
      const updated = prevStudents.filter((s) => s.id !== studentId);
      try {
        localStorage.setItem(STUDENTS_STORAGE_KEY, JSON.stringify(updated));
      } catch {
        // ignore
      }
      if (currentStudent.id === studentId && updated.length > 0) {
        setCurrentStudent(updated[0]);
      }
      return updated;
    });
    recordSyncTimestamp();
  };

  const handleResetCurrentStudentProgress = () => {
    try {
      localStorage.removeItem('khtn7_kntt_mcq_v2');
      localStorage.removeItem('khtn7_kntt_tf_v2');
      localStorage.removeItem('khtn7_kntt_essay_v2');
    } catch {
      // ignore
    }
    refreshGlobalStats();
  };

  // Resilient Student Name Verification against the Teacher's Class Roster
  const handleVerifyStudentByName = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentNameInput.trim()) {
      setLoginError('Vui lòng nhập Họ và Tên học sinh trong danh sách lớp!');
      return;
    }
    const matchedStudent = findStudentByNameOrCode(students, studentNameInput);
    if (matchedStudent) {
      handleSelectStudent(matchedStudent);
      setActiveNav('practice');
      return;
    }
    setLoginError(
      'Tên học sinh không khớp với danh sách lớp! Vui lòng nhập chính xác Họ và Tên học sinh theo danh sách giáo viên đã nhập.'
    );
  };

  // Resilient Parent Child Name Verification against the Teacher's Class Roster
  const handleVerifyParentChildByName = (e: React.FormEvent) => {
    e.preventDefault();
    if (!parentChildNameInput.trim()) {
      setParentLoginError('Quý phụ huynh vui lòng nhập Họ và Tên của con trong danh sách lớp!');
      return;
    }
    const matchedStudent = findStudentByNameOrCode(students, parentChildNameInput);
    if (matchedStudent) {
      setVerifiedParentChild(matchedStudent);
      setParentChildNameInput('');
      setParentLoginError('');
      setActiveNav('parent_portal');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    setParentLoginError(
      'Không tìm thấy tên học sinh trong danh sách lớp! Quý phụ huynh vui lòng kiểm tra lại Họ và Tên của con hoặc chọn từ gợi ý.'
    );
  };

  const handleChangeActiveWeek = (weekNum: number) => {
    setActiveWeek(weekNum);
    try {
      localStorage.setItem(ACTIVE_WEEK_STORAGE_KEY, String(weekNum));
    } catch {
      // ignore
    }
  };

  const handleSaveWeeklyAssignment = (assignment: WeeklyAssignment) => {
    setWeeklyAssignments((prev) => {
      const exists = prev.some((w) => w.weekNumber === assignment.weekNumber);
      const next = exists
        ? prev.map((w) => (w.weekNumber === assignment.weekNumber ? assignment : w))
        : [...prev, assignment].sort((a, b) => a.weekNumber - b.weekNumber);
      saveWeeklyAssignments(next);
      return next;
    });
  };

  const handleTriggerWeekSync = () => {
    refreshGlobalStats();
    const currentAssign =
      weeklyAssignments.find((w) => w.weekNumber === activeWeek) || weeklyAssignments[0];
    setWeekSyncNotice(
      `🔄 Đã đồng bộ nhiệm vụ & tiến độ Tuần ${activeWeek} (${
        currentAssign.semesterLabel || 'HK1'
      }): ${currentAssign.title}`
    );
    setTimeout(() => setWeekSyncNotice(null), 3500);
  };

  const handleAuthenticateTeacher = (pin: string): boolean => {
    const cleaned = pin.trim();
    if (!cleaned) return false;
    let savedCustomPin = '';
    try {
      savedCustomPin = localStorage.getItem('khtn7_teacher_secret_pin_v2') || '';
    } catch {
      // ignore
    }
    const isMatch = savedCustomPin
      ? cleaned === savedCustomPin || cleaned === '0385379344'
      : cleaned === '0385379344';

    if (isMatch) {
      setIsTeacherAuthenticated(true);
      setRole('teacher');
      setPortalTab('teacher');
      setTeacherPinError('');
      setTeacherPinInput('');
      return true;
    }
    return false;
  };

  const handleLockTeacherArea = () => {
    setIsTeacherAuthenticated(false);
    setRole('student');
    setPortalTab('student');
    setTeacherPinInput('');
    setTeacherPinError('');
    if (activeNav === 'admin') {
      setActiveNav('home');
    }
    setWeekSyncNotice('🔒 Đã khóa Khu vực Giáo viên — Chuyển sang chế độ Học sinh an toàn.');
    setTimeout(() => setWeekSyncNotice(null), 3500);
  };

  const handleSaveAndSyncRoster = () => {
    // Use functional state access so we never overwrite localStorage with a stale closure!
    setStudents((latestStudents) => {
      try {
        localStorage.setItem(STUDENTS_STORAGE_KEY, JSON.stringify(latestStudents));
      } catch {
        // ignore
      }
      return latestStudents;
    });
    recordSyncTimestamp();
    refreshGlobalStats();
  };

  const handleRestoreOfficialStudents = () => {
    saveDeletedStudentNames(new Set());
    setStudents((prevStudents) => {
      const mergedMap = new Map<string, StudentProfile>();
      for (const defSt of DEFAULT_STUDENTS) {
        mergedMap.set(normalizeStudentNameNFC(defSt.fullName), defSt);
      }
      for (const st of prevStudents) {
        if (!st?.fullName) continue;
        const key = normalizeStudentNameNFC(st.fullName);
        if (!mergedMap.has(key)) {
          mergedMap.set(key, st);
        }
      }
      const nextList = Array.from(mergedMap.values());
      try {
        localStorage.setItem(STUDENTS_STORAGE_KEY, JSON.stringify(nextList));
      } catch {
        // ignore
      }
      return nextList;
    });
    recordSyncTimestamp();
  };

  const handleSaveWordDoc = (doc: SavedWordExamDoc) => {
    setSavedWordDocs((prev) => {
      const next = [doc, ...prev];
      saveWordDocsToStorage(next);
      return next;
    });
  };

  const handleDeleteWordDoc = (docId: string) => {
    setSavedWordDocs((prev) => {
      const next = prev.filter((d) => d.id !== docId);
      saveWordDocsToStorage(next);
      return next;
    });
  };

  const handleOpenLessonPractice = (lessonId: string) => {
    setPracticeLessonId(lessonId);
    setActiveNav('practice');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenLessonGames = (lessonId: string) => {
    setPracticeLessonId(lessonId);
    setActiveNav('games');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleMasteredTopic = (topicId: string) => {
    setMasteredTopicIds((prev) =>
      prev.includes(topicId) ? prev.filter((id) => id !== topicId) : [...prev, topicId]
    );
  };

  const activeWeekAssignment =
    weeklyAssignments.find((w) => w.weekNumber === activeWeek) || weeklyAssignments[0];
  const currentStudentMetrics = calculateStudentGradeMetrics(currentStudent);
  const currentStudentHomeworkGap = computeActiveStudentWeekHomeworkGap(
    currentStudent,
    activeWeekAssignment
  );

  const sidebarItems: {
    id: NavSectionId;
    label: string;
    badge?: string | number;
    icon: React.ReactNode;
  }[] = [
    { id: 'home', label: 'Trang chủ', icon: <Home className="w-4 h-4" /> },
    {
      id: 'lessons',
      label: 'Bài học & Mô phỏng',
      badge: '30 bài',
      icon: <BookOpen className="w-4 h-4" />,
    },
    {
      id: 'practice',
      label: 'Luyện tập',
      badge: `${LESSON_BANK_STATS.totalMcq} câu`,
      icon: <ClipboardCheck className="w-4 h-4" />,
    },
    {
      id: 'exam',
      label: 'Đề kiểm tra',
      icon: <Award className="w-4 h-4" />,
    },
    {
      id: 'games',
      label: 'Game & Flashcard',
      badge: '12 Game',
      icon: <Gamepad2 className="w-4 h-4" />,
    },
    {
      id: 'parent_portal',
      label: 'Khu vực Phụ huynh',
      badge: verifiedParentChild ? 'Đã mở' : 'Tra cứu',
      icon: <Users className="w-4 h-4" />,
    },
    {
      id: 'weekly_tracker',
      label: 'BTVN theo Tuần',
      badge: `Tuần ${activeWeek}`,
      icon: <BarChart3 className="w-4 h-4" />,
    },
    {
      id: 'wrong_answers',
      label: 'Ôn tập câu sai',
      badge: progressStats.wrongCount > 0 ? progressStats.wrongCount : undefined,
      icon: <RotateCcw className="w-4 h-4" />,
    },
    {
      id: 'word_download',
      label: 'Kho Đề Word & PDF',
      icon: <FileDown className="w-4 h-4" />,
    },
    {
      id: 'admin',
      label: 'Quản lý Giáo viên',
      badge: `${students.length} HS`,
      icon: <Settings className="w-4 h-4" />,
    },
  ];

  const filteredHomeLessons = ALL_KNTT_LESSONS.filter(
    (l) => homeSubjectFilter === 'all' || l.subject === homeSubjectFilter
  );

  // Check if current view requires Student Name Verification Gate
  const requiresVerificationGate =
    role === 'student' &&
    !isStudentVerified &&
    (activeNav === 'practice' || activeNav === 'exam' || activeNav === 'games');

  return (
    <div className="min-h-screen bg-[#f4f7fb] text-slate-900 flex flex-col font-sans">
      {/* ================= CLEAN MODERN TOP NAVIGATION BAR ================= */}
      <header className="sticky top-0 z-40 bg-[#081c38] text-white border-b border-slate-800/80 shadow-md">
        <div className="max-w-[1520px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* Zone 1: Mobile Menu Trigger + Brand Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl bg-white/10 text-slate-200 hover:text-white cursor-pointer"
              aria-label="Mở menu chức năng"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <button
              onClick={() => setActiveNav('home')}
              className="text-left group flex items-center gap-2.5 cursor-pointer whitespace-nowrap shrink-0"
            >
              <Khtn7BrandLogo className="w-9 h-9 rounded-xl shadow-sm border border-white/20 group-hover:scale-105 transition-transform" />
              <span className="text-base sm:text-lg font-black tracking-tight text-white">
                KHTN 7 MASTER
              </span>
            </button>
          </div>

          {/* Zone 2: Clean Single-Line Navigation Links */}
          <nav className="hidden xl:flex items-center gap-6 text-sm font-semibold text-slate-200">
            {[
              { id: 'home' as NavSectionId, label: 'Trang chủ' },
              { id: 'lessons' as NavSectionId, label: '30 Bài học' },
              { id: 'practice' as NavSectionId, label: 'Luyện tập' },
              { id: 'games' as NavSectionId, label: '12 Game' },
              { id: 'parent_portal' as NavSectionId, label: 'Phụ huynh' },
            ].map((item) => {
              const isActive = activeNav === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveNav(item.id)}
                  className={`relative py-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isActive
                      ? 'text-emerald-400 font-extrabold'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-400 rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Compact Week Selector + Primary Quick Action */}
          <div className="flex items-center gap-2.5 shrink-0">
            <div className="hidden sm:inline-flex items-center gap-1.5 bg-white/10 px-2.5 py-1.5 rounded-xl border border-white/15">
              <span className="text-[11px] font-extrabold text-emerald-300 whitespace-nowrap">
                Tuần:
              </span>
              <select
                value={activeWeek}
                onChange={(e) => handleChangeActiveWeek(Number(e.target.value))}
                className="bg-[#0d284e] text-white font-bold text-xs px-2 py-1 rounded-lg border border-white/15 focus:outline-none cursor-pointer"
              >
                <optgroup label="Học kì I (Tuần 1 – 18)">
                  {weeklyAssignments
                    .filter((w) => w.weekNumber <= 18)
                    .map((w) => (
                      <option key={w.weekNumber} value={w.weekNumber}>
                        Tuần {w.weekNumber} (HK1)
                      </option>
                    ))}
                </optgroup>
                <optgroup label="Học kì II (Tuần 19 – 35)">
                  {weeklyAssignments
                    .filter((w) => w.weekNumber >= 19)
                    .map((w) => (
                      <option key={w.weekNumber} value={w.weekNumber}>
                        Tuần {w.weekNumber} (HK2)
                      </option>
                    ))}
                </optgroup>
              </select>
            </div>

            <button
              onClick={() => setShowReminderModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-extrabold text-xs shadow-xs transition whitespace-nowrap shrink-0 cursor-pointer"
              title="Nhắc nhở hoàn thành Bài tập về nhà & Hẹn giờ học tập"
            >
              <Bell className="w-4 h-4 text-amber-200" />
              <span>
                {currentStudentHomeworkGap.isCompleted
                  ? 'Đã xong BTVN'
                  : `Nhắc BTVN (${currentStudentHomeworkGap.percent}%)`}
              </span>
            </button>

            <button
              onClick={() => setSprintCertModalTab('sprint')}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-xs shadow-xs transition whitespace-nowrap shrink-0 cursor-pointer"
              title="Thử thách 5 Phút Đầu Giờ & Chuỗi ngày học liên tiếp"
            >
              <Flame className="w-4 h-4 text-rose-600 fill-rose-600" />
              <span>{streakData.streakDays} ngày</span>
            </button>

            <button
              onClick={() => setShowStudentModal(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs shadow-xs transition whitespace-nowrap shrink-0 cursor-pointer"
              title="Xem Hồ sơ Điểm số & Nhận xét của Học sinh"
            >
              <Users className="w-4 h-4" />
              <span className="hidden md:inline">
                {isStudentVerified ? currentStudent.fullName : 'Hồ sơ HS'}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Global Week Sync Toast */}
      {weekSyncNotice && (
        <div className="bg-blue-600 text-white text-xs sm:text-sm font-extrabold py-2 px-4 text-center shadow-md flex items-center justify-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-amber-300 shrink-0" />
          <span>{weekSyncNotice}</span>
        </div>
      )}

      {/* ================= MAIN BODY: STREAMLINED SIDEBAR + WORKSPACE ================= */}
      <div className="flex-1 max-w-[1520px] w-full mx-auto flex relative">
        {/* Mobile Backdrop */}
        {mobileMenuOpen && (
          <div
            className="fixed inset-0 z-30 bg-slate-950/50 lg:hidden"
            onClick={() => setMobileMenuOpen(false)}
          />
        )}

        {/* LEFT SIDEBAR (CLEAN & COMPACT) */}
        <aside
          className={`${
            mobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
          } fixed lg:static top-16 left-0 z-30 w-64 bg-white border-r border-slate-200/80 min-h-[calc(100vh-4rem)] p-4 flex flex-col justify-between transition-transform duration-200 ease-in-out shrink-0`}
        >
          <div className="space-y-4">
            {/* Compact 3-Role Switcher (Học sinh | Phụ huynh | Giáo viên) */}
            <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-2.5 space-y-2">
              <div className="grid grid-cols-3 gap-1 bg-slate-200/70 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => {
                    setRole('student');
                    setPortalTab('student');
                  }}
                  className={`py-1.5 rounded-lg text-[11px] font-extrabold transition whitespace-nowrap cursor-pointer ${
                    portalTab === 'student'
                      ? 'bg-white text-[#0d6efd] shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🎓 Học sinh
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPortalTab('parent');
                    setActiveNav('parent_portal');
                    setMobileMenuOpen(false);
                  }}
                  className={`py-1.5 rounded-lg text-[11px] font-extrabold transition whitespace-nowrap cursor-pointer ${
                    portalTab === 'parent' || activeNav === 'parent_portal'
                      ? 'bg-white text-[#0d6efd] shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  👨‍👩‍👧 Phụ huynh
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (isTeacherAuthenticated) {
                      setRole('teacher');
                      setPortalTab('teacher');
                      setActiveNav('admin');
                    } else {
                      setPortalTab('teacher');
                      setActiveNav('home');
                    }
                    setMobileMenuOpen(false);
                  }}
                  className={`py-1.5 rounded-lg text-[11px] font-extrabold transition whitespace-nowrap cursor-pointer ${
                    portalTab === 'teacher'
                      ? 'bg-white text-[#0d6efd] shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  👩‍🏫 Giáo viên
                </button>
              </div>

              <div className="text-[11px] text-slate-600 px-1 flex items-center justify-between">
                {portalTab === 'teacher' && isTeacherAuthenticated ? (
                  <>
                    <span className="font-bold text-teal-800">👩‍🏫 Giáo viên quản lý</span>
                    <button
                      type="button"
                      onClick={handleLockTeacherArea}
                      className="font-extrabold text-rose-600 hover:underline cursor-pointer"
                    >
                      Khóa
                    </button>
                  </>
                ) : portalTab === 'parent' && verifiedParentChild ? (
                  <span className="font-bold text-indigo-700 truncate">
                    PH em: {verifiedParentChild.fullName}
                  </span>
                ) : isStudentVerified ? (
                  <span className="font-bold text-slate-800 truncate">
                    {currentStudent.fullName} ({currentStudent.className})
                  </span>
                ) : (
                  <span className="text-rose-600 font-semibold">Chưa xác thực tên HS</span>
                )}
              </div>
            </div>

            {/* Clean Navigation Menu */}
            <nav className="space-y-1">
              {sidebarItems.map((item) => {
                const isActive = activeNav === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      if (item.id === 'parent_portal') {
                        setPortalTab('parent');
                      }
                      setActiveNav(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                      isActive
                        ? 'bg-[#0d6efd] text-white shadow-sm'
                        : 'text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <span className="flex items-center gap-2.5 whitespace-nowrap">
                      {item.icon}
                      <span>{item.label}</span>
                    </span>
                    {item.badge !== undefined && (
                      <span
                        className={`text-[11px] font-bold ${
                          isActive
                            ? 'text-blue-100'
                            : item.id === 'wrong_answers'
                            ? 'text-rose-600'
                            : 'text-slate-400'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Compact Utility Footer in Sidebar */}
          <div className="mt-6 pt-3 border-t border-slate-200/80 space-y-2">
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => setShowHandbookModal(true)}
                className="px-2.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <Table2 className="w-3.5 h-3.5 text-amber-600" />
                <span>Bảng TH</span>
              </button>
              <button
                type="button"
                onClick={() => setClassroomModalTab('picker')}
                className="px-2.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <Award className="w-3.5 h-3.5 text-rose-500" />
                <span>Bảng Vàng</span>
              </button>
            </div>
            <PWAInstallButton
              variant="sidebar"
              onOpenInstallModal={() => setShowPWAInstallModal(true)}
            />
          </div>
        </aside>

        {/* ================= MAIN WORKSPACE AREA ================= */}
        <main className="flex-1 min-w-0 p-4 sm:p-6 space-y-6">
          {/* TOP RETURN TO HOME BAR FOR SUB-VIEWS */}
          {activeNav !== 'home' && (
            <div className="bg-white rounded-2xl border border-slate-200/80 px-4 py-2.5 shadow-xs flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs sm:text-sm font-bold text-slate-700">
                <button
                  type="button"
                  onClick={() => {
                    setActiveNav('home');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition cursor-pointer"
                >
                  <Home className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Trang chủ</span>
                </button>
                <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="font-extrabold text-slate-900">
                  {sidebarItems.find((item) => item.id === activeNav)?.label || 'Chức năng'}
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {activeNav !== 'practice' && (
                  <button
                    type="button"
                    onClick={() => setActiveNav('practice')}
                    className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition cursor-pointer"
                  >
                    Luyện tập
                  </button>
                )}
                {activeNav !== 'parent_portal' && (
                  <button
                    type="button"
                    onClick={() => {
                      setPortalTab('parent');
                      setActiveNav('parent_portal');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold transition cursor-pointer"
                  >
                    👨‍👩‍👧 Phụ huynh theo dõi
                  </button>
                )}
              </div>
            </div>
          )}

          {/* STRICT STUDENT NAME AUTHENTICATION GATE FOR PRACTICE / EXAM / GAMES */}
          {requiresVerificationGate ? (
            <div className="max-w-2xl mx-auto my-6 bg-white rounded-3xl border border-slate-200/90 shadow-xl overflow-hidden">
              <div className="bg-gradient-to-r from-[#071936] via-[#0a2748] to-[#063d3f] p-6 sm:p-7 text-white flex items-center justify-between gap-4">
                <div>
                  <div className="text-xs font-extrabold uppercase tracking-wider text-emerald-300">
                    KHOA HỌC TỰ NHIÊN 7 — KẾT NỐI TRI THỨC VỚI CUỘC SỐNG
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-black tracking-tight mt-1">
                    KHTN 7 MASTER
                  </h2>
                </div>
                <div className="p-1.5 rounded-2xl bg-white/10 border border-white/20 shrink-0">
                  <Khtn7BrandLogo className="w-14 h-14 rounded-xl" />
                </div>
              </div>

              <div className="p-6 sm:p-8 space-y-5">
                <form onSubmit={handleVerifyStudentByName} className="space-y-4">
                  <div>
                    <label className="block text-xs sm:text-sm font-black uppercase tracking-wide text-slate-800 mb-2">
                      HỌ VÀ TÊN HỌC SINH
                    </label>
                    <input
                      type="text"
                      value={studentNameInput}
                      onChange={(e) => setStudentNameInput(e.target.value)}
                      placeholder="Nhập đúng tên học sinh theo danh sách giáo viên đã nhập"
                      className="w-full px-4 py-3.5 rounded-2xl border-2 border-blue-400 text-sm sm:text-base font-semibold text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-500/15 transition"
                    />
                    <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                      Chỉ nhập đúng họ và tên học sinh theo danh sách giáo viên đã nhập (hệ thống bảo mật thông tin học sinh).
                    </p>
                  </div>

                  {loginError && (
                    <p className="text-xs sm:text-sm text-rose-600 font-extrabold bg-rose-50 border border-rose-200 px-3.5 py-2.5 rounded-xl">
                      {loginError}
                    </p>
                  )}

                  <button
                    type="submit"
                    className="w-full py-4 rounded-2xl bg-[#0d6efd] hover:bg-blue-700 text-white font-black text-base shadow-lg shadow-blue-600/25 transition cursor-pointer"
                  >
                    Xác nhận & Vào làm bài →
                  </button>
                </form>
              </div>
            </div>
          ) : (
            <>
              {/* 1. TRANG CHỦ GỌN ĐẸP HIỆN ĐẠI (3-TAB PORTAL CARD + BENTO QUICK ACCESS + 30 BÀI HỌC) */}
              {activeNav === 'home' && (
                <div className="space-y-6">
                  {/* TOP 2-COLUMN MODERN DASHBOARD HERO */}
                  <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-stretch">
                    {/* Left 6 Cols: 3-Tab Portal Card matching image_fe8941cb.png (🎓 Học sinh | 👨‍👩‍👧 Phụ huynh | 👩‍🏫 Giáo viên) */}
                    <div className="xl:col-span-6 bg-white text-slate-900 rounded-3xl overflow-hidden shadow-lg border border-slate-200/90 flex flex-col justify-between">
                      {/* Dark Navy-Teal Header Banner matching image_fe8941cb.png */}
                      <div className="bg-gradient-to-r from-[#071936] via-[#0a2748] to-[#063d3f] px-6 py-5 sm:py-6 text-white flex items-center justify-between gap-4">
                        <div>
                          <div className="text-[11px] sm:text-xs font-extrabold uppercase tracking-wider text-emerald-400">
                            KHOA HỌC TỰ NHIÊN 7 — KẾT NỐI TRI THỨC VỚI CUỘC SỐNG
                          </div>
                          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white mt-1">
                            KHTN 7 MASTER
                          </h1>
                        </div>

                        <button
                          type="button"
                          onClick={() => setShowPWAInstallModal(true)}
                          className="p-1.5 rounded-2xl bg-[#07182e]/90 border border-teal-400/30 shadow-md hover:scale-105 transition shrink-0 cursor-pointer"
                          title="Cài App KHTN 7 lên Màn hình chính điện thoại"
                        >
                          <Khtn7BrandLogo className="w-14 h-14 rounded-xl" />
                        </button>
                      </div>

                      {/* Portal Body: 3-Tab Segmented Switcher (🎓 Học sinh | 👨‍👩‍👧 Phụ huynh | 👩‍🏫 Giáo viên) */}
                      <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between space-y-5">
                        <div className="grid grid-cols-3 gap-1.5 bg-[#f1f4f9] p-1.5 rounded-2xl border border-slate-200/70">
                          <button
                            type="button"
                            onClick={() => {
                              setPortalTab('student');
                              setRole('student');
                              setLoginError('');
                            }}
                            className={`py-2.5 px-2 rounded-xl text-xs sm:text-sm font-extrabold transition flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer ${
                              portalTab === 'student'
                                ? 'bg-white text-[#0d6efd] shadow-sm'
                                : 'text-slate-700 hover:text-slate-900'
                            }`}
                          >
                            <span>🎓</span>
                            <span>Học sinh</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setPortalTab('parent');
                              setParentLoginError('');
                            }}
                            className={`py-2.5 px-2 rounded-xl text-xs sm:text-sm font-extrabold transition flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer ${
                              portalTab === 'parent'
                                ? 'bg-white text-[#0d6efd] shadow-sm'
                                : 'text-slate-700 hover:text-slate-900'
                            }`}
                          >
                            <span>👨‍👩‍👧</span>
                            <span>Phụ huynh</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setPortalTab('teacher');
                              setTeacherPinError('');
                            }}
                            className={`py-2.5 px-2 rounded-xl text-xs sm:text-sm font-extrabold transition flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer ${
                              portalTab === 'teacher'
                                ? 'bg-white text-[#0d6efd] shadow-sm'
                                : 'text-slate-700 hover:text-slate-900'
                            }`}
                          >
                            <span>👩‍🏫</span>
                            <span>Giáo viên</span>
                          </button>
                        </div>

                        {/* Shared datalist for autocomplete in Student & Parent login */}
                        <datalist id="khtn7-official-students-datalist">
                          {students.map((st) => (
                            <option key={st.id} value={st.fullName}>
                              {st.className} — {st.code}
                            </option>
                          ))}
                        </datalist>

                        {/* TAB 1: 🎓 HỌC SINH */}
                        {portalTab === 'student' && (
                          <div className="space-y-4">
                            <form onSubmit={handleVerifyStudentByName} className="space-y-3.5">
                              <div>
                                <label className="block text-xs sm:text-sm font-black uppercase tracking-wide text-slate-900 mb-2">
                                  HỌ VÀ TÊN HỌC SINH
                                </label>
                                <input
                                  type="text"
                                  list="khtn7-official-students-datalist"
                                  value={studentNameInput}
                                  onChange={(e) => {
                                    setStudentNameInput(e.target.value);
                                    if (loginError) setLoginError('');
                                  }}
                                  placeholder="Nhập đúng tên học sinh theo danh sách giáo viên đã nhập"
                                  className="w-full px-4 py-3.5 rounded-2xl border-2 border-blue-400 text-sm sm:text-base font-medium text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-500/15 transition"
                                />
                                {(() => {
                                  const suggestions = suggestStudentsByPartialName(
                                    students,
                                    studentNameInput,
                                    5
                                  );
                                  if (suggestions.length === 0) return null;
                                  return (
                                    <div className="mt-2 flex flex-wrap items-center gap-1.5">
                                      <span className="text-[11px] font-bold text-slate-500">
                                        Chạm chọn nhanh:
                                      </span>
                                      {suggestions.map((st) => (
                                        <button
                                          key={st.id}
                                          type="button"
                                          onClick={() => {
                                            handleSelectStudent(st);
                                            setActiveNav('practice');
                                          }}
                                          className="px-2.5 py-1 rounded-xl bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-900 text-xs font-extrabold transition cursor-pointer"
                                        >
                                          {st.fullName} ({st.className})
                                        </button>
                                      ))}
                                    </div>
                                  );
                                })()}
                                <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                                  Chỉ nhập đúng họ và tên học sinh theo danh sách giáo viên đã nhập (hỗ trợ cả có dấu, không dấu hoặc chạm chọn nhanh khi gõ).
                                </p>
                              </div>

                              {loginError && (
                                <p className="text-xs text-rose-600 font-extrabold bg-rose-50 border border-rose-200 px-3.5 py-2.5 rounded-xl">
                                  {loginError}
                                </p>
                              )}

                              <button
                                type="submit"
                                className="w-full py-3.5 rounded-2xl bg-[#0d6efd] hover:bg-blue-700 text-white font-black text-sm sm:text-base shadow-md shadow-blue-600/20 transition cursor-pointer"
                              >
                                Xác nhận & Vào làm bài →
                              </button>
                            </form>

                            {isStudentVerified && (
                              <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 flex flex-wrap items-center justify-between gap-2">
                                <div className="text-xs">
                                  <span className="font-bold text-slate-600">Đang làm bài: </span>
                                  <strong className="font-black text-slate-900">
                                    {currentStudent.fullName}
                                  </strong>{' '}
                                  <span className="text-teal-700 font-semibold">
                                    ({currentStudent.className} · ĐTB: {currentStudentMetrics.average.toFixed(2)})
                                  </span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <button
                                    type="button"
                                    onClick={() => setShowStudentModal(true)}
                                    className="text-xs font-extrabold text-blue-600 hover:underline cursor-pointer"
                                  >
                                    Xem điểm
                                  </button>
                                  <span className="text-slate-300">·</span>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setIsStudentVerified(false);
                                      setStudentNameInput('');
                                    }}
                                    className="text-xs font-bold text-rose-600 hover:underline cursor-pointer"
                                  >
                                    Đổi HS
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                        )}

                        {/* TAB 2: 👨‍👩‍👧 PHỤ HUYNH (TRA CỨU TÌNH HÌNH HỌC TẬP CỦA CON BẰNG TÊN TRONG LỚP) */}
                        {portalTab === 'parent' && (
                          <div className="space-y-4">
                            <form onSubmit={handleVerifyParentChildByName} className="space-y-3.5">
                              <div>
                                <label className="block text-xs sm:text-sm font-black uppercase tracking-wide text-slate-900 mb-2">
                                  HỌ VÀ TÊN CON (HỌC SINH TRONG LỚP)
                                </label>
                                <input
                                  type="text"
                                  list="khtn7-official-students-datalist"
                                  value={parentChildNameInput}
                                  onChange={(e) => {
                                    setParentChildNameInput(e.target.value);
                                    if (parentLoginError) setParentLoginError('');
                                  }}
                                  placeholder="Nhập đúng tên của con theo danh sách giáo viên đã nhập"
                                  className="w-full px-4 py-3.5 rounded-2xl border-2 border-blue-400 text-sm sm:text-base font-medium text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-500/15 transition"
                                />
                                {(() => {
                                  const suggestions = suggestStudentsByPartialName(
                                    students,
                                    parentChildNameInput,
                                    5
                                  );
                                  if (suggestions.length === 0) return null;
                                  return (
                                    <div className="mt-2 flex flex-wrap items-center gap-1.5">
                                      <span className="text-[11px] font-bold text-slate-500">
                                        Chạm chọn tên con:
                                      </span>
                                      {suggestions.map((st) => (
                                        <button
                                          key={st.id}
                                          type="button"
                                          onClick={() => {
                                            setVerifiedParentChild(st);
                                            setParentChildNameInput('');
                                            setParentLoginError('');
                                            setActiveNav('parent_portal');
                                            window.scrollTo({ top: 0, behavior: 'smooth' });
                                          }}
                                          className="px-2.5 py-1 rounded-xl bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-900 text-xs font-extrabold transition cursor-pointer"
                                        >
                                          {st.fullName} ({st.className})
                                        </button>
                                      ))}
                                    </div>
                                  );
                                })()}
                                <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                                  Phụ huynh nhập đúng họ và tên của con mình trong lớp học để theo dõi điểm số, biểu đồ tiến bộ, tình hình làm BTVN tuần và nhận xét của giáo viên.
                                </p>
                              </div>

                              {parentLoginError && (
                                <p className="text-xs text-rose-600 font-extrabold bg-rose-50 border border-rose-200 px-3.5 py-2.5 rounded-xl">
                                  {parentLoginError}
                                </p>
                              )}

                              <button
                                type="submit"
                                className="w-full py-3.5 rounded-2xl bg-[#0d6efd] hover:bg-blue-700 text-white font-black text-sm sm:text-base shadow-md shadow-blue-600/20 transition cursor-pointer"
                              >
                                Tra cứu Tình hình Học tập của Con →
                              </button>
                            </form>

                            {verifiedParentChild && (
                              <div className="rounded-2xl border border-indigo-200 bg-indigo-50/70 px-4 py-3 flex flex-wrap items-center justify-between gap-2">
                                <div className="text-xs">
                                  <span className="font-bold text-indigo-900">Đang xem hồ sơ con: </span>
                                  <strong className="font-black text-indigo-950">
                                    {verifiedParentChild.fullName}
                                  </strong>{' '}
                                  <span className="text-indigo-700 font-semibold">
                                    ({verifiedParentChild.className})
                                  </span>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => setActiveNav('parent_portal')}
                                  className="text-xs font-extrabold text-blue-600 hover:underline cursor-pointer"
                                >
                                  Mở Sổ liên lạc →
                                </button>
                              </div>
                            )}
                          </div>
                        )}

                        {/* TAB 3: 👩‍🏫 GIÁO VIÊN (CÓ MẬT KHẨU BẢO MẬT ẨN HOÀN TOÀN) */}
                        {portalTab === 'teacher' && (
                          <div className="space-y-3.5">
                            {!isTeacherAuthenticated ? (
                              <form
                                onSubmit={(e) => {
                                  e.preventDefault();
                                  const ok = handleAuthenticateTeacher(teacherPinInput);
                                  if (!ok) {
                                    setTeacherPinError(
                                      'Mật khẩu Giáo viên không chính xác! Vui lòng kiểm tra lại.'
                                    );
                                  }
                                }}
                                className="space-y-3.5"
                              >
                                <div>
                                  <label className="block text-xs sm:text-sm font-black uppercase tracking-wide text-slate-900 mb-2">
                                    MẬT KHẨU GIÁO VIÊN QUẢN LÝ & GIAO BÀI
                                  </label>
                                  <input
                                    type="password"
                                    value={teacherPinInput}
                                    onChange={(e) => setTeacherPinInput(e.target.value)}
                                    placeholder="Nhập mật khẩu bảo mật của giáo viên"
                                    className="w-full px-4 py-3.5 rounded-2xl border-2 border-blue-400 text-sm sm:text-base font-medium text-slate-900 focus:outline-none focus:border-blue-600 transition"
                                  />
                                  <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                                    Khu vực bảo mật dành riêng cho Giáo viên quản lý danh sách lớp (.xlsx), điểm số và đề kiểm tra Word.
                                  </p>
                                </div>

                                {teacherPinError && (
                                  <p className="text-xs text-rose-600 font-extrabold bg-rose-50 border border-rose-200 px-3.5 py-2.5 rounded-xl">
                                    {teacherPinError}
                                  </p>
                                )}

                                <button
                                  type="submit"
                                  className="w-full py-3.5 rounded-2xl bg-[#0d6efd] hover:bg-blue-700 text-white font-black text-sm sm:text-base shadow-md transition cursor-pointer"
                                >
                                  Mở khóa Khu vực Giáo viên →
                                </button>
                              </form>
                            ) : (
                              <div className="space-y-3">
                                <div className="p-3 rounded-2xl bg-teal-50 border border-teal-200 flex items-center justify-between gap-2">
                                  <div className="text-xs font-extrabold text-teal-950">
                                    ✅ Đã mở khóa Giáo viên ({students.length} HS · {savedWordDocs.length} Đề Word)
                                  </div>
                                  <button
                                    type="button"
                                    onClick={handleLockTeacherArea}
                                    className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-black cursor-pointer"
                                  >
                                    🔒 Khóa lại
                                  </button>
                                </div>

                                <div className="grid grid-cols-2 gap-2">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setRole('teacher');
                                      setActiveNav('admin');
                                    }}
                                    className="p-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-black flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                                  >
                                    <Upload className="w-4 h-4" />
                                    <span>Tải & Lưu DS (.XLSX)</span>
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => {
                                      handleSaveAndSyncRoster();
                                      setWeekSyncNotice(
                                        `🔄 Đã lưu & đồng bộ danh sách ${students.length} học sinh toàn hệ thống!`
                                      );
                                      setTimeout(() => setWeekSyncNotice(null), 3500);
                                    }}
                                    className="p-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                                  >
                                    <RefreshCw className="w-4 h-4" />
                                    <span>Đồng bộ Danh sách</span>
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => {
                                      setRole('teacher');
                                      setActiveNav('word_download');
                                    }}
                                    className="p-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                                  >
                                    <FileDown className="w-4 h-4" />
                                    <span>Tải & Lưu Đề Word</span>
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => {
                                      setRole('teacher');
                                      setActiveNav('weekly_tracker');
                                    }}
                                    className="p-3 rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-black flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                                  >
                                    <Plus className="w-4 h-4" />
                                    <span>Giao bài theo Tuần</span>
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Right 6 Cols: Streamlined Weekly Assignment & Bento Quick-Launch Grid */}
                    <div className="xl:col-span-6 bg-white rounded-3xl border border-slate-200/90 p-5 sm:p-6 shadow-sm flex flex-col justify-between space-y-5">
                      {/* Top Weekly Assignment Sync & Homework Reminder Strip */}
                      <div className="rounded-2xl bg-gradient-to-r from-[#071936] via-[#0a2748] to-[#063d3f] text-white p-4 sm:p-5 space-y-3">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div className="space-y-1">
                            <div className="text-[11px] font-bold text-emerald-300">
                              NHIỆM VỤ ĐANG ĐỒNG BỘ · TUẦN {activeWeek} ({activeWeekAssignment.semesterLabel || 'HK1'})
                            </div>
                            <h2 className="text-base sm:text-lg font-black text-white leading-snug">
                              {activeWeekAssignment.title}
                            </h2>
                            <p className="text-xs text-slate-300">
                              Hạn hoàn thành: <strong className="text-amber-300">{activeWeekAssignment.dueDate}</strong> · Tiến độ BTVN của {currentStudent.fullName}: <strong className="text-emerald-300">{currentStudentHomeworkGap.percent}%</strong>
                            </p>
                          </div>

                          <div className="flex flex-wrap items-center gap-2 shrink-0">
                            <button
                              type="button"
                              onClick={() => setShowReminderModal(true)}
                              className="px-3.5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center gap-1.5 whitespace-nowrap shadow transition cursor-pointer"
                            >
                              <Bell className="w-3.5 h-3.5" />
                              <span>Nhắc nhở BTVN</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                const firstLesson =
                                  activeWeekAssignment.lessonIds[0] || ALL_KNTT_LESSONS[0].id;
                                handleOpenLessonPractice(firstLesson);
                              }}
                              className="px-4 py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-black text-xs whitespace-nowrap shadow transition cursor-pointer"
                            >
                              Làm BTVN Tuần {activeWeek} →
                            </button>
                          </div>
                        </div>

                        {/* Smart Homework Reminder Callout Bar inside Weekly Card */}
                        {!currentStudentHomeworkGap.isCompleted ? (
                          <div className="rounded-xl bg-white/10 border border-amber-300/40 px-3.5 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
                            <span className="text-amber-200 font-semibold">
                              🔔 <strong>Nhắc nhở BTVN Tuần {activeWeek}:</strong> Còn thiếu{' '}
                              <strong>{currentStudentHomeworkGap.mcqMissing} câu TN</strong>,{' '}
                              <strong>{currentStudentHomeworkGap.tfMissing} bài Đ/S</strong> và{' '}
                              <strong>{currentStudentHomeworkGap.essayMissing} bài Tự luận</strong>{' '}
                              (Lịch nhắc tối: {reminderSchedule.timeOfDay}).
                            </span>
                            <button
                              type="button"
                              onClick={() => setShowReminderModal(true)}
                              className="text-emerald-300 hover:underline font-extrabold whitespace-nowrap cursor-pointer"
                            >
                              Hẹn giờ & Xem chi tiết →
                            </button>
                          </div>
                        ) : (
                          <div className="rounded-xl bg-emerald-500/20 border border-emerald-400/40 px-3.5 py-2 flex items-center justify-between gap-2 text-xs text-emerald-200 font-bold">
                            <span>
                              ✅ Tuyệt vời! {currentStudent.fullName} đã hoàn thành 100% Bài tập về nhà Tuần {activeWeek} đúng hạn!
                            </span>
                            <button
                              type="button"
                              onClick={() => setShowReminderModal(true)}
                              className="underline font-extrabold whitespace-nowrap cursor-pointer"
                            >
                              Cài đặt lịch nhắc
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Clean 6-Tile Bento Grid for Core App Features */}
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        <button
                          type="button"
                          onClick={() => setActiveNav('practice')}
                          className="p-3.5 rounded-2xl bg-slate-50 hover:bg-blue-50/70 border border-slate-200/90 hover:border-blue-300 text-left transition group cursor-pointer"
                        >
                          <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center mb-2 shadow-xs group-hover:scale-105 transition">
                            <ClipboardCheck className="w-5 h-5" />
                          </div>
                          <div className="text-xs sm:text-sm font-black text-slate-900">
                            Luyện tập 30 Bài
                          </div>
                          <div className="text-[11px] text-slate-500 mt-0.5">
                            TN · Đúng/Sai · Tự luận
                          </div>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setLessonTabMode('simulations');
                            setActiveNav('lessons');
                          }}
                          className="p-3.5 rounded-2xl bg-slate-50 hover:bg-teal-50/70 border border-slate-200/90 hover:border-teal-300 text-left transition group cursor-pointer"
                        >
                          <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center mb-2 shadow-xs group-hover:scale-105 transition">
                            <FlaskConical className="w-5 h-5" />
                          </div>
                          <div className="text-xs sm:text-sm font-black text-slate-900">
                            6 Phòng Thí nghiệm
                          </div>
                          <div className="text-[11px] text-slate-500 mt-0.5">
                            Mô phỏng Hóa · Lí · Sinh
                          </div>
                        </button>

                        <button
                          type="button"
                          onClick={() => setActiveNav('games')}
                          className="p-3.5 rounded-2xl bg-slate-50 hover:bg-amber-50/70 border border-slate-200/90 hover:border-amber-300 text-left transition group cursor-pointer"
                        >
                          <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center mb-2 shadow-xs group-hover:scale-105 transition">
                            <Gamepad2 className="w-5 h-5" />
                          </div>
                          <div className="text-xs sm:text-sm font-black text-slate-900">
                            12 Game Bài học
                          </div>
                          <div className="text-[11px] text-slate-500 mt-0.5">
                            Vừa học vừa chơi sôi nổi
                          </div>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setLessonTabMode('flashcards');
                            setActiveNav('lessons');
                          }}
                          className="p-3.5 rounded-2xl bg-slate-50 hover:bg-indigo-50/70 border border-slate-200/90 hover:border-indigo-300 text-left transition group cursor-pointer"
                        >
                          <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center mb-2 shadow-xs group-hover:scale-105 transition">
                            <BookOpen className="w-5 h-5" />
                          </div>
                          <div className="text-xs sm:text-sm font-black text-slate-900">
                            Thẻ Nhớ Flashcard
                          </div>
                          <div className="text-[11px] text-slate-500 mt-0.5">
                            Ôn nhanh công thức 30 bài
                          </div>
                        </button>

                        <button
                          type="button"
                          onClick={() => setSprintCertModalTab('sprint')}
                          className="p-3.5 rounded-2xl bg-slate-50 hover:bg-rose-50/70 border border-slate-200/90 hover:border-rose-300 text-left transition group cursor-pointer"
                        >
                          <div className="w-9 h-9 rounded-xl bg-rose-500 text-white flex items-center justify-center mb-2 shadow-xs group-hover:scale-105 transition">
                            <Flame className="w-5 h-5" />
                          </div>
                          <div className="text-xs sm:text-sm font-black text-slate-900">
                            Thử thách 5 Phút
                          </div>
                          <div className="text-[11px] text-slate-500 mt-0.5">
                            Chuỗi {streakData.streakDays} ngày · Xuất Giấy khen
                          </div>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setPortalTab('parent');
                            setActiveNav('parent_portal');
                          }}
                          className="p-3.5 rounded-2xl bg-slate-50 hover:bg-emerald-50/70 border border-slate-200/90 hover:border-emerald-300 text-left transition group cursor-pointer"
                        >
                          <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center mb-2 shadow-xs group-hover:scale-105 transition">
                            <Users className="w-5 h-5" />
                          </div>
                          <div className="text-xs sm:text-sm font-black text-slate-900">
                            Sổ Liên lạc Phụ huynh
                          </div>
                          <div className="text-[11px] text-slate-500 mt-0.5">
                            Theo dõi điểm & BTVN của con
                          </div>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* 30 LESSONS INTERACTIVE LAUNCHER ON HOME */}
                  <div className="bg-white rounded-3xl border border-slate-200/90 p-5 sm:p-6 shadow-xs space-y-5">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div>
                        <h2 className="text-lg sm:text-xl font-black text-slate-900">
                          Danh mục 30 Bài học KHTN 7 – Sách Kết nối tri thức với cuộc sống
                        </h2>
                        <p className="text-xs sm:text-sm text-slate-500">
                          Chọn phân môn để ôn luyện lý thuyết, làm bài tập trắc nghiệm, đúng/sai, tự luận và chơi 12 game tương tác.
                        </p>
                      </div>

                      {/* Subject Filter Tabs */}
                      <div className="flex flex-wrap gap-1.5 bg-slate-100 p-1.5 rounded-2xl">
                        {[
                          { id: 'all' as const, label: 'Tất cả (30 bài)' },
                          { id: 'chemistry' as const, label: '🧪 Hóa học (6)' },
                          { id: 'physics' as const, label: '⚡ Vật lí (14)' },
                          { id: 'biology' as const, label: '🌿 Sinh học (10)' },
                        ].map((tab) => (
                          <button
                            key={tab.id}
                            onClick={() => setHomeSubjectFilter(tab.id)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                              homeSubjectFilter === tab.id
                                ? 'bg-white text-slate-900 shadow-xs'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            {tab.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                      {filteredHomeLessons.map((lesson) => {
                        const isAssignedThisWeek = activeWeekAssignment.lessonIds.includes(
                          lesson.id
                        );
                        const badgeStyle =
                          lesson.subject === 'chemistry'
                            ? 'bg-amber-100 text-amber-800 border-amber-300'
                            : lesson.subject === 'physics'
                            ? 'bg-blue-100 text-blue-800 border-blue-300'
                            : 'bg-emerald-100 text-emerald-800 border-emerald-300';

                        const subjectLabel =
                          lesson.subject === 'chemistry'
                            ? 'HÓA HỌC 7'
                            : lesson.subject === 'physics'
                            ? 'VẬT LÍ 7'
                            : 'SINH HỌC 7';

                        return (
                          <div
                            key={lesson.id}
                            className={`rounded-2xl border p-4 transition-all shadow-xs hover:shadow-md flex flex-col justify-between gap-3 ${
                              isAssignedThisWeek
                                ? 'border-blue-500 bg-blue-50/30'
                                : 'border-slate-200 hover:border-teal-500 bg-slate-50/60 hover:bg-white'
                            }`}
                          >
                            <div className="space-y-2">
                              <div className="flex items-center justify-between gap-2">
                                <span
                                  className={`text-[10px] font-black px-2.5 py-0.5 rounded-md border ${badgeStyle}`}
                                >
                                  {subjectLabel} · {lesson.chapterTitle}
                                </span>
                                {isAssignedThisWeek ? (
                                  <span className="px-2 py-0.5 rounded-full bg-blue-600 text-white text-[10px] font-black">
                                    BTVN Tuần {activeWeek}
                                  </span>
                                ) : (
                                  <span className="text-[11px] font-bold text-slate-500">
                                    Bài {lesson.lessonNumber}
                                  </span>
                                )}
                              </div>

                              <h3 className="text-sm font-black text-slate-900 leading-snug">
                                {lesson.title}
                              </h3>

                              <p className="text-xs text-slate-600 line-clamp-2">
                                {lesson.summary}
                              </p>
                            </div>

                            <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between gap-2">
                              <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-bold text-slate-600">
                                <span className="px-2 py-0.5 rounded bg-indigo-50 text-indigo-700">
                                  {lesson.mcqs.length} TN
                                </span>
                                <span className="px-2 py-0.5 rounded bg-teal-50 text-teal-700">
                                  {lesson.trueFalseList.length} Đ/S
                                </span>
                                <span className="px-2 py-0.5 rounded bg-amber-50 text-amber-800">
                                  {lesson.essays.length} Tự luận
                                </span>
                              </div>

                              <div className="flex items-center gap-1.5 shrink-0">
                                <button
                                  onClick={() => handleOpenLessonGames(lesson.id)}
                                  className="px-2.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black transition cursor-pointer"
                                  title="Chơi 12 Game ôn luyện bài này"
                                >
                                  🎮 12 Game
                                </button>
                                <button
                                  onClick={() => handleOpenLessonPractice(lesson.id)}
                                  className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-extrabold transition cursor-pointer"
                                >
                                  Luyện tập →
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* 2. BÀI HỌC (30 BÀI HỌC KNTT + SƠ ĐỒ LÝ THUYẾT + MÔ PHỎNG) */}
              {activeNav === 'lessons' && (
                <div className="space-y-6">
                  <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h2 className="text-lg sm:text-xl font-black text-slate-900">
                        Không gian Bài học & Mô phỏng KHTN 7 (30 Bài SGK KNTT)
                      </h2>
                      <p className="text-xs sm:text-sm text-slate-600">
                        Xem tóm tắt trọng tâm từng bài học, sơ đồ tư duy và phòng thí nghiệm ảo
                        tương tác.
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {[
                        { id: 'catalog' as const, label: '📚 Danh sách 30 Bài học' },
                        { id: 'flashcards' as const, label: '🃏 Thẻ Flashcard (30 bài)' },
                        { id: 'theory' as const, label: '🧠 Sơ đồ & Lý thuyết' },
                        { id: 'simulations' as const, label: '🔬 6 Phòng Thí Nghiệm Ảo (Hóa–Lí–Sinh)' },
                      ].map((t) => (
                        <button
                          key={t.id}
                          onClick={() => setLessonTabMode(t.id)}
                          className={`px-3.5 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                            lessonTabMode === t.id
                              ? 'bg-teal-600 text-white shadow'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                          }`}
                        >
                          {t.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {lessonTabMode === 'catalog' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {ALL_KNTT_LESSONS.map((lesson) => (
                        <div
                          key={lesson.id}
                          className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3 flex flex-col justify-between"
                        >
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-black uppercase text-teal-700">
                                {lesson.chapterTitle}
                              </span>
                              <span className="text-xs font-bold text-slate-500">
                                {lesson.mcqs.length} TN · {lesson.trueFalseList.length} Đ/S ·{' '}
                                {lesson.essays.length} TL
                              </span>
                            </div>
                            <h3 className="text-base font-black text-slate-900">{lesson.title}</h3>
                            <p className="text-xs sm:text-sm text-slate-600">{lesson.summary}</p>
                            <ul className="space-y-1 pt-1">
                              {lesson.keyFormulas.slice(0, 3).map((pt: string, idx: number) => (
                                <li
                                  key={idx}
                                  className="text-xs text-slate-700 flex items-start gap-2"
                                >
                                  <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                                  <span>{pt}</span>
                                </li>
                              ))}
                            </ul>
                          </div>

                          <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                            <div className="flex flex-wrap items-center gap-2">
                              <button
                                onClick={() => handleOpenLessonPractice(lesson.id)}
                                className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold transition cursor-pointer"
                              >
                                Làm bài tập Bài {lesson.lessonNumber}
                              </button>
                              <button
                                onClick={() => handleOpenLessonGames(lesson.id)}
                                className="px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black transition cursor-pointer"
                              >
                                🎮 12 Game Bài {lesson.lessonNumber}
                              </button>
                              <button
                                onClick={() => {
                                  setPracticeLessonId(lesson.id);
                                  setLessonTabMode('flashcards');
                                }}
                                className="px-3 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-extrabold transition cursor-pointer"
                              >
                                🃏 Flashcard
                              </button>
                            </div>
                            <button
                              onClick={() => setLessonTabMode('simulations')}
                              className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition cursor-pointer"
                            >
                              Xem mô phỏng
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {lessonTabMode === 'flashcards' && (
                    <FlashcardsView
                      initialLessonId={practiceLessonId}
                      onStartLessonPractice={(lessonId) => handleOpenLessonPractice(lessonId)}
                    />
                  )}

                  {lessonTabMode === 'theory' && (
                    <TheoryView
                      masteredTopicIds={masteredTopicIds}
                      onToggleMastered={handleToggleMasteredTopic}
                    />
                  )}
                  {lessonTabMode === 'simulations' && <SimulationsView />}
                </div>
              )}

              {/* 3. LUYỆN TẬP (30 BÀI KHTN 7 KNTT: TRẮC NGHIỆM, ĐÚNG-SAI, TỰ LUẬN CÓ ĐÍNH ẢNH) */}
              {activeNav === 'practice' && (
                <PracticeView
                  initialLessonId={practiceLessonId}
                  onBackToHome={() => {
                    setActiveNav('home');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onProgressUpdate={(stats) => {
                    setProgressStats((prev) => ({
                      ...prev,
                      ...stats,
                    }));
                    refreshGlobalStats();
                  }}
                />
              )}

              {/* 4. ĐỀ KIỂM TRA ĐỊNH KÌ (GK1, HK1, GK2, HK2 + TẢI ĐỀ RIÊNG CỦA GV) */}
              {activeNav === 'exam' && (
                <ExamView
                  bestExamScore={bestExamScore}
                  isTeacherAuthenticated={isTeacherAuthenticated}
                  onAuthenticateTeacher={handleAuthenticateTeacher}
                  onBackToHome={() => {
                    setActiveNav('home');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onSaveBestScore={(score) => {
                    setBestExamScore((prev) => (prev === null || score > prev ? score : prev));
                  }}
                />
              )}

              {/* 5. GAME BÀI HỌC (12 GAME THEO TỪNG BÀI) */}
              {activeNav === 'games' && (
                <GamesView
                  initialLessonId={practiceLessonId}
                  highScore={gameHighScore}
                  onUpdateHighScore={(score) => {
                    setGameHighScore((prev) => (score > prev ? score : prev));
                  }}
                />
              )}

              {/* 5.5 KHU VỰC PHỤ HUYNH (TRA CỨU KẾT QUẢ HỌC TẬP CỦA CON BẰNG TÊN TRONG LỚP) */}
              {activeNav === 'parent_portal' && (
                <ParentPortalView
                  students={students}
                  verifiedChild={verifiedParentChild}
                  activeWeek={activeWeek}
                  weeklyAssignments={weeklyAssignments}
                  onVerifyChild={(child) => setVerifiedParentChild(child)}
                  onClearVerifiedChild={() => setVerifiedParentChild(null)}
                  onOpenDetailModal={(child) => {
                    setCurrentStudent(child);
                    setShowStudentModal(true);
                  }}
                  onOpenCertificate={(child) => {
                    setCurrentStudent(child);
                    setSprintCertModalTab('certificate');
                  }}
                />
              )}

              {/* 6. THƯ VIỆN TÀI LIỆU PDF & 9. TẢI TÀI LIỆU WORD */}
              {(activeNav === 'library' || activeNav === 'word_download') && (
                <LibraryAndWordView
                  userRole={isTeacherAuthenticated ? role : 'student'}
                  isTeacherAuthenticated={isTeacherAuthenticated}
                  activeWeek={activeWeek}
                  savedWordDocs={savedWordDocs}
                  onSaveWordDoc={handleSaveWordDoc}
                  onDeleteWordDoc={handleDeleteWordDoc}
                  onOpenLessonPractice={(lessonId) => handleOpenLessonPractice(lessonId)}
                />
              )}

              {/* 7. ÔN TẬP CÂU SAI */}
              {activeNav === 'wrong_answers' && (
                <WrongAnswersView
                  onGoToLesson={(lessonId) => handleOpenLessonPractice(lessonId)}
                />
              )}

              {/* 8. THEO DÕI BTVN TUẦN & GIAO NHIỆM VỤ TUẦN MỚI */}
              {activeNav === 'weekly_tracker' && (
                <WeeklyTrackerView
                  userRole={isTeacherAuthenticated ? role : 'student'}
                  currentStudent={currentStudent}
                  students={students}
                  weeklyAssignments={weeklyAssignments}
                  activeWeek={activeWeek}
                  onChangeActiveWeek={handleChangeActiveWeek}
                  onSaveWeeklyAssignment={handleSaveWeeklyAssignment}
                  onUpdateStudent={handleUpdateSingleStudent}
                  onStartLessonPractice={(lessonId) => handleOpenLessonPractice(lessonId)}
                />
              )}

              {/* 10. QUẢN TRỊ & LỚP (TẢI DANH SÁCH HỌC SINH .XLSX & TẢI/LƯU ĐỀ WORD) */}
              {activeNav === 'admin' && (
                <ClassAdminView
                  userRole={isTeacherAuthenticated ? role : 'student'}
                  isTeacherAuthenticated={isTeacherAuthenticated}
                  onAuthenticateTeacher={handleAuthenticateTeacher}
                  onLockTeacherArea={handleLockTeacherArea}
                  onChangeRole={(nextRole) => {
                    if (nextRole === 'teacher' && !isTeacherAuthenticated) return;
                    setRole(nextRole);
                  }}
                  students={students}
                  currentStudent={currentStudent}
                  activeWeek={activeWeek}
                  savedWordDocs={savedWordDocs}
                  onSaveWordDoc={handleSaveWordDoc}
                  onDeleteWordDoc={handleDeleteWordDoc}
                  onSelectStudent={handleSelectStudent}
                  onAddStudent={handleAddStudent}
                  onBulkImportStudents={handleBulkImportStudents}
                  onSaveAndSyncRoster={handleSaveAndSyncRoster}
                  onRestoreOfficialStudents={handleRestoreOfficialStudents}
                  lastSyncedRosterAt={lastSyncedRosterAt}
                  onUpdateStudent={handleUpdateSingleStudent}
                  onDeleteStudent={handleDeleteStudent}
                  onResetCurrentStudentProgress={handleResetCurrentStudentProgress}
                />
              )}
            </>
          )}

          {/* BOTTOM RETURN TO HOME BAR AFTER EVERY FUNCTIONAL MODULE */}
          {activeNav !== 'home' && (
            <div className="bg-gradient-to-r from-[#081e26] via-[#0b2e38] to-[#081e26] text-white rounded-2xl p-4 sm:p-5 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3 border border-teal-800/80">
              <div className="space-y-0.5">
                <div className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-300">
                  ĐIỀU HƯỚNG NHANH SAU KHI HOÀN THÀNH CHỨC NĂNG
                </div>
                <p className="text-xs sm:text-sm text-slate-200 font-semibold">
                  Bạn đang ở mục{' '}
                  <strong className="text-amber-300">
                    {sidebarItems.find((item) => item.id === activeNav)?.label}
                  </strong>
                  . Bấm nút bên cạnh để quay về Trang chủ hoặc chuyển nhanh sang mục khác.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                <button
                  type="button"
                  onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                  className="px-3.5 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-extrabold transition cursor-pointer"
                >
                  ⬆️ Lên đầu trang
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveNav('home');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-sm transition cursor-pointer"
                >
                  <Home className="w-4 h-4" />
                  <span>Quay về Trang chủ</span>
                </button>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* ================= SỔ TAY & BẢNG TUẦN HOÀN MODAL ================= */}
      {showHandbookModal && (
        <PeriodicTableModal onClose={() => setShowHandbookModal(false)} />
      )}

      {/* ================= 4-TAB STUDENT PROFILE MODAL (IMAGE 2) ================= */}
      {showStudentModal && (
        <StudentProfileModal
          student={currentStudent}
          isCurrentActiveStudent={true}
          userRole={isTeacherAuthenticated ? role : 'student'}
          activeWeek={activeWeek}
          onClose={() => setShowStudentModal(false)}
          onUpdateStudent={handleUpdateSingleStudent}
        />
      )}

      {/* ================= CLASSROOM PICKER, LEADERBOARD & SCIENCE TREE MODAL ================= */}
      {classroomModalTab !== null && (
        <ClassroomToolsModal
          initialTab={classroomModalTab}
          students={students}
          currentStudent={currentStudent}
          activeWeek={activeWeek}
          activeWeekAssignment={activeWeekAssignment}
          onUpdateStudent={handleUpdateSingleStudent}
          onClose={() => setClassroomModalTab(null)}
        />
      )}

      {/* ================= DAILY 5-MIN SPRINT, STREAK & CERTIFICATE GENERATOR MODAL ================= */}
      {sprintCertModalTab !== null && (
        <DailySprintAndCertificateModal
          initialTab={sprintCertModalTab}
          student={currentStudent}
          activeWeek={activeWeek}
          activeWeekAssignment={activeWeekAssignment}
          streakData={streakData}
          onUpdateStreak={(next) => setStreakData(next)}
          onUpdateStudent={handleUpdateSingleStudent}
          onClose={() => setSprintCertModalTab(null)}
        />
      )}

      {/* ================= HOMEWORK REMINDER MODAL ================= */}
      {showReminderModal && (
        <HomeworkReminderModal
          currentStudent={currentStudent}
          students={students}
          activeWeek={activeWeek}
          activeWeekAssignment={activeWeekAssignment}
          isTeacherAuthenticated={isTeacherAuthenticated}
          reminderSchedule={reminderSchedule}
          reminderLogs={reminderLogs}
          onUpdateSchedule={(next) => setReminderSchedule(next)}
          onUpdateReminderLogs={(next) => setReminderLogs(next)}
          onStartHomeworkNow={(lessonId) => handleOpenLessonPractice(lessonId)}
          onClose={() => setShowReminderModal(false)}
        />
      )}

      {/* ================= PWA INSTALL & KHTN 7 LOGO SHOWCASE MODAL ================= */}
      {showPWAInstallModal && (
        <PWAInstallModal onClose={() => setShowPWAInstallModal(false)} />
      )}

      {/* ================= OFFLINE STATUS INDICATOR ================= */}
      <OfflineIndicator />

      {/* ================= UX/UI ANALYSIS MODAL ================= */}
      {showUxAnalysisModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[85vh] overflow-y-auto p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div>
                <span className="text-xs font-extrabold uppercase tracking-wider text-teal-600">
                  BÁO CÁO PHÂN TÍCH UX/UI & KIẾN TRÚC HỆ THỐNG
                </span>
                <h3 className="text-xl font-black text-slate-900">
                  Phân tích Giao diện mẫu & Áp dụng cho KHTN 7 – Sách KNTT
                </h3>
              </div>
              <button
                onClick={() => setShowUxAnalysisModal(false)}
                className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-sm text-slate-700 leading-relaxed">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <h4 className="font-black text-slate-900">
                  1. Khu vực Giáo viên & Học sinh + Giao nhiệm vụ theo Tuần
                </h4>
                <ul className="list-disc pl-5 space-y-1 text-xs sm:text-sm">
                  <li>
                    <strong>Thiết lập nhiệm vụ học tập tuần mới:</strong> Giáo viên chọn Tuần học,
                    Tiêu đề nhiệm vụ, Hạn hoàn thành và tích chọn các bài học KHTN 7 KNTT cần hoàn
                    thành trong tuần.
                  </li>
                  <li>
                    <strong>Thanh chọn Tuần & Nút Cập Nhật đồng bộ:</strong> Cho phép chuyển nhanh
                    giữa các tuần (Tuần 1 HK1 → Tuần 10 HK2) và đồng bộ ngay lập tức nhiệm vụ sang
                    màn hình Học sinh.
                  </li>
                </ul>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <h4 className="font-black text-slate-900">
                  2. Hồ sơ Học tập 4 Tab, Biểu đồ Điểm & Nhận xét Tiến bộ
                </h4>
                <ul className="list-disc pl-5 space-y-1 text-xs sm:text-sm">
                  <li>
                    <strong>Điểm số & Biểu đồ:</strong> Hiển thị Điểm trung bình, Điểm cao nhất/thấp
                    nhất, Số cột điểm (TX1–TX5, ĐGGK, ĐGCK), Xu hướng tiến bộ, Cảnh báo học tập khi
                    ĐTB &lt; 5.0 và Biểu đồ đường tiến trình thay đổi điểm theo thời gian.
                  </li>
                  <li>
                    <strong>Tải danh sách học sinh & Xác thực tên vào lớp:</strong> Hỗ trợ tải file
                    CSV/TXT hoặc dán từ Excel; học sinh phải đăng nhập đúng Họ và Tên trong danh
                    sách lớp mới được vào Luyện tập.
                  </li>
                </ul>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setShowUxAnalysisModal(false)}
                className="px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-extrabold text-sm cursor-pointer"
              >
                Đóng cửa sổ
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
