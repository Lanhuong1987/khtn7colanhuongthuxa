import React, { useState, useRef } from 'react';
import {
  FileText,
  Download,
  Eye,
  BookOpen,
  FileDown,
  CheckCircle2,
  Upload,
  Save,
  Trash2,
  ClipboardCheck,
} from 'lucide-react';
import mammoth from 'mammoth';
import { ALL_KNTT_LESSONS, KNTT_PDF_DOCUMENTS } from '../data/allLessons';
import { KhtnLesson } from '../data/lessonTypes';
import { SavedWordExamDoc } from '../data/classStore';
import { parseMcqsFromWordText } from './ClassAdminView';

interface LibraryAndWordViewProps {
  userRole?: 'student' | 'teacher';
  isTeacherAuthenticated?: boolean;
  activeWeek?: number;
  savedWordDocs: SavedWordExamDoc[];
  onSaveWordDoc: (doc: SavedWordExamDoc) => void;
  onDeleteWordDoc: (docId: string) => void;
  onOpenLessonPractice: (lessonId: string) => void;
}

export const LibraryAndWordView: React.FC<LibraryAndWordViewProps> = ({
  userRole = 'student',
  isTeacherAuthenticated = false,
  activeWeek = 6,
  savedWordDocs,
  onSaveWordDoc,
  onDeleteWordDoc,
  onOpenLessonPractice,
}) => {
  const [selectedPdfUrl, setSelectedPdfUrl] = useState<string>(
    KNTT_PDF_DOCUMENTS[0].url
  );
  const [includeAnswersInWord, setIncludeAnswersInWord] = useState<boolean>(true);
  const [downloadedId, setDownloadedId] = useState<string | null>(null);

  // Word Upload & Save states
  const [wordTitle, setWordTitle] = useState('');
  const [wordDocType, setWordDocType] = useState<'exam' | 'worksheet' | 'material'>('exam');
  const [wordSubject, setWordSubject] = useState<
    'Liên môn KHTN 7' | 'Hóa học 7' | 'Vật lí 7' | 'Sinh học 7'
  >('Liên môn KHTN 7');
  const [wordWeek, setWordWeek] = useState<number>(activeWeek);
  const [uploadedFileName, setUploadedFileName] = useState('');
  const [uploadedHtml, setUploadedHtml] = useState('');
  const [uploadedRawText, setUploadedRawText] = useState('');
  const [uploadedDataUrl, setUploadedDataUrl] = useState<string | undefined>(undefined);
  const [uploadNotice, setUploadNotice] = useState<string | null>(null);
  const [activePreviewWordDoc, setActivePreviewWordDoc] = useState<SavedWordExamDoc | null>(
    savedWordDocs[0] || null
  );
  // Interactive quiz state for saved Word exam MCQs
  const [wordQuizAnswers, setWordQuizAnswers] = useState<Record<string, number>>({});
  const [wordQuizSubmitted, setWordQuizSubmitted] = useState<boolean>(false);

  const wordFileInputRef = useRef<HTMLInputElement | null>(null);

  const handleUploadWordFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    setUploadedFileName(file.name);
    if (!wordTitle.trim()) {
      setWordTitle(file.name.replace(/\.(docx|doc)$/i, '').replace(/[_-]+/g, ' '));
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setUploadedDataUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);

    try {
      if (ext === 'docx') {
        const arrayBuffer = await file.arrayBuffer();
        const htmlRes = await mammoth.convertToHtml({ arrayBuffer });
        const textRes = await mammoth.extractRawText({ arrayBuffer });
        setUploadedHtml(htmlRes.value || `<p>${textRes.value.replace(/\n/g, '<br/>')}</p>`);
        setUploadedRawText(textRes.value || '');
      } else {
        const text = await file.text();
        setUploadedRawText(text.replace(/<[^>]+>/g, ' '));
        setUploadedHtml(
          text.includes('<html') || text.includes('<p')
            ? text
            : `<div style="white-space: pre-wrap">${text}</div>`
        );
      }
      setUploadNotice(
        `📄 Đã chọn file Word "${file.name}". Hãy bấm nút "💾 Lưu Đề / Tài liệu Word" bên dưới để lưu!`
      );
    } catch {
      setUploadNotice(`📄 Đã chọn file "${file.name}". Bấm "💾 Lưu Đề / Tài liệu Word" để lưu!`);
    }
    e.target.value = '';
  };

  const handleSaveWordDocSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!wordTitle.trim() && !uploadedFileName) {
      setUploadNotice('Vui lòng chọn file Word (.docx / .doc) hoặc nhập tên đề trước khi lưu!');
      return;
    }

    const parsedMcqs = parseMcqsFromWordText(uploadedRawText);
    const nowStr = new Date().toLocaleString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });

    const newDoc: SavedWordExamDoc = {
      id: `word-doc-${Date.now()}`,
      title: wordTitle.trim() || uploadedFileName || 'Đề kiểm tra KHTN 7',
      fileName: uploadedFileName || 'De_Kiem_Tra_KHTN7.docx',
      docType: wordDocType,
      subjectLabel: wordSubject,
      weekNumber: wordWeek,
      createdAt: nowStr,
      htmlPreview:
        uploadedHtml ||
        `<p><strong>${wordTitle}</strong> — Tài liệu / Đề kiểm tra Word đã được lưu lên hệ thống.</p>`,
      rawText: uploadedRawText || wordTitle,
      fileDataUrl: uploadedDataUrl,
      parsedMcqs,
    };

    onSaveWordDoc(newDoc);
    setActivePreviewWordDoc(newDoc);
    setWordQuizAnswers({});
    setWordQuizSubmitted(false);
    setWordTitle('');
    setUploadedFileName('');
    setUploadedHtml('');
    setUploadedRawText('');
    setUploadedDataUrl(undefined);
    setUploadNotice(`💾 Đã lưu "${newDoc.title}" vào Kho Đề & Tài liệu Word thành công!`);
    setTimeout(() => setUploadNotice(null), 4000);
  };

  // Generate a Word-compatible .doc file for any KhtnLesson
  const handleDownloadWordWorksheet = (lesson: KhtnLesson) => {
    const htmlContent = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <meta charset="utf-8">
        <title>${lesson.title} - KHTN 7 KNTT</title>
        <style>
          body { font-family: 'Times New Roman', serif; font-size: 13pt; line-height: 1.5; color: #111827; }
          h1 { font-size: 16pt; text-transform: uppercase; color: #0f172a; margin-bottom: 4pt; }
          h2 { font-size: 14pt; color: #047857; margin-top: 14pt; margin-bottom: 6pt; border-bottom: 1px solid #cbd5e1; padding-bottom: 3pt; }
          .meta { font-size: 11pt; color: #475569; margin-bottom: 12pt; }
          .box { background: #f8fafc; border: 1px solid #cbd5e1; padding: 10pt; margin-bottom: 12pt; }
          .q { margin-top: 8pt; margin-bottom: 4pt; font-weight: bold; }
          .opt { margin-left: 16pt; }
          .ans { color: #0369a1; font-style: italic; margin-left: 16pt; margin-top: 3pt; }
          table { width: 100%; border-collapse: collapse; margin-top: 6pt; margin-bottom: 10pt; }
          th, td { border: 1px solid #94a3b8; padding: 6pt; text-align: left; }
          th { background: #f1f5f9; }
        </style>
      </head>
      <body>
        <h1>PHIẾU BÀI TẬP KHOA HỌC TỰ NHIÊN 7 (KNTT) — ${lesson.title.toUpperCase()}</h1>
        <div class="meta">Chương: ${lesson.chapterTitle} | Cấu trúc: ${lesson.mcqs.length} câu Trắc nghiệm · ${lesson.trueFalseList.length} bài Đúng–Sai · ${lesson.essays.length} bài Tự luận</div>
        <div class="box">
          <strong>I. TÓM TẮT LÝ THUYẾT &amp; CÔNG THỨC TRỌNG TÂM:</strong><br/>
          ${lesson.summary}<br/>
          ${lesson.keyFormulas.map((f) => `• ${f}`).join('<br/>')}
        </div>

        <h2>PHẦN I. TRẮC NGHIỆM 4 LỰA CHỌN (${lesson.mcqs.length} CÂU)</h2>
        ${lesson.mcqs
          .map(
            (q, idx) => `
          <div class="q">Câu ${idx + 1}: ${q.question}</div>
          <div class="opt">A. ${q.options[0]} &nbsp;&nbsp;&nbsp;&nbsp; B. ${q.options[1]}</div>
          <div class="opt">C. ${q.options[2]} &nbsp;&nbsp;&nbsp;&nbsp; D. ${q.options[3]}</div>
          ${
            includeAnswersInWord
              ? `<div class="ans">→ Đáp án đúng: ${['A', 'B', 'C', 'D'][q.correctIndex]}. Giải thích: ${q.explanation}</div>`
              : ''
          }
        `
          )
          .join('')}

        <h2>PHẦN II. BÀI TẬP TRẮC NGHIỆM ĐÚNG – SAI (${lesson.trueFalseList.length} BÀI)</h2>
        ${lesson.trueFalseList
          .map(
            (tf, idx) => `
          <div class="q">Bài Đúng–Sai ${idx + 1}: ${tf.stem}</div>
          <table>
            <thead>
              <tr>
                <th>Phát biểu</th>
                <th>Chọn Đúng / Sai</th>
                ${includeAnswersInWord ? '<th>Đáp án &amp; Giải thích</th>' : ''}
              </tr>
            </thead>
            <tbody>
              ${tf.statements
                .map(
                  (st) => `
                <tr>
                  <td><strong>${st.id})</strong> ${st.text}</td>
                  <td>[ &nbsp; ] Đúng &nbsp;&nbsp; [ &nbsp; ] Sai</td>
                  ${
                    includeAnswersInWord
                      ? `<td><strong>${st.isTrue ? 'ĐÚNG' : 'SAI'}</strong> — ${st.explanation}</td>`
                      : ''
                  }
                </tr>
              `
                )
                .join('')}
            </tbody>
          </table>
        `
          )
          .join('')}

        <h2>PHẦN III. BÀI TẬP TỰ LUẬN (${lesson.essays.length} BÀI)</h2>
        ${lesson.essays
          .map(
            (es, idx) => `
          <div class="q">Bài tự luận ${idx + 1}: ${es.question}</div>
          ${es.hint ? `<div class="opt"><em>Gợi ý: ${es.hint}</em></div>` : ''}
          ${
            includeAnswersInWord
              ? `<div class="ans"><strong>Hướng dẫn giải chi tiết:</strong><br/>${es.sampleAnswer.replace(/\n/g, '<br/>')}</div>`
              : '<div class="box" style="height: 80pt;">Bài làm của học sinh: ................................................................................................</div>'
          }
        `
          )
          .join('')}
      </body>
      </html>
    `;

    const blob = new Blob(['\ufeff', htmlContent], {
      type: 'application/msword;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Phieu_Bai_Tap_Bai_${lesson.lessonNumber}_KHTN7_KNTT.doc`;
    a.click();
    URL.revokeObjectURL(url);

    setDownloadedId(lesson.id);
    setTimeout(() => setDownloadedId(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#0d2238] via-[#0e2d40] to-[#083a38] rounded-2xl p-6 text-white shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-mono uppercase tracking-wider text-emerald-300 font-bold">
              THƯ VIỆN HỌC LIỆU SỐ · TẢI LÊN &amp; LƯU ĐỀ WORD (.DOCX / .DOC) · 6 PDF CHUYÊN ĐỀ
            </span>
            <h2 className="text-2xl font-extrabold mt-1">
              Tải Đề / Tài liệu Word lên &amp; Lưu Đề · Thư viện PDF KHTN 7
            </h2>
            <p className="text-sm text-slate-200 mt-1 max-w-3xl">
              Giáo viên tải tài liệu, đề kiểm tra dưới dạng Word (.docx / .doc) lên và lưu đề. Học sinh xem trực tiếp đề đã lưu, tải file Word hoặc tra cứu 6 chuyên đề PDF gốc.
            </p>
          </div>

          <label className="inline-flex items-center gap-2.5 bg-white/10 border border-white/20 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold cursor-pointer shrink-0">
            <input
              type="checkbox"
              checked={includeAnswersInWord}
              onChange={(e) => setIncludeAnswersInWord(e.target.checked)}
              className="w-4 h-4 accent-emerald-500 rounded-sm"
            />
            <span>Kèm đáp án &amp; lời giải khi xuất file Word (.doc)</span>
          </label>
        </div>
      </div>

      {/* ================= PART 0: UPLOAD WORD EXAM/MATERIAL & SAVED WORD EXAMS REPOSITORY ================= */}
      <div className="bg-white rounded-3xl border-2 border-indigo-200 p-5 sm:p-6 shadow-xs space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-200 pb-4">
          <div>
            <span className="text-[11px] font-black uppercase tracking-wider text-indigo-600">
              KHO ĐỀ KIỂM TRA &amp; TÀI LIỆU WORD (.DOCX / .DOC)
            </span>
            <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
              <FileText className="w-5 h-5 text-indigo-600" />
              <span>Tải Tài liệu, Đề Kiểm Tra lên dưới dạng Word &amp; Lưu Đề ({savedWordDocs.length} đề đã lưu)</span>
            </h3>
          </div>

          {userRole === 'teacher' && isTeacherAuthenticated && (
            <>
              <input
                ref={wordFileInputRef}
                type="file"
                accept=".docx,.doc"
                onChange={handleUploadWordFile}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => wordFileInputRef.current?.click()}
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs sm:text-sm flex items-center gap-2 shrink-0 shadow cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Chọn File Đề / Tài liệu Word (.docx, .doc)</span>
              </button>
            </>
          )}
        </div>

        {/* Upload & Save Form (Visible for Authenticated Teacher) */}
        {userRole === 'teacher' && isTeacherAuthenticated ? (
          <form onSubmit={handleSaveWordDocSubmit} className="p-4 rounded-2xl bg-indigo-50/60 border border-indigo-200 space-y-3">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 items-end">
              <div className="lg:col-span-5">
                <label className="block text-xs font-extrabold text-slate-700 mb-1">
                  Tên Đề kiểm tra / Tài liệu Word cần lưu:
                </label>
                <input
                  type="text"
                  value={wordTitle}
                  onChange={(e) => setWordTitle(e.target.value)}
                  placeholder="VD: Đề kiểm tra Giữa kì I KHTN 7 - Đề số 2..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-bold focus:outline-none focus:border-indigo-600"
                />
              </div>

              <div className="lg:col-span-2">
                <label className="block text-xs font-extrabold text-slate-700 mb-1">
                  Phân loại:
                </label>
                <select
                  value={wordDocType}
                  onChange={(e) =>
                    setWordDocType(e.target.value as 'exam' | 'worksheet' | 'material')
                  }
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-bold cursor-pointer"
                >
                  <option value="exam">Đề kiểm tra</option>
                  <option value="worksheet">Phiếu bài tập</option>
                  <option value="material">Tài liệu chuyên đề</option>
                </select>
              </div>

              <div className="lg:col-span-2">
                <label className="block text-xs font-extrabold text-slate-700 mb-1">
                  Phân môn:
                </label>
                <select
                  value={wordSubject}
                  onChange={(e) =>
                    setWordSubject(
                      e.target.value as
                        | 'Liên môn KHTN 7'
                        | 'Hóa học 7'
                        | 'Vật lí 7'
                        | 'Sinh học 7'
                    )
                  }
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-bold cursor-pointer"
                >
                  <option value="Liên môn KHTN 7">Liên môn KHTN 7</option>
                  <option value="Hóa học 7">Hóa học 7</option>
                  <option value="Vật lí 7">Vật lí 7</option>
                  <option value="Sinh học 7">Sinh học 7</option>
                </select>
              </div>

              <div className="lg:col-span-1">
                <label className="block text-xs font-extrabold text-slate-700 mb-1">
                  Tuần:
                </label>
                <input
                  type="number"
                  min={1}
                  max={35}
                  value={wordWeek}
                  onChange={(e) => setWordWeek(Number(e.target.value) || 1)}
                  className="w-full px-2 py-2.5 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-bold text-center"
                />
              </div>

              <div className="lg:col-span-2">
                <button
                  type="submit"
                  className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow transition cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>💾 Lưu Đề Word</span>
                </button>
              </div>
            </div>

            {uploadedFileName && (
              <div className="text-xs font-bold text-indigo-900">
                📎 Đã chọn file: <strong>{uploadedFileName}</strong> — Nhấn <strong>&ldquo;💾 Lưu Đề Word&rdquo;</strong> để lưu cố định!
              </div>
            )}
          </form>
        ) : (
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-600 font-semibold">
            🔒 Chức năng tải đề Word mới lên và xóa đề dành riêng cho <strong>Giáo viên Quản lý</strong>. Học sinh có thể xem và làm trực tiếp các đề Giáo viên đã lưu bên dưới.
          </div>
        )}

        {uploadNotice && (
          <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs sm:text-sm font-extrabold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{uploadNotice}</span>
          </div>
        )}

        {/* Saved Word Docs Grid + Live Reader */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          <div className="lg:col-span-5 space-y-2.5">
            <div className="text-xs font-black uppercase tracking-wider text-slate-500">
              DANH SÁCH ĐỀ &amp; TÀI LIỆU WORD ĐÃ LƯU ({savedWordDocs.length}):
            </div>
            {savedWordDocs.map((doc) => {
              const isSelected = activePreviewWordDoc?.id === doc.id;
              return (
                <div
                  key={doc.id}
                  className={`p-3.5 rounded-2xl border transition ${
                    isSelected
                      ? 'bg-indigo-50/90 border-indigo-400 shadow-xs'
                      : 'bg-slate-50/70 border-slate-200 hover:bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 text-[10px] font-black uppercase">
                      {doc.docType === 'exam'
                        ? 'Đề kiểm tra'
                        : doc.docType === 'worksheet'
                        ? 'Phiếu bài tập'
                        : 'Tài liệu Word'}{' '}
                      · Tuần {doc.weekNumber}
                    </span>
                    <span className="text-[10px] text-slate-400">{doc.createdAt}</span>
                  </div>
                  <div className="text-sm font-black text-slate-900 mt-1">{doc.title}</div>
                  <div className="text-xs text-slate-500 mt-0.5">{doc.fileName}</div>

                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setActivePreviewWordDoc(doc);
                        setWordQuizAnswers({});
                        setWordQuizSubmitted(false);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1 cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-600 text-white'
                          : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Xem &amp; Làm đề</span>
                    </button>

                    {doc.fileDataUrl && (
                      <a
                        href={doc.fileDataUrl}
                        download={doc.fileName}
                        className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-extrabold flex items-center gap-1"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Tải Word</span>
                      </a>
                    )}

                    {userRole === 'teacher' && isTeacherAuthenticated && savedWordDocs.length > 1 && (
                      <button
                        type="button"
                        onClick={() => onDeleteWordDoc(doc.id)}
                        className="p-1.5 rounded-xl text-rose-500 hover:bg-rose-50 cursor-pointer ml-auto"
                        title="Xóa đề này"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right 7 Cols: Live Preview & Interactive Practice of Selected Word Exam */}
          <div className="lg:col-span-7 bg-slate-50 rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-4">
            {activePreviewWordDoc ? (
              <>
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-3">
                  <div>
                    <span className="text-xs font-black uppercase text-indigo-600">
                      NỘI DUNG ĐỀ / TÀI LIỆU WORD ĐANG MỞ ({activePreviewWordDoc.subjectLabel})
                    </span>
                    <h4 className="text-base font-black text-slate-900">
                      {activePreviewWordDoc.title}
                    </h4>
                  </div>
                  {activePreviewWordDoc.fileDataUrl && (
                    <a
                      href={activePreviewWordDoc.fileDataUrl}
                      download={activePreviewWordDoc.fileName}
                      className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Tải bản Word gốc</span>
                    </a>
                  )}
                </div>

                <div
                  className="bg-white rounded-2xl border border-slate-200 p-4 max-h-96 overflow-y-auto prose prose-sm max-w-none text-slate-800"
                  dangerouslySetInnerHTML={{ __html: activePreviewWordDoc.htmlPreview }}
                />

                {/* If Word exam has parsed MCQs, let students practice right here */}
                {activePreviewWordDoc.parsedMcqs && activePreviewWordDoc.parsedMcqs.length > 0 && (
                  <div className="bg-white rounded-2xl border border-emerald-300 p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black uppercase text-emerald-800 flex items-center gap-1.5">
                        <ClipboardCheck className="w-4 h-4 text-emerald-600" />
                        <span>
                          LÀM TRỰC TIẾP CÂU HỎI TRẮC NGHIỆM TÁCH TỪ ĐỀ WORD ({activePreviewWordDoc.parsedMcqs.length} CÂU)
                        </span>
                      </span>
                      <button
                        type="button"
                        onClick={() => setWordQuizSubmitted(true)}
                        className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black cursor-pointer"
                      >
                        Chấm điểm nhanh
                      </button>
                    </div>

                    <div className="space-y-3">
                      {activePreviewWordDoc.parsedMcqs.map((q, idx) => {
                        const chosen = wordQuizAnswers[q.id];
                        return (
                          <div key={q.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                            <div className="text-xs sm:text-sm font-bold text-slate-900">
                              Câu {idx + 1}: {q.question}
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {q.options.map((opt, optIdx) => {
                                const isPicked = chosen === optIdx;
                                const isRight = q.correctIndex === optIdx;
                                let btnCls = 'bg-white border-slate-200 text-slate-700 hover:border-indigo-400';
                                if (wordQuizSubmitted) {
                                  if (isRight) btnCls = 'bg-emerald-100 border-emerald-500 text-emerald-950 font-black';
                                  else if (isPicked) btnCls = 'bg-rose-100 border-rose-400 text-rose-900';
                                } else if (isPicked) {
                                  btnCls = 'bg-indigo-600 border-indigo-600 text-white font-bold';
                                }

                                return (
                                  <button
                                    key={optIdx}
                                    type="button"
                                    onClick={() => {
                                      setWordQuizSubmitted(false);
                                      setWordQuizAnswers((prev) => ({ ...prev, [q.id]: optIdx }));
                                    }}
                                    className={`text-left px-3 py-2 rounded-lg border text-xs transition cursor-pointer ${btnCls}`}
                                  >
                                    <strong>{['A', 'B', 'C', 'D'][optIdx]}.</strong> {opt}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-12 text-xs text-slate-500">
                Chọn một đề hoặc tài liệu Word bên trái để xem nội dung chi tiết.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Part 1: 6 Original Uploaded PDF Documents + Live Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
          <h3 className="text-sm font-mono uppercase tracking-wider font-bold text-slate-800 flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-600" />
            6 CHUYÊN ĐỀ PDF GỐC ĐÃ TÍCH HỢP
          </h3>
          <div className="space-y-2.5">
            {KNTT_PDF_DOCUMENTS.map((doc) => {
              const isSelected = selectedPdfUrl === doc.url;
              return (
                <div
                  key={doc.id}
                  className={`p-3.5 rounded-xl border transition-all ${
                    isSelected
                      ? 'bg-emerald-50/90 border-emerald-400 shadow-2xs'
                      : 'bg-slate-50/70 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <div className="text-xs font-mono font-bold text-emerald-800">
                    {doc.subject === 'chemistry' ? 'HÓA HỌC 7' : 'VẬT LÍ 7'} ·{' '}
                    {doc.lessons}
                  </div>
                  <div className="text-sm font-bold text-slate-900 mt-0.5">
                    {doc.title}
                  </div>
                  <div className="mt-3 flex items-center gap-2">
                    <button
                      onClick={() => setSelectedPdfUrl(doc.url)}
                      className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-600 text-white'
                          : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <Eye className="w-3.5 h-3.5" /> Đọc trực tiếp
                    </button>
                    <a
                      href={doc.url}
                      download
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-900 text-white hover:bg-slate-800"
                    >
                      <Download className="w-3.5 h-3.5" /> Tải PDF
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase font-bold text-slate-700">
              KHUNG ĐỌC TÀI LIỆU PDF TRỰC TIẾP
            </span>
            <a
              href={selectedPdfUrl}
              download
              className="text-xs font-bold text-blue-600 hover:underline"
            >
              Tải bản PDF này về máy →
            </a>
          </div>
          <div className="w-full h-[580px] rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
            <iframe
              src={selectedPdfUrl}
              title="PDF Viewer"
              className="w-full h-full"
            />
          </div>
        </div>
      </div>

      {/* Part 2: Download Word Worksheets (.doc) for each of the 30 KNTT Lessons */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-200">
          <div>
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <FileDown className="w-5 h-5 text-blue-600" />
              Xuất phiếu bài tập Word (.doc) theo từng bài học (Đủ 30 bài KHTN 7 KNTT)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Mỗi file Word xuất ra gồm đầy đủ Lý thuyết trọng tâm, 30 câu Trắc nghiệm (16–18 câu cho Sinh), 5 bài Đúng–Sai và 5–7 bài Tự luận.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {ALL_KNTT_LESSONS.map((lesson) => {
            const isJustDownloaded = downloadedId === lesson.id;
            return (
              <div
                key={lesson.id}
                className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-white hover:border-blue-300 transition-all flex flex-col justify-between gap-3"
              >
                <div>
                  <div className="text-[11px] font-mono font-bold uppercase text-slate-500">
                    {lesson.subject === 'chemistry'
                      ? 'HÓA HỌC 7'
                      : lesson.subject === 'physics'
                      ? 'VẬT LÍ 7'
                      : 'SINH HỌC 7'}{' '}
                    · Bài {lesson.lessonNumber}
                  </div>
                  <div className="text-sm font-bold text-slate-900 mt-0.5 leading-snug">
                    {lesson.title}
                  </div>
                  <div className="text-xs font-mono text-slate-500 mt-1.5 tabular-nums">
                    {lesson.mcqs.length} TN · {lesson.trueFalseList.length} Đ/S ·{' '}
                    {lesson.essays.length} Tự luận
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-slate-200/80">
                  <button
                    onClick={() => handleDownloadWordWorksheet(lesson)}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold cursor-pointer transition-colors"
                  >
                    {isJustDownloaded ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" /> Đã tải .DOC
                      </>
                    ) : (
                      <>
                        <FileDown className="w-3.5 h-3.5" /> Tải file Word
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => onOpenLessonPractice(lesson.id)}
                    className="px-3 py-2 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-bold cursor-pointer"
                  >
                    <BookOpen className="w-3.5 h-3.5 inline mr-1" />
                    Làm online
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
