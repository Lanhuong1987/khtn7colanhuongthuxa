import React, { useState, useRef } from 'react';
import {
  X,
  Upload,
  FileSpreadsheet,
  FileText,
  Save,
  Sparkles,
  CheckCircle2,
  Trash2,
  Layers,
  Play,
  Table2,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import mammoth from 'mammoth';
import { SubSubject } from '../data/khtn7Data';
import {
  KNTT_EXAM_PERIOD_GROUPS,
  KnttExamPaper,
  StandardExamMcq,
  StandardExamEssay,
  CognitiveLevel,
} from '../data/knttStandardExams';
import { ALL_KNTT_LESSONS } from '../data/allLessons';

export interface SubjectMcqQuota {
  nhanBiet: number;
  thongHieu: number;
  vanDung: number;
  vanDungCao: number;
}

export interface SavedExamMatrixConfig {
  id: string;
  title: string;
  periodCode: 'gk1' | 'hk1' | 'gk2' | 'hk2';
  durationMinutes: number;
  scopeSummary: {
    physics: string;
    chemistry: string;
    biology: string;
  };
  mcqQuotas: {
    physics: SubjectMcqQuota;
    chemistry: SubjectMcqQuota;
    biology: SubjectMcqQuota;
  };
  essayQuotas: {
    physicsCount: number; // Vận dụng, Vận dụng cao
    chemistryCount: number; // Vận dụng, Vận dụng cao
    biologyCount: number; // Thông hiểu, Vận dụng
  };
  uploadedMatrixFileName?: string;
  uploadedSourceExamFileName?: string;
  uploadedSourceExamText?: string;
  rawMatrixSummaryText?: string;
  createdAt: string;
}

const SAVED_MATRICES_STORAGE_KEY = 'khtn7_saved_exam_matrices_v1';

export const DEFAULT_SAVED_MATRICES: SavedExamMatrixConfig[] = [
  {
    id: 'matrix-default-gk1',
    title: 'Ma trận chuẩn Đề Giữa Kì 1 – KHTN 7 KNTT (21 TN + 6 TL)',
    periodCode: 'gk1',
    durationMinutes: 60,
    scopeSummary: {
      physics: 'Lí: Bài 8 – 11',
      chemistry: 'Hóa: Bài 1 – 2',
      biology: 'Sinh: Bài 21 – 27',
    },
    mcqQuotas: {
      chemistry: { nhanBiet: 2, thongHieu: 2, vanDung: 2, vanDungCao: 1 },
      physics: { nhanBiet: 2, thongHieu: 2, vanDung: 1, vanDungCao: 2 },
      biology: { nhanBiet: 2, thongHieu: 3, vanDung: 1, vanDungCao: 1 },
    },
    essayQuotas: {
      physicsCount: 2,
      chemistryCount: 2,
      biologyCount: 2,
    },
    createdAt: 'Mặc định hệ thống',
  },
  {
    id: 'matrix-default-hk1',
    title: 'Ma trận chuẩn Đề Cuối Học Kì 1 – KHTN 7 KNTT (21 TN + 6 TL)',
    periodCode: 'hk1',
    durationMinutes: 60,
    scopeSummary: {
      physics: 'Lí: Bài 8 – 14',
      chemistry: 'Hóa: Bài 1 – 4',
      biology: 'Sinh: Bài 21 – 32',
    },
    mcqQuotas: {
      chemistry: { nhanBiet: 2, thongHieu: 2, vanDung: 2, vanDungCao: 1 },
      physics: { nhanBiet: 2, thongHieu: 2, vanDung: 1, vanDungCao: 2 },
      biology: { nhanBiet: 2, thongHieu: 3, vanDung: 1, vanDungCao: 1 },
    },
    essayQuotas: {
      physicsCount: 2,
      chemistryCount: 2,
      biologyCount: 2,
    },
    createdAt: 'Mặc định hệ thống',
  },
  {
    id: 'matrix-default-gk2',
    title: 'Ma trận chuẩn Đề Giữa Kì 2 – KHTN 7 KNTT (21 TN + 6 TL)',
    periodCode: 'gk2',
    durationMinutes: 60,
    scopeSummary: {
      physics: 'Lí: Bài 15 – 17',
      chemistry: 'Hóa: Bài 5 – 6',
      biology: 'Sinh: Bài 33 – 37',
    },
    mcqQuotas: {
      chemistry: { nhanBiet: 2, thongHieu: 2, vanDung: 2, vanDungCao: 1 },
      physics: { nhanBiet: 2, thongHieu: 2, vanDung: 1, vanDungCao: 2 },
      biology: { nhanBiet: 2, thongHieu: 3, vanDung: 1, vanDungCao: 1 },
    },
    essayQuotas: {
      physicsCount: 2,
      chemistryCount: 2,
      biologyCount: 2,
    },
    createdAt: 'Mặc định hệ thống',
  },
  {
    id: 'matrix-default-hk2',
    title: 'Ma trận chuẩn Đề Cuối Học Kì 2 – KHTN 7 KNTT (21 TN + 6 TL)',
    periodCode: 'hk2',
    durationMinutes: 60,
    scopeSummary: {
      physics: 'Lí: Bài 15 – 20',
      chemistry: 'Hóa: Bài 6 – 7',
      biology: 'Sinh: Bài 33 – 42',
    },
    mcqQuotas: {
      chemistry: { nhanBiet: 2, thongHieu: 2, vanDung: 2, vanDungCao: 1 },
      physics: { nhanBiet: 2, thongHieu: 2, vanDung: 1, vanDungCao: 2 },
      biology: { nhanBiet: 2, thongHieu: 3, vanDung: 1, vanDungCao: 1 },
    },
    essayQuotas: {
      physicsCount: 2,
      chemistryCount: 2,
      biologyCount: 2,
    },
    createdAt: 'Mặc định hệ thống',
  },
];

export function loadSavedExamMatrices(): SavedExamMatrixConfig[] {
  try {
    const raw = localStorage.getItem(SAVED_MATRICES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {
    // ignore
  }
  return DEFAULT_SAVED_MATRICES;
}

export function saveExamMatricesToStorage(list: SavedExamMatrixConfig[]): void {
  try {
    localStorage.setItem(SAVED_MATRICES_STORAGE_KEY, JSON.stringify(list));
  } catch {
    // ignore
  }
}

function shuffleArray<T>(items: T[]): T[] {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function shuffleMcqOptions(mcq: StandardExamMcq, newId: string): StandardExamMcq {
  const correctText = mcq.options[mcq.correctIndex];
  const shuffledOpts = shuffleArray([...mcq.options]) as [string, string, string, string];
  const newCorrectIdx = Math.max(0, shuffledOpts.indexOf(correctText));
  return {
    ...mcq,
    id: newId,
    options: shuffledOpts,
    correctIndex: newCorrectIdx,
  };
}

// Parse lesson number range from strings like "Lí: Bài 8 – 11" or "Bài 1-4"
function extractLessonRange(scopeStr: string): [number, number] | null {
  const nums = scopeStr.match(/\d+/g);
  if (!nums || nums.length === 0) return null;
  if (nums.length === 1) {
    const n = Number(nums[0]);
    return [n, n];
  }
  const a = Number(nums[0]);
  const b = Number(nums[1]);
  return [Math.min(a, b), Math.max(a, b)];
}

// Generate 1 or more KnttExamPaper objects strictly following a SavedExamMatrixConfig
export function generatePapersFromMatrixConfig(
  matrix: SavedExamMatrixConfig,
  paperCount: number,
  parsedSourceMcqs: StandardExamMcq[] = [],
  parsedSourceEssays: StandardExamEssay[] = []
): KnttExamPaper[] {
  const periodGroup =
    KNTT_EXAM_PERIOD_GROUPS.find((g) => g.code === matrix.periodCode) ||
    KNTT_EXAM_PERIOD_GROUPS[0];

  // Collect pool from period's 4 standard exam papers
  const periodMcqs = periodGroup.papers.flatMap((p) => p.mcqs);
  const periodEssays = periodGroup.papers.flatMap((p) => p.essays);

  // Also collect lesson bank questions matching the lesson ranges in matrix.scopeSummary
  const physRange = extractLessonRange(matrix.scopeSummary.physics);
  const chemRange = extractLessonRange(matrix.scopeSummary.chemistry);
  const bioRange = extractLessonRange(matrix.scopeSummary.biology);

  const lessonBankMcqs: StandardExamMcq[] = [];
  const lessonBankEssays: StandardExamEssay[] = [];

  ALL_KNTT_LESSONS.forEach((lesson) => {
    const num = lesson.lessonNumber;
    let inScope = false;
    if (lesson.subject === 'physics' && physRange && num >= physRange[0] && num <= physRange[1]) {
      inScope = true;
    } else if (
      lesson.subject === 'chemistry' &&
      chemRange &&
      num >= chemRange[0] &&
      num <= chemRange[1]
    ) {
      inScope = true;
    } else if (
      lesson.subject === 'biology' &&
      bioRange &&
      num >= bioRange[0] &&
      num <= bioRange[1]
    ) {
      inScope = true;
    }

    if (inScope) {
      const shortSub =
        lesson.subject === 'physics'
          ? 'Lí'
          : lesson.subject === 'chemistry'
          ? 'Hóa'
          : 'Sinh';
      lesson.mcqs.forEach((q, idx) => {
        const inferredLevel: CognitiveLevel =
          q.level ||
          (idx % 4 === 0
            ? 'Nhận biết'
            : idx % 4 === 1
            ? 'Thông hiểu'
            : idx % 4 === 2
            ? 'Vận dụng'
            : 'Vận dụng cao');
        lessonBankMcqs.push({
          id: `${lesson.id}-${q.id}`,
          subject: lesson.subject,
          lessonRef: `${shortSub} – Bài ${lesson.lessonNumber}`,
          level: inferredLevel,
          question: q.question,
          options: q.options,
          correctIndex: q.correctIndex,
          explanation: q.explanation,
        });
      });

      lesson.essays.forEach((es, idx) => {
        const inferredEssayLevel: CognitiveLevel =
          lesson.subject === 'biology'
            ? idx % 2 === 0
              ? 'Thông hiểu'
              : 'Vận dụng'
            : idx % 2 === 0
            ? 'Vận dụng'
            : 'Vận dụng cao';
        lessonBankEssays.push({
          id: `${lesson.id}-${es.id}`,
          subject: lesson.subject,
          lessonRef: `${shortSub} – Bài ${lesson.lessonNumber}`,
          level: inferredEssayLevel,
          points: 0.5,
          question: es.question,
          sampleAnswer: es.sampleAnswer,
          rubricCriteria:
            es.rubricPoints && es.rubricPoints.length > 0
              ? es.rubricPoints
              : [
                  'Trình bày đúng kiến thức trọng tâm và công thức liên quan (0,25đ).',
                  'Tính toán chính xác hoặc giải thích đầy đủ ý nghĩa thực tiễn (0,25đ).',
                ],
        });
      });
    }
  });

  // Combined prioritized pools: Teacher uploaded source -> Period Exam Bank -> Lesson Bank
  const fullMcqPool: StandardExamMcq[] = [
    ...parsedSourceMcqs,
    ...periodMcqs,
    ...lessonBankMcqs,
  ];
  const fullEssayPool: StandardExamEssay[] = [
    ...parsedSourceEssays,
    ...periodEssays,
    ...lessonBankEssays,
  ];

  const generatedPapers: KnttExamPaper[] = [];
  const globalUsedQuestionsAcrossPapers = new Set<string>();

  for (let pIdx = 0; pIdx < paperCount; pIdx++) {
    const paperId = `matrix-exam-${matrix.periodCode}-${Date.now()}-${pIdx + 1}`;
    const usedQuestionsInThisPaper = new Set<string>();
    const pickedMcqs: StandardExamMcq[] = [];

    const subjects: SubSubject[] = ['chemistry', 'physics', 'biology'];
    for (const sub of subjects) {
      const qQuota = matrix.mcqQuotas[sub];
      const levelTargets: { level: CognitiveLevel; count: number }[] = [
        { level: 'Nhận biết', count: qQuota.nhanBiet },
        { level: 'Thông hiểu', count: qQuota.thongHieu },
        { level: 'Vận dụng', count: qQuota.vanDung },
        { level: 'Vận dụng cao', count: qQuota.vanDungCao },
      ];

      for (const lt of levelTargets) {
        if (lt.count <= 0) continue;
        // Prefer questions not yet used in previous papers of this batch
        const freshCandidates = shuffleArray(
          fullMcqPool.filter(
            (m) =>
              m.subject === sub &&
              m.level === lt.level &&
              !usedQuestionsInThisPaper.has(m.question) &&
              !globalUsedQuestionsAcrossPapers.has(m.question)
          )
        );
        const fallbackCandidates = shuffleArray(
          fullMcqPool.filter(
            (m) =>
              m.subject === sub &&
              m.level === lt.level &&
              !usedQuestionsInThisPaper.has(m.question)
          )
        );
        const mergedCandidates = [...freshCandidates, ...fallbackCandidates];

        let added = 0;
        for (const cand of mergedCandidates) {
          if (added >= lt.count) break;
          if (usedQuestionsInThisPaper.has(cand.question)) continue;
          usedQuestionsInThisPaper.add(cand.question);
          globalUsedQuestionsAcrossPapers.add(cand.question);
          pickedMcqs.push(cand);
          added++;
        }
      }
    }

    const finalMcqs = pickedMcqs.map((m, idx) =>
      shuffleMcqOptions(m, `${paperId}-mcq-${idx + 1}`)
    );

    // Pick Essays according to matrix.essayQuotas
    const pickedEssays: StandardExamEssay[] = [];
    const usedEssaysInPaper = new Set<string>();

    const essayPlan: { subject: SubSubject; count: number; levels: CognitiveLevel[] }[] = [
      {
        subject: 'physics',
        count: matrix.essayQuotas.physicsCount,
        levels: ['Vận dụng', 'Vận dụng cao'],
      },
      {
        subject: 'chemistry',
        count: matrix.essayQuotas.chemistryCount,
        levels: ['Vận dụng', 'Vận dụng cao'],
      },
      {
        subject: 'biology',
        count: matrix.essayQuotas.biologyCount,
        levels: ['Thông hiểu', 'Vận dụng'],
      },
    ];

    for (const plan of essayPlan) {
      for (let i = 0; i < plan.count; i++) {
        const targetLvl = plan.levels[i % plan.levels.length];
        const freshPool = shuffleArray(
          fullEssayPool.filter(
            (e) =>
              e.subject === plan.subject &&
              e.level === targetLvl &&
              !usedEssaysInPaper.has(e.question) &&
              !globalUsedQuestionsAcrossPapers.has(e.question)
          )
        );
        const fallbackPool = shuffleArray(
          fullEssayPool.filter(
            (e) => e.subject === plan.subject && !usedEssaysInPaper.has(e.question)
          )
        );
        const chosen = freshPool[0] || fallbackPool[0];
        if (chosen) {
          usedEssaysInPaper.add(chosen.question);
          globalUsedQuestionsAcrossPapers.add(chosen.question);
          pickedEssays.push({
            ...chosen,
            id: `${paperId}-tl-${pickedEssays.length + 1}`,
          });
        }
      }
    }

    const totalNb = finalMcqs.filter((q) => q.level === 'Nhận biết').length;
    const totalTh = finalMcqs.filter((q) => q.level === 'Thông hiểu').length;
    const totalVd = finalMcqs.filter((q) => q.level === 'Vận dụng').length;
    const totalVdc = finalMcqs.filter((q) => q.level === 'Vận dụng cao').length;

    const codeLabel =
      paperCount > 1 ? ` – Mã đề 0${pIdx + 1}` : '';

    generatedPapers.push({
      id: paperId,
      code: matrix.periodCode,
      paperNumber: pIdx + 1,
      title: `${matrix.title}${codeLabel}`,
      shortTitle: `Đề Ma Trận (${matrix.periodCode.toUpperCase()})${codeLabel}`,
      durationMinutes: matrix.durationMinutes || 60,
      scopeSummary: matrix.scopeSummary,
      matrixSummary: `Sinh từ Ma trận "${matrix.title}": ${finalMcqs.length} câu TN (Biết: ${totalNb}, Hiểu: ${totalTh}, VD: ${totalVd}, VDC: ${totalVdc}) + ${pickedEssays.length} câu Tự luận.`,
      mcqs: finalMcqs,
      essays: pickedEssays,
      isCustomTeacherExam: true,
      createdAt: new Date().toLocaleDateString('vi-VN'),
    });
  }

  return generatedPapers;
}

interface MatrixExamBuilderModalProps {
  isOpen: boolean;
  onClose: () => void;
  isTeacherAuthenticated: boolean;
  onAuthenticateTeacher?: (pin: string) => boolean;
  savedMatrices: SavedExamMatrixConfig[];
  onSaveMatrix: (matrix: SavedExamMatrixConfig) => void;
  onDeleteMatrix: (matrixId: string) => void;
  onGenerateAndSaveExams: (
    papers: KnttExamPaper[],
    matrix: SavedExamMatrixConfig,
    openImmediately: boolean
  ) => void;
  parseCustomExamTextFn: (
    rawText: string,
    examId: string
  ) => { mcqs: StandardExamMcq[]; essays: StandardExamEssay[] };
}

export const MatrixExamBuilderModal: React.FC<MatrixExamBuilderModalProps> = ({
  isOpen,
  onClose,
  isTeacherAuthenticated,
  onAuthenticateTeacher,
  savedMatrices,
  onSaveMatrix,
  onDeleteMatrix,
  onGenerateAndSaveExams,
  parseCustomExamTextFn,
}) => {
  const [localUnlocked, setLocalUnlocked] = useState<boolean>(isTeacherAuthenticated);
  const [pinInput, setPinInput] = useState<string>('');
  const [pinError, setPinError] = useState<string>('');

  const [matrixTitle, setMatrixTitle] = useState<string>(
    'Ma trận Đề Kiểm Tra Định Kì KHTN 7 – Chuẩn Công văn 7991'
  );
  const [periodCode, setPeriodCode] = useState<'gk1' | 'hk1' | 'gk2' | 'hk2'>('gk1');
  const [durationMinutes, setDurationMinutes] = useState<number>(60);
  const [paperBatchCount, setPaperBatchCount] = useState<1 | 4>(1);

  const [physicsScope, setPhysicsScope] = useState<string>('Lí: Bài 8 – 11');
  const [chemistryScope, setChemistryScope] = useState<string>('Hóa: Bài 1 – 2');
  const [biologyScope, setBiologyScope] = useState<string>('Sinh: Bài 21 – 27');

  const [mcqQuotas, setMcqQuotas] = useState<{
    physics: SubjectMcqQuota;
    chemistry: SubjectMcqQuota;
    biology: SubjectMcqQuota;
  }>({
    chemistry: { nhanBiet: 2, thongHieu: 2, vanDung: 2, vanDungCao: 1 },
    physics: { nhanBiet: 2, thongHieu: 2, vanDung: 1, vanDungCao: 2 },
    biology: { nhanBiet: 2, thongHieu: 3, vanDung: 1, vanDungCao: 1 },
  });

  const [essayQuotas, setEssayQuotas] = useState({
    physicsCount: 2,
    chemistryCount: 2,
    biologyCount: 2,
  });

  const [uploadedMatrixFileName, setUploadedMatrixFileName] = useState<string>('');
  const [uploadedSourceExamFileName, setUploadedSourceExamFileName] = useState<string>('');
  const [uploadedSourceExamText, setUploadedSourceExamText] = useState<string>('');
  const [rawMatrixSummaryText, setRawMatrixSummaryText] = useState<string>('');
  const [statusBanner, setStatusBanner] = useState<string | null>(null);

  const matrixFileInputRef = useRef<HTMLInputElement | null>(null);
  const sourceExamFileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const applyPeriodDefaults = (code: 'gk1' | 'hk1' | 'gk2' | 'hk2') => {
    setPeriodCode(code);
    if (code === 'gk1') {
      setPhysicsScope('Lí: Bài 8 – 11');
      setChemistryScope('Hóa: Bài 1 – 2');
      setBiologyScope('Sinh: Bài 21 – 27');
      setMatrixTitle('Ma trận Đề Kiểm Tra Giữa Kì 1 – KHTN 7 KNTT');
    } else if (code === 'hk1') {
      setPhysicsScope('Lí: Bài 8 – 14');
      setChemistryScope('Hóa: Bài 1 – 4');
      setBiologyScope('Sinh: Bài 21 – 32');
      setMatrixTitle('Ma trận Đề Kiểm Tra Học Kì 1 – KHTN 7 KNTT');
    } else if (code === 'gk2') {
      setPhysicsScope('Lí: Bài 15 – 17');
      setChemistryScope('Hóa: Bài 5 – 6');
      setBiologyScope('Sinh: Bài 33 – 37');
      setMatrixTitle('Ma trận Đề Kiểm Tra Giữa Kì 2 – KHTN 7 KNTT');
    } else {
      setPhysicsScope('Lí: Bài 15 – 20');
      setChemistryScope('Hóa: Bài 6 – 7');
      setBiologyScope('Sinh: Bài 33 – 42');
      setMatrixTitle('Ma trận Đề Kiểm Tra Học Kì 2 – KHTN 7 KNTT');
    }
  };

  const handleLoadSavedMatrixIntoEditor = (m: SavedExamMatrixConfig) => {
    setMatrixTitle(m.title);
    setPeriodCode(m.periodCode);
    setDurationMinutes(m.durationMinutes);
    setPhysicsScope(m.scopeSummary.physics);
    setChemistryScope(m.scopeSummary.chemistry);
    setBiologyScope(m.scopeSummary.biology);
    setMcqQuotas(m.mcqQuotas);
    setEssayQuotas(m.essayQuotas);
    if (m.uploadedSourceExamText) {
      setUploadedSourceExamText(m.uploadedSourceExamText);
    }
    setStatusBanner(`📐 Đã nạp cấu hình "${m.title}" vào bảng thiết lập!`);
  };

  // Auto-parse an uploaded Matrix file (.xlsx, .docx, .txt, .csv)
  const handleMatrixFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    setUploadedMatrixFileName(file.name);
    const cleanTitle = file.name.replace(/\.(xlsx|xls|docx|doc|txt|csv)$/i, '').replace(/[_-]+/g, ' ');
    setMatrixTitle(`Ma trận: ${cleanTitle}`);

    try {
      let extractedText = '';
      if (ext === 'xlsx' || ext === 'xls') {
        const buffer = await file.arrayBuffer();
        const wb = XLSX.read(buffer, { type: 'array' });
        const sheetTexts: string[] = [];
        wb.SheetNames.forEach((name) => {
          const sheet = wb.Sheets[name];
          const csv = XLSX.utils.sheet_to_csv(sheet);
          if (csv.trim()) sheetTexts.push(`[Sheet: ${name}]\n${csv}`);
        });
        extractedText = sheetTexts.join('\n\n');
      } else if (ext === 'docx') {
        const buffer = await file.arrayBuffer();
        const res = await mammoth.extractRawText({ arrayBuffer: buffer });
        extractedText = res.value || '';
      } else {
        extractedText = await file.text();
      }

      setRawMatrixSummaryText(extractedText);

      // Intelligently detect period and lesson scopes from the matrix text if mentioned
      const lower = extractedText.toLowerCase();
      if (lower.includes('giữa kì 2') || lower.includes('giữa học kì 2') || lower.includes('gk2')) {
        applyPeriodDefaults('gk2');
      } else if (lower.includes('cuối kì 2') || lower.includes('học kì 2') || lower.includes('hk2')) {
        applyPeriodDefaults('hk2');
      } else if (lower.includes('cuối kì 1') || lower.includes('học kì 1') || lower.includes('hk1')) {
        applyPeriodDefaults('hk1');
      } else if (lower.includes('giữa kì 1') || lower.includes('giữa học kì 1') || lower.includes('gk1')) {
        applyPeriodDefaults('gk1');
      }

      setMatrixTitle(`Ma trận: ${cleanTitle}`);
      setStatusBanner(
        `✅ Đã đọc file Ma trận "${file.name}" thành công! Thầy/cô có thể kiểm tra số câu bên dưới rồi bấm "💾 Lưu Ma Trận" hoặc "⚡ Sinh Đề Theo Ma Trận & Lưu Đề".`
      );
    } catch {
      setStatusBanner(
        `📎 Đã đính kèm file Ma trận "${file.name}". Thầy/cô có thể kiểm tra các ô số câu bên dưới.`
      );
    }
    e.target.value = '';
  };

  // Upload accompanying source exam Word/Txt file
  const handleSourceExamFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    setUploadedSourceExamFileName(file.name);

    try {
      let text = '';
      if (ext === 'docx') {
        const buffer = await file.arrayBuffer();
        const res = await mammoth.extractRawText({ arrayBuffer: buffer });
        text = res.value || '';
      } else {
        text = await file.text();
      }
      setUploadedSourceExamText(text);
      const previewParsed = parseCustomExamTextFn(text, 'preview');
      setStatusBanner(
        `📄 Đã tải file Đề nguồn "${file.name}" (nhận diện ${previewParsed.mcqs.length} câu TN & ${previewParsed.essays.length} câu TL). Hệ thống sẽ kết hợp đề này với Ngân hàng câu hỏi KHTN 7 để sinh đề theo đúng Ma trận!`
      );
    } catch {
      setStatusBanner(`⚠️ Không đọc được tự động file "${file.name}".`);
    }
    e.target.value = '';
  };

  const updateMcqCell = (
    subject: SubSubject,
    field: keyof SubjectMcqQuota,
    val: number
  ) => {
    const clamped = Math.max(0, Math.min(20, val));
    setMcqQuotas((prev) => ({
      ...prev,
      [subject]: {
        ...prev[subject],
        [field]: clamped,
      },
    }));
  };

  // Totals calculation
  const totalNb =
    mcqQuotas.physics.nhanBiet +
    mcqQuotas.chemistry.nhanBiet +
    mcqQuotas.biology.nhanBiet;
  const totalTh =
    mcqQuotas.physics.thongHieu +
    mcqQuotas.chemistry.thongHieu +
    mcqQuotas.biology.thongHieu;
  const totalVd =
    mcqQuotas.physics.vanDung +
    mcqQuotas.chemistry.vanDung +
    mcqQuotas.biology.vanDung;
  const totalVdc =
    mcqQuotas.physics.vanDungCao +
    mcqQuotas.chemistry.vanDungCao +
    mcqQuotas.biology.vanDungCao;
  const totalMcqs = totalNb + totalTh + totalVd + totalVdc;
  const totalEssays =
    essayQuotas.physicsCount +
    essayQuotas.chemistryCount +
    essayQuotas.biologyCount;

  const buildCurrentMatrixConfig = (): SavedExamMatrixConfig => {
    return {
      id: `matrix-${periodCode}-${Date.now()}`,
      title: matrixTitle.trim() || `Ma trận Đề ${periodCode.toUpperCase()} KHTN 7`,
      periodCode,
      durationMinutes: durationMinutes || 60,
      scopeSummary: {
        physics: physicsScope.trim() || 'Lí: Bài 8 – 11',
        chemistry: chemistryScope.trim() || 'Hóa: Bài 1 – 2',
        biology: biologyScope.trim() || 'Sinh: Bài 21 – 27',
      },
      mcqQuotas,
      essayQuotas,
      uploadedMatrixFileName: uploadedMatrixFileName || undefined,
      uploadedSourceExamFileName: uploadedSourceExamFileName || undefined,
      uploadedSourceExamText: uploadedSourceExamText || undefined,
      rawMatrixSummaryText: rawMatrixSummaryText || undefined,
      createdAt: new Date().toLocaleDateString('vi-VN'),
    };
  };

  const handleSaveMatrixOnly = () => {
    const config = buildCurrentMatrixConfig();
    onSaveMatrix(config);
    setStatusBanner(
      `💾 Đã lưu Ma trận "${config.title}" (${totalMcqs} câu TN + ${totalEssays} câu TL) vào Kho Ma trận của trường/lớp!`
    );
  };

  const handleGenerateAndSaveBoth = (openImmediately: boolean) => {
    const config = buildCurrentMatrixConfig();
    onSaveMatrix(config);

    const parsedSource = uploadedSourceExamText.trim()
      ? parseCustomExamTextFn(uploadedSourceExamText, `src-${Date.now()}`)
      : { mcqs: [], essays: [] };

    const papers = generatePapersFromMatrixConfig(
      config,
      paperBatchCount,
      parsedSource.mcqs,
      parsedSource.essays
    );

    onGenerateAndSaveExams(papers, config, openImmediately);
    if (!openImmediately) {
      setStatusBanner(
        `🎉 Đã Lưu Ma Trận & Sinh thành công ${papers.length} Đề kiểm tra ("${papers[0].title}") vào Kho Đề cho học sinh làm bài!`
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#071936] via-[#0a2748] to-[#063d3f] px-6 py-5 text-white flex items-center justify-between gap-3 sticky top-0 z-10">
          <div>
            <div className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-300">
              CÔNG CỤ TẢI ĐỀ & MA TRẬN — SINH ĐỀ TỰ ĐỘNG CHUẨN KHTN 7 KNTT
            </div>
            <h3 className="text-lg sm:text-xl font-black mt-0.5">
              📐 Tải Đề & Ma Trận Lên → Sinh Đề Theo Ma Trận, Lưu Đề & Lưu Ma Trận
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {!localUnlocked && !isTeacherAuthenticated ? (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const ok = onAuthenticateTeacher
                ? onAuthenticateTeacher(pinInput)
                : pinInput.trim() === '0385379344';
              if (ok) {
                setLocalUnlocked(true);
                setPinError('');
                setPinInput('');
              } else {
                setPinError('Mật khẩu Giáo viên không chính xác! Vui lòng kiểm tra lại.');
              }
            }}
            className="p-6 space-y-4"
          >
            <div>
              <label className="block text-xs font-black uppercase text-slate-800 mb-2">
                NHẬP MẬT KHẨU BẢO MẬT CỦA GIÁO VIÊN ĐỂ TẢI MA TRẬN & SINH ĐỀ
              </label>
              <input
                type="password"
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                placeholder="Nhập mật khẩu riêng của giáo viên..."
                className="w-full px-4 py-3 rounded-2xl border-2 border-blue-400 text-sm font-semibold text-slate-900 focus:outline-none focus:border-blue-600"
              />
              <p className="text-xs text-slate-500 mt-1.5">
                Đảm bảo chỉ giáo viên mới có quyền tải ma trận, sinh đề mới và lưu vào kho đề của học sinh.
              </p>
              {pinError && (
                <p className="text-xs font-extrabold text-rose-600 mt-2">{pinError}</p>
              )}
            </div>
            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-[#0d6efd] hover:bg-blue-700 text-white font-black text-sm shadow-md cursor-pointer"
            >
              Xác nhận Mật khẩu Giáo viên →
            </button>
          </form>
        ) : (
          <div className="p-5 sm:p-6 space-y-6">
            {statusBanner && (
              <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs sm:text-sm font-bold flex items-center justify-between gap-2">
                <span>{statusBanner}</span>
                <button
                  type="button"
                  onClick={() => setStatusBanner(null)}
                  className="text-xs font-black text-emerald-800 hover:underline shrink-0 cursor-pointer"
                >
                  Đóng
                </button>
              </div>
            )}

            {/* STEP 1: UPLOAD MATRIX FILE (.XLSX / .DOCX) & SOURCE EXAM FILE (.DOCX / .TXT) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Upload Matrix File */}
              <div className="p-4 rounded-2xl bg-indigo-50/70 border-2 border-dashed border-indigo-300 flex flex-col justify-between gap-3">
                <div className="space-y-1">
                  <div className="text-xs font-black uppercase text-indigo-950 flex items-center gap-1.5">
                    <FileSpreadsheet className="w-4 h-4 text-indigo-600" />
                    <span>1. Tải File Ma Trận / Đặc Tả lên (.xlsx, .docx, .txt)</span>
                  </div>
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    {uploadedMatrixFileName
                      ? `📎 Đã tải ma trận: ${uploadedMatrixFileName}`
                      : 'Tải bảng Ma trận đề kiểm tra từ máy tính (Excel hoặc Word) để hệ thống tự động nhận diện cấu trúc.'}
                  </p>
                </div>
                <div>
                  <input
                    ref={matrixFileInputRef}
                    type="file"
                    accept=".xlsx,.xls,.docx,.doc,.txt,.csv"
                    onChange={handleMatrixFileUpload}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => matrixFileInputRef.current?.click()}
                    className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Chọn File Ma Trận (.xlsx / .docx)</span>
                  </button>
                </div>
              </div>

              {/* Upload Accompanying Exam / Question Bank File */}
              <div className="p-4 rounded-2xl bg-blue-50/70 border-2 border-dashed border-blue-300 flex flex-col justify-between gap-3">
                <div className="space-y-1">
                  <div className="text-xs font-black uppercase text-blue-950 flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-blue-600" />
                    <span>2. Tải File Đề / Câu hỏi nguồn lên (.docx, .txt)</span>
                  </div>
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    {uploadedSourceExamFileName
                      ? `📄 Đã tải đề nguồn: ${uploadedSourceExamFileName}`
                      : 'Tải kèm file Đề Word của giáo viên (hoặc để trống để hệ thống tự rút câu hỏi từ Ngân hàng KHTN 7 KNTT theo đúng Ma trận).'}
                  </p>
                </div>
                <div>
                  <input
                    ref={sourceExamFileInputRef}
                    type="file"
                    accept=".docx,.doc,.txt"
                    onChange={handleSourceExamFileUpload}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => sourceExamFileInputRef.current?.click()}
                    className="w-full py-2.5 px-4 rounded-xl bg-[#0d6efd] hover:bg-blue-700 text-white text-xs font-black flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Chọn File Đề Nguồn (.docx / .txt)</span>
                  </button>
                </div>
              </div>
            </div>

            {/* STEP 2: CONFIGURE MATRIX DETAILS & LESSON SCOPE */}
            <div className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <Table2 className="w-4 h-4 text-teal-600" />
                  <span>Cấu hình Chi tiết Ma Trận & Phạm Vi Bài Học (Lí · Hóa · Sinh)</span>
                </div>
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[11px] font-bold text-slate-500">Nạp nhanh mẫu:</span>
                  {(
                    [
                      { code: 'gk1', label: 'Mẫu GK1' },
                      { code: 'hk1', label: 'Mẫu HK1' },
                      { code: 'gk2', label: 'Mẫu GK2' },
                      { code: 'hk2', label: 'Mẫu HK2' },
                    ] as const
                  ).map((item) => (
                    <button
                      key={item.code}
                      type="button"
                      onClick={() => applyPeriodDefaults(item.code)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold cursor-pointer ${
                        periodCode === item.code
                          ? 'bg-slate-900 text-white'
                          : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                <div className="sm:col-span-6">
                  <label className="block text-[11px] font-black uppercase text-slate-700 mb-1">
                    Tên Ma trận & Đề kiểm tra:
                  </label>
                  <input
                    type="text"
                    value={matrixTitle}
                    onChange={(e) => setMatrixTitle(e.target.value)}
                    placeholder="VD: Đề Kiểm Tra Giữa Kì 1 KHTN 7 – Theo Ma Trận"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-bold text-slate-900"
                  />
                </div>
                <div className="sm:col-span-3">
                  <label className="block text-[11px] font-black uppercase text-slate-700 mb-1">
                    Kì kiểm tra:
                  </label>
                  <select
                    value={periodCode}
                    onChange={(e) =>
                      applyPeriodDefaults(e.target.value as 'gk1' | 'hk1' | 'gk2' | 'hk2')
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-bold text-slate-900"
                  >
                    <option value="gk1">Giữa Kì 1 (GK1)</option>
                    <option value="hk1">Cuối Học Kì 1 (HK1)</option>
                    <option value="gk2">Giữa Kì 2 (GK2)</option>
                    <option value="hk2">Cuối Học Kì 2 (HK2)</option>
                  </select>
                </div>
                <div className="sm:col-span-3">
                  <label className="block text-[11px] font-black uppercase text-slate-700 mb-1">
                    Số đề muốn sinh:
                  </label>
                  <select
                    value={paperBatchCount}
                    onChange={(e) => setPaperBatchCount(Number(e.target.value) as 1 | 4)}
                    className="w-full px-3 py-2 rounded-xl border border-emerald-400 bg-emerald-50 text-xs sm:text-sm font-black text-emerald-950"
                  >
                    <option value={1}>Sinh 1 Đề từ Ma trận</option>
                    <option value={4}>Sinh bộ 4 Đề (Mã 01–04)</option>
                  </select>
                </div>
              </div>

              {/* Scope per subject */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-black uppercase text-blue-800 mb-1">
                    Giới hạn Vật lí (Bài 8 – 20):
                  </label>
                  <input
                    type="text"
                    value={physicsScope}
                    onChange={(e) => setPhysicsScope(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-blue-200 bg-white text-xs font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-black uppercase text-amber-800 mb-1">
                    Giới hạn Hóa học (Bài 1 – 7):
                  </label>
                  <input
                    type="text"
                    value={chemistryScope}
                    onChange={(e) => setChemistryScope(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-amber-200 bg-white text-xs font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-black uppercase text-emerald-800 mb-1">
                    Giới hạn Sinh học (Bài 21 – 42):
                  </label>
                  <input
                    type="text"
                    value={biologyScope}
                    onChange={(e) => setBiologyScope(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-emerald-200 bg-white text-xs font-bold text-slate-900"
                  />
                </div>
              </div>

              {/* Interactive Matrix Quota Grid */}
              <div className="overflow-x-auto bg-white rounded-2xl border border-slate-200 p-3">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-[11px] font-black uppercase text-slate-600 bg-slate-50">
                      <th className="py-2.5 px-3">Phân môn</th>
                      <th className="py-2.5 px-2 text-center text-emerald-800">
                        TN Nhận biết (~30%)
                      </th>
                      <th className="py-2.5 px-2 text-center text-blue-800">
                        TN Thông hiểu (~30%)
                      </th>
                      <th className="py-2.5 px-2 text-center text-amber-800">
                        TN Vận dụng (~20%)
                      </th>
                      <th className="py-2.5 px-2 text-center text-rose-800">
                        TN Vận dụng cao (~20%)
                      </th>
                      <th className="py-2.5 px-2 text-center text-indigo-900">
                        Số câu Tự luận
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {(
                      [
                        {
                          sub: 'physics' as SubSubject,
                          name: '⚡ Vật lí 7',
                          essayNote: 'Vận dụng & Vận dụng cao',
                          essayVal: essayQuotas.physicsCount,
                          setEssay: (v: number) =>
                            setEssayQuotas((p) => ({ ...p, physicsCount: v })),
                        },
                        {
                          sub: 'chemistry' as SubSubject,
                          name: '🧪 Hóa học 7',
                          essayNote: 'Vận dụng & Vận dụng cao',
                          essayVal: essayQuotas.chemistryCount,
                          setEssay: (v: number) =>
                            setEssayQuotas((p) => ({ ...p, chemistryCount: v })),
                        },
                        {
                          sub: 'biology' as SubSubject,
                          name: '🌿 Sinh học 7',
                          essayNote: 'Thông hiểu & Vận dụng',
                          essayVal: essayQuotas.biologyCount,
                          setEssay: (v: number) =>
                            setEssayQuotas((p) => ({ ...p, biologyCount: v })),
                        },
                      ] as const
                    ).map((row) => {
                      const q = mcqQuotas[row.sub];
                      return (
                        <tr key={row.sub}>
                          <td className="py-2.5 px-3 font-black text-slate-900">
                            <div>{row.name}</div>
                            <div className="text-[10px] font-medium text-slate-500">
                              TL: {row.essayNote}
                            </div>
                          </td>
                          {(
                            ['nhanBiet', 'thongHieu', 'vanDung', 'vanDungCao'] as const
                          ).map((lvlKey) => (
                            <td key={lvlKey} className="py-2 px-2 text-center">
                              <input
                                type="number"
                                min={0}
                                max={15}
                                value={q[lvlKey]}
                                onChange={(e) =>
                                  updateMcqCell(row.sub, lvlKey, Number(e.target.value) || 0)
                                }
                                className="w-16 px-2 py-1.5 rounded-lg border border-slate-300 text-center font-mono font-bold text-slate-900"
                              />
                            </td>
                          ))}
                          <td className="py-2 px-2 text-center">
                            <input
                              type="number"
                              min={0}
                              max={10}
                              value={row.essayVal}
                              onChange={(e) =>
                                row.setEssay(Math.max(0, Number(e.target.value) || 0))
                              }
                              className="w-16 px-2 py-1.5 rounded-lg border border-indigo-300 bg-indigo-50/50 text-center font-mono font-black text-indigo-950"
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot>
                    <tr className="border-t-2 border-slate-200 bg-slate-50 font-black text-slate-900">
                      <td className="py-2.5 px-3">
                        TỔNG MA TRẬN ({totalMcqs} TN + {totalEssays} TL)
                      </td>
                      <td className="py-2.5 px-2 text-center text-emerald-700">
                        {totalNb} câu ({totalMcqs > 0 ? Math.round((totalNb / totalMcqs) * 100) : 0}%)
                      </td>
                      <td className="py-2.5 px-2 text-center text-blue-700">
                        {totalTh} câu ({totalMcqs > 0 ? Math.round((totalTh / totalMcqs) * 100) : 0}%)
                      </td>
                      <td className="py-2.5 px-2 text-center text-amber-700">
                        {totalVd} câu ({totalMcqs > 0 ? Math.round((totalVd / totalMcqs) * 100) : 0}%)
                      </td>
                      <td className="py-2.5 px-2 text-center text-rose-700">
                        {totalVdc} câu ({totalMcqs > 0 ? Math.round((totalVdc / totalMcqs) * 100) : 0}%)
                      </td>
                      <td className="py-2.5 px-2 text-center text-indigo-700">
                        {totalEssays} câu TL (3,0đ)
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

            {/* STEP 3: SAVED MATRICES BANK */}
            <div className="space-y-2">
              <div className="text-xs font-black uppercase text-slate-600 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-indigo-600" />
                <span>Kho Ma Trận Đã Lưu ({savedMatrices.length} Ma trận — Bấm để nạp hoặc sinh đề):</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 max-h-44 overflow-y-auto pr-1">
                {savedMatrices.map((m) => {
                  const mMcqTotal =
                    m.mcqQuotas.physics.nhanBiet +
                    m.mcqQuotas.physics.thongHieu +
                    m.mcqQuotas.physics.vanDung +
                    m.mcqQuotas.physics.vanDungCao +
                    m.mcqQuotas.chemistry.nhanBiet +
                    m.mcqQuotas.chemistry.thongHieu +
                    m.mcqQuotas.chemistry.vanDung +
                    m.mcqQuotas.chemistry.vanDungCao +
                    m.mcqQuotas.biology.nhanBiet +
                    m.mcqQuotas.biology.thongHieu +
                    m.mcqQuotas.biology.vanDung +
                    m.mcqQuotas.biology.vanDungCao;
                  const mEssayTotal =
                    m.essayQuotas.physicsCount +
                    m.essayQuotas.chemistryCount +
                    m.essayQuotas.biologyCount;

                  return (
                    <div
                      key={m.id}
                      className="p-3 rounded-2xl border border-slate-200 bg-slate-50/70 hover:bg-white flex items-center justify-between gap-2 transition"
                    >
                      <div className="min-w-0">
                        <div className="text-xs font-black text-slate-900 truncate">
                          {m.title}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate">
                          {m.scopeSummary.physics} · {m.scopeSummary.chemistry} ·{' '}
                          {m.scopeSummary.biology} ({mMcqTotal} TN + {mEssayTotal} TL)
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleLoadSavedMatrixIntoEditor(m)}
                          className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-[11px] font-extrabold cursor-pointer"
                        >
                          Nạp
                        </button>
                        {!m.id.startsWith('matrix-default-') && (
                          <button
                            type="button"
                            onClick={() => onDeleteMatrix(m.id)}
                            className="p-1 rounded-lg text-rose-500 hover:bg-rose-50 cursor-pointer"
                            title="Xóa ma trận này"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* STEP 4: PRIMARY ACTION BUTTONS (LƯU MA TRẬN / SINH ĐỀ & LƯU ĐỀ / MỞ CHO HỌC SINH LÀM) */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-200">
              <button
                type="button"
                onClick={handleSaveMatrixOnly}
                className="px-4 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-black flex items-center gap-2 shadow-sm transition cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>💾 Lưu Ma Trận</span>
              </button>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => handleGenerateAndSaveBoth(false)}
                  className="px-4 py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-black flex items-center gap-2 shadow-sm transition cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>
                    ⚡ Sinh {paperBatchCount} Đề Theo Ma Trận & Lưu Đề
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => handleGenerateAndSaveBoth(true)}
                  className="px-5 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-black flex items-center gap-2 shadow-md transition cursor-pointer"
                >
                  <Play className="w-4 h-4" />
                  <span>
                    🎓 Lưu Đề & Mở Cho Học Sinh Làm Ngay
                  </span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
