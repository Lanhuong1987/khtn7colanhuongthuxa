import React, { useState } from 'react';
import { Search, CheckCircle2, Circle, Calculator, ChevronDown, ChevronUp } from 'lucide-react';
import { THEORY_TOPICS, SUBJECT_LABELS, SubSubject } from '../data/khtn7Data';

interface TheoryViewProps {
  masteredTopicIds: string[];
  onToggleMastered: (topicId: string) => void;
}

export const TheoryView: React.FC<TheoryViewProps> = ({
  masteredTopicIds,
  onToggleMastered,
}) => {
  const [selectedSubject, setSelectedSubject] = useState<'all' | SubSubject>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [revealedQuickChecks, setRevealedQuickChecks] = useState<Record<string, boolean>>({});
  const [showCalculators, setShowCalculators] = useState<boolean>(true);

  // Quick Calculator 1: Speed v = s / t
  const [calcDistanceKm, setCalcDistanceKm] = useState<number>(45);
  const [calcTimeHours, setCalcTimeHours] = useState<number>(1.25);

  // Quick Calculator 2: Valence Formula Builder (AxBy)
  const [valenceA, setValenceA] = useState<number>(3); // e.g., Al (III)
  const [valenceB, setValenceB] = useState<number>(2); // e.g., O (II)
  const [massA, setMassA] = useState<number>(27);
  const [massB, setMassB] = useState<number>(16);

  const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b));
  const commonDivisor = gcd(valenceA, valenceB);
  const subX = valenceB / commonDivisor;
  const subY = valenceA / commonDivisor;
  const totalMolecularMass = subX * massA + subY * massB;

  const filteredTopics = THEORY_TOPICS.filter((topic) => {
    const matchesSubject = selectedSubject === 'all' || topic.subject === selectedSubject;
    const q = searchQuery.trim().toLowerCase();
    const matchesQuery =
      !q ||
      topic.title.toLowerCase().includes(q) ||
      topic.summary.toLowerCase().includes(q) ||
      topic.coreFormula.toLowerCase().includes(q) ||
      topic.keyPoints.some((pt) => pt.toLowerCase().includes(q));
    return matchesSubject && matchesQuery;
  });

  const toggleQuickCheck = (id: string) => {
    setRevealedQuickChecks((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <section className="space-y-8">
      {/* Header & Filter Controls */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 pb-5 border-b border-slate-200">
        <div>
          <p className="text-xs font-medium text-slate-500">
            Hệ thống kiến thức cốt lõi · Công thức chuẩn · Ví dụ vận dụng thực tế
          </p>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 mt-1">
            Sổ tay Lý thuyết & Công cụ Tính nhanh KHTN 7
          </h2>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Interactive Filter Tabs */}
          <div className="inline-flex items-center gap-1 p-1 bg-slate-200/80 rounded-xl">
            <button
              type="button"
              onClick={() => setSelectedSubject('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                selectedSubject === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Tất cả ({THEORY_TOPICS.length})
            </button>
            <button
              type="button"
              onClick={() => setSelectedSubject('chemistry')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                selectedSubject === 'chemistry'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Hóa học 7
            </button>
            <button
              type="button"
              onClick={() => setSelectedSubject('physics')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                selectedSubject === 'physics'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Vật lí 7
            </button>
            <button
              type="button"
              onClick={() => setSelectedSubject('biology')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                selectedSubject === 'biology'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Sinh học 7
            </button>
          </div>

          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Tìm công thức, khái niệm..."
              className="pl-9 pr-4 py-1.5 text-xs bg-white border border-slate-200 rounded-xl text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-blue-600"
            />
          </div>
        </div>
      </div>

      {/* Collapsible Interactive Quick-Calculators */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Calculator className="w-5 h-5 text-blue-600" />
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Bàn tính Công thức Tự động (Vật lí & Hóa học 7)
              </h3>
              <p className="text-xs text-slate-500">
                Kiểm tra nhanh kết quả bài tập tốc độ chuyển động và quy tắc hóa trị ngay khi ôn lý thuyết.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowCalculators((prev) => !prev)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 rounded-lg hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0"
          >
            <span>{showCalculators ? 'Thu gọn bàn tính' : 'Mở bàn tính'}</span>
            {showCalculators ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>

        {showCalculators && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-5 pt-5 border-t border-slate-100">
            {/* Speed Calculator */}
            <div className="space-y-4">
              <div className="text-xs font-semibold text-slate-900">
                01. Quy đổi Tốc độ – Quãng đường – Thời gian (v = s / t)
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-600 mb-1">Quãng đường s (km):</label>
                  <input
                    type="number"
                    min={0.1}
                    step={0.5}
                    value={calcDistanceKm}
                    onChange={(e) => setCalcDistanceKm(Math.max(0, Number(e.target.value)))}
                    className="w-full px-3 py-2 text-sm font-mono bg-slate-50 border border-slate-200 rounded-lg tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-600 mb-1">Thời gian t (giờ):</label>
                  <input
                    type="number"
                    min={0.05}
                    step={0.25}
                    value={calcTimeHours}
                    onChange={(e) => setCalcTimeHours(Math.max(0.01, Number(e.target.value)))}
                    className="w-full px-3 py-2 text-sm font-mono bg-slate-50 border border-slate-200 rounded-lg tabular-nums"
                  />
                </div>
              </div>
              <div className="p-3.5 bg-slate-900 text-white rounded-xl flex items-center justify-between text-xs font-mono">
                <span>
                  v = {calcDistanceKm} / {calcTimeHours} ={' '}
                  <strong className="text-sky-400 text-sm tabular-nums">
                    {(calcDistanceKm / calcTimeHours).toFixed(2)} km/h
                  </strong>
                </span>
                <span className="text-emerald-400 font-bold tabular-nums">
                  ≈ {(calcDistanceKm / calcTimeHours / 3.6).toFixed(2)} m/s
                </span>
              </div>
            </div>

            {/* Valence & Molecular Mass Calculator */}
            <div className="space-y-4">
              <div className="text-xs font-semibold text-slate-900">
                02. Lập CTHH AₓBᵧ & Tính Khối lượng phân tử (x · a = y · b)
              </div>
              <div className="grid grid-cols-4 gap-2.5">
                <div>
                  <label className="block text-[11px] text-slate-600 mb-1">Hóa trị A (a):</label>
                  <select
                    value={valenceA}
                    onChange={(e) => setValenceA(Number(e.target.value))}
                    className="w-full px-2.5 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    {[1, 2, 3, 4, 5, 6].map((v) => (
                      <option key={v} value={v}>
                        Hóa trị {v}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-slate-600 mb-1">KLNT A (amu):</label>
                  <input
                    type="number"
                    min={1}
                    value={massA}
                    onChange={(e) => setMassA(Math.max(1, Number(e.target.value)))}
                    className="w-full px-2.5 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-600 mb-1">Hóa trị B (b):</label>
                  <select
                    value={valenceB}
                    onChange={(e) => setValenceB(Number(e.target.value))}
                    className="w-full px-2.5 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    {[1, 2, 3, 4].map((v) => (
                      <option key={v} value={v}>
                        Hóa trị {v}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-slate-600 mb-1">KLNT B (amu):</label>
                  <input
                    type="number"
                    min={1}
                    value={massB}
                    onChange={(e) => setMassB(Math.max(1, Number(e.target.value)))}
                    className="w-full px-2.5 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg tabular-nums"
                  />
                </div>
              </div>
              <div className="p-3.5 bg-slate-900 text-white rounded-xl flex items-center justify-between text-xs font-mono">
                <span>
                  Chỉ số tối giản: x = {subX}, y = {subY} ⇒{' '}
                  <strong className="text-amber-300 text-sm">
                    A{subX > 1 ? subX : ''}B{subY > 1 ? subY : ''}
                  </strong>
                </span>
                <span className="text-emerald-400 font-bold tabular-nums">
                  KLPT = {totalMolecularMass} amu (%A = {((subX * massA * 100) / totalMolecularMass).toFixed(1)}%)
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Topic Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredTopics.map((topic) => {
          const isMastered = masteredTopicIds.includes(topic.id);
          const isRevealed = !!revealedQuickChecks[topic.id];
          const subjectMeta = SUBJECT_LABELS[topic.subject];

          return (
            <article
              key={topic.id}
              className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between space-y-5"
            >
              <div className="space-y-4">
                {/* Clean unboxed metadata with typographic separators (Zero-Pill Rule) */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span className="font-semibold text-slate-800">{subjectMeta.name}</span>
                    <span aria-hidden="true">·</span>
                    <span>{topic.chapterCode}</span>
                    <span aria-hidden="true">·</span>
                    <span>Thời lượng {topic.duration}</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => onToggleMastered(topic.id)}
                    className={`flex items-center gap-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                      isMastered ? 'text-emerald-700' : 'text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    {isMastered ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Đã nắm vững</span>
                      </>
                    ) : (
                      <>
                        <Circle className="w-4 h-4 text-slate-400" />
                        <span>Đánh dấu đã học</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Title & Formula */}
                <div>
                  <h3 className="text-lg font-bold text-slate-900 leading-snug">
                    {topic.title}
                  </h3>
                  <div className="mt-2 px-3.5 py-2 bg-slate-900 text-sky-300 font-mono text-xs font-semibold rounded-xl">
                    {topic.coreFormula}
                  </div>
                </div>

                {/* Summary & Key Bullet Points */}
                <p className="text-sm text-slate-600 leading-relaxed">
                  {topic.summary}
                </p>

                <ul className="space-y-2 text-xs text-slate-700 border-t border-slate-100 pt-3">
                  {topic.keyPoints.map((pt, idx) => (
                    <li key={idx} className="leading-relaxed">
                      <span className="font-mono font-bold text-slate-900 mr-1.5">0{idx + 1}.</span>
                      {pt}
                    </li>
                  ))}
                </ul>

                {/* Practical Example */}
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 text-xs text-slate-700 leading-relaxed">
                  <strong className="text-slate-900">Liên hệ thực tiễn: </strong>
                  {topic.practicalExample}
                </div>
              </div>

              {/* Interactive Self-Check Question */}
              <div className="pt-4 border-t border-slate-100 space-y-3">
                <div className="text-xs font-semibold text-slate-900">
                  Câu hỏi tự kiểm tra nhanh:
                </div>
                <p className="text-xs text-slate-700 leading-relaxed">
                  {topic.quickCheckQuestion.prompt}
                </p>
                <button
                  type="button"
                  onClick={() => toggleQuickCheck(topic.id)}
                  className="px-3.5 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  {isRevealed ? 'Ẩn lời giải chi tiết' : 'Xem đáp án & hướng dẫn giải'}
                </button>

                {isRevealed && (
                  <div className="p-3.5 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs space-y-1">
                    <div className="font-bold text-emerald-900">
                      ● Đáp án: {topic.quickCheckQuestion.answer}
                    </div>
                    <p className="text-emerald-800 leading-relaxed">
                      {topic.quickCheckQuestion.explanation}
                    </p>
                  </div>
                )}
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
};
