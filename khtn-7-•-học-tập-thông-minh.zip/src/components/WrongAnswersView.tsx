import React, { useState, useEffect } from 'react';
import {
  RotateCcw,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { ALL_KNTT_LESSONS } from '../data/allLessons';
import { SubSubject } from '../data/khtn7Data';

interface WrongAnswersViewProps {
  onGoToLesson: (lessonId: string) => void;
}

export const WrongAnswersView: React.FC<WrongAnswersViewProps> = ({ onGoToLesson }) => {
  const [mcqAnswers, setMcqAnswers] = useState<Record<string, number>>(() => {
    try {
      const raw = localStorage.getItem('khtn7_kntt_mcq_v2');
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  });

  const [tfAnswers, setTfAnswers] = useState<Record<string, boolean>>(() => {
    try {
      const raw = localStorage.getItem('khtn7_kntt_tf_v2');
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  });

  const [subjectFilter, setSubjectFilter] = useState<'all' | SubSubject>('all');
  // Track retry answers in this view so student can fix their mistakes interactively
  const [retryMcq, setRetryMcq] = useState<Record<string, number>>({});
  const [fixedKeys, setFixedKeys] = useState<string[]>([]);

  useEffect(() => {
    try {
      localStorage.setItem('khtn7_kntt_mcq_v2', JSON.stringify(mcqAnswers));
    } catch {
      // ignore
    }
  }, [mcqAnswers]);

  useEffect(() => {
    try {
      localStorage.setItem('khtn7_kntt_tf_v2', JSON.stringify(tfAnswers));
    } catch {
      // ignore
    }
  }, [tfAnswers]);

  // Collect all wrong MCQs across all 30 lessons
  const wrongMcqItems: Array<{
    key: string;
    lessonId: string;
    lessonNumber: number;
    lessonTitle: string;
    subject: SubSubject;
    question: string;
    options: [string, string, string, string];
    correctIndex: number;
    userWrongIndex: number;
    explanation: string;
  }> = [];

  // Collect all wrong TF statements
  const wrongTfItems: Array<{
    key: string;
    lessonId: string;
    lessonNumber: number;
    lessonTitle: string;
    subject: SubSubject;
    stem: string;
    statementId: string;
    statementText: string;
    isTrue: boolean;
    userChoice: boolean;
    explanation: string;
  }> = [];

  ALL_KNTT_LESSONS.forEach((lesson) => {
    if (subjectFilter !== 'all' && lesson.subject !== subjectFilter) return;

    lesson.mcqs.forEach((q) => {
      const key = `${lesson.id}:${q.id}`;
      const ans = mcqAnswers[key];
      if (ans !== undefined && ans !== q.correctIndex) {
        wrongMcqItems.push({
          key,
          lessonId: lesson.id,
          lessonNumber: lesson.lessonNumber,
          lessonTitle: lesson.title,
          subject: lesson.subject,
          question: q.question,
          options: q.options,
          correctIndex: q.correctIndex,
          userWrongIndex: ans,
          explanation: q.explanation,
        });
      }
    });

    lesson.trueFalseList.forEach((tf) => {
      tf.statements.forEach((st) => {
        const key = `${lesson.id}:${tf.id}:${st.id}`;
        const ans = tfAnswers[key];
        if (ans !== undefined && ans !== st.isTrue) {
          wrongTfItems.push({
            key,
            lessonId: lesson.id,
            lessonNumber: lesson.lessonNumber,
            lessonTitle: lesson.title,
            subject: lesson.subject,
            stem: tf.stem,
            statementId: st.id,
            statementText: st.text,
            isTrue: st.isTrue,
            userChoice: ans,
            explanation: st.explanation,
          });
        }
      });
    });
  });

  // Curated "Tricky Questions" bank if student hasn't made any mistakes yet
  const trickySampleMcqs = ALL_KNTT_LESSONS.slice(0, 6).map((lesson) => ({
    lessonId: lesson.id,
    lessonNumber: lesson.lessonNumber,
    lessonTitle: lesson.title,
    subject: lesson.subject,
    mcq: lesson.mcqs[lesson.mcqs.length - 1],
  }));

  const handleFixMcq = (key: string, chosenIdx: number, correctIdx: number) => {
    setRetryMcq((prev) => ({ ...prev, [key]: chosenIdx }));
    if (chosenIdx === correctIdx) {
      setMcqAnswers((prev) => ({ ...prev, [key]: chosenIdx }));
      if (!fixedKeys.includes(key)) {
        setFixedKeys((prev) => [...prev, key]);
      }
    }
  };

  const handleFixTf = (key: string, correctVal: boolean) => {
    setTfAnswers((prev) => ({ ...prev, [key]: correctVal }));
    if (!fixedKeys.includes(key)) {
      setFixedKeys((prev) => [...prev, key]);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#111c38] via-[#132a46] to-[#0b383d] rounded-2xl p-6 text-white shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-mono uppercase tracking-wider text-amber-300 font-bold">
              HỆ THỐNG KHẮC PHỤC LỖI SAI THÔNG MINH · KHTN 7 KNTT
            </span>
            <h2 className="text-2xl font-extrabold mt-1">
              Ôn tập &amp; Làm lại các câu trả lời sai
            </h2>
            <p className="text-sm text-slate-200 mt-1 max-w-2xl">
              Tự động thống kê mọi câu Trắc nghiệm và mệnh đề Đúng–Sai bạn đã chọn nhầm trong 30 bài học. Khi bạn chọn lại đáp án đúng, hệ thống sẽ cập nhật điểm tiến độ ngay lập tức.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="bg-white/10 border border-white/15 rounded-xl px-4 py-3 text-center">
              <div className="text-[11px] font-mono uppercase text-rose-300">Câu TN đang sai</div>
              <div className="text-2xl font-extrabold font-mono tabular-nums text-white">
                {wrongMcqItems.length}
              </div>
            </div>
            <div className="bg-white/10 border border-white/15 rounded-xl px-4 py-3 text-center">
              <div className="text-[11px] font-mono uppercase text-amber-300">Ý Đ/S đang sai</div>
              <div className="text-2xl font-extrabold font-mono tabular-nums text-white">
                {wrongTfItems.length}
              </div>
            </div>
            <div className="bg-emerald-500/20 border border-emerald-400/30 rounded-xl px-4 py-3 text-center">
              <div className="text-[11px] font-mono uppercase text-emerald-300">Đã sửa đúng</div>
              <div className="text-2xl font-extrabold font-mono tabular-nums text-emerald-300">
                {fixedKeys.length}
              </div>
            </div>
          </div>
        </div>

        {/* Filter by Subject */}
        <div className="flex flex-wrap items-center gap-2 mt-5 pt-4 border-t border-white/10">
          {(
            [
              { id: 'all', label: 'Tất cả phân môn' },
              { id: 'chemistry', label: 'Hóa học 7 (Bài 2–7)' },
              { id: 'physics', label: 'Vật lí 7 (Bài 8–21)' },
              { id: 'biology', label: 'Sinh học 7 (Bài 22–38)' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSubjectFilter(tab.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                subjectFilter === tab.id
                  ? 'bg-emerald-400 text-slate-950'
                  : 'bg-white/10 text-slate-200 hover:bg-white/20'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Wrong MCQs Section */}
      {wrongMcqItems.length === 0 && wrongTfItems.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-200">
            <div className="flex items-start gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  Tuyệt vời! Hiện tại bạn không có câu trả lời sai nào tồn đọng
                </h3>
                <p className="text-sm text-slate-600 mt-0.5">
                  Dưới đây là <strong>6 câu hỏi vận dụng hay nhầm lẫn nhất</strong> trong chương trình KHTN 7 KNTT để bạn thử sức nhanh:
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {trickySampleMcqs.map(({ lessonId, lessonTitle, mcq }) => {
              const key = `${lessonId}:${mcq.id}`;
              const userAns = mcqAnswers[key];
              const isAnswered = userAns !== undefined;
              const isCorrect = userAns === mcq.correctIndex;

              return (
                <div
                  key={key}
                  className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 flex flex-col justify-between space-y-3"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-mono font-bold text-blue-700">
                        {lessonTitle}
                      </span>
                      <button
                        onClick={() => onGoToLesson(lessonId)}
                        className="inline-flex items-center gap-1 text-xs font-semibold text-slate-600 hover:text-blue-600 cursor-pointer"
                      >
                        Mở bài học <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <p className="text-sm font-bold text-slate-900 leading-snug">
                      {mcq.question}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 gap-2">
                    {mcq.options.map((opt, idx) => {
                      const letter = ['A', 'B', 'C', 'D'][idx];
                      const selected = userAns === idx;
                      const correct = mcq.correctIndex === idx;

                      let cls = 'bg-white border-slate-200 text-slate-800 hover:bg-slate-100';
                      if (isAnswered) {
                        if (correct) cls = 'bg-emerald-50 border-emerald-500 text-emerald-950 font-semibold';
                        else if (selected) cls = 'bg-rose-50 border-rose-400 text-rose-900 line-through';
                      }

                      return (
                        <button
                          key={idx}
                          onClick={() =>
                            setMcqAnswers((prev) => ({ ...prev, [key]: idx }))
                          }
                          className={`p-2.5 rounded-lg border text-left text-xs transition-all cursor-pointer flex items-center gap-2 ${cls}`}
                        >
                          <span className="w-5 h-5 rounded-sm bg-slate-100 border border-slate-300 font-mono font-bold flex items-center justify-center shrink-0">
                            {letter}
                          </span>
                          <span>{opt}</span>
                        </button>
                      );
                    })}
                  </div>

                  {isAnswered && (
                    <div
                      className={`text-xs p-2.5 rounded-lg border ${
                        isCorrect
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                          : 'bg-rose-50 border-rose-200 text-rose-900'
                      }`}
                    >
                      <strong>Giải thích:</strong> {mcq.explanation}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {wrongMcqItems.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-rose-600" />
                Danh sách câu Trắc nghiệm cần làm lại ({wrongMcqItems.length} câu)
              </h3>

              {wrongMcqItems.map((item, idx) => {
                const retryChoice = retryMcq[item.key];
                return (
                  <article
                    key={item.key}
                    className="bg-white rounded-2xl border border-rose-200 p-5 shadow-xs space-y-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-1 rounded-md bg-rose-600 text-white font-mono text-xs font-bold">
                          Câu sai #{idx + 1}
                        </span>
                        <span className="text-xs font-bold text-slate-700">
                          {item.lessonTitle}
                        </span>
                      </div>
                      <button
                        onClick={() => onGoToLesson(item.lessonId)}
                        className="text-xs font-semibold text-blue-600 hover:underline cursor-pointer"
                      >
                        Về bài học gốc →
                      </button>
                    </div>

                    <p className="text-base font-bold text-slate-900">
                      {item.question}
                    </p>

                    <div className="text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2">
                      Lựa chọn trước đó của bạn:{' '}
                      <strong>
                        {['A', 'B', 'C', 'D'][item.userWrongIndex]}.{' '}
                        {item.options[item.userWrongIndex]}
                      </strong>{' '}
                      (Chưa chính xác — Hãy chọn lại đáp án đúng bên dưới để khắc phục!)
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {item.options.map((opt, optIdx) => {
                        const letter = ['A', 'B', 'C', 'D'][optIdx];
                        const isPrevWrong = optIdx === item.userWrongIndex;
                        return (
                          <button
                            key={optIdx}
                            onClick={() =>
                              handleFixMcq(item.key, optIdx, item.correctIndex)
                            }
                            className={`p-3 rounded-xl border text-left text-sm transition-all cursor-pointer flex items-start gap-2.5 ${
                              isPrevWrong && retryChoice === undefined
                                ? 'bg-rose-50/70 border-rose-300 text-rose-900 line-through'
                                : 'bg-slate-50 hover:bg-emerald-50 hover:border-emerald-400 border-slate-200 text-slate-800'
                            }`}
                          >
                            <span className="w-6 h-6 rounded-md bg-white border border-slate-300 font-mono text-xs font-bold flex items-center justify-center shrink-0">
                              {letter}
                            </span>
                            <span>{opt}</span>
                          </button>
                        );
                      })}
                    </div>

                    <div className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200">
                      <strong className="text-slate-900">Gợi ý &amp; Giải thích:</strong>{' '}
                      {item.explanation}
                    </div>
                  </article>
                );
              })}
            </div>
          )}

          {wrongTfItems.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <RotateCcw className="w-5 h-5 text-amber-600" />
                Các mệnh đề Đúng – Sai cần khắc phục ({wrongTfItems.length} ý)
              </h3>

              {wrongTfItems.map((item) => (
                <div
                  key={item.key}
                  className="bg-white rounded-2xl border border-amber-200 p-5 shadow-xs space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-amber-800">
                      {item.lessonTitle} · Ý {item.statementId})
                    </span>
                    <button
                      onClick={() => handleFixTf(item.key, item.isTrue)}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer"
                    >
                      Sửa lại thành: {item.isTrue ? 'ĐÚNG' : 'SAI'}
                    </button>
                  </div>
                  <p className="text-xs text-slate-500">{item.stem}</p>
                  <p className="text-sm font-bold text-slate-900">
                    {item.statementId}) {item.statementText}
                  </p>
                  <div className="text-xs text-slate-700 bg-amber-50/80 border border-amber-200 rounded-lg p-3">
                    <strong>Đáp án đúng là {item.isTrue ? 'ĐÚNG' : 'SAI'}:</strong>{' '}
                    {item.explanation}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
