import React, { useState, useRef, useEffect } from 'react';
import {
  CheckCircle2,
  XCircle,
  RotateCcw,
  Camera,
  ClipboardPaste,
  ImagePlus,
  Trash2,
  Eye,
  EyeOff,
  FileText,
  Sparkles,
  BookOpen,
  Check,
  X,
  ZoomIn,
  ChevronRight,
  SlidersHorizontal,
  Home,
  AlertCircle,
  ArrowUpRight,
  Search,
  Filter,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ALL_KNTT_LESSONS, KNTT_PDF_DOCUMENTS, LESSON_BANK_STATS } from '../data/allLessons';
import { KhtnLesson, EssaySubmission } from '../data/lessonTypes';
import { SubSubject } from '../data/khtn7Data';
import { soundEngine } from '../utils/gameSoundEngine';

interface PracticeViewProps {
  initialLessonId?: string;
  onBackToHome?: () => void;
  onProgressUpdate: (stats: {
    mcqAnswered: number;
    mcqCorrect: number;
    tfAnswered: number;
    tfCorrect: number;
    essayCompleted: number;
  }) => void;
}

type SubjectFilter = 'all' | SubSubject;
type ExerciseSection = 'all' | 'mcq' | 'tf' | 'essay' | 'pdf';

const SCIENCE_SYMBOLS = [
  '→',
  '⇌',
  '°C',
  'amu',
  'v = s / t',
  's = v · t',
  't = s / v',
  'f = N / t',
  "i = i'",
  'H₂O',
  'CO₂',
  'O₂',
  'N₂',
  'H₂',
  'SO₄²⁻',
  'NO₃⁻',
  'CO₃²⁻',
  'PO₄³⁻',
  'OH⁻',
  'NH₄⁺',
  '₁',
  '₂',
  '₃',
  '₄',
  '⁺',
  '²⁺',
  '³⁺',
  '⁻',
  '²⁻',
];

const SUBJECT_META: Record<
  SubSubject,
  { label: string; shortLabel: string; accentText: string; accentBg: string; accentBorder: string }
> = {
  chemistry: {
    label: 'Hóa học 7 (Chất & Sự biến đổi)',
    shortLabel: 'HÓA HỌC 7',
    accentText: 'text-amber-700',
    accentBg: 'bg-amber-50',
    accentBorder: 'border-amber-300',
  },
  physics: {
    label: 'Vật lí 7 (Năng lượng & Sự biến đổi)',
    shortLabel: 'VẬT LÍ 7',
    accentText: 'text-blue-700',
    accentBg: 'bg-blue-50',
    accentBorder: 'border-blue-300',
  },
  biology: {
    label: 'Sinh học 7 (Vật sống)',
    shortLabel: 'SINH HỌC 7',
    accentText: 'text-emerald-700',
    accentBg: 'bg-emerald-50',
    accentBorder: 'border-emerald-300',
  },
};

export const PracticeView: React.FC<PracticeViewProps> = ({
  initialLessonId,
  onBackToHome,
  onProgressUpdate,
}) => {
  const [subjectFilter, setSubjectFilter] = useState<SubjectFilter>('all');
  const [chapterFilter, setChapterFilter] = useState<string>('all');
  const [lessonSearchQuery, setLessonSearchQuery] = useState<string>('');
  const [completionStatusFilter, setCompletionStatusFilter] = useState<
    'all' | 'incomplete' | 'completed'
  >('all');
  const [selectedLessonId, setSelectedLessonId] = useState<string>(
    initialLessonId || ALL_KNTT_LESSONS[0].id
  );
  const [activeSection, setActiveSection] = useState<ExerciseSection>('all');
  const [highlightedCardId, setHighlightedCardId] = useState<string | null>(null);

  useEffect(() => {
    if (initialLessonId && ALL_KNTT_LESSONS.some((l) => l.id === initialLessonId)) {
      setSelectedLessonId(initialLessonId);
      setSubjectFilter('all');
      setChapterFilter('all');
    }
  }, [initialLessonId]);

  // MCQ Answers: key = `${lessonId}:${mcqId}` -> option index (0-3)
  const [mcqAnswers, setMcqAnswers] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem('khtn7_kntt_mcq_v2');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // True/False Answers: key = `${lessonId}:${tfId}:${statementId}` -> boolean
  const [tfAnswers, setTfAnswers] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem('khtn7_kntt_tf_v2');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Track which TF items have "shown explanation" toggled
  const [tfRevealed, setTfRevealed] = useState<Record<string, boolean>>({});

  // Essay Submissions: key = `${lessonId}:${essayId}` -> EssaySubmission
  const [essaySubmissions, setEssaySubmissions] = useState<Record<string, EssaySubmission>>(() => {
    try {
      const saved = localStorage.getItem('khtn7_kntt_essay_v2');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // UI state for MCQ filtering inside a lesson
  const [mcqFilterMode, setMcqFilterMode] = useState<'all' | 'unanswered' | 'wrong'>('all');

  // UI state for active textarea ref per essay item (for inserting scientific symbols)
  const textareaRefs = useRef<Record<string, HTMLTextAreaElement | null>>({});

  // Hidden file inputs for mobile camera capture and gallery upload
  const cameraInputRefs = useRef<Record<string, HTMLInputElement | null>>({});
  const galleryInputRefs = useRef<Record<string, HTMLInputElement | null>>({});

  // Toast / status message per essay card
  const [essayStatusMsg, setEssayStatusMsg] = useState<Record<string, string>>({});

  // Lightbox image preview modal
  const [lightboxImage, setLightboxImage] = useState<{ url: string; title: string } | null>(null);

  // Live Camera Modal state (for desktop/tablet/phone direct browser camera capture)
  const [liveCameraTargetKey, setLiveCameraTargetKey] = useState<string | null>(null);
  const [liveCameraError, setLiveCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  // Save to localStorage & notify parent stats whenever answers change
  useEffect(() => {
    try {
      localStorage.setItem('khtn7_kntt_mcq_v2', JSON.stringify(mcqAnswers));
    } catch {
      // ignore quota errors
    }
  }, [mcqAnswers]);

  useEffect(() => {
    try {
      localStorage.setItem('khtn7_kntt_tf_v2', JSON.stringify(tfAnswers));
    } catch {
      // ignore quota errors
    }
  }, [tfAnswers]);

  useEffect(() => {
    try {
      localStorage.setItem('khtn7_kntt_essay_v2', JSON.stringify(essaySubmissions));
    } catch {
      // ignore quota errors if many high-res photos are stored
    }
  }, [essaySubmissions]);

  // Compute global statistics and report to parent
  useEffect(() => {
    let mcqAnswered = 0;
    let mcqCorrect = 0;
    let tfAnswered = 0;
    let tfCorrect = 0;
    let essayCompleted = 0;

    ALL_KNTT_LESSONS.forEach((lesson) => {
      lesson.mcqs.forEach((q) => {
        const key = `${lesson.id}:${q.id}`;
        if (mcqAnswers[key] !== undefined) {
          mcqAnswered += 1;
          if (mcqAnswers[key] === q.correctIndex) {
            mcqCorrect += 1;
          }
        }
      });

      lesson.trueFalseList.forEach((tf) => {
        tf.statements.forEach((st) => {
          const key = `${lesson.id}:${tf.id}:${st.id}`;
          if (tfAnswers[key] !== undefined) {
            tfAnswered += 1;
            if (tfAnswers[key] === st.isTrue) {
              tfCorrect += 1;
            }
          }
        });
      });

      lesson.essays.forEach((es) => {
        const key = `${lesson.id}:${es.id}`;
        const sub = essaySubmissions[key];
        if (sub && (sub.textAnswer.trim().length > 0 || sub.attachedImages.length > 0)) {
          essayCompleted += 1;
        }
      });
    });

    onProgressUpdate({
      mcqAnswered,
      mcqCorrect,
      tfAnswered,
      tfCorrect,
      essayCompleted,
    });
  }, [mcqAnswers, tfAnswers, essaySubmissions, onProgressUpdate]);

  // Helper to check if a lesson is 100% completed
  const isLessonFullyCompleted = (lesson: KhtnLesson): boolean => {
    const allMcqDone = lesson.mcqs.every(
      (q) => mcqAnswers[`${lesson.id}:${q.id}`] !== undefined
    );
    const allTfDone = lesson.trueFalseList.every((tf) =>
      tf.statements.every(
        (st) => tfAnswers[`${lesson.id}:${tf.id}:${st.id}`] !== undefined
      )
    );
    const allEssayDone = lesson.essays.every((es) => {
      const sub = essaySubmissions[`${lesson.id}:${es.id}`];
      return sub && (sub.textAnswer.trim().length > 0 || sub.attachedImages.length > 0);
    });
    return allMcqDone && allTfDone && allEssayDone;
  };

  // Unique chapters/topics available for the currently selected subject filter
  const subjectScopedLessons = ALL_KNTT_LESSONS.filter(
    (l) => subjectFilter === 'all' || l.subject === subjectFilter
  );
  const availableChapters = Array.from(
    new Set(subjectScopedLessons.map((l) => l.chapterTitle))
  );

  const filteredLessons = subjectScopedLessons.filter((l) => {
    if (chapterFilter !== 'all' && l.chapterTitle !== chapterFilter) {
      return false;
    }
    if (completionStatusFilter === 'completed' && !isLessonFullyCompleted(l)) {
      return false;
    }
    if (completionStatusFilter === 'incomplete' && isLessonFullyCompleted(l)) {
      return false;
    }
    if (lessonSearchQuery.trim()) {
      const q = lessonSearchQuery.trim().toLowerCase();
      const matchTitle = l.title.toLowerCase().includes(q);
      const matchChapter = l.chapterTitle.toLowerCase().includes(q);
      const matchNum =
        `bài ${l.lessonNumber}`.includes(q) || String(l.lessonNumber) === q;
      const matchQuestion =
        l.mcqs.some((m) => m.question.toLowerCase().includes(q)) ||
        l.essays.some((e) => e.question.toLowerCase().includes(q));
      if (!matchTitle && !matchChapter && !matchNum && !matchQuestion) {
        return false;
      }
    }
    return true;
  });

  const currentLesson: KhtnLesson =
    filteredLessons.find((l) => l.id === selectedLessonId) ||
    ALL_KNTT_LESSONS.find((l) => l.id === selectedLessonId) ||
    filteredLessons[0] ||
    ALL_KNTT_LESSONS[0];

  // Compute per-subject progress summary for the filter cards
  const getSubjectPracticeSummary = (sub: SubSubject) => {
    const lessonsOfSub = ALL_KNTT_LESSONS.filter((l) => l.subject === sub);
    let totalQ = 0;
    let doneQ = 0;
    lessonsOfSub.forEach((l) => {
      totalQ += l.mcqs.length + l.trueFalseList.length + l.essays.length;
      doneQ += l.mcqs.filter((q) => mcqAnswers[`${l.id}:${q.id}`] !== undefined).length;
      doneQ += l.trueFalseList.filter((tf) =>
        tf.statements.every((st) => tfAnswers[`${l.id}:${tf.id}:${st.id}`] !== undefined)
      ).length;
      doneQ += l.essays.filter((es) => {
        const subItem = essaySubmissions[`${l.id}:${es.id}`];
        return (
          subItem &&
          (subItem.textAnswer.trim().length > 0 || subItem.attachedImages.length > 0)
        );
      }).length;
    });
    return {
      lessonCount: lessonsOfSub.length,
      totalQ,
      doneQ,
    };
  };

  // Helper to get or initialize an EssaySubmission
  const getEssaySubmission = (key: string): EssaySubmission => {
    return (
      essaySubmissions[key] || {
        textAnswer: '',
        attachedImages: [],
        selfScore: undefined,
        submittedAt: undefined,
      }
    );
  };

  const updateEssaySubmission = (
    key: string,
    updater: (prev: EssaySubmission) => EssaySubmission
  ) => {
    setEssaySubmissions((prev) => {
      const current = prev[key] || {
        textAnswer: '',
        attachedImages: [],
      };
      return {
        ...prev,
        [key]: updater(current),
      };
    });
  };

  const showTempMessage = (key: string, msg: string) => {
    setEssayStatusMsg((prev) => ({ ...prev, [key]: msg }));
    setTimeout(() => {
      setEssayStatusMsg((prev) => {
        const copy = { ...prev };
        delete copy[key];
        return copy;
      });
    }, 3500);
  };

  // Compress image file into reasonable dataURL so multiple phone photos fit smoothly
  const processImageFile = (file: File, essayKey: string) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const rawDataUrl = event.target?.result as string;
      if (!rawDataUrl) return;

      const img = new Image();
      img.onload = () => {
        const maxDim = 1280;
        let width = img.width;
        let height = img.height;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.82);
          updateEssaySubmission(essayKey, (prev) => ({
            ...prev,
            attachedImages: [...prev.attachedImages, compressedDataUrl],
          }));
          showTempMessage(essayKey, 'Đã đính kèm ảnh bài làm thành công!');
        }
      };
      img.src = rawDataUrl;
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    essayKey: string
  ) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    Array.from(files).forEach((file) => {
      if (file.type.startsWith('image/')) {
        processImageFile(file, essayKey);
      }
    });
    e.target.value = '';
  };

  // Handle clipboard paste inside the essay card (supports pasting text or images/screenshots)
  const handlePasteEvent = (
    e: React.ClipboardEvent<HTMLElement>,
    essayKey: string
  ) => {
    const items = e.clipboardData?.items;
    if (!items) return;

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.type.indexOf('image') !== -1) {
        const file = item.getAsFile();
        if (file) {
          e.preventDefault();
          processImageFile(file, essayKey);
        }
      }
    }
  };

  // Explicit "Dán đáp án" button handler using Clipboard API
  const handleClipboardPasteButton = async (essayKey: string) => {
    try {
      if (navigator.clipboard && navigator.clipboard.read) {
        try {
          const clipboardItems = await navigator.clipboard.read();
          for (const clipItem of clipboardItems) {
            const imageType = clipItem.types.find((t) => t.startsWith('image/'));
            if (imageType) {
              const blob = await clipItem.getType(imageType);
              const file = new File([blob], 'pasted-image.png', { type: imageType });
              processImageFile(file, essayKey);
              return;
            }
          }
        } catch {
          // Fallback to readText below
        }
      }

      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        if (text && text.trim().length > 0) {
          updateEssaySubmission(essayKey, (prev) => ({
            ...prev,
            textAnswer: prev.textAnswer
              ? `${prev.textAnswer}\n${text}`
              : text,
          }));
          showTempMessage(essayKey, 'Đã dán nội dung từ bộ nhớ tạm!');
          return;
        }
      }

      const el = textareaRefs.current[essayKey];
      if (el) {
        el.focus();
      }
      showTempMessage(
        essayKey,
        'Đã đặt con trỏ vào ô làm bài — hãy nhấn Ctrl+V (hoặc giữ chọn Dán trên điện thoại).'
      );
    } catch {
      const el = textareaRefs.current[essayKey];
      if (el) el.focus();
      showTempMessage(
        essayKey,
        'Hãy nhấn Ctrl+V (hoặc chạm giữ → Dán trên điện thoại) vào ô nhập đáp án.'
      );
    }
  };

  // Insert scientific symbol at cursor position
  const insertSymbolAtCursor = (essayKey: string, symbol: string) => {
    const el = textareaRefs.current[essayKey];
    const currentText = getEssaySubmission(essayKey).textAnswer;

    if (el) {
      const start = el.selectionStart ?? currentText.length;
      const end = el.selectionEnd ?? currentText.length;
      const nextText =
        currentText.slice(0, start) + symbol + currentText.slice(end);
      updateEssaySubmission(essayKey, (prev) => ({
        ...prev,
        textAnswer: nextText,
      }));
      setTimeout(() => {
        el.focus();
        el.setSelectionRange(start + symbol.length, start + symbol.length);
      }, 0);
    } else {
      updateEssaySubmission(essayKey, (prev) => ({
        ...prev,
        textAnswer: prev.textAnswer + symbol,
      }));
    }
  };

  // Start Live Camera Modal
  const openLiveCamera = async (essayKey: string) => {
    setLiveCameraTargetKey(essayKey);
    setLiveCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' } },
        audio: false,
      });
      mediaStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch {
      setLiveCameraError(
        'Trình duyệt chưa cấp quyền Camera trực tiếp. Bạn có thể bấm nút "Chụp ảnh từ điện thoại" để mở ứng dụng máy ảnh của thiết bị.'
      );
    }
  };

  const closeLiveCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    setLiveCameraTargetKey(null);
    setLiveCameraError(null);
  };

  const captureFromLiveCamera = () => {
    if (!videoRef.current || !liveCameraTargetKey) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 960;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      updateEssaySubmission(liveCameraTargetKey, (prev) => ({
        ...prev,
        attachedImages: [...prev.attachedImages, dataUrl],
      }));
      showTempMessage(liveCameraTargetKey, 'Đã chụp và đính kèm ảnh bài làm!');
      closeLiveCamera();
    }
  };

  // Lesson-level statistics
  const lessonMcqTotal = currentLesson.mcqs.length;
  const lessonMcqAnswered = currentLesson.mcqs.filter(
    (q) => mcqAnswers[`${currentLesson.id}:${q.id}`] !== undefined
  ).length;
  const lessonMcqCorrect = currentLesson.mcqs.filter(
    (q) => mcqAnswers[`${currentLesson.id}:${q.id}`] === q.correctIndex
  ).length;

  const lessonTfTotalStatements = currentLesson.trueFalseList.reduce(
    (acc, tf) => acc + tf.statements.length,
    0
  );
  const lessonTfAnsweredStatements = currentLesson.trueFalseList.reduce(
    (acc, tf) =>
      acc +
      tf.statements.filter(
        (st) => tfAnswers[`${currentLesson.id}:${tf.id}:${st.id}`] !== undefined
      ).length,
    0
  );
  const lessonTfCorrectStatements = currentLesson.trueFalseList.reduce(
    (acc, tf) =>
      acc +
      tf.statements.filter(
        (st) => tfAnswers[`${currentLesson.id}:${tf.id}:${st.id}`] === st.isTrue
      ).length,
    0
  );

  const lessonEssayTotal = currentLesson.essays.length;
  const lessonEssayCompleted = currentLesson.essays.filter((es) => {
    const sub = essaySubmissions[`${currentLesson.id}:${es.id}`];
    return sub && (sub.textAnswer.trim().length > 0 || sub.attachedImages.length > 0);
  }).length;

  const resetCurrentLessonMcq = () => {
    setMcqAnswers((prev) => {
      const next = { ...prev };
      currentLesson.mcqs.forEach((q) => {
        delete next[`${currentLesson.id}:${q.id}`];
      });
      return next;
    });
  };

  const resetCurrentLessonTf = () => {
    setTfAnswers((prev) => {
      const next = { ...prev };
      currentLesson.trueFalseList.forEach((tf) => {
        tf.statements.forEach((st) => {
          delete next[`${currentLesson.id}:${tf.id}:${st.id}`];
        });
      });
      return next;
    });
    setTfRevealed({});
  };

  const displayedMcqs = currentLesson.mcqs.filter((q) => {
    const ans = mcqAnswers[`${currentLesson.id}:${q.id}`];
    if (mcqFilterMode === 'unanswered') return ans === undefined;
    if (mcqFilterMode === 'wrong') return ans !== undefined && ans !== q.correctIndex;
    return true;
  });

  // Detailed status per True/False card (done 4/4, partial 1-3/4, empty 0/4)
  const tfCardStatuses = currentLesson.trueFalseList.map((tf, idx) => {
    const tfKey = `${currentLesson.id}:${tf.id}`;
    const answeredCount = tf.statements.filter(
      (st) => tfAnswers[`${tfKey}:${st.id}`] !== undefined
    ).length;
    const totalCount = tf.statements.length;
    const missingStatements = tf.statements
      .filter((st) => tfAnswers[`${tfKey}:${st.id}`] === undefined)
      .map((st) => st.id);
    return {
      tf,
      index: idx + 1,
      answeredCount,
      totalCount,
      missingStatements,
      status:
        answeredCount === 0
          ? ('unanswered' as const)
          : answeredCount < totalCount
          ? ('partial' as const)
          : ('completed' as const),
    };
  });

  const lessonTfCompletedCards = tfCardStatuses.filter((s) => s.status === 'completed').length;
  const lessonTfPartialCards = tfCardStatuses.filter((s) => s.status === 'partial').length;
  const lessonMcqUnanswered = lessonMcqTotal - lessonMcqAnswered;
  const lessonEssayUnanswered = lessonEssayTotal - lessonEssayCompleted;
  const totalMissingItems =
    lessonMcqUnanswered +
    (currentLesson.trueFalseList.length - lessonTfCompletedCards) +
    lessonEssayUnanswered;

  // Track which lessons have already fired automatic completion confetti
  const celebratedLessonsRef = useRef<Record<string, boolean>>({});
  const prevMissingByLessonRef = useRef<Record<string, number>>({});

  const triggerCelebrationConfetti = () => {
    soundEngine.playVictory();
    const duration = 2600;
    const end = Date.now() + duration;

    confetti({
      particleCount: 90,
      spread: 80,
      origin: { y: 0.6 },
    });

    const interval = window.setInterval(() => {
      if (Date.now() > end) {
        window.clearInterval(interval);
        return;
      }
      confetti({
        particleCount: 35,
        angle: 60,
        spread: 55,
        origin: { x: 0, y: 0.65 },
      });
      confetti({
        particleCount: 35,
        angle: 120,
        spread: 55,
        origin: { x: 1, y: 0.65 },
      });
    }, 350);
  };

  useEffect(() => {
    const prevMissing = prevMissingByLessonRef.current[currentLesson.id];
    prevMissingByLessonRef.current[currentLesson.id] = totalMissingItems;

    if (
      totalMissingItems === 0 &&
      prevMissing !== undefined &&
      prevMissing > 0 &&
      !celebratedLessonsRef.current[currentLesson.id]
    ) {
      celebratedLessonsRef.current[currentLesson.id] = true;
      triggerCelebrationConfetti();
    } else if (totalMissingItems > 0) {
      celebratedLessonsRef.current[currentLesson.id] = false;
    }
  }, [currentLesson.id, totalMissingItems]);

  const scrollToQuestionCard = (cardDomId: string, requiredSection: ExerciseSection) => {
    if (activeSection !== 'all' && activeSection !== requiredSection) {
      setActiveSection('all');
    }
    if (requiredSection === 'mcq' && mcqFilterMode !== 'all') {
      setMcqFilterMode('all');
    }
    setHighlightedCardId(cardDomId);
    setTimeout(() => {
      const el = document.getElementById(cardDomId);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 60);
    setTimeout(() => {
      setHighlightedCardId((prev) => (prev === cardDomId ? null : prev));
    }, 2200);
  };

  const jumpToNextMissingQuestion = () => {
    // 1. Check unanswered MCQ first
    const firstMissingMcqIdx = currentLesson.mcqs.findIndex(
      (q) => mcqAnswers[`${currentLesson.id}:${q.id}`] === undefined
    );
    if (firstMissingMcqIdx !== -1) {
      scrollToQuestionCard(`mcq-card-${firstMissingMcqIdx + 1}`, 'mcq');
      return;
    }
    // 2. Check incomplete or unanswered True/False card
    const firstMissingTf = tfCardStatuses.find((s) => s.status !== 'completed');
    if (firstMissingTf) {
      scrollToQuestionCard(`tf-card-${firstMissingTf.index}`, 'tf');
      return;
    }
    // 3. Check unanswered Essay card
    const firstMissingEssayIdx = currentLesson.essays.findIndex((es) => {
      const sub = essaySubmissions[`${currentLesson.id}:${es.id}`];
      return !sub || (sub.textAnswer.trim().length === 0 && sub.attachedImages.length === 0);
    });
    if (firstMissingEssayIdx !== -1) {
      scrollToQuestionCard(`essay-card-${firstMissingEssayIdx + 1}`, 'essay');
    }
  };

  const subjMeta = SUBJECT_META[currentLesson.subject];

  return (
    <div className="space-y-6">
      {/* Top Curriculum Banner & Overview Metrics */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-200">
          <div>
            <p className="text-xs font-mono uppercase tracking-wider text-blue-700 font-semibold">
              CHƯƠNG TRÌNH KHTN 7 · SÁCH KẾT NỐI TRI THỨC VỚI CUỘC SỐNG (KNTT)
            </p>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
              Luyện tập chuyên sâu theo từng bài học
            </h2>
            <p className="text-sm text-slate-600 mt-1 max-w-3xl">
              Vật lí &amp; Hóa học: <strong className="text-slate-900 font-semibold">30 câu trắc nghiệm · 5 bài Đúng–Sai · 5–10 bài Tự luận</strong> mỗi bài. Sinh học: <strong className="text-slate-900 font-semibold">15–20 câu trắc nghiệm · 5 bài Đúng–Sai · 3–6 bài Tự luận</strong> mỗi bài. Hỗ trợ nhập đáp án, dán từ bộ nhớ tạm hoặc chụp ảnh bài giải từ điện thoại.
            </p>
          </div>

          <div className="grid grid-cols-3 gap-2.5 sm:gap-3 shrink-0">
            <div className="bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5">
              <div className="text-[11px] font-mono uppercase text-slate-500">Trắc nghiệm</div>
              <div className="text-lg font-bold font-mono tabular-nums text-slate-900">
                {LESSON_BANK_STATS.totalMcq} câu
              </div>
            </div>
            <div className="bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5">
              <div className="text-[11px] font-mono uppercase text-slate-500">Đúng – Sai</div>
              <div className="text-lg font-bold font-mono tabular-nums text-slate-900">
                {LESSON_BANK_STATS.totalTrueFalse} bài
              </div>
            </div>
            <div className="bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5">
              <div className="text-[11px] font-mono uppercase text-slate-500">Tự luận</div>
              <div className="text-lg font-bold font-mono tabular-nums text-slate-900">
                {LESSON_BANK_STATS.totalEssay} bài
              </div>
            </div>
          </div>
        </div>

        {/* ================= BỘ LỌC BÀI TẬP THEO PHÂN MÔN (VẬT LÍ, HÓA HỌC, SINH HỌC) & CHUYÊN ĐỀ ================= */}
        <div className="pt-4 space-y-3.5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-wider text-slate-700">
              <Filter className="w-4 h-4 text-blue-600" />
              <span>1. Lọc nhanh danh sách bài tập theo Phân môn (Vật lí · Hóa học · Sinh học):</span>
            </div>
            <span className="text-xs font-mono text-slate-500 tabular-nums">
              Tài liệu gốc đã tích hợp: {KNTT_PDF_DOCUMENTS.length} chuyên đề PDF
            </span>
          </div>

          {/* 4 Subject Filter Cards: Tất cả | Vật lí 7 | Hóa học 7 | Sinh học 7 */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-2.5">
            {(
              [
                {
                  id: 'all' as SubjectFilter,
                  title: 'Tất cả 3 Phân môn',
                  subtitle: `${ALL_KNTT_LESSONS.length} bài học (Bài 1 – 42)`,
                  badge: `${LESSON_BANK_STATS.totalMcq} TN + ${LESSON_BANK_STATS.totalEssay} TL`,
                  activeClass: 'bg-slate-900 text-white border-slate-900 shadow-sm',
                  idleClass:
                    'bg-slate-50 hover:bg-white text-slate-800 border-slate-200 hover:border-slate-400',
                },
                {
                  id: 'physics' as SubjectFilter,
                  title: '⚡ Phân môn Vật lí 7',
                  subtitle: 'Tốc độ · Âm thanh · Ánh sáng · Từ (Bài 8 – 20)',
                  badge: (() => {
                    const s = getSubjectPracticeSummary('physics');
                    return `${s.lessonCount} bài · Đã làm ${s.doneQ}/${s.totalQ}`;
                  })(),
                  activeClass: 'bg-blue-600 text-white border-blue-600 shadow-sm',
                  idleClass:
                    'bg-blue-50/70 hover:bg-blue-100/70 text-blue-950 border-blue-200 hover:border-blue-400',
                },
                {
                  id: 'chemistry' as SubjectFilter,
                  title: '🧪 Phân môn Hóa học 7',
                  subtitle: 'Nguyên tử · Bảng tuần hoàn · Phân tử · Hóa trị (Bài 1 – 7)',
                  badge: (() => {
                    const s = getSubjectPracticeSummary('chemistry');
                    return `${s.lessonCount} bài · Đã làm ${s.doneQ}/${s.totalQ}`;
                  })(),
                  activeClass: 'bg-amber-600 text-white border-amber-600 shadow-sm',
                  idleClass:
                    'bg-amber-50/70 hover:bg-amber-100/70 text-amber-950 border-amber-200 hover:border-amber-400',
                },
                {
                  id: 'biology' as SubjectFilter,
                  title: '🌿 Phân môn Sinh học 7',
                  subtitle: 'Trao đổi chất · Cảm ứng · Sinh trưởng · Sinh sản (Bài 21 – 42)',
                  badge: (() => {
                    const s = getSubjectPracticeSummary('biology');
                    return `${s.lessonCount} bài · Đã làm ${s.doneQ}/${s.totalQ}`;
                  })(),
                  activeClass: 'bg-emerald-600 text-white border-emerald-600 shadow-sm',
                  idleClass:
                    'bg-emerald-50/70 hover:bg-emerald-100/70 text-emerald-950 border-emerald-200 hover:border-emerald-400',
                },
              ] as const
            ).map((card) => {
              const active = subjectFilter === card.id;
              return (
                <button
                  key={card.id}
                  type="button"
                  onClick={() => {
                    setSubjectFilter(card.id);
                    setChapterFilter('all');
                    const firstMatch = ALL_KNTT_LESSONS.find(
                      (l) => card.id === 'all' || l.subject === card.id
                    );
                    if (firstMatch) setSelectedLessonId(firstMatch.id);
                  }}
                  className={`p-3.5 rounded-2xl border text-left transition flex flex-col justify-between gap-1.5 cursor-pointer ${
                    active ? card.activeClass : card.idleClass
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs sm:text-sm font-black">{card.title}</span>
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg ${
                        active
                          ? 'bg-white/20 text-white'
                          : 'bg-white/90 text-slate-700 border border-slate-200/80'
                      }`}
                    >
                      {card.badge}
                    </span>
                  </div>
                  <div
                    className={`text-[11px] leading-snug ${
                      active ? 'opacity-90' : 'text-slate-600'
                    }`}
                  >
                    {card.subtitle}
                  </div>
                </button>
              );
            })}
          </div>

          {/* 2. Topic / Chapter Filter + Search Keyword + Completion Status Bar */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/90 flex flex-col xl:flex-row xl:items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2 flex-1">
              <span className="text-xs font-extrabold text-slate-700 shrink-0">
                2. Chuyên đề / Chương:
              </span>
              <select
                value={chapterFilter}
                onChange={(e) => {
                  const val = e.target.value;
                  setChapterFilter(val);
                  const firstInChap = subjectScopedLessons.find(
                    (l) => val === 'all' || l.chapterTitle === val
                  );
                  if (firstInChap) setSelectedLessonId(firstInChap.id);
                }}
                className="px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-blue-600 cursor-pointer max-w-full"
              >
                <option value="all">
                  Tất cả chuyên đề ({availableChapters.length} chương · {subjectScopedLessons.length} bài)
                </option>
                {availableChapters.map((chap) => (
                  <option key={chap} value={chap}>
                    {chap}
                  </option>
                ))}
              </select>

              {/* Completion Status Filter */}
              <div className="inline-flex items-center bg-white border border-slate-300 rounded-xl p-0.5 text-xs font-bold">
                {(
                  [
                    { id: 'all', label: 'Tất cả' },
                    { id: 'incomplete', label: 'Chưa xong' },
                    { id: 'completed', label: 'Đã xong 100%' },
                  ] as const
                ).map((st) => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => setCompletionStatusFilter(st.id)}
                    className={`px-2.5 py-1.5 rounded-lg transition cursor-pointer ${
                      completionStatusFilter === st.id
                        ? 'bg-blue-600 text-white'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Search Input for Lesson Title, Number, or Exercise Keyword */}
            <div className="relative w-full xl:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={lessonSearchQuery}
                onChange={(e) => setLessonSearchQuery(e.target.value)}
                placeholder="Tìm tên bài, số bài (VD: Bài 12, tốc độ, nguyên tử)..."
                className="w-full pl-9 pr-8 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:border-blue-600"
              />
              {lessonSearchQuery && (
                <button
                  type="button"
                  onClick={() => setLessonSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 cursor-pointer"
                  title="Xóa từ khóa tìm kiếm"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main 2-Column Workspace: Left Lesson Navigator + Right Exercise Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Sidebar: KNTT Lesson Selector with Quick Subject Pills */}
        <aside className="lg:col-span-4 xl:col-span-3 bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden lg:sticky lg:top-20">
          <div className="p-3.5 border-b border-slate-200 bg-slate-50/70 space-y-2.5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-slate-800">
                  DANH SÁCH BÀI TẬP ({filteredLessons.length} BÀI)
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Lọc theo Vật lí · Hóa học · Sinh học
                </p>
              </div>
              {(subjectFilter !== 'all' ||
                chapterFilter !== 'all' ||
                lessonSearchQuery ||
                completionStatusFilter !== 'all') && (
                <button
                  type="button"
                  onClick={() => {
                    setSubjectFilter('all');
                    setChapterFilter('all');
                    setLessonSearchQuery('');
                    setCompletionStatusFilter('all');
                  }}
                  className="text-[11px] font-extrabold text-blue-600 hover:underline cursor-pointer"
                >
                  Đặt lại lọc
                </button>
              )}
            </div>

            {/* Quick Subject Pills right inside the Sidebar */}
            <div className="grid grid-cols-4 gap-1 bg-slate-200/75 p-1 rounded-xl text-[11px] font-extrabold">
              {(
                [
                  { id: 'all' as SubjectFilter, label: 'Tất cả' },
                  { id: 'physics' as SubjectFilter, label: 'Vật lí' },
                  { id: 'chemistry' as SubjectFilter, label: 'Hóa học' },
                  { id: 'biology' as SubjectFilter, label: 'Sinh học' },
                ] as const
              ).map((pill) => {
                const active = subjectFilter === pill.id;
                return (
                  <button
                    key={pill.id}
                    type="button"
                    onClick={() => {
                      setSubjectFilter(pill.id);
                      setChapterFilter('all');
                      const firstMatch = ALL_KNTT_LESSONS.find(
                        (l) => pill.id === 'all' || l.subject === pill.id
                      );
                      if (firstMatch) setSelectedLessonId(firstMatch.id);
                    }}
                    className={`py-1.5 rounded-lg text-center transition cursor-pointer ${
                      active
                        ? 'bg-white text-blue-700 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {pill.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="max-h-[420px] lg:max-h-[calc(100vh-16rem)] overflow-y-auto divide-y divide-slate-100 p-2 space-y-1">
            {filteredLessons.length === 0 ? (
              <div className="p-6 text-center space-y-2">
                <p className="text-xs font-bold text-slate-600">
                  Không tìm thấy bài tập phù hợp với bộ lọc hiện tại.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSubjectFilter('all');
                    setChapterFilter('all');
                    setLessonSearchQuery('');
                    setCompletionStatusFilter('all');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-blue-600 text-white text-xs font-extrabold cursor-pointer"
                >
                  Hiển thị toàn bộ 30 bài học
                </button>
              </div>
            ) : (
              filteredLessons.map((lesson) => {
                const isSelected = lesson.id === currentLesson.id;
                const lMeta = SUBJECT_META[lesson.subject];

                // Calculate completion for this lesson
                const doneMcq = lesson.mcqs.filter(
                  (q) => mcqAnswers[`${lesson.id}:${q.id}`] !== undefined
                ).length;
                const doneTf = lesson.trueFalseList.filter((tf) =>
                  tf.statements.every(
                    (st) => tfAnswers[`${lesson.id}:${tf.id}:${st.id}`] !== undefined
                  )
                ).length;
                const doneEssay = lesson.essays.filter((es) => {
                  const sub = essaySubmissions[`${lesson.id}:${es.id}`];
                  return sub && (sub.textAnswer.trim().length > 0 || sub.attachedImages.length > 0);
                }).length;

                return (
                  <button
                    key={lesson.id}
                    onClick={() => {
                      setSelectedLessonId(lesson.id);
                      setMcqFilterMode('all');
                    }}
                    className={`w-full text-left p-3 rounded-xl transition-all cursor-pointer flex items-start justify-between gap-2 ${
                      isSelected
                        ? 'bg-blue-50/90 border border-blue-300 shadow-2xs'
                        : 'hover:bg-slate-50 border border-transparent'
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 text-[11px] font-mono uppercase tracking-wide">
                        <span className={`font-bold ${lMeta.accentText}`}>
                          Bài {lesson.lessonNumber}
                        </span>
                        <span className="text-slate-300">·</span>
                        <span className="text-slate-500 truncate">{lMeta.shortLabel}</span>
                      </div>
                      <div
                        className={`text-sm font-semibold mt-0.5 leading-snug ${
                          isSelected ? 'text-blue-950' : 'text-slate-800'
                        }`}
                      >
                        {lesson.title}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate mt-0.5">
                        {lesson.chapterTitle}
                      </div>
                      <div className="mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] font-mono text-slate-500 tabular-nums">
                        <span className={doneMcq > 0 ? 'text-blue-700 font-semibold' : ''}>
                          TN: {doneMcq}/{lesson.mcqs.length}
                        </span>
                        <span>·</span>
                        <span className={doneTf > 0 ? 'text-amber-700 font-semibold' : ''}>
                          Đ/S: {doneTf}/{lesson.trueFalseList.length}
                        </span>
                        <span>·</span>
                        <span className={doneEssay > 0 ? 'text-emerald-700 font-semibold' : ''}>
                          TL: {doneEssay}/{lesson.essays.length}
                        </span>
                      </div>
                    </div>
                    <ChevronRight
                      className={`w-4 h-4 shrink-0 mt-1 transition-transform ${
                        isSelected ? 'text-blue-600 translate-x-0.5' : 'text-slate-400'
                      }`}
                    />
                  </button>
                );
              })
            )}
          </div>
        </aside>

        {/* Right Main Content: Active Lesson Workspace */}
        <section className="lg:col-span-8 xl:col-span-9 space-y-5">
          {/* Lesson Header Card */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-2 text-xs font-mono uppercase tracking-wider">
                <span className={`font-bold ${subjMeta.accentText}`}>
                  {subjMeta.shortLabel}
                </span>
                <span className="text-slate-300">·</span>
                <span className="text-slate-600">{currentLesson.chapterTitle}</span>
                <span className="text-slate-300">·</span>
                <span className="text-slate-900 font-bold">
                  Bài {currentLesson.lessonNumber}
                </span>
              </div>

              {currentLesson.pdfUrl && (
                <button
                  onClick={() =>
                    setActiveSection(activeSection === 'pdf' ? 'all' : 'pdf')
                  }
                  className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg border transition-colors cursor-pointer ${
                    activeSection === 'pdf'
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  {activeSection === 'pdf'
                    ? 'Đóng tài liệu PDF gốc'
                    : 'Xem tài liệu PDF gốc của bài'}
                </button>
              )}
            </div>

            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 mt-2">
              {currentLesson.title}
            </h3>
            <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
              {currentLesson.summary}
            </p>

            {/* Key Formulas / Core Knowledge */}
            {currentLesson.keyFormulas.length > 0 && (
              <div className="mt-4 pt-3.5 border-t border-slate-100 flex flex-wrap items-center gap-2">
                <span className="text-xs font-mono uppercase text-slate-500 font-semibold mr-1">
                  Trọng tâm &amp; Công thức:
                </span>
                {currentLesson.keyFormulas.map((formula, idx) => (
                  <code
                    key={idx}
                    className="text-xs font-mono bg-slate-100 text-slate-800 px-2.5 py-1 rounded-md border border-slate-200/80"
                  >
                    {formula}
                  </code>
                ))}
              </div>
            )}

            {/* 4-Button Exercise Mode Switcher */}
            <div className="mt-5 pt-4 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
              <button
                onClick={() => setActiveSection('all')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                  activeSection === 'all'
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                }`}
              >
                <div>
                  <div
                    className={`text-[11px] font-mono uppercase ${
                      activeSection === 'all' ? 'text-slate-300' : 'text-slate-500'
                    }`}
                  >
                    XEM ĐẦY ĐỦ CẢ BÀI
                  </div>
                  <div className="text-sm font-bold mt-0.5">
                    Cả 3 phần (TN · Đ/S · TL)
                  </div>
                </div>
                <div className="text-right font-mono tabular-nums">
                  <div className="text-xs font-bold">
                    {lessonMcqTotal} TN · 5 Đ/S · {lessonEssayTotal} TL
                  </div>
                </div>
              </button>

              <button
                onClick={() => setActiveSection('mcq')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                  activeSection === 'mcq'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                }`}
              >
                <div>
                  <div
                    className={`text-[11px] font-mono uppercase ${
                      activeSection === 'mcq' ? 'text-blue-100' : 'text-slate-500'
                    }`}
                  >
                    PHẦN I · TRẮC NGHIỆM
                  </div>
                  <div className="text-sm font-bold mt-0.5">
                    {lessonMcqTotal} câu trắc nghiệm
                  </div>
                </div>
                <div className="text-right font-mono tabular-nums">
                  <div className="text-sm font-bold">
                    {lessonMcqCorrect}/{lessonMcqTotal}
                  </div>
                  <div
                    className={`text-[11px] ${
                      activeSection === 'mcq' ? 'text-blue-100' : 'text-slate-500'
                    }`}
                  >
                    Đã làm {lessonMcqAnswered}
                  </div>
                </div>
              </button>

              <button
                onClick={() => setActiveSection('tf')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                  activeSection === 'tf'
                    ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                }`}
              >
                <div>
                  <div
                    className={`text-[11px] font-mono uppercase ${
                      activeSection === 'tf' ? 'text-amber-100' : 'text-slate-500'
                    }`}
                  >
                    PHẦN II · ĐÚNG – SAI
                  </div>
                  <div className="text-sm font-bold mt-0.5">
                    {currentLesson.trueFalseList.length} bài tập ({lessonTfTotalStatements} ý)
                  </div>
                </div>
                <div className="text-right font-mono tabular-nums">
                  <div className="text-sm font-bold">
                    {lessonTfCorrectStatements}/{lessonTfTotalStatements}
                  </div>
                  <div
                    className={`text-[11px] ${
                      activeSection === 'tf' ? 'text-amber-100' : 'text-slate-500'
                    }`}
                  >
                    Đã chọn {lessonTfAnsweredStatements}
                  </div>
                </div>
              </button>

              <button
                onClick={() => setActiveSection('essay')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                  activeSection === 'essay'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                }`}
              >
                <div>
                  <div
                    className={`text-[11px] font-mono uppercase ${
                      activeSection === 'essay' ? 'text-emerald-100' : 'text-slate-500'
                    }`}
                  >
                    PHẦN III · TỰ LUẬN
                  </div>
                  <div className="text-sm font-bold mt-0.5">
                    {lessonEssayTotal} bài tập tự luận
                  </div>
                </div>
                <div className="text-right font-mono tabular-nums">
                  <div className="text-sm font-bold">
                    {lessonEssayCompleted}/{lessonEssayTotal}
                  </div>
                  <div
                    className={`text-[11px] ${
                      activeSection === 'essay' ? 'text-emerald-100' : 'text-slate-500'
                    }`}
                  >
                    Nhập / Dán / Ảnh
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* SECTION 0: EMBEDDED PDF VIEWER (WHEN TOGGLED) */}
          {activeSection === 'pdf' && currentLesson.pdfUrl && (
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h4 className="text-base font-bold text-slate-900">
                    Tài liệu chuyên đề PDF gốc (Bài {currentLesson.lessonNumber})
                  </h4>
                  <p className="text-xs text-slate-500">
                    Tài liệu bạn đã tải lên được tích hợp trực tiếp để tra cứu lý thuyết và bài tập.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href={currentLesson.pdfUrl}
                    download
                    className="px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 text-xs font-semibold border border-blue-200 hover:bg-blue-100"
                  >
                    Tải PDF về máy
                  </a>
                  <button
                    onClick={() => setActiveSection('all')}
                    className="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 text-xs font-semibold hover:bg-slate-200 cursor-pointer"
                  >
                    Quay lại làm bài
                  </button>
                </div>
              </div>
              <div className="w-full h-[640px] rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
                <iframe
                  src={currentLesson.pdfUrl}
                  title={currentLesson.title}
                  className="w-full h-full"
                />
              </div>
            </div>
          )}

          {/* PARALLEL WORKSPACE: QUESTIONS LIST (LEFT) + STICKY QUESTION COORDINATOR PANEL (RIGHT) */}
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-5 items-start">
            {/* LEFT COLUMN (8 COLS ON XL): ACTIVE QUESTIONS STREAM */}
            <div className="xl:col-span-8 space-y-6 order-2 xl:order-1">
              {/* SECTION 1: MULTIPLE CHOICE QUESTIONS (30 CÂU LÍ/HÓA, 15-20 CÂU SINH) */}
              {(activeSection === 'all' || activeSection === 'mcq') && (
                <div className="space-y-4">
                  {/* Quick Filter Bar */}
                  <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-xs space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <SlidersHorizontal className="w-4 h-4 text-blue-600" />
                        <span className="text-sm font-bold text-slate-800">
                          Phần I: {lessonMcqTotal} Câu hỏi Trắc nghiệm khách quan
                        </span>
                      </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {[
                      { id: 'all', label: `Tất cả (${lessonMcqTotal})` },
                      {
                        id: 'unanswered',
                        label: `Chưa làm (${lessonMcqTotal - lessonMcqAnswered})`,
                      },
                      {
                        id: 'wrong',
                        label: `Câu sai (${lessonMcqAnswered - lessonMcqCorrect})`,
                      },
                    ].map((f) => (
                      <button
                        key={f.id}
                        onClick={() =>
                          setMcqFilterMode(f.id as 'all' | 'unanswered' | 'wrong')
                        }
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                          mcqFilterMode === f.id
                            ? 'bg-slate-900 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}

                    {lessonMcqAnswered > 0 && (
                      <button
                        onClick={resetCurrentLessonMcq}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        Làm lại {lessonMcqTotal} câu
                      </button>
                    )}
                  </div>
                </div>

                {/* Number Grid 1..30 */}
                <div className="grid grid-cols-10 sm:grid-cols-15 gap-1.5">
                  {currentLesson.mcqs.map((q, idx) => {
                    const key = `${currentLesson.id}:${q.id}`;
                    const userAns = mcqAnswers[key];
                    const isAnswered = userAns !== undefined;
                    const isCorrect = isAnswered && userAns === q.correctIndex;

                    return (
                      <a
                        key={q.id}
                        href={`#mcq-card-${idx + 1}`}
                        onClick={() => setMcqFilterMode('all')}
                        className={`h-8 rounded-lg font-mono text-xs font-bold flex items-center justify-center border transition-all tabular-nums ${
                          !isAnswered
                            ? 'bg-slate-50 text-slate-600 border-slate-200 hover:border-slate-400'
                            : isCorrect
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-rose-600 text-white border-rose-600'
                        }`}
                      >
                        {idx + 1}
                      </a>
                    );
                  })}
                </div>
              </div>

              {/* Questions List */}
              {displayedMcqs.length === 0 ? (
                <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
                  <p className="text-base font-semibold text-slate-800">
                    Không có câu hỏi nào trong bộ lọc này.
                  </p>
                  <button
                    onClick={() => setMcqFilterMode('all')}
                    className="mt-3 px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold cursor-pointer"
                  >
                    Hiển thị toàn bộ {lessonMcqTotal} câu
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {displayedMcqs.map((q) => {
                    const originalIndex =
                      currentLesson.mcqs.findIndex((item) => item.id === q.id) + 1;
                    const key = `${currentLesson.id}:${q.id}`;
                    const selectedOption = mcqAnswers[key];
                    const isAnswered = selectedOption !== undefined;
                    const isCorrect = selectedOption === q.correctIndex;

                    return (
                      <article
                        key={q.id}
                        id={`mcq-card-${originalIndex}`}
                        className={`bg-white rounded-2xl border p-5 shadow-xs transition-all scroll-mt-24 ${
                          highlightedCardId === `mcq-card-${originalIndex}`
                            ? 'border-blue-600 ring-4 ring-blue-500/20'
                            : !isAnswered
                            ? 'border-slate-200/90'
                            : isCorrect
                            ? 'border-emerald-300'
                            : 'border-rose-300'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-2">
                            <span className="px-2.5 py-1 rounded-md bg-slate-900 text-white font-mono text-xs font-bold tabular-nums">
                              Câu {originalIndex}/{lessonMcqTotal}
                            </span>
                            {q.level && (
                              <span className="text-xs font-mono text-slate-500">
                                · {q.level}
                              </span>
                            )}
                            {isAnswered && (
                              <span
                                className={`inline-flex items-center gap-1 text-xs font-semibold ${
                                  isCorrect ? 'text-emerald-700' : 'text-rose-700'
                                }`}
                              >
                                {isCorrect ? (
                                  <>
                                    <CheckCircle2 className="w-4 h-4" /> Chính xác
                                  </>
                                ) : (
                                  <>
                                    <XCircle className="w-4 h-4" /> Chưa đúng
                                  </>
                                )}
                              </span>
                            )}
                          </div>

                          {isAnswered && (
                            <button
                              onClick={() =>
                                setMcqAnswers((prev) => {
                                  const copy = { ...prev };
                                  delete copy[key];
                                  return copy;
                                })
                              }
                              className="text-xs text-slate-400 hover:text-slate-700 font-medium cursor-pointer"
                            >
                              Chọn lại
                            </button>
                          )}
                        </div>

                        <p className="text-base font-semibold text-slate-900 mt-3 leading-relaxed">
                          {q.question}
                        </p>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mt-4">
                          {q.options.map((optText, optIdx) => {
                            const letter = ['A', 'B', 'C', 'D'][optIdx];
                            const isThisSelected = selectedOption === optIdx;
                            const isThisCorrect = q.correctIndex === optIdx;

                            let btnStyle =
                              'bg-slate-50/80 hover:bg-slate-100 border-slate-200 text-slate-800';
                            if (isAnswered) {
                              if (isThisCorrect) {
                                btnStyle =
                                  'bg-emerald-50 border-emerald-500 text-emerald-950 font-semibold';
                              } else if (isThisSelected && !isThisCorrect) {
                                btnStyle =
                                  'bg-rose-50 border-rose-400 text-rose-900 line-through';
                              } else {
                                btnStyle =
                                  'bg-slate-50/40 border-slate-200/60 text-slate-400';
                              }
                            }

                            return (
                              <button
                                key={optIdx}
                                onClick={() =>
                                  setMcqAnswers((prev) => ({
                                    ...prev,
                                    [key]: optIdx,
                                  }))
                                }
                                className={`p-3.5 rounded-xl border text-left text-sm transition-all cursor-pointer flex items-start gap-2.5 ${btnStyle}`}
                              >
                                <span
                                  className={`w-6 h-6 rounded-md font-mono text-xs font-bold flex items-center justify-center shrink-0 mt-0.5 ${
                                    isAnswered && isThisCorrect
                                      ? 'bg-emerald-600 text-white'
                                      : isAnswered && isThisSelected && !isThisCorrect
                                      ? 'bg-rose-600 text-white'
                                      : 'bg-white border border-slate-300 text-slate-700'
                                  }`}
                                >
                                  {letter}
                                </span>
                                <span className="leading-snug">{optText}</span>
                              </button>
                            );
                          })}
                        </div>

                        {isAnswered && (
                          <div className="mt-4 pt-3.5 border-t border-slate-200/80 bg-slate-50/90 rounded-xl p-3.5 text-xs sm:text-sm text-slate-700">
                            <span className="font-mono font-bold text-slate-900 uppercase mr-1.5">
                              Giải thích đáp án ({['A', 'B', 'C', 'D'][q.correctIndex]}):
                            </span>
                            {q.explanation}
                          </div>
                        )}
                      </article>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* SECTION 2: TRUE / FALSE EXERCISES (5 BÀI TẬP ĐÚNG - SAI MỖI BÀI HỌC) */}
          {(activeSection === 'all' || activeSection === 'tf') && (
            <div className="space-y-4">
              <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-xs flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h4 className="text-base font-bold text-slate-900">
                    Phần II: {currentLesson.trueFalseList.length} Bài tập Trắc nghiệm Đúng – Sai
                  </h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Trong mỗi bài tập, hãy chọn <strong>Đúng</strong> hoặc <strong>Sai</strong> cho từng phát biểu a), b), c), d).
                  </p>
                </div>

                {lessonTfAnsweredStatements > 0 && (
                  <button
                    onClick={resetCurrentLessonTf}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Làm lại phần Đúng – Sai
                  </button>
                )}
              </div>

              {currentLesson.trueFalseList.map((tf, tfIdx) => {
                const tfCardKey = `${currentLesson.id}:${tf.id}`;
                const allFourAnswered = tf.statements.every(
                  (st) => tfAnswers[`${tfCardKey}:${st.id}`] !== undefined
                );
                const isRevealed = tfRevealed[tfCardKey] || allFourAnswered;

                const correctCountInCard = tf.statements.filter(
                  (st) => tfAnswers[`${tfCardKey}:${st.id}`] === st.isTrue
                ).length;

                return (
                  <article
                    key={tf.id}
                    id={`tf-card-${tfIdx + 1}`}
                    className={`bg-white rounded-2xl border p-5 sm:p-6 shadow-xs space-y-4 transition-all scroll-mt-24 ${
                      highlightedCardId === `tf-card-${tfIdx + 1}`
                        ? 'border-amber-500 ring-4 ring-amber-500/20'
                        : 'border-slate-200/90'
                    }`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-1 rounded-md bg-amber-600 text-white font-mono text-xs font-bold">
                          Bài Đúng–Sai {tfIdx + 1}/{currentLesson.trueFalseList.length}
                        </span>
                        <span className="text-xs font-mono text-slate-500 tabular-nums">
                          Đúng {correctCountInCard}/{tf.statements.length} mệnh đề
                        </span>
                      </div>

                      <button
                        onClick={() =>
                          setTfRevealed((prev) => ({
                            ...prev,
                            [tfCardKey]: !isRevealed,
                          }))
                        }
                        className="inline-flex items-center gap-1 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 px-3 py-1.5 rounded-lg cursor-pointer"
                      >
                        {isRevealed ? (
                          <>
                            <EyeOff className="w-3.5 h-3.5" /> Ẩn giải thích
                          </>
                        ) : (
                          <>
                            <Eye className="w-3.5 h-3.5" /> Xem đáp án &amp; giải thích
                          </>
                        )}
                      </button>
                    </div>

                    <p className="text-base font-bold text-slate-900 leading-relaxed">
                      {tf.stem}
                    </p>

                    <div className="divide-y divide-slate-200 border border-slate-200 rounded-xl overflow-hidden">
                      {tf.statements.map((st) => {
                        const stKey = `${tfCardKey}:${st.id}`;
                        const userChoice = tfAnswers[stKey];
                        const hasChosen = userChoice !== undefined;
                        const isStCorrect = hasChosen && userChoice === st.isTrue;

                        return (
                          <div
                            key={st.id}
                            className="p-3.5 sm:p-4 bg-white hover:bg-slate-50/60 transition-colors space-y-2"
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                              <div className="flex items-start gap-2.5 flex-1">
                                <span className="font-mono text-xs font-bold text-slate-700 bg-slate-100 border border-slate-300 rounded-md px-2 py-0.5 shrink-0 mt-0.5">
                                  {st.id})
                                </span>
                                <span className="text-sm text-slate-800 leading-relaxed">
                                  {st.text}
                                </span>
                              </div>

                              <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                                <button
                                  onClick={() =>
                                    setTfAnswers((prev) => ({
                                      ...prev,
                                      [stKey]: true,
                                    }))
                                  }
                                  className={`px-3.5 py-1.5 rounded-lg font-mono text-xs font-bold border transition-all cursor-pointer flex items-center gap-1 ${
                                    userChoice === true
                                      ? st.isTrue
                                        ? 'bg-emerald-600 text-white border-emerald-600'
                                        : 'bg-rose-600 text-white border-rose-600'
                                      : 'bg-slate-50 text-slate-700 border-slate-300 hover:bg-slate-100'
                                  }`}
                                >
                                  <Check className="w-3.5 h-3.5" /> ĐÚNG
                                </button>

                                <button
                                  onClick={() =>
                                    setTfAnswers((prev) => ({
                                      ...prev,
                                      [stKey]: false,
                                    }))
                                  }
                                  className={`px-3.5 py-1.5 rounded-lg font-mono text-xs font-bold border transition-all cursor-pointer flex items-center gap-1 ${
                                    userChoice === false
                                      ? !st.isTrue
                                        ? 'bg-emerald-600 text-white border-emerald-600'
                                        : 'bg-rose-600 text-white border-rose-600'
                                      : 'bg-slate-50 text-slate-700 border-slate-300 hover:bg-slate-100'
                                  }`}
                                >
                                  <X className="w-3.5 h-3.5" /> SAI
                                </button>
                              </div>
                            </div>

                            {(hasChosen || isRevealed) && (
                              <div
                                className={`text-xs rounded-lg p-2.5 border ${
                                  hasChosen
                                    ? isStCorrect
                                      ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
                                      : 'bg-rose-50/80 border-rose-200 text-rose-950'
                                    : 'bg-amber-50/70 border-amber-200 text-slate-800'
                                }`}
                              >
                                <span className="font-mono font-bold uppercase mr-1.5">
                                  Đáp án chuẩn: {st.isTrue ? 'ĐÚNG' : 'SAI'}
                                </span>
                                · {st.explanation}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </article>
                );
              })}
            </div>
          )}

          {/* SECTION 3: ESSAY / CONSTRUCTED-RESPONSE EXERCISES (TỰ LUẬN: NHẬP, DÁN, CHỤP ẢNH ĐÍNH KÈM) */}
          {(activeSection === 'all' || activeSection === 'essay') && (
            <div className="space-y-5">
              {/* Instructions Banner for Essay Input Modes */}
              <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h4 className="text-base font-bold text-slate-900">
                      Phần III: Bài tập Tự luận &amp; Vận dụng ({currentLesson.essays.length} bài)
                    </h4>
                    <p className="text-xs sm:text-sm text-slate-600 mt-1">
                      Mỗi bài tập hỗ trợ 3 cách nộp bài linh hoạt: <strong>(1) Nhập trực tiếp</strong> kèm thanh công cụ kí hiệu KHTN, <strong>(2) Dán đáp án hoặc ảnh chụp màn hình</strong> từ bộ nhớ tạm, hoặc <strong>(3) Chụp ảnh vở làm bài từ điện thoại</strong> để đính kèm và đối chiếu lời giải chi tiết.
                    </p>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-mono text-emerald-800 bg-emerald-50 border border-emerald-200 px-3.5 py-2 rounded-xl shrink-0 tabular-nums">
                    <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
                    Đã hoàn thành: {lessonEssayCompleted}/{lessonEssayTotal} bài
                  </div>
                </div>
              </div>

              {currentLesson.essays.map((essay, esIdx) => {
                const essayKey = `${currentLesson.id}:${essay.id}`;
                const submission = getEssaySubmission(essayKey);
                const statusToast = essayStatusMsg[essayKey];
                const isSolutionShown = Boolean(submission.submittedAt);

                return (
                  <article
                    key={essay.id}
                    id={`essay-card-${esIdx + 1}`}
                    onPaste={(e) => handlePasteEvent(e, essayKey)}
                    className={`bg-white rounded-2xl border p-5 sm:p-6 shadow-xs space-y-4 transition-all scroll-mt-24 ${
                      highlightedCardId === `essay-card-${esIdx + 1}`
                        ? 'border-emerald-600 ring-4 ring-emerald-500/20'
                        : 'border-slate-200/90'
                    }`}
                  >
                    {/* Problem Header */}
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-1 rounded-md bg-emerald-700 text-white font-mono text-xs font-bold tabular-nums">
                          Bài tự luận {esIdx + 1}/{lessonEssayTotal}
                        </span>
                        <span className="text-xs font-mono text-slate-500">
                          Bài {currentLesson.lessonNumber}
                        </span>
                      </div>

                      {submission.selfScore && (
                        <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-md">
                          Tự đánh giá:{' '}
                          {submission.selfScore === 'full'
                            ? '● Đạt 100%'
                            : submission.selfScore === 'partial'
                            ? '▲ Đạt một phần'
                            : '◆ Cần làm lại'}
                        </span>
                      )}
                    </div>

                    {/* Question Stem */}
                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/90">
                      <p className="text-base font-bold text-slate-900 leading-relaxed whitespace-pre-line">
                        {essay.question}
                      </p>
                      {essay.hint && (
                        <p className="text-xs text-slate-600 mt-2 font-mono">
                          💡 Gợi ý: {essay.hint}
                        </p>
                      )}
                    </div>

                    {/* Action Toolbar: Paste Answer, Mobile Camera Capture, Upload Photo, Live Camera */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                      <div className="flex flex-wrap items-center gap-2">
                        {/* 1. Paste button */}
                        <button
                          type="button"
                          onClick={() => handleClipboardPasteButton(essayKey)}
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300/80 transition-colors cursor-pointer"
                        >
                          <ClipboardPaste className="w-3.5 h-3.5 text-blue-600" />
                          Dán đáp án / ảnh (Ctrl+V)
                        </button>

                        {/* 2. Mobile Camera Capture (rear camera on phones) */}
                        <input
                          ref={(el) => {
                            cameraInputRefs.current[essayKey] = el;
                          }}
                          type="file"
                          accept="image/*"
                          capture="environment"
                          multiple
                          className="hidden"
                          onChange={(e) => handleFileChange(e, essayKey)}
                        />
                        <button
                          type="button"
                          onClick={() => cameraInputRefs.current[essayKey]?.click()}
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white shadow-2xs transition-colors cursor-pointer"
                        >
                          <Camera className="w-3.5 h-3.5" />
                          Chụp ảnh từ điện thoại
                        </button>

                        {/* 3. Choose existing photo from phone/computer */}
                        <input
                          ref={(el) => {
                            galleryInputRefs.current[essayKey] = el;
                          }}
                          type="file"
                          accept="image/*"
                          multiple
                          className="hidden"
                          onChange={(e) => handleFileChange(e, essayKey)}
                        />
                        <button
                          type="button"
                          onClick={() => galleryInputRefs.current[essayKey]?.click()}
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300/80 transition-colors cursor-pointer"
                        >
                          <ImagePlus className="w-3.5 h-3.5 text-emerald-600" />
                          Đính kèm ảnh bài giải
                        </button>

                        {/* 4. Direct WebRTC Camera Modal */}
                        <button
                          type="button"
                          onClick={() => openLiveCamera(essayKey)}
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 transition-colors cursor-pointer"
                        >
                          <Camera className="w-3.5 h-3.5 text-amber-700" />
                          Mở Camera trực tiếp
                        </button>
                      </div>

                      {(submission.textAnswer || submission.attachedImages.length > 0) && (
                        <button
                          type="button"
                          onClick={() =>
                            updateEssaySubmission(essayKey, () => ({
                              textAnswer: '',
                              attachedImages: [],
                              selfScore: undefined,
                              submittedAt: undefined,
                            }))
                          }
                          className="inline-flex items-center gap-1 text-xs font-semibold text-rose-600 hover:text-rose-800 px-2 py-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          Xóa bài làm
                        </button>
                      )}
                    </div>

                    {/* Toast Feedback if any */}
                    {statusToast && (
                      <div className="text-xs font-semibold text-blue-800 bg-blue-50 border border-blue-200 rounded-lg px-3 py-2">
                        {statusToast}
                      </div>
                    )}

                    {/* Quick Scientific Symbol Insertion Strip */}
                    <div className="flex items-center gap-1 overflow-x-auto pb-1">
                      <span className="text-[11px] font-mono text-slate-400 shrink-0 mr-1">
                        Chèn nhanh:
                      </span>
                      {SCIENCE_SYMBOLS.map((sym) => (
                        <button
                          key={sym}
                          type="button"
                          onClick={() => insertSymbolAtCursor(essayKey, sym)}
                          className="px-2 py-1 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-800 font-mono text-xs border border-slate-200/80 shrink-0 cursor-pointer"
                        >
                          {sym}
                        </button>
                      ))}
                    </div>

                    {/* Textarea for Typing or Pasting Answer */}
                    <div>
                      <textarea
                        ref={(el) => {
                          textareaRefs.current[essayKey] = el;
                        }}
                        rows={4}
                        value={submission.textAnswer}
                        onChange={(e) =>
                          updateEssaySubmission(essayKey, (prev) => ({
                            ...prev,
                            textAnswer: e.target.value,
                          }))
                        }
                        placeholder="Nhập lời giải của bạn tại đây, dán văn bản/hình ảnh (Ctrl+V), hoặc bấm 'Chụp ảnh từ điện thoại' để đính kèm ảnh chụp vở làm bài..."
                        className="w-full rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-hidden p-3.5 text-sm text-slate-900 placeholder:text-slate-400 leading-relaxed font-sans bg-white"
                      />
                    </div>

                    {/* Attached Photos Gallery */}
                    {submission.attachedImages.length > 0 && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-mono uppercase tracking-wider font-bold text-slate-700">
                            ẢNH BÀI LÀM ĐÃ ĐÍNH KÈM ({submission.attachedImages.length} ẢNH)
                          </span>
                          <span className="text-xs text-slate-500">
                            Bấm vào ảnh để phóng to đối chiếu
                          </span>
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                          {submission.attachedImages.map((imgUrl, imgIdx) => (
                            <div
                              key={imgIdx}
                              className="group relative rounded-xl overflow-hidden border border-slate-300 bg-slate-100 aspect-4/3"
                            >
                              <img
                                src={imgUrl}
                                alt={`Ảnh bài làm ${imgIdx + 1}`}
                                onClick={() =>
                                  setLightboxImage({
                                    url: imgUrl,
                                    title: `Bài ${currentLesson.lessonNumber} - Tự luận ${
                                      esIdx + 1
                                    } (Ảnh ${imgIdx + 1})`,
                                  })
                                }
                                className="w-full h-full object-cover cursor-zoom-in"
                              />
                              <div className="absolute inset-x-0 bottom-0 bg-slate-900/75 text-white px-2.5 py-1.5 flex items-center justify-between text-xs">
                                <button
                                  type="button"
                                  onClick={() =>
                                    setLightboxImage({
                                      url: imgUrl,
                                      title: `Bài ${currentLesson.lessonNumber} - Tự luận ${
                                        esIdx + 1
                                      } (Ảnh ${imgIdx + 1})`,
                                    })
                                  }
                                  className="inline-flex items-center gap-1 hover:text-blue-300 cursor-pointer"
                                >
                                  <ZoomIn className="w-3.5 h-3.5" /> Phóng to
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    updateEssaySubmission(essayKey, (prev) => ({
                                      ...prev,
                                      attachedImages: prev.attachedImages.filter(
                                        (_, i) => i !== imgIdx
                                      ),
                                    }))
                                  }
                                  className="text-rose-300 hover:text-rose-200 cursor-pointer"
                                  title="Xóa ảnh này"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Submit / Toggle Solution & Self-Evaluation Bar */}
                    <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() =>
                          updateEssaySubmission(essayKey, (prev) => ({
                            ...prev,
                            submittedAt: prev.submittedAt
                              ? undefined
                              : new Date().toISOString(),
                          }))
                        }
                        className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                          isSolutionShown
                            ? 'bg-slate-800 text-white'
                            : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                        }`}
                      >
                        <BookOpen className="w-4 h-4" />
                        {isSolutionShown
                          ? 'Ẩn lời giải & biểu điểm chuẩn'
                          : 'Nộp bài & Đối chiếu lời giải chi tiết'}
                      </button>

                      {/* Self-Grading Buttons */}
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-xs font-mono text-slate-500 mr-1">
                          Tự chấm điểm:
                        </span>
                        {(
                          [
                            {
                              score: 'full',
                              label: '● Đạt 100%',
                              activeClass: 'bg-emerald-600 text-white border-emerald-600',
                            },
                            {
                              score: 'partial',
                              label: '▲ Đạt một phần',
                              activeClass: 'bg-amber-600 text-white border-amber-600',
                            },
                            {
                              score: 'retry',
                              label: '◆ Cần làm lại',
                              activeClass: 'bg-rose-600 text-white border-rose-600',
                            },
                          ] as const
                        ).map((grade) => (
                          <button
                            key={grade.score}
                            type="button"
                            onClick={() =>
                              updateEssaySubmission(essayKey, (prev) => ({
                                ...prev,
                                submittedAt:
                                  prev.submittedAt || new Date().toISOString(),
                                selfScore: grade.score,
                              }))
                            }
                            className={`px-2.5 py-1.5 rounded-lg text-xs font-mono font-semibold border transition-colors cursor-pointer ${
                              submission.selfScore === grade.score
                                ? grade.activeClass
                                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            {grade.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Detailed Sample Answer & Grading Rubric */}
                    {isSolutionShown && (
                      <div className="mt-4 rounded-xl bg-emerald-50/70 border border-emerald-200 p-4 sm:p-5 space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-mono uppercase tracking-wider font-bold text-emerald-900">
                            HƯỚNG DẪN GIẢI CHI TIẾT &amp; ĐÁP ÁN CHUẨN KNTT
                          </span>
                        </div>

                        <div className="text-sm text-slate-800 leading-relaxed whitespace-pre-line bg-white p-3.5 rounded-lg border border-emerald-200/80">
                          {essay.sampleAnswer}
                        </div>

                        {essay.rubricPoints.length > 0 && (
                          <div className="space-y-1.5">
                            <div className="text-xs font-mono uppercase text-emerald-900 font-bold">
                              Bảng kiểm các ý cần đạt:
                            </div>
                            <ul className="space-y-1">
                              {essay.rubricPoints.map((rItem, rIdx) => (
                                <li
                                  key={rIdx}
                                  className="text-xs sm:text-sm text-slate-700 flex items-start gap-2"
                                >
                                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                                  <span>{rItem}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}
                  </article>
                );
              })}
            </div>
          )}

              {/* Bottom Return to Home & Scroll Top Bar after finishing questions */}
              <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs flex flex-wrap items-center justify-between gap-3">
                <div className="text-xs sm:text-sm text-slate-600">
                  Đã làm: <strong className="text-blue-700">{lessonMcqAnswered}/{lessonMcqTotal} câu TN</strong> ·{' '}
                  <strong className="text-amber-700">{lessonTfCompletedCards}/{currentLesson.trueFalseList.length} bài Đ/S</strong> ·{' '}
                  <strong className="text-emerald-700">{lessonEssayCompleted}/{lessonEssayTotal} bài TL</strong>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {totalMissingItems > 0 && (
                    <button
                      type="button"
                      onClick={jumpToNextMissingQuestion}
                      className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <AlertCircle className="w-4 h-4" />
                      <span>Làm tiếp câu còn thiếu ({totalMissingItems})</span>
                    </button>
                  )}
                  {onBackToHome && (
                    <button
                      type="button"
                      onClick={onBackToHome}
                      className="px-4 py-2 rounded-xl bg-[#081e26] hover:bg-teal-950 text-white font-extrabold text-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <Home className="w-4 h-4 text-emerald-400" />
                      <span>Quay về Trang chủ</span>
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* RIGHT COLUMN (4 COLS ON XL): PARALLEL STICKY QUESTION COORDINATOR PANEL */}
            <aside className="xl:col-span-4 order-1 xl:order-2 xl:sticky xl:top-20 space-y-4">
              <div className="bg-white rounded-2xl border-2 border-teal-500/80 shadow-md overflow-hidden">
                {/* Coordinator Header */}
                <div className="bg-gradient-to-r from-[#081e26] via-[#0d3b46] to-[#081e26] text-white px-4 py-3.5 flex items-center justify-between gap-2">
                  <div>
                    <div className="text-[10px] font-mono uppercase tracking-wider text-emerald-300 font-bold">
                      BẢNG ĐIỀU PHỐI SONG SONG
                    </div>
                    <h4 className="text-sm font-black text-white">
                      Bài {currentLesson.lessonNumber}: Sơ đồ câu hỏi
                    </h4>
                  </div>
                  {onBackToHome && (
                    <button
                      type="button"
                      onClick={onBackToHome}
                      className="px-2.5 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white text-[11px] font-extrabold flex items-center gap-1 cursor-pointer shrink-0"
                      title="Quay về Trang chủ"
                    >
                      <Home className="w-3.5 h-3.5 text-amber-300" />
                      <span>Trang chủ</span>
                    </button>
                  )}
                </div>

                <div className="p-4 space-y-4 max-h-[calc(100vh-8rem)] overflow-y-auto">
                  {/* Live Summary Counters: Done vs Partial vs Unanswered */}
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-200">
                      <div className="text-[10px] font-extrabold uppercase text-emerald-700">
                        Đã làm đủ
                      </div>
                      <div className="text-base font-black text-emerald-900 tabular-nums">
                        {lessonMcqAnswered + lessonTfCompletedCards + lessonEssayCompleted}
                      </div>
                    </div>
                    <div className="p-2 rounded-xl bg-amber-50 border border-amber-200">
                      <div className="text-[10px] font-extrabold uppercase text-amber-700">
                        Còn thiếu ý
                      </div>
                      <div className="text-base font-black text-amber-900 tabular-nums">
                        {lessonTfPartialCards}
                      </div>
                    </div>
                    <div className="p-2 rounded-xl bg-rose-50 border border-rose-200">
                      <div className="text-[10px] font-extrabold uppercase text-rose-700">
                        Chưa làm
                      </div>
                      <div className="text-base font-black text-rose-900 tabular-nums">
                        {lessonMcqUnanswered +
                          (currentLesson.trueFalseList.length -
                            lessonTfCompletedCards -
                            lessonTfPartialCards) +
                          lessonEssayUnanswered}
                      </div>
                    </div>
                  </div>

                  {/* Quick Jump to Next Missing Question Button OR Full Completion Celebration Banner */}
                  {totalMissingItems > 0 ? (
                    <button
                      type="button"
                      onClick={jumpToNextMissingQuestion}
                      className="w-full py-2.5 px-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-2xs transition cursor-pointer"
                    >
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>Nhảy tới câu chưa làm / còn thiếu ({totalMissingItems})</span>
                      <ArrowUpRight className="w-3.5 h-3.5 shrink-0" />
                    </button>
                  ) : (
                    <div className="p-3 rounded-xl bg-gradient-to-r from-emerald-100 via-teal-100 to-amber-100 border border-emerald-400 text-emerald-950 space-y-2 text-center">
                      <div className="text-xs font-black flex items-center justify-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                        <span>🎉 Tuyệt vời! Đã hoàn thành 100% bài tập Bài {currentLesson.lessonNumber}!</span>
                      </div>
                      <button
                        type="button"
                        onClick={triggerCelebrationConfetti}
                        className="w-full py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold shadow-2xs transition cursor-pointer"
                      >
                        🎆 Bắn pháo hoa chúc mừng!
                      </button>
                    </div>
                  )}

                  {/* 1. MCQ Number Grid (1..30) */}
                  <div className="space-y-2 pt-1 border-t border-slate-100">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-extrabold text-slate-800">
                        I. Trắc nghiệm ({lessonMcqAnswered}/{lessonMcqTotal})
                      </span>
                      <span className="text-[11px] font-semibold text-rose-600">
                        {lessonMcqUnanswered > 0
                          ? `Thiếu ${lessonMcqUnanswered} câu`
                          : 'Đã làm đủ'}
                      </span>
                    </div>

                    <div className="grid grid-cols-6 sm:grid-cols-10 xl:grid-cols-6 gap-1.5">
                      {currentLesson.mcqs.map((q, idx) => {
                        const qNum = idx + 1;
                        const key = `${currentLesson.id}:${q.id}`;
                        const userAns = mcqAnswers[key];
                        const isAnswered = userAns !== undefined;
                        const isCorrect = isAnswered && userAns === q.correctIndex;
                        const isActiveHighlight = highlightedCardId === `mcq-card-${qNum}`;

                        return (
                          <button
                            key={q.id}
                            type="button"
                            onClick={() => scrollToQuestionCard(`mcq-card-${qNum}`, 'mcq')}
                            title={
                              !isAnswered
                                ? `Câu ${qNum}: Chưa làm (Bấm để chuyển tới)`
                                : isCorrect
                                ? `Câu ${qNum}: Đã làm - Chính xác`
                                : `Câu ${qNum}: Đã làm - Cần xem lại`
                            }
                            className={`h-8 rounded-lg font-mono text-xs font-black flex items-center justify-center border transition-all cursor-pointer tabular-nums ${
                              isActiveHighlight
                                ? 'ring-2 ring-blue-600 scale-105 '
                                : ''
                            }${
                              !isAnswered
                                ? 'bg-slate-50 text-slate-600 border-dashed border-slate-300 hover:border-blue-500 hover:text-blue-700'
                                : isCorrect
                                ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                                : 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                            }`}
                          >
                            {qNum}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* 2. True/False Coordinator Grid (5 Bài x 4 Ý a,b,c,d) */}
                  <div className="space-y-2 pt-2 border-t border-slate-100">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-extrabold text-slate-800">
                        II. Đúng – Sai ({lessonTfCompletedCards}/{currentLesson.trueFalseList.length} bài)
                      </span>
                      <span className="text-[11px] font-semibold text-amber-700">
                        {lessonTfAnsweredStatements}/{lessonTfTotalStatements} ý
                      </span>
                    </div>

                    <div className="grid grid-cols-1 gap-1.5">
                      {tfCardStatuses.map((item) => {
                        const isComplete = item.status === 'completed';
                        const isPartial = item.status === 'partial';
                        return (
                          <button
                            key={item.tf.id}
                            type="button"
                            onClick={() =>
                              scrollToQuestionCard(`tf-card-${item.index}`, 'tf')
                            }
                            className={`w-full px-3 py-2 rounded-xl border text-left text-xs font-bold flex items-center justify-between transition cursor-pointer ${
                              isComplete
                                ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                                : isPartial
                                ? 'bg-amber-50 border-amber-400 text-amber-950'
                                : 'bg-slate-50 border-dashed border-slate-300 text-slate-700 hover:border-amber-400'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <span
                                className={`px-2 py-0.5 rounded font-mono text-[11px] font-black ${
                                  isComplete
                                    ? 'bg-emerald-600 text-white'
                                    : isPartial
                                    ? 'bg-amber-500 text-slate-950'
                                    : 'bg-slate-200 text-slate-700'
                                }`}
                              >
                                Đ/S {item.index}
                              </span>
                              <span>
                                {isComplete
                                  ? 'Đã chọn đủ 4/4 ý'
                                  : isPartial
                                  ? `Còn thiếu ý: ${item.missingStatements.join(', ')}`
                                  : 'Chưa làm (0/4 ý)'}
                              </span>
                            </div>
                            <span className="font-mono text-[11px] font-black">
                              {item.answeredCount}/{item.totalCount}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* 3. Essay Coordinator Grid (Tự luận 1..N) */}
                  <div className="space-y-2 pt-2 border-t border-slate-100">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-extrabold text-slate-800">
                        III. Tự luận ({lessonEssayCompleted}/{lessonEssayTotal} bài)
                      </span>
                      <span className="text-[11px] font-semibold text-emerald-700">
                        {lessonEssayUnanswered > 0
                          ? `Thiếu ${lessonEssayUnanswered} bài`
                          : 'Đã hoàn thành'}
                      </span>
                    </div>

                    <div className="grid grid-cols-5 gap-1.5">
                      {currentLesson.essays.map((es, idx) => {
                        const esNum = idx + 1;
                        const sub = essaySubmissions[`${currentLesson.id}:${es.id}`];
                        const isDone =
                          sub &&
                          (sub.textAnswer.trim().length > 0 ||
                            sub.attachedImages.length > 0);
                        return (
                          <button
                            key={es.id}
                            type="button"
                            onClick={() =>
                              scrollToQuestionCard(`essay-card-${esNum}`, 'essay')
                            }
                            title={
                              isDone
                                ? `Tự luận ${esNum}: Đã làm / đính ảnh`
                                : `Tự luận ${esNum}: Chưa làm`
                            }
                            className={`py-2 rounded-lg font-mono text-xs font-black border transition cursor-pointer ${
                              isDone
                                ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                                : 'bg-slate-50 text-slate-600 border-dashed border-slate-300 hover:border-emerald-500'
                            }`}
                          >
                            TL {esNum}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Color Legend */}
                  <div className="pt-2 border-t border-slate-100 grid grid-cols-2 gap-1.5 text-[11px] text-slate-600 font-semibold">
                    <div className="flex items-center gap-1.5">
                      <span className="w-3 h-3 rounded bg-emerald-600 inline-block shrink-0" />
                      <span>Đã làm / Đúng</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-3 h-3 rounded bg-rose-600 inline-block shrink-0" />
                      <span>Đã làm / Sai</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-3 h-3 rounded bg-amber-400 inline-block shrink-0" />
                      <span>Còn thiếu ý</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-3 h-3 rounded border border-dashed border-slate-400 bg-slate-50 inline-block shrink-0" />
                      <span>Chưa làm</span>
                    </div>
                  </div>
                </div>
              </div>
            </aside>
          </div>
        </section>
      </div>

      {/* LIVE CAMERA CAPTURE MODAL */}
      {liveCameraTargetKey && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden border border-slate-200 shadow-xl">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h4 className="text-base font-bold text-slate-900">
                  Chụp ảnh bài làm tự luận trực tiếp
                </h4>
                <p className="text-xs text-slate-500">
                  Hướng camera vào trang vở bài tập và nhấn Chụp ảnh
                </p>
              </div>
              <button
                onClick={closeLiveCamera}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 bg-slate-950 flex items-center justify-center min-h-[280px]">
              {liveCameraError ? (
                <div className="text-center p-6 space-y-3">
                  <p className="text-sm text-amber-200">{liveCameraError}</p>
                  <button
                    onClick={() => {
                      const target = liveCameraTargetKey;
                      closeLiveCamera();
                      if (target) cameraInputRefs.current[target]?.click();
                    }}
                    className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-bold cursor-pointer"
                  >
                    Mở ứng dụng Máy ảnh của điện thoại
                  </button>
                </div>
              ) : (
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full max-h-[380px] rounded-lg object-contain"
                />
              )}
            </div>

            <div className="p-4 border-t border-slate-200 flex items-center justify-end gap-2 bg-slate-50">
              <button
                onClick={closeLiveCamera}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-200 cursor-pointer"
              >
                Hủy
              </button>
              {!liveCameraError && (
                <button
                  onClick={captureFromLiveCamera}
                  className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white cursor-pointer"
                >
                  <Camera className="w-4 h-4" />
                  Chụp &amp; Đính vào bài làm
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* IMAGE LIGHTBOX ZOOM MODAL */}
      {lightboxImage && (
        <div
          onClick={() => setLightboxImage(null)}
          className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl max-w-4xl w-full overflow-hidden border border-slate-200 shadow-2xl"
          >
            <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
              <span className="text-sm font-bold text-slate-900">
                {lightboxImage.title}
              </span>
              <button
                onClick={() => setLightboxImage(null)}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 bg-slate-900 max-h-[80vh] overflow-auto flex items-center justify-center">
              <img
                src={lightboxImage.url}
                alt={lightboxImage.title}
                className="max-w-full max-h-[75vh] object-contain rounded-lg"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
