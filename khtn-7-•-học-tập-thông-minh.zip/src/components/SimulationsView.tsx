import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Atom,
  Gauge,
  Sprout,
  SunMedium,
  Volume2,
  VolumeX,
  Magnet,
  FlaskConical,
  Flame,
  Zap,
} from 'lucide-react';
import { ELEMENTS_FIRST_20, ElementData } from '../data/khtn7Data';

type ActiveLab =
  | 'chemistry-bohr'
  | 'chemistry-bonding'
  | 'physics-motion-optics'
  | 'physics-sound'
  | 'physics-magnetism'
  | 'biology-vascular';
type PhysicsSubMode = 'motion' | 'optics';

interface MoleculeBondModel {
  id: string;
  formula: string;
  name: string;
  bondType: 'ion' | 'covalent';
  massAmu: number;
  atomsDesc: string;
  mechanismDesc: string;
  leftAtom: { symbol: string; z: number; outerE: number; targetOuterE: number; chargeLabel: string; color: string };
  rightAtom: { symbol: string; z: number; outerE: number; targetOuterE: number; chargeLabel: string; color: string };
  transferredOrSharedCount: number;
}

const BOND_MOLECULES: MoleculeBondModel[] = [
  {
    id: 'nacl',
    formula: 'NaCl',
    name: 'Sodium chloride (Muối ăn)',
    bondType: 'ion',
    massAmu: 58.5,
    atomsDesc: '1 nguyên tử Kim loại Na (Z=11) + 1 nguyên tử Phi kim Cl (Z=17)',
    mechanismDesc:
      'Nguyên tử Na nhường 1e lớp ngoài cùng cho nguyên tử Cl → Tạo ion dương Na⁺ (vỏ 2,8 bền vững) và ion âm Cl⁻ (vỏ 2,8,8 bền vững) hút nhau bằng lực tĩnh điện.',
    leftAtom: { symbol: 'Na', z: 11, outerE: 1, targetOuterE: 8, chargeLabel: 'Na⁺', color: '#38bdf8' },
    rightAtom: { symbol: 'Cl', z: 17, outerE: 7, targetOuterE: 8, chargeLabel: 'Cl⁻', color: '#34d399' },
    transferredOrSharedCount: 1,
  },
  {
    id: 'mgo',
    formula: 'MgO',
    name: 'Magnesium oxide',
    bondType: 'ion',
    massAmu: 40,
    atomsDesc: '1 nguyên tử Kim loại Mg (Z=12) + 1 nguyên tử Phi kim O (Z=8)',
    mechanismDesc:
      'Nguyên tử Mg nhường 2e lớp ngoài cùng cho nguyên tử O → Tạo ion Mg²⁺ và ion O²⁻ đều có 8e lớp ngoài cùng giống khí hiếm Neon.',
    leftAtom: { symbol: 'Mg', z: 12, outerE: 2, targetOuterE: 8, chargeLabel: 'Mg²⁺', color: '#60a5fa' },
    rightAtom: { symbol: 'O', z: 8, outerE: 6, targetOuterE: 8, chargeLabel: 'O²⁻', color: '#f43f5e' },
    transferredOrSharedCount: 2,
  },
  {
    id: 'h2o',
    formula: 'H₂O',
    name: 'Phân tử Nước',
    bondType: 'covalent',
    massAmu: 18,
    atomsDesc: '2 nguyên tử Phi kim H (Z=1) + 1 nguyên tử Phi kim O (Z=8)',
    mechanismDesc:
      'Nguyên tử O (6e ngoài cùng) góp chung 2e với 2 nguyên tử H (mỗi H góp 1e) tạo ra 2 cặp electron dùng chung. O đạt 8e (giống Ne), mỗi H đạt 2e (giống He).',
    leftAtom: { symbol: '2H', z: 1, outerE: 1, targetOuterE: 2, chargeLabel: 'Góp 2e', color: '#38bdf8' },
    rightAtom: { symbol: 'O', z: 8, outerE: 6, targetOuterE: 8, chargeLabel: 'Góp 2e', color: '#f43f5e' },
    transferredOrSharedCount: 2,
  },
  {
    id: 'co2',
    formula: 'CO₂',
    name: 'Carbon dioxide (Khí cacbonic)',
    bondType: 'covalent',
    massAmu: 44,
    atomsDesc: '1 nguyên tử C (Z=6) + 2 nguyên tử O (Z=8)',
    mechanismDesc:
      'Nguyên tử C (4e ngoài cùng) góp chung 4e với 2 nguyên tử O (mỗi O góp 2e) tạo thành 4 cặp electron dùng chung để cả C và O đều đạt 8e bền vững.',
    leftAtom: { symbol: 'C', z: 6, outerE: 4, targetOuterE: 8, chargeLabel: 'Góp 4e', color: '#fbbf24' },
    rightAtom: { symbol: '2O', z: 8, outerE: 6, targetOuterE: 8, chargeLabel: 'Góp 4e', color: '#f43f5e' },
    transferredOrSharedCount: 4,
  },
];

export const SimulationsView: React.FC = () => {
  const [activeLab, setActiveLab] = useState<ActiveLab>('chemistry-bohr');

  // --- Lab 1: Chemistry Rutherford-Bohr State ---
  const [selectedZ, setSelectedZ] = useState<number>(8); // Default Oxygen (Z=8)
  const [orbitPlaying, setOrbitPlaying] = useState<boolean>(true);
  const [orbitAngle, setOrbitAngle] = useState<number>(0);

  // --- Lab 2: Physics Motion & Optics State ---
  const [physicsMode, setPhysicsMode] = useState<PhysicsSubMode>('motion');
  const [v1Kmh, setV1Kmh] = useState<number>(54); // 15 m/s
  const [v2Kmh, setV2Kmh] = useState<number>(36); // 10 m/s
  const [simTimeHours, setSimTimeHours] = useState<number>(1.5); // 0 to 3 hours
  const [motionPlaying, setMotionPlaying] = useState<boolean>(false);
  const [incidentAngle, setIncidentAngle] = useState<number>(40); // degrees

  // --- Lab 3: Biology Xylem/Phloem & Photosynthesis State ---
  const [lightIntensity, setLightIntensity] = useState<number>(650); // 0 - 1000 lux*100
  const [co2Ppm, setCo2Ppm] = useState<number>(420); // 100 - 1000 ppm
  const [temperatureC, setTemperatureC] = useState<number>(28); // 10 - 45 C
  const [soilMoisture, setSoilMoisture] = useState<number>(75); // 15 - 95 %
  const [bioFlowTick, setBioFlowTick] = useState<number>(0);
  const [bioPlaying, setBioPlaying] = useState<boolean>(true);
  const [splintTestMode, setSplintTestMode] = useState<'idle' | 'oxygen_burst' | 'co2_extinguish'>('idle');

  // --- Lab 4: Chemistry Chemical Bonding State ---
  const [selectedMoleculeId, setSelectedMoleculeId] = useState<string>('nacl');
  const [bondFormed, setBondFormed] = useState<boolean>(false);

  // --- Lab 5: Physics Sound Waves & Oscilloscope State ---
  const [soundFreqHz, setSoundFreqHz] = useState<number>(440); // 100 - 1000 Hz
  const [soundAmplitude, setSoundAmplitude] = useState<number>(65); // 10 - 100 %
  const [isTonePlaying, setIsTonePlaying] = useState<boolean>(false);
  const [wavePhase, setWavePhase] = useState<number>(0);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscNodeRef = useRef<OscillatorNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  // --- Lab 6: Physics Electromagnet & Magnetic Field State ---
  const [coilTurns, setCoilTurns] = useState<number>(100); // 20 - 200 turns
  const [currentAmp, setCurrentAmp] = useState<number>(2.5); // 0 - 5.0 A
  const [hasIronCore, setHasIronCore] = useState<boolean>(true);
  const [reversePolarity, setReversePolarity] = useState<boolean>(false);
  const [switchClosed, setSwitchClosed] = useState<boolean>(true);

  const currentMolecule =
    BOND_MOLECULES.find((m) => m.id === selectedMoleculeId) || BOND_MOLECULES[0];

  const currentElement: ElementData =
    ELEMENTS_FIRST_20.find((el) => el.z === selectedZ) || ELEMENTS_FIRST_20[7];

  // Stop Web Audio tone if switching away from sound lab
  useEffect(() => {
    if (activeLab !== 'physics-sound' && isTonePlaying) {
      if (oscNodeRef.current) {
        try {
          oscNodeRef.current.stop();
        } catch {
          // ignore
        }
        oscNodeRef.current = null;
      }
      setIsTonePlaying(false);
    }
  }, [activeLab, isTonePlaying]);

  // Update live frequency and gain when sliders move during tone playback
  useEffect(() => {
    if (isTonePlaying && audioCtxRef.current && oscNodeRef.current && gainNodeRef.current) {
      const now = audioCtxRef.current.currentTime;
      oscNodeRef.current.frequency.setValueAtTime(soundFreqHz, now);
      gainNodeRef.current.gain.setValueAtTime((soundAmplitude / 100) * 0.22, now);
    }
  }, [soundFreqHz, soundAmplitude, isTonePlaying]);

  const toggleSoundTone = () => {
    if (isTonePlaying) {
      if (oscNodeRef.current) {
        try {
          oscNodeRef.current.stop();
        } catch {
          // ignore
        }
        oscNodeRef.current = null;
      }
      setIsTonePlaying(false);
      return;
    }

    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    if (!audioCtxRef.current) {
      audioCtxRef.current = new AudioCtx();
    }
    if (audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume().catch(() => {});
    }
    const osc = audioCtxRef.current.createOscillator();
    const gain = audioCtxRef.current.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(soundFreqHz, audioCtxRef.current.currentTime);
    gain.gain.setValueAtTime((soundAmplitude / 100) * 0.22, audioCtxRef.current.currentTime);
    osc.connect(gain);
    gain.connect(audioCtxRef.current.destination);
    osc.start();
    oscNodeRef.current = osc;
    gainNodeRef.current = gain;
    setIsTonePlaying(true);
  };

  // Animation loop for Bohr model, Biology vascular flow, and Sound wave phase
  useEffect(() => {
    const interval = setInterval(() => {
      if (orbitPlaying && activeLab === 'chemistry-bohr') {
        setOrbitAngle((prev) => (prev + 2) % 360);
      }
      if (bioPlaying && activeLab === 'biology-vascular') {
        setBioFlowTick((prev) => (prev + 1) % 100);
      }
      if (activeLab === 'physics-sound') {
        setWavePhase((prev) => (prev + Math.max(2, Math.round(soundFreqHz / 80))) % 360);
      }
    }, 50);
    return () => clearInterval(interval);
  }, [orbitPlaying, bioPlaying, activeLab, soundFreqHz]);

  // Animation loop for Physics motion
  useEffect(() => {
    if (!motionPlaying || activeLab !== 'physics-motion-optics' || physicsMode !== 'motion') {
      return;
    }
    const timer = setInterval(() => {
      setSimTimeHours((prev) => {
        if (prev >= 3.0) {
          setMotionPlaying(false);
          return 3.0;
        }
        return Number((prev + 0.05).toFixed(2));
      });
    }, 80);
    return () => clearInterval(timer);
  }, [motionPlaying, activeLab, physicsMode]);

  // Calculate Photosynthesis & Vascular rates for Biology Lab
  const tempFactor =
    temperatureC < 15
      ? 0.35
      : temperatureC <= 33
      ? 1.0 - Math.abs(27 - temperatureC) * 0.025
      : Math.max(0.15, 1.0 - (temperatureC - 33) * 0.075);

  const stomataOpeningPct =
    soilMoisture < 30 || temperatureC > 39
      ? Math.max(12, Math.round(soilMoisture * 0.45))
      : Math.min(100, Math.round(soilMoisture * 0.85 + (lightIntensity / 1000) * 20));

  const photosynthesisRate = Math.round(
    Math.min(100, (lightIntensity / 850) * (co2Ppm / 600) * tempFactor * (stomataOpeningPct / 80) * 100)
  );

  const xylemFlowSpeed = Math.round((stomataOpeningPct * 0.65 + (temperatureC / 40) * 35));

  return (
    <section className="space-y-6">
      {/* Lab Selection Bar (6 Virtual Labs across Chemistry, Physics, Biology) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div>
            <p className="text-xs font-extrabold uppercase tracking-wider text-teal-700">
              TRUNG TÂM THÍ NGHIỆM ẢO TƯƠNG TÁC KHTN 7 (6 PHÒNG LAB ĐỦ 3 PHÂN MÔN)
            </p>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 mt-0.5">
              Khám phá bản chất tự nhiên qua thông số thực nghiệm trực quan
            </h2>
          </div>
          <span className="px-3 py-1.5 rounded-xl bg-teal-50 border border-teal-200 text-teal-900 text-xs font-extrabold self-start">
            🧪 2 Lab Hóa học · ⚡ 3 Lab Vật lí · 🌿 1 Lab Sinh học (Tích hợp thử que đóm)
          </span>
        </div>

        {/* 6-Button Grid Lab Switcher */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {[
            {
              id: 'chemistry-bohr' as ActiveLab,
              sub: 'HÓA HỌC 7 (Bài 2–4)',
              title: 'Mô hình Nguyên tử Bohr & BTH',
              icon: <Atom className="w-4 h-4 text-blue-600" />,
            },
            {
              id: 'chemistry-bonding' as ActiveLab,
              sub: 'HÓA HỌC 7 (Bài 5–7)',
              title: 'Liên kết Ion & Cộng hóa trị',
              icon: <FlaskConical className="w-4 h-4 text-amber-600" />,
            },
            {
              id: 'physics-motion-optics' as ActiveLab,
              sub: 'VẬT LÍ 7 (Bài 8–11, 15–17)',
              title: 'Đồ thị Tốc độ & Phản xạ Ánh sáng',
              icon: <Gauge className="w-4 h-4 text-indigo-600" />,
            },
            {
              id: 'physics-sound' as ActiveLab,
              sub: 'VẬT LÍ 7 (Bài 12–14)',
              title: 'Dao động kí Sóng âm & Phát tần số Hz',
              icon: <Volume2 className="w-4 h-4 text-rose-600" />,
            },
            {
              id: 'physics-magnetism' as ActiveLab,
              sub: 'VẬT LÍ 7 (Bài 18–21)',
              title: 'Từ trường & Chế tạo Nam châm điện',
              icon: <Magnet className="w-4 h-4 text-purple-600" />,
            },
            {
              id: 'biology-vascular' as ActiveLab,
              sub: 'SINH HỌC 7 (Bài 22–30)',
              title: 'Mạch gỗ, Quang hợp & Thử que đóm',
              icon: <Sprout className="w-4 h-4 text-emerald-600" />,
            },
          ].map((tab) => {
            const isActive = activeLab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveLab(tab.id)}
                className={`p-3 rounded-xl border text-left transition-all flex items-center gap-3 cursor-pointer ${
                  isActive
                    ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                }`}
              >
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isActive ? 'bg-white/15' : 'bg-white border border-slate-200'
                  }`}
                >
                  {tab.icon}
                </div>
                <div className="min-w-0">
                  <div
                    className={`text-[10px] font-mono uppercase font-bold ${
                      isActive ? 'text-emerald-300' : 'text-slate-500'
                    }`}
                  >
                    {tab.sub}
                  </div>
                  <div className="text-xs sm:text-sm font-extrabold truncate">{tab.title}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* =====================================================================
          LAB 1: CHEMISTRY - RUTHERFORD-BOHR ATOMIC MODEL & PERIODIC TABLE
         ===================================================================== */}
      {activeLab === 'chemistry-bohr' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Left Zone (65% -> 8 cols): Interactive Stage */}
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <div className="text-xs text-slate-500">
                  Hóa học 7 · Ô nguyên tố số {currentElement.z} · Chu kì {currentElement.period} · Nhóm {currentElement.group}
                </div>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  {currentElement.nameIupac} ({currentElement.nameVi}) — Ký hiệu: {currentElement.symbol}
                </h3>
              </div>

              {/* Dual-coded state indicator (Icon + Text, never color alone) */}
              <div className="text-xs font-mono font-semibold">
                {currentElement.category === 'Khí hiếm' && (
                  <span className="text-emerald-700">● KHÍ HIẾM · VỎ BỀN VỮNG ({currentElement.shells[currentElement.shells.length - 1]}e)</span>
                )}
                {currentElement.category === 'Kim loại' && (
                  <span className="text-blue-700">▲ KIM LOẠI · DỄ NHƯỜNG ELECTRON ({currentElement.shells[currentElement.shells.length - 1]}e ngoài cùng)</span>
                )}
                {currentElement.category === 'Phi kim' && (
                  <span className="text-amber-700">◆ PHI KIM · NHẬN / GÓP CHUNG ELECTRON ({currentElement.shells[currentElement.shells.length - 1]}e ngoài cùng)</span>
                )}
              </div>
            </div>

            {/* SVG Rutherford-Bohr Diagram + Mini Periodic Selector */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 py-4 items-center">
              {/* Animated Bohr Canvas */}
              <div className="md:col-span-7 flex flex-col items-center justify-center bg-slate-900 rounded-xl p-4 relative min-h-[340px]">
                <svg viewBox="0 0 320 320" className="w-full max-w-[300px] h-auto">
                  {/* Coordinate crosshairs */}
                  <line x1="160" y1="10" x2="160" y2="310" stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
                  <line x1="10" y1="160" x2="310" y2="160" stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />

                  {/* Electron Shells */}
                  {currentElement.shells.map((electronCount, shellIdx) => {
                    const radius = 44 + shellIdx * 28;
                    const shellLabel = ['K', 'L', 'M', 'N'][shellIdx];
                    const isOuterShell = shellIdx === currentElement.shells.length - 1;
                    return (
                      <g key={shellIdx}>
                        <circle
                          cx="160"
                          cy="160"
                          r={radius}
                          fill="none"
                          stroke={isOuterShell ? '#38bdf8' : '#475569'}
                          strokeWidth={isOuterShell ? '1.75' : '1.2'}
                          strokeDasharray={isOuterShell ? 'none' : '4 3'}
                        />
                        <text
                          x={160 + radius - 10}
                          y="155"
                          fill="#94a3b8"
                          fontSize="9"
                          fontFamily="IBM Plex Mono, monospace"
                        >
                          {shellLabel}
                        </text>

                        {/* Electrons on this shell */}
                        {Array.from({ length: electronCount }).map((_, eIdx) => {
                          const baseDeg = (360 / electronCount) * eIdx;
                          const speedMultiplier = shellIdx % 2 === 0 ? 1 : -0.75;
                          const angleRad = ((baseDeg + orbitAngle * speedMultiplier) * Math.PI) / 180;
                          const ex = 160 + radius * Math.cos(angleRad);
                          const ey = 160 + radius * Math.sin(angleRad);
                          return (
                            <g key={eIdx}>
                              <circle
                                cx={ex}
                                cy={ey}
                                r={isOuterShell ? 5.5 : 4.2}
                                fill={isOuterShell ? '#38bdf8' : '#cbd5e1'}
                                stroke="#0f172a"
                                strokeWidth="1.5"
                              />
                            </g>
                          );
                        })}
                      </g>
                    );
                  })}

                  {/* Nucleus */}
                  <circle cx="160" cy="160" r="22" fill="#dc2626" stroke="#fca5a5" strokeWidth="2" />
                  <text
                    x="160"
                    y="157"
                    textAnchor="middle"
                    fill="#ffffff"
                    fontSize="11"
                    fontWeight="bold"
                    fontFamily="IBM Plex Mono, monospace"
                  >
                    +{currentElement.z}
                  </text>
                  <text
                    x="160"
                    y="169"
                    textAnchor="middle"
                    fill="#fecaca"
                    fontSize="8.5"
                    fontFamily="IBM Plex Mono, monospace"
                  >
                    {currentElement.neutrons}n
                  </text>
                </svg>

                <div className="w-full flex items-center justify-between text-xs text-slate-300 font-mono px-2 pt-2 border-t border-slate-800">
                  <span>Hạt nhân: {currentElement.z}p + {currentElement.neutrons}n</span>
                  <span>Phân bố e: {currentElement.shells.join(' - ')}</span>
                </div>
              </div>

              {/* Quick 20-Element Periodic Grid */}
              <div className="md:col-span-5 space-y-3">
                <div className="text-xs font-semibold text-slate-700">
                  Chọn nhanh 20 nguyên tố đầu bảng tuần hoàn (Z = 1 → 20):
                </div>
                <div className="grid grid-cols-5 gap-1.5">
                  {ELEMENTS_FIRST_20.map((el) => {
                    const isSelected = el.z === selectedZ;
                    return (
                      <button
                        key={el.z}
                        type="button"
                        onClick={() => setSelectedZ(el.z)}
                        className={`p-2 rounded-lg border text-left transition-colors ${
                          isSelected
                            ? 'bg-blue-600 text-white border-blue-600 font-bold'
                            : 'bg-slate-50 text-slate-800 border-slate-200 hover:border-slate-400'
                        }`}
                      >
                        <div className={`text-[10px] font-mono tabular-nums ${isSelected ? 'text-blue-100' : 'text-slate-500'}`}>
                          {el.z}
                        </div>
                        <div className="text-sm font-bold leading-tight">{el.symbol}</div>
                      </button>
                    );
                  })}
                </div>
                <p className="text-xs text-slate-600 leading-relaxed pt-1">
                  <strong className="text-slate-900">Ứng dụng thực tiễn:</strong> {currentElement.application}
                </p>
              </div>
            </div>

            {/* Bottom Telemetry / Formula Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-slate-100 text-xs">
              <div>
                <span className="text-slate-500 block">Điện tích hạt nhân (Z)</span>
                <span className="font-mono font-bold text-base text-slate-900 tabular-nums">
                  +{currentElement.z} ({currentElement.z}p = {currentElement.z}e)
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Khối lượng nguyên tử (A)</span>
                <span className="font-mono font-bold text-base text-slate-900 tabular-nums">
                  {currentElement.mass} amu
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Số lớp / Lớp ngoài cùng</span>
                <span className="font-mono font-bold text-base text-slate-900 tabular-nums">
                  {currentElement.period} lớp / {currentElement.shells[currentElement.shells.length - 1]}e
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Hóa trị phổ biến</span>
                <span className="font-mono font-bold text-base text-blue-700 tabular-nums">
                  {currentElement.valence}
                </span>
              </div>
            </div>
          </div>

          {/* Right Zone (35% -> 4 cols): Control & Concept Deck */}
          <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between space-y-6">
            <div className="space-y-5">
              <div>
                <h4 className="text-base font-bold text-slate-900">Bảng điều khiển nguyên tử</h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Điều chỉnh số hạt Proton (Z) để quan sát quy luật điền electron vào các lớp K, L, M, N.
                </p>
              </div>

              {/* Slider with explicit label, numeric value, and unit */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <label htmlFor="slider-z" className="font-semibold text-slate-700">
                    Số hiệu nguyên tử (Z = số p):
                  </label>
                  <span className="font-mono font-bold text-blue-700 tabular-nums">
                    Z = {selectedZ} hạt ({currentElement.symbol})
                  </span>
                </div>
                <input
                  id="slider-z"
                  type="range"
                  min={1}
                  max={20}
                  value={selectedZ}
                  onChange={(e) => setSelectedZ(Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
                <div className="flex justify-between text-[11px] font-mono text-slate-400 tabular-nums">
                  <span>1 (H)</span>
                  <span>10 (Ne)</span>
                  <span>20 (Ca)</span>
                </div>
              </div>

              {/* Playback Controls */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setOrbitPlaying((prev) => !prev)}
                  className="flex-1 flex items-center justify-center gap-2 py-2 px-4 bg-slate-900 text-white text-xs font-semibold rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
                >
                  {orbitPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{orbitPlaying ? 'Tạm dừng quỹ đạo' : 'Chạy quỹ đạo e'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedZ(8)}
                  className="py-2 px-3 border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Step-by-step progressive explanation */}
              <div className="pt-4 border-t border-slate-100 space-y-3 text-xs">
                <div className="font-semibold text-slate-900">Giải thích cấu tạo & Vị trí bảng tuần hoàn:</div>
                <p className="text-slate-600 leading-relaxed">
                  1. <strong className="text-slate-900">Trung hòa điện:</strong> Nguyên tử {currentElement.nameIupac} có{' '}
                  <span className="font-mono font-semibold">{currentElement.z} proton (+)</span> trong hạt nhân nên vỏ nguyên tử có đúng{' '}
                  <span className="font-mono font-semibold">{currentElement.z} electron (-)</span>.
                </p>
                <p className="text-slate-600 leading-relaxed">
                  2. <strong className="text-slate-900">Chu kì {currentElement.period}:</strong> Các electron được xếp vào{' '}
                  <span className="font-mono font-semibold">{currentElement.shells.length} lớp</span> ({currentElement.shells.join(' / ')}), do đó nguyên tố nằm ở hàng ngang số {currentElement.period}.
                </p>
                <p className="text-slate-600 leading-relaxed">
                  3. <strong className="text-slate-900">Xu hướng liên kết:</strong>{' '}
                  {currentElement.category === 'Khí hiếm'
                    ? 'Lớp ngoài cùng đã bão hòa bền vững nên nguyên tử tồn tại độc lập, hầu như không liên kết.'
                    : currentElement.category === 'Kim loại'
                    ? `Có ${currentElement.shells[currentElement.shells.length - 1]}e lớp ngoài cùng, dễ nhường electron để tạo ion dương trong liên kết ion.`
                    : `Có ${currentElement.shells[currentElement.shells.length - 1]}e lớp ngoài cùng, dễ nhận thêm hoặc góp chung ${8 - currentElement.shells[currentElement.shells.length - 1]} electron để đạt 8e bền vững.`}
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 text-xs font-mono text-slate-600">
              Công thức chuẩn: A = Z + N = {currentElement.z} + {currentElement.neutrons} = {currentElement.mass} amu
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          LAB 2: PHYSICS - SPEED GRAPH (s - t) & LIGHT REFLECTION (i = i')
         ===================================================================== */}
      {activeLab === 'physics-motion-optics' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Left Zone: Interactive Stage */}
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <div className="text-xs text-slate-500">
                  Vật lí 7 · Năng lượng và sự biến đổi · Đo lường trực tiếp
                </div>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  {physicsMode === 'motion'
                    ? 'Đồ thị Quãng đường – Thời gian (s – t) của 2 chuyển động đều'
                    : 'Định luật Phản xạ Ánh sáng trên Gương phẳng (i′ = i)'}
                </h3>
              </div>

              <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
                <button
                  type="button"
                  onClick={() => setPhysicsMode('motion')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    physicsMode === 'motion' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Đồ thị s – t (v = s/t)
                </button>
                <button
                  type="button"
                  onClick={() => setPhysicsMode('optics')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    physicsMode === 'optics' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Phản xạ ánh sáng (i = i′)
                </button>
              </div>
            </div>

            {physicsMode === 'motion' ? (
              <div className="space-y-5">
                {/* Coordinate Graph s(km) vs t(h) */}
                <div className="bg-slate-900 rounded-xl p-4">
                  <svg viewBox="0 0 560 250" className="w-full h-auto">
                    {/* Grid lines */}
                    {[0, 1, 2, 3].map((tHour) => {
                      const x = 60 + tHour * 150;
                      return (
                        <g key={tHour}>
                          <line x1={x} y1="20" x2={x} y2="210" stroke="#1e293b" strokeWidth="1" />
                          <text x={x} y="230" textAnchor="middle" fill="#94a3b8" fontSize="11" fontFamily="IBM Plex Mono">
                            {tHour}h
                          </text>
                        </g>
                      );
                    })}
                    {[0, 60, 120, 180, 240].map((sKm, idx) => {
                      const y = 210 - idx * 45;
                      return (
                        <g key={sKm}>
                          <line x1="60" y1={y} x2="510" y2={y} stroke="#1e293b" strokeWidth="1" />
                          <text x="50" y={y + 4} textAnchor="end" fill="#94a3b8" fontSize="10" fontFamily="IBM Plex Mono">
                            {sKm}km
                          </text>
                        </g>
                      );
                    })}

                    {/* Axes */}
                    <line x1="60" y1="210" x2="525" y2="210" stroke="#cbd5e1" strokeWidth="1.5" />
                    <line x1="60" y1="210" x2="60" y2="15" stroke="#cbd5e1" strokeWidth="1.5" />
                    <text x="528" y="214" fill="#f8fafc" fontSize="11" fontWeight="bold" fontFamily="IBM Plex Mono">
                      t (h)
                    </text>
                    <text x="68" y="22" fill="#f8fafc" fontSize="11" fontWeight="bold" fontFamily="IBM Plex Mono">
                      s (km)
                    </text>

                    {/* Line for Vehicle 1 (Blue) */}
                    <line
                      x1="60"
                      y1="210"
                      x2={60 + 3 * 150}
                      y2={210 - ((v1Kmh * 3) / 240) * 180}
                      stroke="#38bdf8"
                      strokeWidth="2.5"
                    />
                    {/* Line for Vehicle 2 (Amber) */}
                    <line
                      x1="60"
                      y1="210"
                      x2={60 + 3 * 150}
                      y2={210 - ((v2Kmh * 3) / 240) * 180}
                      stroke="#fbbf24"
                      strokeWidth="2.5"
                      strokeDasharray="6 3"
                    />

                    {/* Current Time Marker Line */}
                    <line
                      x1={60 + simTimeHours * 150}
                      y1="20"
                      x2={60 + simTimeHours * 150}
                      y2="210"
                      stroke="#f43f5e"
                      strokeWidth="1.2"
                      strokeDasharray="3 3"
                    />

                    {/* Current Position Dots */}
                    <circle
                      cx={60 + simTimeHours * 150}
                      cy={210 - ((v1Kmh * simTimeHours) / 240) * 180}
                      r="5.5"
                      fill="#38bdf8"
                      stroke="#0f172a"
                      strokeWidth="2"
                    />
                    <circle
                      cx={60 + simTimeHours * 150}
                      cy={210 - ((v2Kmh * simTimeHours) / 240) * 180}
                      r="5.5"
                      fill="#fbbf24"
                      stroke="#0f172a"
                      strokeWidth="2"
                    />
                  </svg>
                </div>

                {/* Live Track Comparison */}
                <div className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="font-semibold text-blue-700">
                        ● Xe A: v₁ = {v1Kmh} km/h ({(v1Kmh / 3.6).toFixed(1)} m/s)
                      </span>
                      <span className="font-bold text-slate-900 tabular-nums">
                        s₁ = {(v1Kmh * simTimeHours).toFixed(1)} km
                      </span>
                    </div>
                    <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-blue-600 transition-transform duration-150 origin-left"
                        style={{
                          transform: `scaleX(${Math.min(1, (v1Kmh * simTimeHours) / 270)})`,
                        }}
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="font-semibold text-amber-700">
                        ▲ Xe B: v₂ = {v2Kmh} km/h ({(v2Kmh / 3.6).toFixed(1)} m/s)
                      </span>
                      <span className="font-bold text-slate-900 tabular-nums">
                        s₂ = {(v2Kmh * simTimeHours).toFixed(1)} km
                      </span>
                    </div>
                    <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-amber-500 transition-transform duration-150 origin-left"
                        style={{
                          transform: `scaleX(${Math.min(1, (v2Kmh * simTimeHours) / 270)})`,
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              /* Optics Mode: Plane Mirror Reflection */
              <div className="bg-slate-900 rounded-xl p-6 flex flex-col items-center">
                <svg viewBox="0 0 520 270" className="w-full h-auto max-w-[500px]">
                  {/* Mirror Surface */}
                  <line x1="60" y1="220" x2="460" y2="220" stroke="#38bdf8" strokeWidth="4" />
                  {Array.from({ length: 20 }).map((_, idx) => (
                    <line
                      key={idx}
                      x1={70 + idx * 20}
                      y1="220"
                      x2={62 + idx * 20}
                      y2="232"
                      stroke="#64748b"
                      strokeWidth="1.5"
                    />
                  ))}
                  <text x="455" y="245" textAnchor="end" fill="#94a3b8" fontSize="11" fontFamily="IBM Plex Mono">
                    Gương phẳng (G)
                  </text>

                  {/* Normal Line IN */}
                  <line x1="260" y1="30" x2="260" y2="220" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="5 5" />
                  <text x="266" y="42" fill="#cbd5e1" fontSize="11" fontFamily="IBM Plex Mono">
                    N (Pháp tuyến)
                  </text>
                  <text x="260" y="238" textAnchor="middle" fill="#f8fafc" fontSize="12" fontWeight="bold" fontFamily="IBM Plex Mono">
                    I
                  </text>

                  {/* Calculate Ray Coordinates */}
                  {(() => {
                    const rad = (incidentAngle * Math.PI) / 180;
                    const rayLen = 175;
                    const sx = 260 - rayLen * Math.sin(rad);
                    const sy = 220 - rayLen * Math.cos(rad);
                    const rx = 260 + rayLen * Math.sin(rad);
                    const ry = 220 - rayLen * Math.cos(rad);
                    return (
                      <g>
                        {/* Incident Ray SI */}
                        <line x1={sx} y1={sy} x2="260" y2="220" stroke="#f43f5e" strokeWidth="3" />
                        <text x={sx - 8} y={sy - 6} fill="#fda4af" fontSize="12" fontWeight="bold" fontFamily="IBM Plex Mono">
                          S (Tia tới)
                        </text>

                        {/* Reflected Ray IR */}
                        <line x1="260" y1="220" x2={rx} y2={ry} stroke="#34d399" strokeWidth="3" />
                        <text x={rx + 8} y={ry - 6} textAnchor="end" fill="#6ee7b7" fontSize="12" fontWeight="bold" fontFamily="IBM Plex Mono">
                          R (Tia phản xạ)
                        </text>
                      </g>
                    );
                  })()}

                  {/* Angle labels */}
                  <text x="220" y="150" textAnchor="end" fill="#fda4af" fontSize="12" fontWeight="bold" fontFamily="IBM Plex Mono">
                    i = {incidentAngle}°
                  </text>
                  <text x="300" y="150" textAnchor="start" fill="#6ee7b7" fontSize="12" fontWeight="bold" fontFamily="IBM Plex Mono">
                    i′ = {incidentAngle}°
                  </text>
                </svg>

                <div className="w-full flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-800 text-xs font-mono text-slate-300">
                  <span>Góc tới: i = {incidentAngle}°</span>
                  <span>Góc phản xạ: i′ = {incidentAngle}°</span>
                  <span>Góc hợp với mặt gương: α = {90 - incidentAngle}°</span>
                  <span>Góc lệch (SI, IR): {incidentAngle * 2}°</span>
                </div>
              </div>
            )}

            {/* Key Physics Metrics */}
            <div className="grid grid-cols-3 gap-4 pt-3 border-t border-slate-100 text-xs">
              <div>
                <span className="text-slate-500 block">Công thức trọng tâm</span>
                <span className="font-mono font-bold text-slate-900">
                  {physicsMode === 'motion' ? 'v = s / t  ⇒  s = v · t' : 'i′ = i  &  α = 90° - i'}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Chênh lệch tại t = {simTimeHours}h</span>
                <span className="font-mono font-bold text-slate-900 tabular-nums">
                  {physicsMode === 'motion'
                    ? `Δs = ${Math.abs((v1Kmh - v2Kmh) * simTimeHours).toFixed(1)} km`
                    : `i + i′ = ${incidentAngle * 2}°`}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Nhận xét thực nghiệm</span>
                <span className="font-semibold text-blue-700">
                  {physicsMode === 'motion'
                    ? v1Kmh > v2Kmh
                      ? '● Đồ thị Xe A dốc hơn Xe B'
                      : v1Kmh < v2Kmh
                      ? '▲ Đồ thị Xe B dốc hơn Xe A'
                      : '◆ Hai xe cùng tốc độ'
                    : '● Tia phản xạ đối xứng qua IN'}
                </span>
              </div>
            </div>
          </div>

          {/* Right Zone: Control Deck */}
          <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between space-y-6">
            {physicsMode === 'motion' ? (
              <div className="space-y-5">
                <div>
                  <h4 className="text-base font-bold text-slate-900">Thông số chuyển động</h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Thay đổi tốc độ v₁, v₂ để quan sát độ dốc của đường biểu diễn trên đồ thị s – t.
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <label htmlFor="v1-slider" className="font-semibold text-slate-700">
                      Tốc độ Xe A (v₁):
                    </label>
                    <span className="font-mono font-bold text-blue-700 tabular-nums">
                      {v1Kmh} km/h ({(v1Kmh / 3.6).toFixed(1)} m/s)
                    </span>
                  </div>
                  <input
                    id="v1-slider"
                    type="range"
                    min={18}
                    max={90}
                    step={9}
                    value={v1Kmh}
                    onChange={(e) => setV1Kmh(Number(e.target.value))}
                    className="w-full accent-blue-600 cursor-pointer"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <label htmlFor="v2-slider" className="font-semibold text-slate-700">
                      Tốc độ Xe B (v₂):
                    </label>
                    <span className="font-mono font-bold text-amber-700 tabular-nums">
                      {v2Kmh} km/h ({(v2Kmh / 3.6).toFixed(1)} m/s)
                    </span>
                  </div>
                  <input
                    id="v2-slider"
                    type="range"
                    min={18}
                    max={90}
                    step={9}
                    value={v2Kmh}
                    onChange={(e) => setV2Kmh(Number(e.target.value))}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <label htmlFor="time-slider" className="font-semibold text-slate-700">
                      Thời gian khảo sát (t):
                    </label>
                    <span className="font-mono font-bold text-slate-900 tabular-nums">
                      {simTimeHours.toFixed(2)} giờ
                    </span>
                  </div>
                  <input
                    id="time-slider"
                    type="range"
                    min={0}
                    max={3}
                    step={0.1}
                    value={simTimeHours}
                    onChange={(e) => setSimTimeHours(Number(e.target.value))}
                    className="w-full accent-slate-900 cursor-pointer"
                  />
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      if (simTimeHours >= 3) setSimTimeHours(0);
                      setMotionPlaying((prev) => !prev);
                    }}
                    className="flex-1 flex items-center justify-center gap-2 py-2 px-4 bg-slate-900 text-white text-xs font-semibold rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
                  >
                    {motionPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                    <span>{motionPlaying ? 'Tạm dừng' : 'Mô phỏng hành trình'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setMotionPlaying(false);
                      setSimTimeHours(1.5);
                      setV1Kmh(54);
                      setV2Kmh(36);
                    }}
                    className="py-2 px-3 border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg hover:bg-slate-100 transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-5">
                <div>
                  <h4 className="text-base font-bold text-slate-900">Điều chỉnh Góc tới (i)</h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Kéo thanh trượt để chiếu tia sáng SI ở các góc tới khác nhau từ 0° đến 85°.
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <label htmlFor="angle-slider" className="font-semibold text-slate-700">
                      Góc tới (i = góc SIN):
                    </label>
                    <span className="font-mono font-bold text-rose-600 tabular-nums">{incidentAngle}°</span>
                  </div>
                  <input
                    id="angle-slider"
                    type="range"
                    min={0}
                    max={85}
                    step={5}
                    value={incidentAngle}
                    onChange={(e) => setIncidentAngle(Number(e.target.value))}
                    className="w-full accent-rose-600 cursor-pointer"
                  />
                </div>

                <div className="space-y-2 pt-3 border-t border-slate-100 text-xs text-slate-600 leading-relaxed">
                  <p>
                    <strong className="text-slate-900">Lưu ý bẫy thường gặp trong đề thi:</strong> Khi đề bài cho góc hợp bởi tia tới và mặt gương là{' '}
                    <span className="font-mono font-semibold">α = {90 - incidentAngle}°</span>, học sinh phải lấy{' '}
                    <span className="font-mono font-semibold">i = 90° - α = {incidentAngle}°</span>.
                  </p>
                  <p>
                    Khi chiếu tia sáng vuông góc với mặt gương (<span className="font-mono">α = 90°</span>), góc tới{' '}
                    <span className="font-mono">i = 0°</span> nên tia phản xạ truyền ngược lại chính đường tia tới.
                  </p>
                </div>
              </div>
            )}

            <div className="pt-4 border-t border-slate-100 text-xs text-slate-500">
              Quy tắc quy đổi chuẩn: <span className="font-mono font-semibold text-slate-800">1 m/s = 3,6 km/h</span>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          LAB 3: BIOLOGY - VASCULAR FLOW (XYLEM & PHLOEM) & PHOTOSYNTHESIS
         ===================================================================== */}
      {activeLab === 'biology-vascular' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Left Zone: Plant Vascular & Leaf Gas Exchange Stage */}
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <div className="text-xs text-slate-500">
                  Sinh học 7 · Trao đổi chất và chuyển hóa năng lượng ở Thực vật
                </div>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  Mô phỏng Dòng Mạch gỗ (Xylem), Mạch rây (Phloem) & Khí khổng
                </h3>
              </div>

              <div className="text-xs font-mono font-semibold">
                {photosynthesisRate >= 65 && (
                  <span className="text-emerald-700">● QUANG HỢP TỐI ƯU ({photosynthesisRate}% hiệu suất)</span>
                )}
                {photosynthesisRate >= 30 && photosynthesisRate < 65 && (
                  <span className="text-amber-700">▲ TRUNG BÌNH ({photosynthesisRate}% hiệu suất)</span>
                )}
                {photosynthesisRate < 30 && (
                  <span className="text-rose-700">◆ ỨC CHẾ QUANG HỢP ({photosynthesisRate}% hiệu suất)</span>
                )}
              </div>
            </div>

            {/* Interactive SVG Plant Vascular Diagram */}
            <div className="bg-slate-900 rounded-xl p-5 grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
              <div className="md:col-span-7">
                <svg viewBox="0 0 360 280" className="w-full h-auto">
                  {/* Sun Indicator */}
                  <circle cx="52" cy="44" r="20" fill="#facc15" opacity={Math.max(0.25, lightIntensity / 1000)} />
                  <text x="52" y="80" textAnchor="middle" fill="#fde047" fontSize="9.5" fontFamily="IBM Plex Mono">
                    {lightIntensity} lux
                  </text>

                  {/* Soil layer */}
                  <rect x="20" y="225" width="320" height="45" rx="6" fill="#334155" />
                  <text x="35" y="248" fill="#cbd5e1" fontSize="10" fontFamily="IBM Plex Mono">
                    Đất trồng · Độ ẩm: {soilMoisture}% (H₂O + Ion khoáng)
                  </text>

                  {/* Stem Conduit Housing */}
                  <rect x="145" y="55" width="70" height="175" rx="8" fill="#1e293b" stroke="#475569" strokeWidth="1.5" />

                  {/* Xylem Channel (Left inside stem - Cerulean Blue #0EA5E9) */}
                  <line x1="165" y1="225" x2="165" y2="65" stroke="#0ea5e9" strokeWidth="8" strokeLinecap="round" opacity="0.3" />
                  {/* Animated Xylem Water Particles moving UP */}
                  {[0, 1, 2, 3, 4].map((idx) => {
                    const offset = (bioFlowTick * (xylemFlowSpeed / 30) + idx * 20) % 100;
                    const cy = 220 - (offset / 100) * 150;
                    return <circle key={idx} cx="165" cy={cy} r="4" fill="#38bdf8" />;
                  })}

                  {/* Phloem Channel (Right inside stem - Golden Marigold #EAB308) */}
                  <line x1="195" y1="65" x2="195" y2="225" stroke="#eab308" strokeWidth="8" strokeLinecap="round" opacity="0.3" />
                  {/* Animated Phloem Sugar Particles moving DOWN */}
                  {[0, 1, 2, 3].map((idx) => {
                    const offset = (bioFlowTick * (photosynthesisRate / 35) + idx * 25) % 100;
                    const cy = 70 + (offset / 100) * 150;
                    return <circle key={idx} cx="195" cy={cy} r="4" fill="#facc15" />;
                  })}

                  {/* Leaf Canopy */}
                  <path
                    d="M 180 65 C 240 25, 320 40, 330 85 C 310 125, 230 115, 180 85 Z"
                    fill="#059669"
                    stroke="#34d399"
                    strokeWidth="2"
                  />
                  <text x="260" y="76" textAnchor="middle" fill="#ecfdf5" fontSize="10" fontWeight="bold">
                    Lục lạp ở Lá
                  </text>
                  <text x="260" y="92" textAnchor="middle" fill="#a7f3d0" fontSize="9" fontFamily="IBM Plex Mono">
                    CO₂ vào · O₂ + H₂O ra
                  </text>

                  {/* Labels for Xylem and Phloem */}
                  <text x="135" y="135" textAnchor="end" fill="#38bdf8" fontSize="10" fontWeight="bold" fontFamily="IBM Plex Mono">
                    ↑ Mạch gỗ (Xylem)
                  </text>
                  <text x="135" y="149" textAnchor="end" fill="#94a3b8" fontSize="9" fontFamily="IBM Plex Mono">
                    Nước & Muối khoáng
                  </text>

                  <text x="225" y="155" textAnchor="start" fill="#facc15" fontSize="10" fontWeight="bold" fontFamily="IBM Plex Mono">
                    ↓ Mạch rây (Phloem)
                  </text>
                  <text x="225" y="169" textAnchor="start" fill="#94a3b8" fontSize="9" fontFamily="IBM Plex Mono">
                    Đường C₆H₁₂O₆
                  </text>
                </svg>
              </div>

              {/* Stomata & Formula Live Readout */}
              <div className="md:col-span-5 bg-slate-800/90 rounded-xl p-4 space-y-3 text-xs text-slate-200">
                <div className="flex items-center justify-between border-b border-slate-700 pb-2">
                  <span className="font-semibold text-white">Trạng thái Khí khổng:</span>
                  <span className="font-mono font-bold text-emerald-400 tabular-nums">
                    Mở {stomataOpeningPct}%
                  </span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  {soilMoisture < 30 || temperatureC > 39
                    ? '▲ CẢNH BÁO: Nhiệt độ quá cao hoặc đất khô làm tế bào khí khổng mất nước và đóng hẹp lại để chống héo, khiến CO₂ khó đi vào lá.'
                    : '● BÌNH THƯỜNG: Tế bào hạt đậu trương nước giúp khí khổng mở rộng, tạo lực kéo dòng mạch gỗ đi lên và đón CO₂ vào quang hợp.'}
                </p>
                <div className="pt-2 border-t border-slate-700 font-mono text-[11px] space-y-1">
                  <div className="text-slate-400">Phương trình quang hợp:</div>
                  <div className="text-emerald-300 font-semibold">
                    6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂↑
                  </div>
                  <div className="text-slate-400 pt-1">Tốc độ dòng mạch gỗ (Xylem):</div>
                  <div className="text-sky-300 font-semibold tabular-nums">
                    {xylemFlowSpeed} đơn vị vận chuyển / phút
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Summary Metrics */}
            <div className="grid grid-cols-3 gap-4 pt-3 border-t border-slate-100 text-xs">
              <div>
                <span className="text-slate-500 block">Mạch gỗ (Xylem - #0EA5E9)</span>
                <span className="font-semibold text-slate-900">Tế bào chết hóa gỗ · Đi từ Rễ ↑ Lá</span>
              </div>
              <div>
                <span className="text-slate-500 block">Mạch rây (Phloem - #EAB308)</span>
                <span className="font-semibold text-slate-900">Tế bào sống · Đi từ Lá ↓ Rễ, Củ, Quả</span>
              </div>
              <div>
                <span className="text-slate-500 block">Động lực chính của dòng mạch gỗ</span>
                <span className="font-semibold text-emerald-700">Sự thoát hơi nước qua khí khổng ở lá</span>
              </div>
            </div>
          </div>

          {/* Right Zone: Control Deck */}
          <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between space-y-5">
            <div className="space-y-4">
              <div>
                <h4 className="text-base font-bold text-slate-900">Điều chỉnh yếu tố ngoại cảnh</h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Thay đổi ánh sáng, CO₂, nhiệt độ và độ ẩm đất để kiểm chứng ảnh hưởng đến quang hợp.
                </p>
              </div>

              {/* Light Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <label htmlFor="bio-light" className="font-semibold text-slate-700 flex items-center gap-1.5">
                    <SunMedium className="w-3.5 h-3.5 text-amber-500" />
                    <span>Cường độ ánh sáng:</span>
                  </label>
                  <span className="font-mono font-bold text-slate-900 tabular-nums">{lightIntensity} lux</span>
                </div>
                <input
                  id="bio-light"
                  type="range"
                  min={50}
                  max={1000}
                  step={50}
                  value={lightIntensity}
                  onChange={(e) => setLightIntensity(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>

              {/* CO2 Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <label htmlFor="bio-co2" className="font-semibold text-slate-700">
                    Nồng độ khí CO₂:
                  </label>
                  <span className="font-mono font-bold text-slate-900 tabular-nums">{co2Ppm} ppm</span>
                </div>
                <input
                  id="bio-co2"
                  type="range"
                  min={150}
                  max={1000}
                  step={50}
                  value={co2Ppm}
                  onChange={(e) => setCo2Ppm(Number(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
              </div>

              {/* Temperature Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <label htmlFor="bio-temp" className="font-semibold text-slate-700">
                    Nhiệt độ môi trường:
                  </label>
                  <span className="font-mono font-bold text-slate-900 tabular-nums">{temperatureC} °C</span>
                </div>
                <input
                  id="bio-temp"
                  type="range"
                  min={10}
                  max={45}
                  step={1}
                  value={temperatureC}
                  onChange={(e) => setTemperatureC(Number(e.target.value))}
                  className="w-full accent-rose-600 cursor-pointer"
                />
              </div>

              {/* Soil Moisture Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <label htmlFor="bio-moisture" className="font-semibold text-slate-700">
                    Độ ẩm đất vùng rễ:
                  </label>
                  <span className="font-mono font-bold text-sky-700 tabular-nums">{soilMoisture} %</span>
                </div>
                <input
                  id="bio-moisture"
                  type="range"
                  min={15}
                  max={95}
                  step={5}
                  value={soilMoisture}
                  onChange={(e) => setSoilMoisture(Number(e.target.value))}
                  className="w-full accent-sky-600 cursor-pointer"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setBioPlaying((prev) => !prev)}
                  className="flex-1 flex items-center justify-center gap-2 py-2 px-4 bg-slate-900 text-white text-xs font-semibold rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
                >
                  {bioPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{bioPlaying ? 'Tạm dừng dòng mạch' : 'Tiếp tục mô phỏng'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setLightIntensity(650);
                    setCo2Ppm(420);
                    setTemperatureC(28);
                    setSoilMoisture(75);
                  }}
                  className="py-2 px-3 border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg hover:bg-slate-100 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 space-y-2.5 text-xs text-slate-600">
              <div className="font-extrabold text-slate-900 uppercase flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-amber-600" />
                <span>Thí nghiệm Que đóm còn tàn đỏ (Bài 23 & 25):</span>
              </div>
              <div className="grid grid-cols-1 gap-2">
                <button
                  type="button"
                  onClick={() => setSplintTestMode('oxygen_burst')}
                  className={`p-2.5 rounded-xl border text-left font-bold transition cursor-pointer ${
                    splintTestMode === 'oxygen_burst'
                      ? 'bg-amber-500 text-slate-950 border-amber-600'
                      : 'bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-200'
                  }`}
                >
                  🔥 Đưa que đóm vào ống nghiệm thu khí Quang hợp (O₂)
                </button>
                <button
                  type="button"
                  onClick={() => setSplintTestMode('co2_extinguish')}
                  className={`p-2.5 rounded-xl border text-left font-bold transition cursor-pointer ${
                    splintTestMode === 'co2_extinguish'
                      ? 'bg-slate-800 text-white border-slate-900'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300'
                  }`}
                >
                  💨 Đưa que đóm vào bình Hạt đậu đang nảy mầm (CO₂)
                </button>
              </div>
              {splintTestMode === 'oxygen_burst' && (
                <div className="p-3 rounded-xl bg-amber-100 border border-amber-300 text-amber-950 font-semibold">
                  ✨ <strong>Hiện tượng:</strong> Que đóm còn tàn đỏ <strong>bùng cháy thành ngọn lửa sáng</strong> vì quá trình quang hợp của cành rong đuôi chó ngoài sáng đã giải phóng khí <strong>Oxygen (O₂)</strong> duy trì sự cháy!
                </div>
              )}
              {splintTestMode === 'co2_extinguish' && (
                <div className="p-3 rounded-xl bg-slate-200 border border-slate-400 text-slate-900 font-semibold">
                  🕯️ <strong>Hiện tượng:</strong> Ngọn lửa/tàn đỏ <strong>tắt ngay lập tức</strong> vì hạt đang nảy mầm hô hấp mạnh đã lấy hết O₂ và thải ra nhiều khí <strong>Carbon dioxide (CO₂)</strong> không duy trì sự cháy!
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          LAB 4: CHEMISTRY - CHEMICAL BONDING (IONIC & COVALENT)
         ===================================================================== */}
      {activeLab === 'chemistry-bonding' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <div className="text-xs text-slate-500">
                  Hóa học 7 · Bài 5, 6, 7 · Phân tử – Đơn chất – Hợp chất – Liên kết hóa học
                </div>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  Mô phỏng sự tạo thành liên kết trong phân tử {currentMolecule.formula} ({currentMolecule.name})
                </h3>
              </div>
              <span
                className={`px-3 py-1 rounded-full text-xs font-black uppercase ${
                  currentMolecule.bondType === 'ion'
                    ? 'bg-blue-100 text-blue-800'
                    : 'bg-emerald-100 text-emerald-800'
                }`}
              >
                {currentMolecule.bondType === 'ion'
                  ? '⚡ Liên kết Ion (Nhường – Nhận e)'
                  : '🔗 Liên kết Cộng hóa trị (Góp chung e)'}
              </span>
            </div>

            {/* Interactive SVG Bonding Stage */}
            <div className="bg-slate-900 rounded-2xl p-6 flex flex-col items-center justify-center min-h-[300px] space-y-4">
              <svg viewBox="0 0 540 230" className="w-full max-w-[520px] h-auto">
                {/* Left Atom */}
                <g transform={`translate(${bondFormed ? 205 : 145}, 115)`}>
                  <circle
                    r="58"
                    fill="none"
                    stroke={currentMolecule.leftAtom.color}
                    strokeWidth="2.5"
                    strokeDasharray={bondFormed ? 'none' : '5 4'}
                  />
                  <circle r="24" fill={currentMolecule.leftAtom.color} opacity="0.25" />
                  <text
                    y="-2"
                    textAnchor="middle"
                    fill="#ffffff"
                    fontSize="16"
                    fontWeight="bold"
                    fontFamily="IBM Plex Mono"
                  >
                    {currentMolecule.leftAtom.symbol}
                  </text>
                  <text
                    y="15"
                    textAnchor="middle"
                    fill="#cbd5e1"
                    fontSize="10"
                    fontFamily="IBM Plex Mono"
                  >
                    {bondFormed
                      ? currentMolecule.leftAtom.chargeLabel
                      : `${currentMolecule.leftAtom.outerE}e ngoài cùng`}
                  </text>
                </g>

                {/* Right Atom */}
                <g transform={`translate(${bondFormed ? 335 : 395}, 115)`}>
                  <circle
                    r="58"
                    fill="none"
                    stroke={currentMolecule.rightAtom.color}
                    strokeWidth="2.5"
                    strokeDasharray={bondFormed ? 'none' : '5 4'}
                  />
                  <circle r="24" fill={currentMolecule.rightAtom.color} opacity="0.25" />
                  <text
                    y="-2"
                    textAnchor="middle"
                    fill="#ffffff"
                    fontSize="16"
                    fontWeight="bold"
                    fontFamily="IBM Plex Mono"
                  >
                    {currentMolecule.rightAtom.symbol}
                  </text>
                  <text
                    y="15"
                    textAnchor="middle"
                    fill="#cbd5e1"
                    fontSize="10"
                    fontFamily="IBM Plex Mono"
                  >
                    {bondFormed
                      ? currentMolecule.rightAtom.chargeLabel
                      : `${currentMolecule.rightAtom.outerE}e ngoài cùng`}
                  </text>
                </g>

                {/* Shared or Transferred Electrons in the Middle */}
                {Array.from({ length: currentMolecule.transferredOrSharedCount }).map((_, idx) => {
                  const yOffset =
                    (idx - (currentMolecule.transferredOrSharedCount - 1) / 2) * 18;
                  const cx = !bondFormed
                    ? 203
                    : currentMolecule.bondType === 'ion'
                    ? 278
                    : 270;
                  return (
                    <circle
                      key={idx}
                      cx={cx}
                      cy={115 + yOffset}
                      r="6"
                      fill="#facc15"
                      stroke="#0f172a"
                      strokeWidth="1.5"
                    />
                  );
                })}

                <text
                  x="270"
                  y="212"
                  textAnchor="middle"
                  fill="#fde047"
                  fontSize="11.5"
                  fontWeight="bold"
                  fontFamily="IBM Plex Mono"
                >
                  {bondFormed
                    ? `Đã hình thành phân tử ${currentMolecule.formula} bền vững (Vỏ đủ ${currentMolecule.rightAtom.targetOuterE}e)`
                    : 'Trạng thái trước liên kết: Các nguyên tử chưa đạt cấu hình khí hiếm'}
                </text>
              </svg>

              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => setBondFormed((prev) => !prev)}
                  className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm cursor-pointer"
                >
                  {bondFormed
                    ? '🔄 Tách rời về nguyên tử ban đầu'
                    : currentMolecule.bondType === 'ion'
                    ? '⚡ Kích hoạt Nhường – Nhận Electron (Tạo liên kết Ion)'
                    : '🔗 Kích hoạt Góp chung Electron (Tạo liên kết Cộng hóa trị)'}
                </button>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm text-slate-700 leading-relaxed">
              <strong className="text-slate-900">Cơ chế hình thành:</strong>{' '}
              {currentMolecule.mechanismDesc}
            </div>
          </div>

          <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between space-y-5">
            <div className="space-y-4">
              <h4 className="text-base font-bold text-slate-900">Chọn phân tử thực hành</h4>
              <div className="grid grid-cols-1 gap-2">
                {BOND_MOLECULES.map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => {
                      setSelectedMoleculeId(m.id);
                      setBondFormed(false);
                    }}
                    className={`p-3 rounded-xl border text-left transition cursor-pointer flex items-center justify-between ${
                      selectedMoleculeId === m.id
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                    }`}
                  >
                    <div>
                      <div className="text-sm font-black">{m.formula} — {m.name}</div>
                      <div
                        className={`text-[11px] ${
                          selectedMoleculeId === m.id ? 'text-slate-300' : 'text-slate-500'
                        }`}
                      >
                        {m.bondType === 'ion' ? 'Kim loại + Phi kim (Ion)' : 'Phi kim + Phi kim (Cộng hóa trị)'}
                      </div>
                    </div>
                    <span className="font-mono text-xs font-bold">{m.massAmu} amu</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs space-y-1.5">
              <div className="font-black text-amber-950 uppercase">Quy tắc nhớ nhanh KHTN 7:</div>
              <div>• <strong>Liên kết Ion:</strong> Giữa Kim loại điển hình và Phi kim điển hình (nhường – nhận e).</div>
              <div>• <strong>Liên kết Cộng hóa trị:</strong> Giữa các nguyên tử Phi kim với nhau (góp chung e).</div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          LAB 5: PHYSICS - SOUND WAVES & OSCILLOSCOPE WITH REAL AUDIO TONE
         ===================================================================== */}
      {activeLab === 'physics-sound' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <div className="text-xs text-slate-500">
                  Vật lí 7 · Chủ đề Âm thanh (Bài 12, 13, 14) · f = N / t (Hz)
                </div>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  Dao động kí Sóng âm: Độ cao (Tần số f) & Độ to (Biên độ a)
                </h3>
              </div>

              <button
                type="button"
                onClick={toggleSoundTone}
                className={`px-4 py-2 rounded-xl font-extrabold text-xs flex items-center gap-2 transition cursor-pointer ${
                  isTonePlaying
                    ? 'bg-rose-600 hover:bg-rose-700 text-white'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                }`}
              >
                {isTonePlaying ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                <span>
                  {isTonePlaying
                    ? 'Tắt âm thanh tần số thực'
                    : `🔊 Phát âm thanh ${soundFreqHz} Hz`}
                </span>
              </button>
            </div>

            {/* Oscilloscope Screen */}
            <div className="bg-slate-950 rounded-2xl p-5 border-2 border-slate-800 space-y-3">
              <svg viewBox="0 0 560 220" className="w-full h-auto">
                {/* Oscilloscope Grid */}
                {[40, 110, 180].map((y) => (
                  <line
                    key={y}
                    x1="0"
                    y1={y}
                    x2="560"
                    y2={y}
                    stroke="#1e293b"
                    strokeWidth="1"
                    strokeDasharray={y === 110 ? 'none' : '4 4'}
                  />
                ))}
                {/* Sine Wave Path */}
                <path
                  d={(() => {
                    const points: string[] = [];
                    const ampPx = (soundAmplitude / 100) * 80;
                    const cycles = soundFreqHz / 110;
                    for (let x = 0; x <= 560; x += 4) {
                      const rad =
                        (x / 560) * cycles * Math.PI * 2 + (wavePhase * Math.PI) / 180;
                      const y = 110 - Math.sin(rad) * ampPx;
                      points.push(`${x === 0 ? 'M' : 'L'} ${x} ${y.toFixed(1)}`);
                    }
                    return points.join(' ');
                  })()}
                  fill="none"
                  stroke="#34d399"
                  strokeWidth="3"
                />
              </svg>

              <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono text-emerald-400 border-t border-slate-800 pt-2">
                <span>Tần số: f = {soundFreqHz} Hz ({soundFreqHz} dao động/giây)</span>
                <span>Biên độ: a = {soundAmplitude}%</span>
                <span>
                  Nhận xét:{' '}
                  {soundFreqHz >= 550 ? 'Âm BỔNG (Cao)' : soundFreqHz <= 250 ? 'Âm TRẦM (Thấp)' : 'Âm Trung'} ·{' '}
                  {soundAmplitude >= 70 ? 'Âm TO' : soundAmplitude <= 30 ? 'Âm NHỎ' : 'Âm Vừa'}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 pt-2 text-xs">
              <div>
                <span className="text-slate-500 block">Công thức tính tần số</span>
                <span className="font-mono font-bold text-slate-900">f = N / t (Đơn vị: Hz)</span>
              </div>
              <div>
                <span className="text-slate-500 block">Số dao động trong 5 giây</span>
                <span className="font-mono font-bold text-blue-700">{soundFreqHz * 5} dao động</span>
              </div>
              <div>
                <span className="text-slate-500 block">Môi trường truyền âm</span>
                <span className="font-semibold text-emerald-700">v(Rắn) &gt; v(Lỏng) &gt; v(Khí)</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between space-y-5">
            <div className="space-y-4">
              <h4 className="text-base font-bold text-slate-900">Điều chỉnh Sóng âm</h4>

              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <label className="font-semibold text-slate-700">Tần số dao động (f):</label>
                  <span className="font-mono font-bold text-emerald-700">{soundFreqHz} Hz</span>
                </div>
                <input
                  type="range"
                  min={100}
                  max={880}
                  step={20}
                  value={soundFreqHz}
                  onChange={(e) => setSoundFreqHz(Number(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <label className="font-semibold text-slate-700">Biên độ dao động (a):</label>
                  <span className="font-mono font-bold text-blue-700">{soundAmplitude} %</span>
                </div>
                <input
                  type="range"
                  min={15}
                  max={100}
                  step={5}
                  value={soundAmplitude}
                  onChange={(e) => setSoundAmplitude(Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1.5 text-slate-700">
                <div>• <strong>Tần số (f) càng lớn</strong> → Sóng trên màn hình càng dày → <strong>Âm phát ra càng cao (bổng)</strong>.</div>
                <div>• <strong>Biên độ (a) càng lớn</strong> → Đỉnh sóng càng cao → <strong>Âm phát ra càng to</strong>.</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          LAB 6: PHYSICS - ELECTROMAGNET & MAGNETIC FIELD
         ===================================================================== */}
      {activeLab === 'physics-magnetism' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <div className="text-xs text-slate-500">
                  Vật lí 7 · Chủ đề Từ (Bài 18, 19, 20, 21) · Nam châm & Nam châm điện
                </div>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  Chế tạo Nam châm điện & Khảo sát Lực từ hút kẹp sắt
                </h3>
              </div>

              <button
                type="button"
                onClick={() => setSwitchClosed((prev) => !prev)}
                className={`px-4 py-2 rounded-xl font-extrabold text-xs flex items-center gap-1.5 transition cursor-pointer ${
                  switchClosed
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-200 text-slate-800'
                }`}
              >
                <Zap className="w-4 h-4" />
                <span>{switchClosed ? 'Khóa K ĐÓNG (Có dòng điện)' : 'Khóa K NGẮT (Mất từ tính)'}</span>
              </button>
            </div>

            {(() => {
              const magneticScore = !switchClosed
                ? 0
                : Math.round(
                    (coilTurns / 200) * (currentAmp / 5) * (hasIronCore ? 100 : 35)
                  );
              const clipsAttracted = Math.round((magneticScore / 100) * 12);
              const leftPole = reversePolarity ? 'S' : 'N';
              const rightPole = reversePolarity ? 'N' : 'S';

              return (
                <>
                  <div className="bg-slate-900 rounded-2xl p-6 flex flex-col items-center space-y-4">
                    <svg viewBox="0 0 540 230" className="w-full max-w-[520px] h-auto">
                      {/* Magnetic Field Lines when switch closed */}
                      {switchClosed && (
                        <g opacity={Math.max(0.25, magneticScore / 100)}>
                          <ellipse cx="270" cy="110" rx="185" ry="75" fill="none" stroke="#38bdf8" strokeWidth="1.5" strokeDasharray="5 4" />
                          <ellipse cx="270" cy="110" rx="145" ry="50" fill="none" stroke="#38bdf8" strokeWidth="1.5" strokeDasharray="5 4" />
                        </g>
                      )}

                      {/* Iron Core */}
                      {hasIronCore && (
                        <rect x="150" y="90" width="240" height="40" rx="8" fill="#64748b" stroke="#94a3b8" strokeWidth="2" />
                      )}

                      {/* Solenoid Coil Turns */}
                      {Array.from({ length: Math.min(14, Math.round(coilTurns / 14)) }).map(
                        (_, idx) => {
                          const x = 165 + idx * 15;
                          return (
                            <line
                              key={idx}
                              x1={x}
                              y1="86"
                              x2={x + 6}
                              y2="134"
                              stroke={switchClosed ? '#f59e0b' : '#475569'}
                              strokeWidth="3.5"
                              strokeLinecap="round"
                            />
                          );
                        }
                      )}

                      {/* Magnetic Poles Label when Switch Closed */}
                      {switchClosed && (
                        <>
                          <circle cx="135" cy="110" r="16" fill={leftPole === 'N' ? '#ef4444' : '#3b82f6'} />
                          <text x="135" y="115" textAnchor="middle" fill="#fff" fontSize="13" fontWeight="bold">
                            {leftPole}
                          </text>
                          <circle cx="405" cy="110" r="16" fill={rightPole === 'N' ? '#ef4444' : '#3b82f6'} />
                          <text x="405" y="115" textAnchor="middle" fill="#fff" fontSize="13" fontWeight="bold">
                            {rightPole}
                          </text>
                        </>
                      )}

                      {/* Attracted Iron Paperclips */}
                      <text x="270" y="195" textAnchor="middle" fill="#fde047" fontSize="12" fontWeight="bold" fontFamily="IBM Plex Mono">
                        {switchClosed
                          ? `Hút được ${clipsAttracted} đinh sắt (Cường độ từ trường: ${magneticScore}%)`
                          : 'Ngắt dòng điện → Lõi sắt non mất từ tính ngay lập tức (0 đinh sắt)'}
                      </text>
                    </svg>
                  </div>

                  <div className="grid grid-cols-3 gap-4 pt-2 text-xs">
                    <div>
                      <span className="text-slate-500 block">Cực từ của ống dây</span>
                      <span className="font-mono font-bold text-slate-900">
                        {switchClosed ? `Đầu trái: Cực ${leftPole} · Đầu phải: Cực ${rightPole}` : 'Chưa có từ cực'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Số đinh sắt hút được</span>
                      <span className="font-mono font-bold text-indigo-700">{clipsAttracted} đinh sắt</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Lõi trong lòng ống dây</span>
                      <span className="font-semibold text-emerald-700">
                        {hasIronCore ? 'Có lõi sắt non (Tăng mạnh lực từ)' : 'Không có lõi sắt non'}
                      </span>
                    </div>
                  </div>
                </>
              );
            })()}
          </div>

          <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between space-y-4">
            <div className="space-y-4">
              <h4 className="text-base font-bold text-slate-900">Điều khiển Nam châm điện</h4>

              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <label className="font-semibold text-slate-700">Số vòng dây (N):</label>
                  <span className="font-mono font-bold text-indigo-700">{coilTurns} vòng</span>
                </div>
                <input
                  type="range"
                  min={20}
                  max={200}
                  step={20}
                  value={coilTurns}
                  onChange={(e) => setCoilTurns(Number(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <label className="font-semibold text-slate-700">Cường độ dòng điện (I):</label>
                  <span className="font-mono font-bold text-amber-700">{currentAmp.toFixed(1)} A</span>
                </div>
                <input
                  type="range"
                  min={0.5}
                  max={5.0}
                  step={0.5}
                  value={currentAmp}
                  onChange={(e) => setCurrentAmp(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>

              <div className="grid grid-cols-1 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setHasIronCore((prev) => !prev)}
                  className="py-2 px-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-bold text-slate-800 cursor-pointer"
                >
                  {hasIronCore ? '🔩 Đang đặt Lõi sắt non trong ống dây' : '➕ Đặt thêm Lõi sắt non vào ống dây'}
                </button>
                <button
                  type="button"
                  onClick={() => setReversePolarity((prev) => !prev)}
                  className="py-2 px-3 rounded-xl border border-indigo-200 bg-indigo-50 hover:bg-indigo-100 text-xs font-bold text-indigo-900 cursor-pointer"
                >
                  🔄 Đổi chiều dòng điện (Đổi cực N ↔ S)
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
