import React, { useState, useEffect } from 'react';
import {
  Calendar,
  CheckCircle2,
  Clock,
  AlertCircle,
  Download,
  ArrowRight,
  Users,
  Eye,
  Plus,
  RefreshCw,
  FileSpreadsheet,
  Sparkles,
  Check,
  TrendingUp,
  TrendingDown,
  Minus,
  BarChart3,
} from 'lucide-react';
import {
  StudentProfile,
  WeeklyAssignment,
  calculateStudentGradeMetrics,
} from '../data/classStore';
import { ALL_KNTT_LESSONS } from '../data/allLessons';
import { EssaySubmission } from '../data/lessonTypes';
import { StudentProfileModal } from './StudentProfileModal';

interface WeeklyTrackerViewProps {
  userRole: 'student' | 'teacher';
  currentStudent: StudentProfile;
  students: StudentProfile[];
  weeklyAssignments: WeeklyAssignment[];
  activeWeek: number;
  onChangeActiveWeek: (weekNum: number) => void;
  onSaveWeeklyAssignment: (assignment: WeeklyAssignment) => void;
  onUpdateStudent: (updated: StudentProfile) => void;
  onStartLessonPractice: (lessonId: string) => void;
}

export const WeeklyTrackerView: React.FC<WeeklyTrackerViewProps> = ({
  userRole,
  currentStudent,
  students,
  weeklyAssignments,
  activeWeek,
  onChangeActiveWeek,
  onSaveWeeklyAssignment,
  onUpdateStudent,
  onStartLessonPractice,
}) => {
  const [statusFilter, setStatusFilter] = useState<
    'all' | 'completed' | 'in_progress' | 'not_started'
  >('all');
  const [inspectingStudent, setInspectingStudent] = useState<StudentProfile | null>(null);
  const [showAssignForm, setShowAssignForm] = useState<boolean>(true);
  const [syncToast, setSyncToast] = useState<string | null>(null);

  // Task builder form states (Matching Image 1)
  const [formWeekNumber, setFormWeekNumber] = useState<number>(activeWeek);
  const [formTitle, setFormTitle] = useState<string>('');
  const [formDueDate, setFormDueDate] = useState<string>('Thứ Sáu tuần tới');
  const [formLessonIds, setFormLessonIds] = useState<string[]>(['kntt-bai-2']);

  // Keep form synced when activeWeek changes if editing existing week
  useEffect(() => {
    const existing = weeklyAssignments.find((w) => w.weekNumber === activeWeek);
    if (existing) {
      setFormWeekNumber(existing.weekNumber);
      setFormTitle(existing.title);
      setFormDueDate(existing.dueDate);
      setFormLessonIds(existing.lessonIds);
    }
  }, [activeWeek, weeklyAssignments]);

  // Read live answers from localStorage for the active student
  const mcqAnswers: Record<string, number> = (() => {
    try {
      const raw = localStorage.getItem('khtn7_kntt_mcq_v2');
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  })();

  const tfAnswers: Record<string, boolean> = (() => {
    try {
      const raw = localStorage.getItem('khtn7_kntt_tf_v2');
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  })();

  const essaySubmissions: Record<string, EssaySubmission> = (() => {
    try {
      const raw = localStorage.getItem('khtn7_kntt_essay_v2');
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  })();

  const activeAssignment: WeeklyAssignment =
    weeklyAssignments.find((w) => w.weekNumber === activeWeek) || weeklyAssignments[0];

  const assignedLessons = ALL_KNTT_LESSONS.filter((l) =>
    activeAssignment.lessonIds.includes(l.id)
  );

  // Toggle lesson in Task Builder (Image 1)
  const handleToggleFormLesson = (lessonId: string) => {
    setFormLessonIds((prev) =>
      prev.includes(lessonId) ? prev.filter((id) => id !== lessonId) : [...prev, lessonId]
    );
  };

  // Save new or updated weekly assignment
  const handleSaveTaskAssignment = (e: React.FormEvent) => {
    e.preventDefault();
    if (formLessonIds.length === 0) {
      setSyncToast('Vui lòng chọn ít nhất 1 bài học KNTT cần hoàn thành trong tuần!');
      setTimeout(() => setSyncToast(null), 3000);
      return;
    }

    const pickedLessons = ALL_KNTT_LESSONS.filter((l) => formLessonIds.includes(l.id));
    const totalTargetMcq = pickedLessons.reduce((acc, l) => acc + l.mcqs.length, 0);
    const totalTargetTf = pickedLessons.reduce((acc, l) => acc + l.trueFalseList.length, 0);
    const totalTargetEssay = pickedLessons.reduce((acc, l) => acc + l.essays.length, 0);

    const newAssignment: WeeklyAssignment = {
      weekNumber: Number(formWeekNumber) || activeWeek,
      semesterLabel: Number(formWeekNumber) <= 18 ? 'HK1' : 'HK2',
      title:
        formTitle.trim() ||
        `Tuần ${formWeekNumber}: ${pickedLessons.map((l) => l.title).join(' & ')}`,
      subjectLabel: 'KHTN 7 – Kết nối tri thức',
      lessonIds: formLessonIds,
      dueDate: formDueDate.trim() || 'Thứ Sáu tuần tới',
      targetMcq: totalTargetMcq,
      targetTf: totalTargetTf,
      targetEssay: totalTargetEssay,
    };

    onSaveWeeklyAssignment(newAssignment);
    onChangeActiveWeek(newAssignment.weekNumber);
    setSyncToast(
      `Đã giao và đồng bộ nhiệm vụ Tuần ${newAssignment.weekNumber} (${pickedLessons.length} bài học) cho toàn bộ học sinh!`
    );
    setTimeout(() => setSyncToast(null), 3500);
  };

  const handleManualSyncWeek = () => {
    setSyncToast(
      `🔄 Đã đồng bộ dữ liệu bài tập, điểm số và nhận xét của Tuần ${activeWeek} (${
        activeAssignment.semesterLabel || 'HK1'
      })!`
    );
    setTimeout(() => setSyncToast(null), 3000);
  };

  // Compute progress for a student on the selected week
  const computeStudentWeekProgress = (student: StudentProfile, week: WeeklyAssignment) => {
    const isCurrentUser = student.id === currentStudent.id;

    let liveMcqDone = 0;
    let liveMcqCorrect = 0;
    let liveTfDone = 0;
    let liveEssayDone = 0;
    let livePhotosAttached = 0;

    if (isCurrentUser) {
      for (const lessonId of week.lessonIds) {
        const lesson = ALL_KNTT_LESSONS.find((l) => l.id === lessonId);
        if (!lesson) continue;

        for (const mcq of lesson.mcqs) {
          const ans = mcqAnswers[`${lesson.id}:${mcq.id}`];
          if (ans !== undefined) {
            liveMcqDone++;
            if (ans === mcq.correctIndex) liveMcqCorrect++;
          }
        }

        for (const tf of lesson.trueFalseList) {
          const allAnswered = tf.statements.every(
            (st) => tfAnswers[`${lesson.id}:${tf.id}:${st.id}`] !== undefined
          );
          if (allAnswered) liveTfDone++;
        }

        for (const es of lesson.essays) {
          const sub = essaySubmissions[`${lesson.id}:${es.id}`];
          if (sub && (sub.textAnswer.trim().length > 0 || sub.attachedImages.length > 0)) {
            liveEssayDone++;
            livePhotosAttached += sub.attachedImages.length;
          }
        }
      }
    }

    const hasBaselineCompleted = student.baselineWeeksCompleted.includes(week.weekNumber);

    const mcqDone = Math.max(
      liveMcqDone,
      hasBaselineCompleted
        ? week.targetMcq
        : Math.min(
            week.targetMcq,
            Math.floor(student.baselineMcqDone / Math.max(1, week.weekNumber))
          )
    );
    const tfDone = Math.max(
      liveTfDone,
      hasBaselineCompleted
        ? week.targetTf
        : Math.min(
            week.targetTf,
            Math.floor(student.baselineTfDone / Math.max(1, week.weekNumber))
          )
    );
    const essayDone = Math.max(
      liveEssayDone,
      hasBaselineCompleted
        ? week.targetEssay
        : Math.min(
            week.targetEssay,
            Math.floor(student.baselineEssayDone / Math.max(1, week.weekNumber))
          )
    );

    const totalTarget = Math.max(1, week.targetMcq + week.targetTf + week.targetEssay);
    const totalDone = Math.min(totalTarget, mcqDone + tfDone + essayDone);
    const percent = Math.min(100, Math.round((totalDone / totalTarget) * 100));

    let status: 'completed' | 'in_progress' | 'not_started' = 'not_started';
    if (percent >= 90) status = 'completed';
    else if (percent > 0) status = 'in_progress';

    return {
      mcqDone,
      mcqCorrect:
        liveMcqDone > 0 ? liveMcqCorrect : Math.round(mcqDone * 0.85),
      tfDone,
      essayDone,
      photosCount: livePhotosAttached || (essayDone > 0 ? Math.min(3, essayDone) : 0),
      percent,
      status,
    };
  };

  const studentRows = students.map((st) => ({
    student: st,
    progress: computeStudentWeekProgress(st, activeAssignment),
    metrics: calculateStudentGradeMetrics(st),
  }));

  const filteredRows = studentRows.filter((row) => {
    if (statusFilter === 'all') return true;
    return row.progress.status === statusFilter;
  });

  const completedCount = studentRows.filter((r) => r.progress.status === 'completed').length;
  const inProgressCount = studentRows.filter((r) => r.progress.status === 'in_progress').length;
  const notStartedCount = studentRows.filter((r) => r.progress.status === 'not_started').length;

  const handleExportCsv = () => {
    const headers = [
      'Ma HS',
      'Ho va Ten',
      'Lop',
      'Tuan',
      'Trac nghiem',
      'Dung Sai',
      'Tu luan',
      'Tien do (%)',
      'Diem TB',
      'Xu huong',
    ];
    const lines = studentRows.map((r) => [
      r.student.code,
      `"${r.student.fullName}"`,
      `"${r.student.className}"`,
      `Tuan ${activeAssignment.weekNumber}`,
      `${r.progress.mcqDone}/${activeAssignment.targetMcq}`,
      `${r.progress.tfDone}/${activeAssignment.targetTf}`,
      `${r.progress.essayDone}/${activeAssignment.targetEssay}`,
      `${r.progress.percent}%`,
      r.metrics.average,
      `"${r.metrics.trendLabel}"`,
    ]);

    const csvContent =
      '\uFEFF' + [headers.join(','), ...lines.map((l) => l.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Bao_Cao_BTVN_KHTN7_Tuan_${activeAssignment.weekNumber}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getSubjectLabel = (sub: string) =>
    sub === 'chemistry' ? 'Hóa học' : sub === 'physics' ? 'Vật lí' : 'Sinh học';

  return (
    <div className="space-y-6">
      {/* ================= TOP HEADER & WEEK SYNC WIDGET (MATCHING IMAGE 1 & IMAGE 3) ================= */}
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-7 shadow-xs space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="text-xs sm:text-sm font-bold text-blue-600">
              Quản lý kế hoạch dạy học KHTN 7 – Kết nối tri thức
            </div>
            <h2 className="text-xl sm:text-2xl lg:text-3xl font-black text-slate-900 tracking-tight">
              Theo dõi Tiến độ Bài tập của Học sinh theo Tuần
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Dark Blue Week Selector & Sync Bar (Matching Image 3) */}
            <div className="inline-flex items-center gap-2 bg-[#162d69] text-white px-3.5 py-2 rounded-2xl border border-blue-800 shadow-sm">
              <span className="text-xs font-black uppercase tracking-wider text-amber-300">
                TUẦN:
              </span>
              <select
                value={activeWeek}
                onChange={(e) => onChangeActiveWeek(Number(e.target.value))}
                className="bg-[#1e3a8a] text-white font-extrabold text-xs sm:text-sm px-3 py-1.5 rounded-xl border border-blue-500/60 focus:outline-none cursor-pointer"
              >
                <optgroup label="Học kì I (Tuần 1 – 18)">
                  {weeklyAssignments
                    .filter((w) => w.weekNumber <= 18)
                    .map((w) => (
                      <option key={w.weekNumber} value={w.weekNumber}>
                        Tuần {w.weekNumber} (HK1)
                      </option>
                    ))}
                </optgroup>
                <optgroup label="Học kì II (Tuần 19 – 35)">
                  {weeklyAssignments
                    .filter((w) => w.weekNumber >= 19)
                    .map((w) => (
                      <option key={w.weekNumber} value={w.weekNumber}>
                        Tuần {w.weekNumber} (HK2)
                      </option>
                    ))}
                </optgroup>
              </select>

              <button
                onClick={handleManualSyncWeek}
                className="px-3.5 py-1.5 rounded-xl bg-[#1d6bf3] hover:bg-[#1557c7] text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 shadow transition cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Cập Nhật</span>
              </button>
            </div>

            {/* + Giao nhiệm vụ tuần mới Button (Matching Image 1) */}
            {userRole === 'teacher' && (
              <button
                onClick={() => {
                  setShowAssignForm(!showAssignForm);
                  if (!showAssignForm) {
                    const nextWeekNum = weeklyAssignments.length + 1;
                    setFormWeekNumber(nextWeekNum);
                    setFormTitle(`Tuần ${nextWeekNum}: Ôn tập trọng tâm KHTN 7`);
                    setFormDueDate('Thứ Sáu tuần tới');
                  }
                }}
                className="px-5 py-2.5 rounded-2xl bg-[#1d6bf3] hover:bg-[#1557c7] text-white font-extrabold text-xs sm:text-sm flex items-center gap-2 shadow-md shadow-blue-600/20 transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Giao nhiệm vụ tuần mới</span>
              </button>
            )}
          </div>
        </div>

        {syncToast && (
          <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs sm:text-sm font-extrabold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{syncToast}</span>
          </div>
        )}

        {/* ================= TASK ASSIGNMENT BUILDER (EXACT MATCH TO IMAGE 1) ================= */}
        {userRole === 'teacher' && showAssignForm && (
          <form
            onSubmit={handleSaveTaskAssignment}
            className="rounded-3xl bg-[#f8fafc] border border-slate-200/90 p-5 sm:p-6 space-y-5"
          >
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-base sm:text-lg font-black text-slate-900">
                Thiết lập nhiệm vụ học tập tuần mới
              </h3>
              <span className="text-xs font-bold text-blue-600">
                Đồng bộ tự động sang tài khoản Học sinh
              </span>
            </div>

            {/* 3 Inputs Row: Tuần học thứ | Tiêu đề nhiệm vụ tuần | Hạn hoàn thành */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              <div className="md:col-span-3 space-y-1.5">
                <label className="block text-xs font-extrabold text-slate-700">
                  Tuần học thứ
                </label>
                <input
                  type="number"
                  min={1}
                  max={35}
                  value={formWeekNumber}
                  onChange={(e) => setFormWeekNumber(Number(e.target.value))}
                  className="w-full px-4 py-2.5 rounded-xl bg-white border border-slate-300 font-bold text-sm text-slate-900 focus:outline-none focus:border-blue-600"
                />
              </div>

              <div className="md:col-span-6 space-y-1.5">
                <label className="block text-xs font-extrabold text-slate-700">
                  Tiêu đề nhiệm vụ tuần
                </label>
                <input
                  type="text"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="Ví dụ: Tuần 5: Ôn tập chương Tốc độ & Âm thanh"
                  className="w-full px-4 py-2.5 rounded-xl bg-white border border-slate-300 font-medium text-sm text-slate-900 focus:outline-none focus:border-blue-600"
                />
              </div>

              <div className="md:col-span-3 space-y-1.5">
                <label className="block text-xs font-extrabold text-slate-700">
                  Hạn hoàn thành
                </label>
                <input
                  type="text"
                  value={formDueDate}
                  onChange={(e) => setFormDueDate(e.target.value)}
                  placeholder="Thứ Sáu tuần tới"
                  className="w-full px-4 py-2.5 rounded-xl bg-white border border-slate-300 font-medium text-sm text-slate-900 focus:outline-none focus:border-blue-600"
                />
              </div>
            </div>

            {/* Multi-select Checkboxes for 30 KNTT Lessons (Exact Match to Image 1) */}
            <div className="space-y-2.5">
              <label className="block text-xs font-extrabold text-slate-700">
                Chọn các bài học KNTT cần hoàn thành trong tuần ({formLessonIds.length} bài đang chọn):
              </label>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-64 overflow-y-auto pr-1">
                {ALL_KNTT_LESSONS.map((lesson) => {
                  const isChecked = formLessonIds.includes(lesson.id);
                  return (
                    <div
                      key={lesson.id}
                      onClick={() => handleToggleFormLesson(lesson.id)}
                      className={`p-3.5 rounded-xl border-2 flex items-center gap-3 transition cursor-pointer select-none ${
                        isChecked
                          ? 'border-[#1d6bf3] bg-blue-50/60 text-slate-900 font-extrabold shadow-2xs'
                          : 'border-slate-200 bg-white hover:border-slate-300 text-slate-700 font-medium'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-md flex items-center justify-center border transition shrink-0 ${
                          isChecked
                            ? 'bg-[#1d6bf3] border-[#1d6bf3] text-white'
                            : 'bg-white border-slate-300'
                        }`}
                      >
                        {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                      <span className="text-xs sm:text-sm truncate">
                        {lesson.title} ({getSubjectLabel(lesson.subject)})
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="text-xs text-slate-500">
                Khi lưu, học sinh đăng nhập vào lớp sẽ thấy ngay nhiệm vụ của <strong>Tuần {formWeekNumber}</strong>.
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-[#1d6bf3] hover:bg-[#1557c7] text-white font-extrabold text-xs sm:text-sm shadow transition cursor-pointer"
                >
                  Lưu & Giao nhiệm vụ Tuần {formWeekNumber}
                </button>
              </div>
            </div>
          </form>
        )}
      </div>

      {/* ================= ACTIVE WEEK DETAILS & ASSIGNED LESSONS ================= */}
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-black">
                NHIỆM VỤ ĐANG CHỌN: TUẦN {activeAssignment.weekNumber} (
                {activeAssignment.semesterLabel || 'HK1'})
              </span>
              <span className="text-xs font-bold text-slate-500">
                Hạn hoàn thành: <strong className="text-slate-800">{activeAssignment.dueDate}</strong>
              </span>
            </div>
            <h3 className="text-lg sm:text-xl font-black text-slate-900">
              {activeAssignment.title}
            </h3>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs font-extrabold">
            <span className="px-3 py-1.5 rounded-xl bg-indigo-50 text-indigo-800 border border-indigo-200">
              Chỉ tiêu TN: {activeAssignment.targetMcq} câu
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-teal-50 text-teal-800 border border-teal-200">
              Đúng/Sai: {activeAssignment.targetTf} bài
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-amber-50 text-amber-800 border border-amber-200">
              Tự luận: {activeAssignment.targetEssay} bài
            </span>
          </div>
        </div>

        {/* Assigned Lesson Launch Cards for Current Week */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3.5">
          {assignedLessons.map((lesson) => (
            <div
              key={lesson.id}
              className="p-4 rounded-2xl border border-slate-200 bg-slate-50/70 flex flex-col justify-between gap-3"
            >
              <div>
                <span className="text-[11px] font-black uppercase text-blue-600">
                  {lesson.chapterTitle}
                </span>
                <h4 className="text-sm font-black text-slate-900 mt-0.5">{lesson.title}</h4>
                <p className="text-xs text-slate-500 mt-1">
                  {lesson.mcqs.length} câu TN · {lesson.trueFalseList.length} bài Đ/S ·{' '}
                  {lesson.essays.length} bài Tự luận
                </p>
              </div>
              <button
                onClick={() => onStartLessonPractice(lesson.id)}
                className="w-full py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-extrabold flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <span>Vào làm bài tập tuần này</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* ================= CLASS PROGRESS TABLE & TEACHER EVALUATION ================= */}
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-600" />
              <span>
                Bảng theo dõi làm Bài tập về nhà & Nhận xét Tiến bộ (Tuần{' '}
                {activeAssignment.weekNumber})
              </span>
            </h3>
            <p className="text-xs text-slate-500">
              Bấm vào tên học sinh hoặc nút <strong>"Hồ sơ & Nhận xét"</strong> để xem Biểu đồ điểm, Cảnh báo học tập và ghi nhận xét tiến bộ.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {[
              { id: 'all' as const, label: `Tất cả (${students.length})` },
              { id: 'completed' as const, label: `Hoàn thành (${completedCount})` },
              { id: 'in_progress' as const, label: `Đang làm (${inProgressCount})` },
              { id: 'not_started' as const, label: `Chưa làm (${notStartedCount})` },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setStatusFilter(f.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                  statusFilter === f.id
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {f.label}
              </button>
            ))}

            <button
              onClick={handleExportCsv}
              className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Xuất Excel (CSV)</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-[11px] font-black uppercase text-slate-500 bg-slate-50">
                <th className="py-3 px-3">Học sinh</th>
                <th className="py-3 px-3">Tiến độ Tuần {activeAssignment.weekNumber}</th>
                <th className="py-3 px-3">Chi tiết BTVN</th>
                <th className="py-3 px-3">ĐTB & Xu hướng</th>
                <th className="py-3 px-3">Nhận xét tiến bộ</th>
                <th className="py-3 px-3 text-right">Hồ sơ & Đánh giá</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/80 text-xs sm:text-sm">
              {filteredRows.map(({ student, progress, metrics }) => {
                const isMe = student.id === currentStudent.id;
                const latestComment = (student.teacherComments || [])[0];

                return (
                  <tr
                    key={student.id}
                    className={`hover:bg-slate-50/90 transition ${
                      isMe ? 'bg-emerald-50/40' : ''
                    }`}
                  >
                    <td className="py-3.5 px-3">
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-9 h-9 rounded-xl ${
                            student.avatarColor || 'bg-teal-600'
                          } text-white font-black text-xs flex items-center justify-center shrink-0`}
                        >
                          {student.fullName.trim().split(' ').pop()?.charAt(0) || 'H'}
                        </div>
                        <div>
                          <button
                            onClick={() => setInspectingStudent(student)}
                            className="font-black text-slate-900 hover:text-blue-600 text-left flex items-center gap-1.5 cursor-pointer"
                          >
                            <span>{student.fullName}</span>
                            {isMe && (
                              <span className="px-1.5 py-0.5 rounded bg-emerald-600 text-white text-[10px]">
                                Bạn
                              </span>
                            )}
                          </button>
                          <div className="text-[11px] text-slate-500 font-semibold">
                            {student.code} · {student.className}
                          </div>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-3">
                      <div className="w-36 space-y-1">
                        <div className="flex justify-between text-xs font-extrabold">
                          <span
                            className={
                              progress.status === 'completed'
                                ? 'text-emerald-700'
                                : progress.status === 'in_progress'
                                ? 'text-amber-700'
                                : 'text-rose-600'
                            }
                          >
                            {progress.status === 'completed'
                              ? 'Hoàn thành'
                              : progress.status === 'in_progress'
                              ? 'Đang làm'
                              : 'Chưa làm'}
                          </span>
                          <span>{progress.percent}%</span>
                        </div>
                        <div className="h-2 rounded-full bg-slate-200 overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              progress.status === 'completed'
                                ? 'bg-emerald-500'
                                : progress.status === 'in_progress'
                                ? 'bg-amber-500'
                                : 'bg-rose-500'
                            }`}
                            style={{ width: `${progress.percent}%` }}
                          />
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-3">
                      <div className="flex flex-wrap gap-1.5 text-[11px] font-bold">
                        <span className="px-2 py-0.5 rounded bg-indigo-50 text-indigo-700">
                          {progress.mcqDone}/{activeAssignment.targetMcq} TN
                        </span>
                        <span className="px-2 py-0.5 rounded bg-teal-50 text-teal-700">
                          {progress.tfDone}/{activeAssignment.targetTf} Đ/S
                        </span>
                        <span className="px-2 py-0.5 rounded bg-amber-50 text-amber-800">
                          {progress.essayDone}/{activeAssignment.targetEssay} TL
                        </span>
                      </div>
                    </td>

                    <td className="py-3.5 px-3">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-sm font-black ${
                            metrics.needsWarning ? 'text-rose-600' : 'text-indigo-600'
                          }`}
                        >
                          {metrics.average.toFixed(2)}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                            metrics.trend === 'down'
                              ? 'bg-amber-100 text-amber-800'
                              : metrics.trend === 'up'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {metrics.trendLabel}
                        </span>
                      </div>
                    </td>

                    <td className="py-3.5 px-3 max-w-xs">
                      {latestComment ? (
                        <div className="text-xs text-slate-700 line-clamp-2">
                          <strong className="text-indigo-700">
                            [Tuần {latestComment.weekNumber}]:
                          </strong>{' '}
                          {latestComment.content}
                        </div>
                      ) : metrics.needsWarning ? (
                        <span className="text-xs font-bold text-rose-600">
                          ⚠️ Cảnh báo ĐTB &lt; 5.0 – Cần nhắc nhở làm bài!
                        </span>
                      ) : (
                        <span className="text-xs text-slate-400 italic">
                          Bấm "Hồ sơ & Nhận xét" để ghi đánh giá
                        </span>
                      )}
                    </td>

                    <td className="py-3.5 px-3 text-right">
                      <button
                        onClick={() => setInspectingStudent(student)}
                        className="px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-600 text-indigo-700 hover:text-white font-extrabold text-xs inline-flex items-center gap-1.5 transition cursor-pointer"
                      >
                        <BarChart3 className="w-3.5 h-3.5" />
                        <span>Hồ sơ & Nhận xét</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ================= 4-TAB STUDENT PROFILE & PROGRESS MODAL (IMAGE 2) ================= */}
      {inspectingStudent && (
        <StudentProfileModal
          student={inspectingStudent}
          isCurrentActiveStudent={inspectingStudent.id === currentStudent.id}
          userRole={userRole}
          activeWeek={activeAssignment.weekNumber}
          onClose={() => setInspectingStudent(null)}
          onUpdateStudent={(updated) => {
            onUpdateStudent(updated);
            setInspectingStudent(updated);
          }}
        />
      )}
    </div>
  );
};
