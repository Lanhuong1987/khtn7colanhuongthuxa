import React, { useState, useRef } from 'react';
import {
  Users,
  UserPlus,
  CheckCircle2,
  Trash2,
  ShieldCheck,
  RotateCcw,
  Upload,
  FileSpreadsheet,
  Download,
  BarChart3,
  ClipboardPaste,
  Search,
  AlertTriangle,
  Save,
  RefreshCw,
  FileText,
  Lock,
  Eye,
  KeyRound,
  Edit3,
  Check,
  X,
  Share2,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import mammoth from 'mammoth';
import {
  StudentProfile,
  calculateStudentGradeMetrics,
  SavedWordExamDoc,
  ParsedWordMcq,
} from '../data/classStore';
import { StudentProfileModal } from './StudentProfileModal';

interface ClassAdminViewProps {
  userRole: 'student' | 'teacher';
  isTeacherAuthenticated: boolean;
  onAuthenticateTeacher: (pin: string) => boolean;
  onLockTeacherArea: () => void;
  onChangeRole: (role: 'student' | 'teacher') => void;
  students: StudentProfile[];
  currentStudent: StudentProfile | null;
  activeWeek: number;
  savedWordDocs: SavedWordExamDoc[];
  onSaveWordDoc: (doc: SavedWordExamDoc) => void;
  onDeleteWordDoc: (docId: string) => void;
  onSelectStudent: (student: StudentProfile) => void;
  onAddStudent: (fullName: string, className: string) => void;
  onBulkImportStudents: (
    entries: { fullName: string; className: string; code?: string }[],
    replaceExisting: boolean
  ) => void;
  onSaveAndSyncRoster: () => void;
  onRestoreOfficialStudents?: () => void;
  lastSyncedRosterAt: string;
  onUpdateStudent: (updated: StudentProfile) => void;
  onDeleteStudent: (studentId: string) => void;
  onResetCurrentStudentProgress: () => void;
}

// Helper to parse MCQs from plain text of a Word document if formatted with Câu 1... A. B. C. D.
export function parseMcqsFromWordText(rawText: string): ParsedWordMcq[] {
  const lines = rawText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  const mcqs: ParsedWordMcq[] = [];
  let currentQ = '';
  let currentOpts: string[] = [];
  let correctIdx = 0;

  const flushQuestion = () => {
    if (currentQ && currentOpts.length >= 4) {
      mcqs.push({
        id: `w-mcq-${mcqs.length + 1}`,
        question: currentQ,
        options: [
          currentOpts[0],
          currentOpts[1],
          currentOpts[2],
          currentOpts[3],
        ],
        correctIndex: correctIdx,
      });
    }
    currentQ = '';
    currentOpts = [];
    correctIdx = 0;
  };

  for (const line of lines) {
    if (/^(Câu|Question)\s*\d+[\.:\)]/i.test(line)) {
      flushQuestion();
      currentQ = line.replace(/^(Câu|Question)\s*\d+[\.:\)]\s*/i, '').trim();
    } else if (/^[A-D][\.:\)]\s+/i.test(line)) {
      // Check if multiple options are on the same line: e.g. "A. ... B. ..."
      const parts = line.split(/(?=[A-D][\.:\)]\s+)/i).map((p) => p.trim());
      for (const p of parts) {
        const cleanOpt = p.replace(/^[A-D][\.:\)]\s*/i, '').trim();
        if (cleanOpt.startsWith('*')) {
          correctIdx = currentOpts.length;
          currentOpts.push(cleanOpt.replace(/^\*+/, '').trim());
        } else {
          currentOpts.push(cleanOpt);
        }
      }
    } else if (/^(Đáp án|Dap an)[\s:]*([A-D])/i.test(line)) {
      const match = line.match(/^(?:Đáp án|Dap an)[\s:]*([A-D])/i);
      if (match) {
        const letter = match[1].toUpperCase();
        correctIdx = ['A', 'B', 'C', 'D'].indexOf(letter);
        if (correctIdx < 0) correctIdx = 0;
      }
    } else if (currentQ && currentOpts.length === 0) {
      currentQ += ' ' + line;
    }
  }
  flushQuestion();
  return mcqs;
}

export const ClassAdminView: React.FC<ClassAdminViewProps> = ({
  userRole,
  isTeacherAuthenticated,
  onAuthenticateTeacher,
  onLockTeacherArea,
  students,
  currentStudent,
  activeWeek,
  savedWordDocs,
  onSaveWordDoc,
  onDeleteWordDoc,
  onSelectStudent,
  onAddStudent,
  onBulkImportStudents,
  onSaveAndSyncRoster,
  onRestoreOfficialStudents,
  lastSyncedRosterAt,
  onUpdateStudent,
  onDeleteStudent,
  onResetCurrentStudentProgress,
}) => {
  const [teacherPinInput, setTeacherPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const [showChangePinBox, setShowChangePinBox] = useState(false);
  const [newCustomPin, setNewCustomPin] = useState('');
  const [confirmCustomPin, setConfirmCustomPin] = useState('');

  const [newFullName, setNewFullName] = useState('');
  const [newClassName, setNewClassName] = useState('Lớp 7A1');
  const [bulkText, setBulkText] = useState('');
  const [bulkClassDefault, setBulkClassDefault] = useState('Lớp 7A1');
  const [replaceExistingOnImport, setReplaceExistingOnImport] = useState(false);
  const [pendingExcelEntries, setPendingExcelEntries] = useState<
    { fullName: string; className: string; code?: string }[] | null
  >(null);
  const [pendingExcelFileName, setPendingExcelFileName] = useState<string>('');

  const [searchQuery, setSearchQuery] = useState('');
  const [classFilter, setClassFilter] = useState<string>('Tất cả');
  const [statusNotice, setStatusNotice] = useState<string | null>(null);
  const [inspectingStudent, setInspectingStudent] = useState<StudentProfile | null>(null);

  // Inline Edit Student Name / Class / Code states in Roster Table
  const [editingStudentId, setEditingStudentId] = useState<string | null>(null);
  const [editStudentName, setEditStudentName] = useState<string>('');
  const [editStudentClass, setEditStudentClass] = useState<string>('');
  const [editStudentCode, setEditStudentCode] = useState<string>('');
  const [showTableQuickAdd, setShowTableQuickAdd] = useState<boolean>(false);
  const [quickAddName, setQuickAddName] = useState<string>('');
  const [quickAddClass, setQuickAddClass] = useState<string>('Lớp 7A1');

  // Word Exam / Material upload states
  const [wordTitle, setWordTitle] = useState('');
  const [wordDocType, setWordDocType] = useState<'exam' | 'worksheet' | 'material'>('exam');
  const [wordSubject, setWordSubject] = useState<
    'Liên môn KHTN 7' | 'Hóa học 7' | 'Vật lí 7' | 'Sinh học 7'
  >('Liên môn KHTN 7');
  const [wordWeek, setWordWeek] = useState<number>(activeWeek);
  const [uploadedWordFileName, setUploadedWordFileName] = useState('');
  const [uploadedWordHtml, setUploadedWordHtml] = useState('');
  const [uploadedWordRawText, setUploadedWordRawText] = useState('');
  const [uploadedWordDataUrl, setUploadedWordDataUrl] = useState<string | undefined>(undefined);
  const [previewingWordDoc, setPreviewingWordDoc] = useState<SavedWordExamDoc | null>(null);

  const excelFileInputRef = useRef<HTMLInputElement | null>(null);
  const wordFileInputRef = useRef<HTMLInputElement | null>(null);

  // If not authenticated as teacher, block access so students cannot modify teacher settings
  if (!isTeacherAuthenticated || userRole !== 'teacher') {
    return (
      <div className="max-w-xl mx-auto my-8 bg-white rounded-3xl border-2 border-indigo-200 shadow-2xl overflow-hidden">
        <div className="bg-gradient-to-r from-[#061838] via-[#0b2b52] to-[#083b42] p-6 text-white">
          <div className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-emerald-300">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
            <span>KHU VỰC DÀNH RIÊNG CHO GIÁO VIÊN QUẢN LÝ & GIAO BÀI</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black mt-1">
            Bảo mật Khu vực Giáo viên KHTN 7
          </h2>
          <p className="text-xs sm:text-sm text-slate-200 mt-1">
            Học sinh không được phép tự ý vào khu vực của giáo viên để chỉnh sửa danh sách lớp, điểm số hoặc đề kiểm tra.
          </p>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            const ok = onAuthenticateTeacher(teacherPinInput);
            if (!ok) {
              setPinError('Mật khẩu Giáo viên không chính xác. Vui lòng kiểm tra lại!');
            } else {
              setPinError('');
              setTeacherPinInput('');
            }
          }}
          className="p-6 sm:p-7 space-y-4"
        >
          <div>
            <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-2">
              MẬT KHẨU / MÃ BẢO MẬT GIÁO VIÊN
            </label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                value={teacherPinInput}
                onChange={(e) => setTeacherPinInput(e.target.value)}
                placeholder="Nhập mật khẩu bảo mật của giáo viên..."
                className="w-full pl-10 pr-4 py-3.5 rounded-2xl border-2 border-blue-400 text-sm font-bold focus:outline-none focus:border-blue-600"
              />
            </div>
            <p className="text-xs text-slate-500 mt-1.5">
              Khu vực dành riêng cho giáo viên bộ môn. Vui lòng nhập mật khẩu riêng của giáo viên để mở khóa chức năng quản lý lớp, điểm số và đề kiểm tra.
            </p>
            {pinError && (
              <p className="text-xs font-extrabold text-rose-600 mt-2">{pinError}</p>
            )}
          </div>

          <button
            type="submit"
            className="w-full py-3.5 rounded-2xl bg-[#0d6efd] hover:bg-blue-700 text-white font-black text-sm shadow-lg transition cursor-pointer"
          >
            Xác nhận & Mở Khu vực Giáo viên →
          </button>
        </form>
      </div>
    );
  }

  const showNotice = (msg: string) => {
    setStatusNotice(msg);
    setTimeout(() => setStatusNotice(null), 5000);
  };

  const handleCopyShareableRosterLink = async () => {
    try {
      const compactRoster = students.map((s) => ({
        fullName: s.fullName,
        className: s.className,
        code: s.code,
      }));
      const json = JSON.stringify(compactRoster);
      const encoded = btoa(unescape(encodeURIComponent(json)));
      const shareUrl = `${window.location.origin}${window.location.pathname}?roster=${encodeURIComponent(encoded)}`;
      await navigator.clipboard.writeText(shareUrl);
      showNotice(
        `🔗 Đã sao chép Link lớp kèm toàn bộ ${students.length} học sinh! Cô gửi link này qua Zalo cho Phụ huynh & Học sinh để mọi máy tự động cập nhật danh sách mới nhất.`
      );
    } catch {
      showNotice('⚠️ Không thể tự sao chép vào bộ nhớ tạm trên trình duyệt này.');
    }
  };

  const handleSubmitNewStudent = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newFullName.trim().toUpperCase();
    if (!trimmed) return;
    onAddStudent(trimmed, newClassName.trim() || 'Lớp 7A1');
    onSaveAndSyncRoster();
    setNewFullName('');
    showNotice(`✅ Đã thêm học sinh "${trimmed}" vào danh sách ${newClassName} và cập nhật đồng bộ!`);
  };

  const handleQuickAddInTable = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = quickAddName.trim().toUpperCase();
    if (!trimmed) return;
    const cls = quickAddClass.trim() || 'Lớp 7A1';
    onAddStudent(trimmed, cls);
    onSaveAndSyncRoster();
    setQuickAddName('');
    setShowTableQuickAdd(false);
    showNotice(`✅ Đã thêm học sinh "${trimmed}" (${cls}) và cập nhật đồng bộ danh sách lớp!`);
  };

  const handleStartEditStudent = (st: StudentProfile) => {
    setEditingStudentId(st.id);
    setEditStudentName(st.fullName);
    setEditStudentClass(st.className);
    setEditStudentCode(st.code);
  };

  const handleSaveEditedStudent = (st: StudentProfile) => {
    const cleanedName = editStudentName.trim().toUpperCase();
    if (!cleanedName) {
      showNotice('⚠️ Họ và tên học sinh không được để trống!');
      return;
    }
    const cleanedClass = editStudentClass.trim() || st.className || 'Lớp 7A1';
    const cleanedCode = editStudentCode.trim().toUpperCase() || st.code;

    const updatedStudent: StudentProfile = {
      ...st,
      fullName: cleanedName,
      className: cleanedClass,
      code: cleanedCode,
    };

    onUpdateStudent(updatedStudent);
    onSaveAndSyncRoster();
    setEditingStudentId(null);
    showNotice(
      `✅ Đã cập nhật tên học sinh thành "${cleanedName}" (${cleanedClass}) và đồng bộ toàn hệ thống!`
    );
  };

  const handleRemoveStudentWithNotice = (st: StudentProfile) => {
    if (students.length <= 1) {
      showNotice('⚠️ Danh sách lớp cần giữ lại ít nhất 1 học sinh!');
      return;
    }
    onDeleteStudent(st.id);
    onSaveAndSyncRoster();
    showNotice(
      `🗑️ Đã xóa học sinh "${st.fullName}" (${st.className}) khỏi danh sách lớp và cập nhật đồng bộ!`
    );
  };

  // Parse lines from CSV or pasted Excel text
  const parseStudentLines = (rawContent: string) => {
    const lines = rawContent
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter((l) => l.length > 0);

    const parsed: { fullName: string; className: string; code?: string }[] = [];

    for (const line of lines) {
      const lower = line.toLowerCase();
      if (
        lower.includes('họ và tên') ||
        lower.includes('ho va ten') ||
        lower.startsWith('stt,') ||
        lower.startsWith('ma hs') ||
        lower.startsWith('mã hs')
      ) {
        continue;
      }

      const parts = line.split(/[,;\t]/).map((p) => p.replace(/^["']|["']$/g, '').trim());
      if (parts.length === 1) {
        const cleanName = parts[0].replace(/^\d+[\.\)\-\s]+/, '').trim().toUpperCase();
        if (cleanName.length >= 2) {
          parsed.push({ fullName: cleanName, className: bulkClassDefault });
        }
      } else if (parts.length === 2) {
        if (/^\d+$/.test(parts[0]) || parts[0].toUpperCase().includes('HS')) {
          parsed.push({
            code: parts[0].toUpperCase().includes('HS') ? parts[0].toUpperCase() : undefined,
            fullName: parts[1].toUpperCase(),
            className: bulkClassDefault,
          });
        } else {
          parsed.push({
            fullName: parts[0].toUpperCase(),
            className: parts[1].startsWith('Lớp') ? parts[1] : `Lớp ${parts[1]}`,
          });
        }
      } else if (parts.length >= 3) {
        const codeCandidate = parts[0].toUpperCase().includes('HS')
          ? parts[0].toUpperCase()
          : undefined;
        const nameCandidate = parts[1].toUpperCase();
        const classCandidate = parts[2].startsWith('Lớp')
          ? parts[2]
          : `Lớp ${parts[2] || '7A1'}`;
        if (nameCandidate.length >= 2) {
          parsed.push({
            code: codeCandidate,
            fullName: nameCandidate,
            className: classCandidate,
          });
        }
      }
    }

    return parsed;
  };

  // Handle uploading .xlsx, .xls, .csv, .txt
  const handleExcelOrCsvUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const ext = file.name.split('.').pop()?.toLowerCase() || '';

    try {
      if (ext === 'xlsx' || ext === 'xls') {
        const buffer = await file.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const rows = XLSX.utils.sheet_to_json<string[]>(worksheet, { header: 1 });

        const entries: { fullName: string; className: string; code?: string }[] = [];
        for (const row of rows) {
          if (!Array.isArray(row) || row.length === 0) continue;
          const cells = row.map((c) => String(c ?? '').trim()).filter(Boolean);
          if (cells.length === 0) continue;

          const joinedLower = cells.join(' ').toLowerCase();
          if (
            joinedLower.includes('họ và tên') ||
            joinedLower.includes('ho va ten') ||
            joinedLower.includes('danh sách học sinh')
          ) {
            continue;
          }

          if (cells.length === 1) {
            const nameClean = cells[0].replace(/^\d+[\.\)\-\s]+/, '').trim().toUpperCase();
            if (nameClean.length >= 2) {
              entries.push({ fullName: nameClean, className: bulkClassDefault });
            }
          } else if (cells.length === 2) {
            if (/^\d+$/.test(cells[0]) || cells[0].toUpperCase().includes('HS')) {
              entries.push({
                code: cells[0].toUpperCase().includes('HS') ? cells[0].toUpperCase() : undefined,
                fullName: cells[1].toUpperCase(),
                className: bulkClassDefault,
              });
            } else {
              entries.push({
                fullName: cells[0].toUpperCase(),
                className: cells[1].startsWith('Lớp') ? cells[1] : `Lớp ${cells[1]}`,
              });
            }
          } else {
            const firstCell = cells[0].toUpperCase();
            const isFirstIndexOrCode = /^\d+$/.test(firstCell) || firstCell.includes('HS');
            const nameCell = (isFirstIndexOrCode ? cells[1] : cells[0]).toUpperCase();
            const classCellRaw = isFirstIndexOrCode ? cells[2] : cells[1];
            const classCell = classCellRaw
              ? classCellRaw.startsWith('Lớp')
                ? classCellRaw
                : `Lớp ${classCellRaw}`
              : bulkClassDefault;
            if (nameCell && nameCell.length >= 2) {
              entries.push({
                code: firstCell.includes('HS') ? firstCell : undefined,
                fullName: nameCell,
                className: classCell,
              });
            }
          }
        }

        if (entries.length > 0) {
          setPendingExcelEntries(entries);
          setPendingExcelFileName(file.name);
          showNotice(
            `📊 Đã đọc thành công ${entries.length} học sinh từ file Excel "${file.name}". Hãy bấm "Lưu danh sách học sinh" và "Đồng bộ danh sách" bên dưới!`
          );
        } else {
          showNotice('Không tìm thấy cột Họ và Tên học sinh hợp lệ trong file Excel!');
        }
      } else {
        const text = await file.text();
        const entries = parseStudentLines(text);
        if (entries.length > 0) {
          setPendingExcelEntries(entries);
          setPendingExcelFileName(file.name);
          showNotice(
            `📂 Đã đọc ${entries.length} học sinh từ file "${file.name}". Hãy bấm "Lưu danh sách học sinh" để áp dụng!`
          );
        } else {
          showNotice('Không tìm thấy tên học sinh hợp lệ trong file!');
        }
      }
    } catch {
      showNotice('Lỗi khi đọc file Excel! Vui lòng kiểm tra lại định dạng .xlsx / .csv.');
    }

    e.target.value = '';
  };

  // Save pending Excel entries + Sync roster
  const handleSaveUploadedRoster = () => {
    if (pendingExcelEntries && pendingExcelEntries.length > 0) {
      onBulkImportStudents(pendingExcelEntries, replaceExistingOnImport);
      const count = pendingExcelEntries.length;
      setPendingExcelEntries(null);
      setPendingExcelFileName('');
      onSaveAndSyncRoster();
      showNotice(
        `💾 Đã lưu & đồng bộ ${count} học sinh từ file Excel vào danh sách lớp thành công!`
      );
    } else if (bulkText.trim()) {
      const entries = parseStudentLines(bulkText);
      if (entries.length > 0) {
        onBulkImportStudents(entries, replaceExistingOnImport);
        setBulkText('');
        onSaveAndSyncRoster();
        showNotice(`💾 Đã lưu & đồng bộ ${entries.length} học sinh vừa nhập thành công!`);
      }
    } else {
      onSaveAndSyncRoster();
      showNotice(
        `💾 Đã lưu danh sách ${students.length} học sinh và đồng bộ toàn hệ thống (Phòng thi, BTVN Tuần, Bảng điểm)!`
      );
    }
  };

  const normalizeClassName = (raw: string): string => {
    const cleaned = (raw || '').trim();
    if (!cleaned) return 'Lớp 7A1';
    if (/^lớp\s+/i.test(cleaned)) {
      return `Lớp ${cleaned.replace(/^lớp\s+/i, '').trim().toUpperCase()}`;
    }
    return `Lớp ${cleaned.toUpperCase()}`;
  };

  const getShortClassCode = (cls: string): string => {
    return normalizeClassName(cls).replace(/^Lớp\s+/i, '');
  };

  const isAllClassesSelected = (val: string): boolean =>
    !val || val === 'Tất cả' || val === 'all';

  // Export current roster (or filtered class roster) to a real .xlsx file
  const handleExportRosterToXlsx = (onlyFilteredClass = false) => {
    const targetList =
      onlyFilteredClass && !isAllClassesSelected(classFilter)
        ? students.filter((s) => normalizeClassName(s.className) === normalizeClassName(classFilter))
        : students;

    const dataRows = targetList.map((st, idx) => {
      const metrics = calculateStudentGradeMetrics(st);
      return {
        STT: idx + 1,
        'Mã HS': st.code,
        'Họ và Tên Học sinh': st.fullName,
        Lớp: normalizeClassName(st.className),
        'TX1 (HS1)': st.scores?.tx1 ?? '',
        'TX2 (HS1)': st.scores?.tx2 ?? '',
        'TX3 (HS1)': st.scores?.tx3 ?? '',
        'ĐGGK (HS2)': st.scores?.dggk ?? '',
        'ĐGCK (HS3)': st.scores?.dgck ?? '',
        'Điểm TB': metrics.average,
        'Xếp loại': metrics.rankLabel,
        'Điểm Rèn luyện': st.commendationPoints || 0,
      };
    });

    const classSuffix =
      onlyFilteredClass && !isAllClassesSelected(classFilter)
        ? `_${getShortClassCode(classFilter)}`
        : '_TatCaCacLop';
    const worksheet = XLSX.utils.json_to_sheet(dataRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, `DanhSach${classSuffix}`);
    XLSX.writeFile(workbook, `Danh_Sach_Hoc_Sinh_KHTN7${classSuffix}.xlsx`);
    showNotice(
      onlyFilteredClass && !isAllClassesSelected(classFilter)
        ? `📥 Đã xuất file Excel (.xlsx) danh sách riêng của ${normalizeClassName(classFilter)} (${targetList.length} học sinh)!`
        : `📥 Đã xuất và tải về máy file Excel (.xlsx) danh sách toàn bộ ${targetList.length} học sinh!`
    );
  };

  // Download sample .xlsx template
  const handleDownloadSampleXlsx = () => {
    const sampleRows = [
      { STT: 1, 'Mã HS': 'KHTN7_HS01', 'Họ và Tên': 'VÕ THỊ THANH HÀ', Lớp: 'Lớp 7A1' },
      { STT: 2, 'Mã HS': 'KHTN7_HS02', 'Họ và Tên': 'LÊ PHAN BẢO CHÂU', Lớp: 'Lớp 7A1' },
      { STT: 3, 'Mã HS': 'KHTN7_HS03', 'Họ và Tên': 'PHẠM ĐOÀN NINA', Lớp: 'Lớp 7A1' },
      { STT: 4, 'Mã HS': 'KHTN7_HS04', 'Họ và Tên': 'NGUYỄN ĐỖ ÁNH TIÊN', Lớp: 'Lớp 7A1' },
      { STT: 5, 'Mã HS': 'KHTN7_HS05', 'Họ và Tên': 'VÕ ĐỨC ĐAM', Lớp: 'Lớp 7A1' },
      { STT: 6, 'Mã HS': 'KHTN7_HS06', 'Họ và Tên': 'NGUYỄN BẢO KHANG', Lớp: 'Lớp 7A1' },
      { STT: 7, 'Mã HS': 'KHTN7_HS07', 'Họ và Tên': 'NGUYỄN THỊ GIA NHI', Lớp: 'Lớp 7A1' },
      { STT: 8, 'Mã HS': 'KHTN7_HS08', 'Họ và Tên': 'PHẠM THÀNH TIẾN', Lớp: 'Lớp 7A1' },
      { STT: 9, 'Mã HS': 'KHTN7_HS09', 'Họ và Tên': 'TRƯƠNG THỊ QUỲNH NHƯ', Lớp: 'Lớp 7A1' },
      { STT: 10, 'Mã HS': 'KHTN7_HS10', 'Họ và Tên': 'KIỀU TRƯƠNG THẢO NHƯ', Lớp: 'Lớp 7A1' },
      { STT: 11, 'Mã HS': 'KHTN7_HS11', 'Họ và Tên': 'BÙI NHÂN NHÂN', Lớp: 'Lớp 7A1' },
      { STT: 12, 'Mã HS': 'KHTN7_HS12', 'Họ và Tên': 'NGUYỄN NỮ MỘC MIÊN', Lớp: 'Lớp 7A1' },
      { STT: 13, 'Mã HS': 'KHTN7_HS13', 'Họ và Tên': 'PHẠM ANH TRÍ', Lớp: 'Lớp 7A1' },
      { STT: 14, 'Mã HS': 'KHTN7_HS14', 'Họ và Tên': 'NGUYỄN LÊ THÙY DƯƠNG', Lớp: 'Lớp 7A1' },
      { STT: 15, 'Mã HS': 'KHTN7_HS15', 'Họ và Tên': 'LÝ TIẾN THIÊN', Lớp: 'Lớp 7A1' },
      { STT: 16, 'Mã HS': 'KHTN7_HS16', 'Họ và Tên': 'MAI ĐĂNG KHOA', Lớp: 'Lớp 7A1' },
      { STT: 17, 'Mã HS': 'KHTN7_HS17', 'Họ và Tên': 'BÙI ANH KIỆT', Lớp: 'Lớp 7A1' },
      { STT: 18, 'Mã HS': 'KHTN7_HS18', 'Họ và Tên': 'THIÊN KIM', Lớp: 'Lớp 7A1' },
      { STT: 19, 'Mã HS': 'KHTN7_HS19', 'Họ và Tên': 'PHƯƠNG LINH', Lớp: 'Lớp 7A1' },
    ];
    const ws = XLSX.utils.json_to_sheet(sampleRows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Mau_Danh_Sach_KHTN7');
    XLSX.writeFile(wb, 'Mau_Danh_Sach_Hoc_Sinh_KHTN7.xlsx');
  };

  // Handle uploading Word (.docx, .doc) exam/document
  const handleWordFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    setUploadedWordFileName(file.name);
    if (!wordTitle.trim()) {
      setWordTitle(file.name.replace(/\.(docx|doc)$/i, '').replace(/[_-]+/g, ' '));
    }

    // Read Data URL for downloading the original file
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setUploadedWordDataUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);

    try {
      if (ext === 'docx') {
        const arrayBuffer = await file.arrayBuffer();
        const htmlResult = await mammoth.convertToHtml({ arrayBuffer });
        const textResult = await mammoth.extractRawText({ arrayBuffer });
        setUploadedWordHtml(
          htmlResult.value || `<p>${textResult.value.replace(/\n/g, '<br/>')}</p>`
        );
        setUploadedWordRawText(textResult.value || '');
        showNotice(
          `📄 Đã tải lên file Word "${file.name}". Hãy kiểm tra thông tin và bấm "💾 Lưu Đề / Tài liệu Word"!`
        );
      } else {
        // .doc or text/html Word file
        const text = await file.text();
        setUploadedWordRawText(text.replace(/<[^>]+>/g, ' '));
        setUploadedWordHtml(
          text.includes('<html') || text.includes('<p')
            ? text
            : `<div style="white-space: pre-wrap">${text}</div>`
        );
        showNotice(
          `📄 Đã tải lên file Word "${file.name}". Hãy bấm "💾 Lưu Đề / Tài liệu Word" để lưu vào hệ thống!`
        );
      }
    } catch {
      showNotice('Đã đính kèm file Word. Bấm "💾 Lưu Đề / Tài liệu Word" để lưu!');
    }

    e.target.value = '';
  };

  const handleSaveWordExamOrMaterial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!wordTitle.trim() && !uploadedWordFileName) {
      showNotice('Vui lòng chọn file Word (.docx / .doc) hoặc nhập tên đề cần lưu!');
      return;
    }

    const parsedMcqs = parseMcqsFromWordText(uploadedWordRawText);
    const nowStr = new Date().toLocaleString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });

    const newDoc: SavedWordExamDoc = {
      id: `word-doc-${Date.now()}`,
      title: wordTitle.trim() || uploadedWordFileName || 'Đề kiểm tra KHTN 7 mới',
      fileName: uploadedWordFileName || 'De_KHTN7.docx',
      docType: wordDocType,
      subjectLabel: wordSubject,
      weekNumber: wordWeek,
      createdAt: nowStr,
      htmlPreview:
        uploadedWordHtml ||
        `<p><strong>${wordTitle}</strong> — Đề / Tài liệu Word đã được giáo viên lưu lên hệ thống.</p>`,
      rawText: uploadedWordRawText || wordTitle,
      fileDataUrl: uploadedWordDataUrl,
      parsedMcqs,
    };

    onSaveWordDoc(newDoc);
    setWordTitle('');
    setUploadedWordFileName('');
    setUploadedWordHtml('');
    setUploadedWordRawText('');
    setUploadedWordDataUrl(undefined);
    showNotice(
      `💾 Đã lưu "${newDoc.title}" vào Kho Đề & Tài liệu Word thành công (${
        parsedMcqs.length > 0 ? `Tự động nhận diện ${parsedMcqs.length} câu TN` : 'Đã lưu bản Word'
      })!`
    );
  };

  const presetClasses = ['Lớp 7A1', 'Lớp 7A2', 'Lớp 7A3', 'Lớp 7A4', 'Lớp 7A5'];
  const studentClassesNormalized = students.map((s) => normalizeClassName(s.className));
  const uniqueClasses = Array.from(
    new Set([...presetClasses, ...studentClassesNormalized])
  ).sort((a, b) => a.localeCompare(b, 'vi', { numeric: true }));

  const getClassCount = (cls: string) =>
    students.filter((s) => normalizeClassName(s.className) === normalizeClassName(cls)).length;

  const handleSelectClassFilter = (selectedCls: string) => {
    setClassFilter(selectedCls);
    if (!isAllClassesSelected(selectedCls)) {
      const norm = normalizeClassName(selectedCls);
      setNewClassName(norm);
      setQuickAddClass(norm);
      setBulkClassDefault(norm);
    }
  };

  const filteredStudents = students.filter((s) => {
    const matchesClass =
      isAllClassesSelected(classFilter) ||
      normalizeClassName(s.className) === normalizeClassName(classFilter) ||
      getShortClassCode(s.className) === getShortClassCode(classFilter);
    const matchesSearch =
      !searchQuery.trim() ||
      s.fullName.toLowerCase().includes(searchQuery.trim().toLowerCase()) ||
      s.code.toLowerCase().includes(searchQuery.trim().toLowerCase()) ||
      normalizeClassName(s.className).toLowerCase().includes(searchQuery.trim().toLowerCase());
    return matchesClass && matchesSearch;
  });

  // Compute summary metrics for currently filtered students
  const filteredMetricsList = filteredStudents.map((st) => calculateStudentGradeMetrics(st));
  const filteredClassAvg =
    filteredMetricsList.length > 0
      ? Number(
          (
            filteredMetricsList.reduce((acc, m) => acc + m.average, 0) /
            filteredMetricsList.length
          ).toFixed(2)
        )
      : 0;
  const filteredGoodOrExcellentCount = filteredMetricsList.filter(
    (m) => m.rankLabel === 'Giỏi' || m.rankLabel === 'Khá'
  ).length;
  const filteredWarningCount = filteredMetricsList.filter((m) => m.needsWarning).length;

  return (
    <div className="space-y-6">
      {/* ================= TOP BANNER ================= */}
      <div className="rounded-3xl bg-gradient-to-r from-[#081e26] via-[#0d333f] to-[#081e26] text-white p-6 sm:p-7 shadow-lg border border-teal-800/80 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-400/20 border border-emerald-400/40 text-emerald-300 text-xs font-extrabold">
            <ShieldCheck className="w-4 h-4" />
            <span>KHU VỰC GIÁO VIÊN QUẢN LÝ · TẢI XLSX HỌC SINH & TẢI/LƯU ĐỀ WORD</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black">
            Quản lý Danh sách Học sinh (.XLSX) & Kho Đề Kiểm Tra Word (.DOCX)
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-3xl">
            Đồng bộ lần cuối: <strong className="text-amber-300">{lastSyncedRosterAt}</strong> · Tổng số: <strong className="text-emerald-300">{students.length} học sinh</strong> · <strong className="text-cyan-300">{savedWordDocs.length} đề/tài liệu Word đã lưu</strong>.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => {
              onSaveAndSyncRoster();
              showNotice(
                `🔄 Đã đồng bộ danh sách ${students.length} học sinh và ${savedWordDocs.length} đề Word sang khu vực Học sinh!`
              );
            }}
            className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-1.5 shadow transition cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Đồng bộ Danh sách ngay</span>
          </button>

          <button
            type="button"
            onClick={handleCopyShareableRosterLink}
            className="px-4 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-1.5 shadow transition cursor-pointer"
            title="Sao chép đường link có đính kèm danh sách học sinh hiện tại để gửi Zalo cho Học sinh & Phụ huynh"
          >
            <Share2 className="w-4 h-4" />
            <span>Sao chép Link lớp (gửi Zalo)</span>
          </button>

          {onRestoreOfficialStudents && (
            <button
              type="button"
              onClick={() => {
                onRestoreOfficialStudents();
                showNotice(
                  '✅ Đã khôi phục & đồng bộ đầy đủ 19 học sinh chính thức của lớp!'
                );
              }}
              className="px-3.5 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white border border-white/25 font-extrabold text-xs sm:text-sm flex items-center gap-1.5 transition cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Khôi phục 19 HS gốc</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setShowChangePinBox((prev) => !prev)}
            className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-1.5 shadow transition cursor-pointer"
          >
            <KeyRound className="w-4 h-4" />
            <span>Đổi mật khẩu GV</span>
          </button>

          <button
            type="button"
            onClick={onLockTeacherArea}
            className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-black text-xs sm:text-sm flex items-center gap-1.5 shadow transition cursor-pointer"
            title="Khóa khu vực Giáo viên để học sinh không tự ý vào chỉnh sửa"
          >
            <Lock className="w-4 h-4" />
            <span>Khóa Khu vực GV (Chuyển sang HS)</span>
          </button>
        </div>
      </div>

      {showChangePinBox && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const cleanPin = newCustomPin.trim();
            if (cleanPin.length < 3) {
              showNotice('⚠️ Mật khẩu mới phải có ít nhất 3 ký tự!');
              return;
            }
            if (cleanPin !== confirmCustomPin.trim()) {
              showNotice('⚠️ Mật khẩu xác nhận chưa trùng khớp!');
              return;
            }
            localStorage.setItem('khtn7_teacher_secret_pin_v2', cleanPin);
            setNewCustomPin('');
            setConfirmCustomPin('');
            setShowChangePinBox(false);
            showNotice('🔐 Đã lưu mật khẩu bảo mật riêng của Giáo viên! Mật khẩu này được ẩn hoàn toàn trên giao diện.');
          }}
          className="bg-amber-50/90 border-2 border-amber-300 rounded-3xl p-5 flex flex-col md:flex-row md:items-end gap-3 shadow-xs"
        >
          <div className="flex-1">
            <label className="block text-xs font-black uppercase text-amber-950 mb-1">
              Thiết lập Mật khẩu riêng của Giáo viên (Chỉ giáo viên tự nhớ, không hiển thị gợi ý trên màn hình)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <input
                type="password"
                value={newCustomPin}
                onChange={(e) => setNewCustomPin(e.target.value)}
                placeholder="Nhập mật khẩu mới của Giáo viên..."
                className="px-3.5 py-2.5 rounded-xl border border-amber-300 bg-white text-sm font-bold text-slate-900 focus:outline-none focus:border-amber-600"
              />
              <input
                type="password"
                value={confirmCustomPin}
                onChange={(e) => setConfirmCustomPin(e.target.value)}
                placeholder="Nhập lại mật khẩu mới để xác nhận..."
                className="px-3.5 py-2.5 rounded-xl border border-amber-300 bg-white text-sm font-bold text-slate-900 focus:outline-none focus:border-amber-600"
              />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="submit"
              className="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-black text-xs sm:text-sm shadow cursor-pointer"
            >
              Lưu Mật khẩu Mới
            </button>
            <button
              type="button"
              onClick={() => setShowChangePinBox(false)}
              className="px-3.5 py-2.5 rounded-xl bg-white border border-slate-300 text-slate-700 font-bold text-xs sm:text-sm cursor-pointer"
            >
              Đóng
            </button>
          </div>
        </form>
      )}

      {statusNotice && (
        <div className="p-4 rounded-2xl bg-emerald-50 border-2 border-emerald-400 text-emerald-950 text-xs sm:text-sm font-extrabold flex items-center gap-2 shadow-sm">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{statusNotice}</span>
        </div>
      )}

      {/* ================= SECTION 1: UPLOAD XLSX STUDENT ROSTER + SAVE & SYNC BUTTONS ================= */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        <div className="xl:col-span-7 bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <span className="text-[11px] font-black uppercase tracking-wider text-blue-600">
                QUẢN LÝ DANH SÁCH LỚP BẰNG EXCEL (.XLSX)
              </span>
              <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
                <span>Tải Danh sách Học sinh lên (.XLSX / .CSV) · Lưu & Đồng bộ</span>
              </h3>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleDownloadSampleXlsx}
                className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold text-xs flex items-center gap-1.5 transition cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Tải mẫu .XLSX</span>
              </button>
              <button
                type="button"
                onClick={() => handleExportRosterToXlsx(false)}
                className="px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-extrabold text-xs flex items-center gap-1.5 transition cursor-pointer"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>Xuất DS ra .XLSX</span>
              </button>
            </div>
          </div>

          {/* Excel (.xlsx) Upload Box */}
          <div className="p-4 rounded-2xl border-2 border-dashed border-blue-400 bg-blue-50/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-0.5">
              <div className="text-xs sm:text-sm font-black text-blue-950">
                Chọn file Excel danh sách học sinh (.xlsx, .xls, .csv) từ máy tính
              </div>
              <div className="text-xs text-blue-800">
                Hỗ trợ file Excel có cột <code>Họ và Tên</code> hoặc <code>STT, Mã HS, Họ và Tên, Lớp</code>
              </div>
            </div>

            <input
              ref={excelFileInputRef}
              type="file"
              accept=".xlsx,.xls,.csv,.txt"
              onChange={handleExcelOrCsvUpload}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => excelFileInputRef.current?.click()}
              className="px-4 py-2.5 rounded-xl bg-[#1d6bf3] hover:bg-[#1557c7] text-white font-black text-xs sm:text-sm flex items-center gap-2 shrink-0 shadow cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>Tải File .XLSX Lên</span>
            </button>
          </div>

          {/* Pending Excel Preview Banner */}
          {pendingExcelEntries && pendingExcelEntries.length > 0 && (
            <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-400 space-y-2.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="text-xs sm:text-sm font-black text-amber-950">
                  📊 Đã tải lên {pendingExcelEntries.length} học sinh từ file &ldquo;{pendingExcelFileName}&rdquo; (Chờ lưu):
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setPendingExcelEntries(null);
                    setPendingExcelFileName('');
                  }}
                  className="text-xs font-bold text-rose-600 hover:underline cursor-pointer"
                >
                  Hủy file này
                </button>
              </div>
              <div className="max-h-28 overflow-y-auto text-xs text-slate-700 bg-white p-2.5 rounded-xl border border-amber-200 grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                {pendingExcelEntries.map((item, idx) => (
                  <div key={idx} className="font-bold truncate">
                    {idx + 1}. {item.fullName} ({item.className})
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quick Paste from Excel */}
          <div className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5">
                <ClipboardPaste className="w-4 h-4 text-teal-600" />
                <span>Hoặc dán trực tiếp cột Họ và Tên học sinh từ Excel:</span>
              </label>

              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-600">Lớp mặc định:</span>
                <input
                  type="text"
                  value={bulkClassDefault}
                  onChange={(e) => setBulkClassDefault(e.target.value)}
                  className="w-24 px-2.5 py-1 rounded-lg border border-slate-300 text-xs font-bold"
                />
              </div>
            </div>

            <textarea
              rows={3}
              value={bulkText}
              onChange={(e) => setBulkText(e.target.value)}
              placeholder={`Ví dụ:\nNGUYỄN VĂN AN\nTRẦN THỊ BÍCH NGỌC\nLÊ MINH KHANG, Lớp 7A2`}
              className="w-full p-3 rounded-2xl border border-slate-300 text-xs sm:text-sm font-medium focus:outline-none focus:border-blue-600"
            />
          </div>

          {/* Save Roster & Sync Roster Action Bar */}
          <div className="pt-2 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <label className="inline-flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={replaceExistingOnImport}
                onChange={(e) => setReplaceExistingOnImport(e.target.checked)}
                className="rounded text-blue-600 w-4 h-4"
              />
              <span>Thay thế danh sách cũ bằng danh sách mới tải lên</span>
            </label>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={handleSaveUploadedRoster}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm flex items-center gap-1.5 shadow transition cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>💾 Lưu danh sách học sinh</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  handleSaveUploadedRoster();
                  handleExportRosterToXlsx(false);
                }}
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs sm:text-sm flex items-center gap-1.5 shadow transition cursor-pointer"
              >
                <RefreshCw className="w-4 h-4" />
                <span>🔄 Lưu & Xuất đồng bộ (.XLSX)</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right 5 Cols: Add Single Student & Quick Status */}
        <div className="xl:col-span-5 bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col justify-between space-y-5">
          <form onSubmit={handleSubmitNewStudent} className="space-y-4">
            <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-emerald-600" />
              <span>Thêm lẻ 1 Học sinh vào Danh sách Lớp</span>
            </h3>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-extrabold text-slate-700 mb-1">
                  Họ và Tên học sinh (học sinh nhập đúng tên này để vào Phòng thi):
                </label>
                <input
                  type="text"
                  value={newFullName}
                  onChange={(e) => setNewFullName(e.target.value)}
                  placeholder="VD: NGUYỄN HOÀNG NAM..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm font-bold focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-extrabold text-slate-700 mb-1">
                  Lớp học (Chọn nhanh 7A1, 7A2, 7A3, 7A4... hoặc tự nhập):
                </label>
                <div className="flex items-center gap-2">
                  <select
                    value={uniqueClasses.includes(normalizeClassName(newClassName)) ? normalizeClassName(newClassName) : 'custom'}
                    onChange={(e) => {
                      if (e.target.value !== 'custom') {
                        setNewClassName(e.target.value);
                      }
                    }}
                    className="px-3 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-xs sm:text-sm font-extrabold text-slate-800 focus:outline-none focus:border-emerald-600 cursor-pointer"
                  >
                    {uniqueClasses.map((cls) => (
                      <option key={cls} value={cls}>
                        {getShortClassCode(cls)} ({cls})
                      </option>
                    ))}
                    <option value="custom">Lớp khác...</option>
                  </select>
                  <input
                    type="text"
                    list="khtn7-class-datalist"
                    value={newClassName}
                    onChange={(e) => setNewClassName(e.target.value)}
                    placeholder="VD: Lớp 7A1"
                    className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm font-bold focus:outline-none focus:border-emerald-600"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs sm:text-sm shadow transition cursor-pointer"
              >
                + Thêm Học sinh & Lưu vào Lớp
              </button>
            </div>
          </form>

          {currentStudent && (
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-slate-500 uppercase">
                  HỌC SINH ĐANG CHỌN KIỂM TRA
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[11px] font-black">
                  {currentStudent.code}
                </span>
              </div>
              <div className="text-base font-black text-slate-900">
                {currentStudent.fullName} ({currentStudent.className})
              </div>
              <button
                type="button"
                onClick={() => {
                  onResetCurrentStudentProgress();
                  showNotice(`Đã đặt lại dữ liệu bài làm thử của ${currentStudent.fullName}!`);
                }}
                className="text-xs font-extrabold text-rose-600 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Đặt lại bài làm hiện tại trên máy này</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ================= SECTION 2: UPLOAD & SAVE WORD EXAMS / DOCUMENTS (.DOCX / .DOC) ================= */}
      <div className="bg-white rounded-3xl border-2 border-indigo-200 p-5 sm:p-6 shadow-xs space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-200 pb-4">
          <div>
            <span className="text-[11px] font-black uppercase tracking-wider text-indigo-600">
              QUẢN LÝ ĐỀ KIỂM TRA & TÀI LIỆU WORD (.DOCX / .DOC)
            </span>
            <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
              <FileText className="w-5 h-5 text-indigo-600" />
              <span>Tải Tài liệu, Đề Kiểm Tra lên dưới dạng Word (.DOCX / .DOC) & Lưu Đề</span>
            </h3>
            <p className="text-xs text-slate-600">
              Giáo viên tải file đề kiểm tra hoặc tài liệu ôn tập (.docx, .doc) lên và bấm <strong>&ldquo;💾 Lưu Đề&rdquo;</strong> để lưu vào hệ thống cho học sinh ôn luyện.
            </p>
          </div>

          <input
            ref={wordFileInputRef}
            type="file"
            accept=".docx,.doc"
            onChange={handleWordFileUpload}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => wordFileInputRef.current?.click()}
            className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs sm:text-sm flex items-center gap-2 shrink-0 shadow cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            <span>Chọn File Đề / Tài liệu Word (.docx, .doc)</span>
          </button>
        </div>

        <form onSubmit={handleSaveWordExamOrMaterial} className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-end">
          <div className="lg:col-span-5">
            <label className="block text-xs font-extrabold text-slate-700 mb-1">
              Tên Đề kiểm tra / Tài liệu Word:
            </label>
            <input
              type="text"
              value={wordTitle}
              onChange={(e) => setWordTitle(e.target.value)}
              placeholder="VD: Đề kiểm tra Giữa kì I KHTN 7 - Đề số 2..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm font-bold focus:outline-none focus:border-indigo-600"
            />
          </div>

          <div className="lg:col-span-2">
            <label className="block text-xs font-extrabold text-slate-700 mb-1">
              Loại học liệu:
            </label>
            <select
              value={wordDocType}
              onChange={(e) =>
                setWordDocType(e.target.value as 'exam' | 'worksheet' | 'material')
              }
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm font-bold bg-white cursor-pointer"
            >
              <option value="exam">Đề kiểm tra</option>
              <option value="worksheet">Phiếu bài tập</option>
              <option value="material">Tài liệu chuyên đề</option>
            </select>
          </div>

          <div className="lg:col-span-2">
            <label className="block text-xs font-extrabold text-slate-700 mb-1">
              Phân môn:
            </label>
            <select
              value={wordSubject}
              onChange={(e) =>
                setWordSubject(
                  e.target.value as
                    | 'Liên môn KHTN 7'
                    | 'Hóa học 7'
                    | 'Vật lí 7'
                    | 'Sinh học 7'
                )
              }
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm font-bold bg-white cursor-pointer"
            >
              <option value="Liên môn KHTN 7">Liên môn KHTN 7</option>
              <option value="Hóa học 7">Hóa học 7</option>
              <option value="Vật lí 7">Vật lí 7</option>
              <option value="Sinh học 7">Sinh học 7</option>
            </select>
          </div>

          <div className="lg:col-span-1">
            <label className="block text-xs font-extrabold text-slate-700 mb-1">
              Tuần:
            </label>
            <input
              type="number"
              min={1}
              max={35}
              value={wordWeek}
              onChange={(e) => setWordWeek(Number(e.target.value) || 1)}
              className="w-full px-2.5 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm font-bold text-center"
            />
          </div>

          <div className="lg:col-span-2">
            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow transition cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>💾 Lưu Đề Word</span>
            </button>
          </div>
        </form>

        {uploadedWordFileName && (
          <div className="p-3.5 rounded-2xl bg-indigo-50 border border-indigo-200 flex items-center justify-between gap-3 text-xs font-bold text-indigo-950">
            <span>
              📎 File Word đã chọn: <strong>{uploadedWordFileName}</strong> — Hãy bấm nút{' '}
              <strong className="text-emerald-700">&ldquo;💾 Lưu Đề Word&rdquo;</strong> để lưu cố định vào kho đề!
            </span>
          </div>
        )}

        {/* List of Saved Word Exams / Materials */}
        <div className="space-y-2.5 pt-2">
          <div className="text-xs font-black uppercase tracking-wider text-slate-500">
            DANH SÁCH ĐỀ & TÀI LIỆU WORD ĐÃ LƯU ({savedWordDocs.length} ĐỀ):
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {savedWordDocs.map((doc) => (
              <div
                key={doc.id}
                className="p-4 rounded-2xl border border-slate-200 bg-slate-50/70 hover:bg-white flex items-center justify-between gap-3 transition"
              >
                <div className="min-w-0 space-y-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 text-[10px] font-black uppercase">
                      {doc.docType === 'exam'
                        ? 'Đề kiểm tra'
                        : doc.docType === 'worksheet'
                        ? 'Phiếu bài tập'
                        : 'Tài liệu Word'}
                    </span>
                    <span className="text-[11px] font-bold text-teal-700">
                      {doc.subjectLabel} · Tuần {doc.weekNumber}
                    </span>
                    <span className="text-[10px] text-slate-400">{doc.createdAt}</span>
                  </div>
                  <div className="text-sm font-black text-slate-900 truncate">{doc.title}</div>
                  <div className="text-[11px] text-slate-500 truncate">
                    File: {doc.fileName}
                    {doc.parsedMcqs && doc.parsedMcqs.length > 0
                      ? ` · Đã tách ${doc.parsedMcqs.length} câu TN`
                      : ''}
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => setPreviewingWordDoc(doc)}
                    className="px-2.5 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 font-extrabold text-xs flex items-center gap-1 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Xem đề</span>
                  </button>
                  {doc.fileDataUrl && (
                    <a
                      href={doc.fileDataUrl}
                      download={doc.fileName}
                      className="px-2.5 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-extrabold text-xs flex items-center gap-1"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Tải về</span>
                    </a>
                  )}
                  <button
                    type="button"
                    onClick={() => onDeleteWordDoc(doc.id)}
                    className="p-1.5 rounded-xl text-rose-500 hover:bg-rose-50 cursor-pointer"
                    title="Xóa đề Word này"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Shared datalist for class names across inputs */}
      <datalist id="khtn7-class-datalist">
        {uniqueClasses.map((cls) => (
          <option key={cls} value={cls} />
        ))}
      </datalist>

      {/* ================= STUDENT ROSTER MANAGEMENT TABLE ================= */}
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-3">
          <div>
            <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
              <Users className="w-5 h-5 text-teal-600" />
              <span>
                Danh sách Học sinh theo Lớp ({filteredStudents.length}/{students.length} học sinh)
              </span>
              {!isAllClassesSelected(classFilter) && (
                <span className="px-2.5 py-0.5 rounded-full bg-teal-100 text-teal-900 text-xs font-black border border-teal-300">
                  Đang lọc: {normalizeClassName(classFilter)}
                </span>
              )}
            </h3>
            <p className="text-xs text-slate-500">
              Chọn <strong>Bộ lọc Lớp học (Tất cả, 7A1, 7A2, 7A3, 7A4...)</strong> bên dưới để lọc danh sách theo lớp. Bấm <strong>&ldquo;✏️ Sửa tên&rdquo;</strong> để sửa tên/lớp nhập sai, hoặc <strong>&ldquo;+ Thêm HS&rdquo;</strong> / <strong>&ldquo;Xóa&rdquo;</strong> khi có học sinh chuyển lớp.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Prominent Class Dropdown Filter */}
            <div className="flex items-center gap-1.5 bg-teal-50/90 border-2 border-teal-500 rounded-xl px-2.5 py-1 shadow-2xs">
              <Users className="w-4 h-4 text-teal-700 shrink-0" />
              <label
                htmlFor="teacher-class-dropdown-filter"
                className="text-[11px] font-black uppercase text-teal-900 whitespace-nowrap"
              >
                Lọc theo lớp:
              </label>
              <select
                id="teacher-class-dropdown-filter"
                value={classFilter}
                onChange={(e) => handleSelectClassFilter(e.target.value)}
                className="pr-2 py-0.5 rounded-lg bg-transparent text-xs sm:text-sm font-black text-teal-950 focus:outline-none cursor-pointer"
              >
                <option value="Tất cả">Tất cả ({students.length} HS)</option>
                {uniqueClasses.map((cls) => {
                  const count = getClassCount(cls);
                  const shortCode = getShortClassCode(cls);
                  return (
                    <option key={cls} value={shortCode}>
                      {shortCode} — {cls} ({count} HS)
                    </option>
                  );
                })}
              </select>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Tìm tên, mã HS, lớp..."
                className="pl-9 pr-3 py-1.5 rounded-xl border border-slate-300 text-xs font-bold focus:outline-none focus:border-teal-600"
              />
            </div>

            <button
              type="button"
              onClick={() => setShowTableQuickAdd((prev) => !prev)}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>{showTableQuickAdd ? 'Đóng khung thêm' : '+ Thêm Học sinh'}</span>
            </button>

            {!isAllClassesSelected(classFilter) && (
              <button
                type="button"
                onClick={() => handleExportRosterToXlsx(true)}
                className="px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-300 text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer"
                title={`Xuất danh sách riêng của ${normalizeClassName(classFilter)} ra file Excel`}
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>Xuất .XLSX ({getShortClassCode(classFilter)})</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => {
                onSaveAndSyncRoster();
                showNotice(
                  `🔄 Đã cập nhật & đồng bộ danh sách ${students.length} học sinh sang khu vực Học sinh, Phụ huynh và Nhắc nhở BTVN!`
                );
              }}
              className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Cập nhật & Đồng bộ</span>
            </button>
          </div>
        </div>

        {/* Multi-Class Quick Filter Bar & Selected Class Summary Strip */}
        <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/90 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] font-black uppercase text-slate-500 mr-1">
              Chọn nhanh lớp:
            </span>
            <button
              type="button"
              onClick={() => handleSelectClassFilter('Tất cả')}
              className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${
                isAllClassesSelected(classFilter)
                  ? 'bg-teal-700 text-white shadow-xs'
                  : 'bg-white hover:bg-teal-50 text-slate-700 border border-slate-200'
              }`}
            >
              <span>Tất cả</span>
              <span
                className={`px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                  isAllClassesSelected(classFilter)
                    ? 'bg-teal-900/60 text-emerald-200'
                    : 'bg-slate-100 text-slate-600'
                }`}
              >
                {students.length}
              </span>
            </button>

            {uniqueClasses.map((cls) => {
              const count = getClassCount(cls);
              const shortCode = getShortClassCode(cls);
              const isSelectedClass =
                !isAllClassesSelected(classFilter) &&
                normalizeClassName(classFilter) === normalizeClassName(cls);
              return (
                <button
                  key={cls}
                  type="button"
                  onClick={() => handleSelectClassFilter(shortCode)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${
                    isSelectedClass
                      ? 'bg-teal-600 text-white shadow-xs'
                      : 'bg-white hover:bg-teal-50 text-slate-700 border border-slate-200'
                  }`}
                >
                  <span>{shortCode}</span>
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                      isSelectedClass
                        ? 'bg-teal-900/50 text-white'
                        : count > 0
                        ? 'bg-teal-50 text-teal-800'
                        : 'bg-slate-100 text-slate-400'
                    }`}
                  >
                    {count} HS
                  </span>
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center gap-3 text-xs">
            <div className="px-2.5 py-1 rounded-xl bg-white border border-slate-200 font-bold text-slate-700">
              Sĩ số đang xem:{' '}
              <strong className="text-slate-950 font-black">{filteredStudents.length} HS</strong>
            </div>
            <div className="px-2.5 py-1 rounded-xl bg-white border border-slate-200 font-bold text-slate-700">
              Điểm TB lớp:{' '}
              <strong className="text-indigo-600 font-black">
                {filteredClassAvg.toFixed(2)}
              </strong>
            </div>
            <div className="px-2.5 py-1 rounded-xl bg-emerald-50 border border-emerald-200 font-bold text-emerald-800">
              Khá/Giỏi: <strong>{filteredGoodOrExcellentCount} HS</strong>
            </div>
            {filteredWarningCount > 0 && (
              <div className="px-2.5 py-1 rounded-xl bg-rose-50 border border-rose-200 font-bold text-rose-700 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Cần hỗ trợ: <strong>{filteredWarningCount} HS</strong></span>
              </div>
            )}
          </div>
        </div>

        {/* Quick Inline Add Student Bar inside Roster Table */}
        {showTableQuickAdd && (
          <form
            onSubmit={handleQuickAddInTable}
            className="p-4 rounded-2xl bg-emerald-50/90 border border-emerald-300 flex flex-col sm:flex-row sm:items-end gap-3"
          >
            <div className="flex-1">
              <label className="block text-[11px] font-black uppercase text-emerald-950 mb-1">
                Họ và Tên Học sinh mới (hoặc chuyển đến):
              </label>
              <input
                type="text"
                value={quickAddName}
                onChange={(e) => setQuickAddName(e.target.value)}
                placeholder="Nhập đúng Họ và Tên học sinh (VD: NGUYỄN THỊ MAI ANH)..."
                className="w-full px-3.5 py-2 rounded-xl border border-emerald-400 bg-white text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-700"
              />
            </div>
            <div className="w-full sm:w-52">
              <label className="block text-[11px] font-black uppercase text-emerald-950 mb-1">
                Lớp (Chọn 7A1, 7A2... hoặc nhập):
              </label>
              <div className="flex items-center gap-1.5">
                <select
                  value={
                    uniqueClasses.includes(normalizeClassName(quickAddClass))
                      ? normalizeClassName(quickAddClass)
                      : 'custom'
                  }
                  onChange={(e) => {
                    if (e.target.value !== 'custom') {
                      setQuickAddClass(e.target.value);
                    }
                  }}
                  className="px-2.5 py-2 rounded-xl border border-emerald-400 bg-white text-xs font-extrabold text-slate-900 focus:outline-none cursor-pointer"
                >
                  {uniqueClasses.map((cls) => (
                    <option key={cls} value={cls}>
                      {getShortClassCode(cls)}
                    </option>
                  ))}
                  <option value="custom">Khác</option>
                </select>
                <input
                  type="text"
                  list="khtn7-class-datalist"
                  value={quickAddClass}
                  onChange={(e) => setQuickAddClass(e.target.value)}
                  placeholder="Lớp 7A1"
                  className="w-full px-3 py-2 rounded-xl border border-emerald-400 bg-white text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-700"
                />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-black shadow-xs cursor-pointer"
              >
                + Lưu thêm vào danh sách
              </button>
              <button
                type="button"
                onClick={() => setShowTableQuickAdd(false)}
                className="px-3 py-2 rounded-xl bg-white border border-slate-300 text-slate-700 text-xs font-bold cursor-pointer"
              >
                Hủy
              </button>
            </div>
          </form>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-[11px] font-black uppercase text-slate-500 bg-slate-50">
                <th className="py-3 px-3">Mã HS</th>
                <th className="py-3 px-3">Họ và Tên Học sinh</th>
                <th className="py-3 px-3">Lớp</th>
                <th className="py-3 px-3">ĐTB & Đánh giá</th>
                <th className="py-3 px-3">Điểm rèn luyện</th>
                <th className="py-3 px-3 text-right">Thao tác quản lý (Sửa tên / Hồ sơ / Xóa)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/80 text-xs sm:text-sm">
              {filteredStudents.map((st) => {
                const isSelected = currentStudent?.id === st.id;
                const isEditingRow = editingStudentId === st.id;
                const metrics = calculateStudentGradeMetrics(st);

                return (
                  <tr
                    key={st.id}
                    className={`hover:bg-slate-50 transition ${
                      isEditingRow
                        ? 'bg-blue-50/70'
                        : isSelected
                        ? 'bg-emerald-50/50'
                        : ''
                    }`}
                  >
                    <td className="py-3 px-3 font-mono font-bold text-slate-600">
                      {isEditingRow ? (
                        <input
                          type="text"
                          value={editStudentCode}
                          onChange={(e) => setEditStudentCode(e.target.value)}
                          className="w-24 px-2 py-1.5 rounded-lg border-2 border-blue-400 bg-white text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-blue-600"
                          placeholder="Mã HS"
                        />
                      ) : (
                        st.code
                      )}
                    </td>
                    <td className="py-3 px-3">
                      {isEditingRow ? (
                        <div className="flex flex-col gap-1">
                          <input
                            type="text"
                            value={editStudentName}
                            onChange={(e) => setEditStudentName(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                handleSaveEditedStudent(st);
                              } else if (e.key === 'Escape') {
                                setEditingStudentId(null);
                              }
                            }}
                            autoFocus
                            className="w-full min-w-[210px] px-3 py-1.5 rounded-xl border-2 border-blue-500 bg-white text-xs sm:text-sm font-black text-slate-900 focus:outline-none"
                            placeholder="Nhập đúng Họ và Tên học sinh..."
                          />
                          <span className="text-[10px] font-bold text-blue-700">
                            Nhập tên chính xác rồi bấm &ldquo;Cập nhật&rdquo; (hoặc phím Enter)
                          </span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setInspectingStudent(st)}
                            className="font-black text-slate-900 hover:text-indigo-600 flex items-center gap-2 text-left cursor-pointer"
                          >
                            <span>{st.fullName}</span>
                            {metrics.needsWarning && (
                              <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 text-[10px] font-extrabold flex items-center gap-1">
                                <AlertTriangle className="w-3 h-3" />
                                Cần hỗ trợ
                              </span>
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleStartEditStudent(st)}
                            title="Sửa lại tên học sinh bị nhập sai"
                            className="p-1 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-3 font-bold text-slate-700">
                      {isEditingRow ? (
                        <input
                          type="text"
                          value={editStudentClass}
                          onChange={(e) => setEditStudentClass(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleSaveEditedStudent(st);
                            }
                          }}
                          className="w-28 px-2.5 py-1.5 rounded-xl border-2 border-blue-400 bg-white text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-600"
                          placeholder="Lớp 7A1"
                        />
                      ) : (
                        st.className
                      )}
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`font-black ${
                          metrics.needsWarning ? 'text-rose-600' : 'text-indigo-600'
                        }`}
                      >
                        {metrics.average.toFixed(2)} ({metrics.rankLabel})
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-xs font-extrabold">
                        +{st.commendationPoints || 10} đ
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      {isEditingRow ? (
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleSaveEditedStudent(st)}
                            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs inline-flex items-center gap-1 shadow-xs transition cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Cập nhật</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingStudentId(null)}
                            className="px-2.5 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-extrabold text-xs inline-flex items-center gap-1 transition cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>Hủy</span>
                          </button>
                        </div>
                      ) : (
                        <div className="inline-flex flex-wrap items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleStartEditStudent(st)}
                            className="px-2.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-500 text-amber-900 hover:text-white border border-amber-200 font-extrabold text-xs inline-flex items-center gap-1 transition cursor-pointer"
                            title="Sửa lại Họ tên hoặc Lớp của học sinh"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Sửa tên</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setInspectingStudent(st)}
                            className="px-2.5 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-600 text-indigo-700 hover:text-white font-extrabold text-xs inline-flex items-center gap-1 transition cursor-pointer"
                          >
                            <BarChart3 className="w-3.5 h-3.5" />
                            <span>Hồ sơ & Nhận xét</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => onSelectStudent(st)}
                            className={`px-2.5 py-1.5 rounded-xl font-extrabold text-xs transition cursor-pointer ${
                              isSelected
                                ? 'bg-emerald-600 text-white'
                                : 'bg-slate-100 hover:bg-teal-600 hover:text-white text-slate-700'
                            }`}
                          >
                            {isSelected ? 'Đang chọn' : 'Chọn HS'}
                          </button>

                          {students.length > 1 && (
                            <button
                              type="button"
                              onClick={() => handleRemoveStudentWithNotice(st)}
                              className="px-2 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-600 text-rose-600 hover:text-white border border-rose-200 font-extrabold text-xs inline-flex items-center gap-1 transition cursor-pointer"
                              title="Xóa học sinh khỏi danh sách lớp (khi học sinh chuyển đi)"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Xóa</span>
                            </button>
                          )}
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
              {filteredStudents.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-8 px-4 text-center text-slate-500">
                    <div className="space-y-2">
                      <p className="text-sm font-bold text-slate-700">
                        Chưa có học sinh nào trong lớp{' '}
                        <span className="text-teal-700 font-black">
                          {isAllClassesSelected(classFilter)
                            ? 'Tất cả'
                            : normalizeClassName(classFilter)}
                        </span>
                        {searchQuery.trim() ? ` khớp với từ khóa "${searchQuery}"` : ''}.
                      </p>
                      <div className="flex items-center justify-center gap-2">
                        {!isAllClassesSelected(classFilter) && (
                          <button
                            type="button"
                            onClick={() => handleSelectClassFilter('Tất cả')}
                            className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-extrabold cursor-pointer"
                          >
                            Hiển thị Tất cả các lớp
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setShowTableQuickAdd(true)}
                          className="px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 text-xs font-extrabold cursor-pointer"
                        >
                          + Thêm học sinh vào {isAllClassesSelected(classFilter) ? 'lớp' : normalizeClassName(classFilter)}
                        </button>
                      </div>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ================= PREVIEW SAVED WORD EXAM MODAL ================= */}
      {previewingWordDoc && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[85vh] overflow-y-auto p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div>
                <span className="text-xs font-black uppercase text-indigo-600">
                  {previewingWordDoc.subjectLabel} · Tuần {previewingWordDoc.weekNumber}
                </span>
                <h3 className="text-lg font-black text-slate-900">{previewingWordDoc.title}</h3>
              </div>
              <button
                type="button"
                onClick={() => setPreviewingWordDoc(null)}
                className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-xs font-extrabold text-slate-700 cursor-pointer"
              >
                Đóng
              </button>
            </div>
            <div
              className="prose prose-sm max-w-none p-4 rounded-2xl bg-slate-50 border border-slate-200 text-slate-800"
              dangerouslySetInnerHTML={{ __html: previewingWordDoc.htmlPreview }}
            />
          </div>
        </div>
      )}

      {/* ================= 4-TAB STUDENT PROFILE MODAL ================= */}
      {inspectingStudent && (
        <StudentProfileModal
          student={inspectingStudent}
          isCurrentActiveStudent={currentStudent?.id === inspectingStudent.id}
          userRole={userRole}
          activeWeek={activeWeek}
          onClose={() => setInspectingStudent(null)}
          onUpdateStudent={(updated) => {
            onUpdateStudent(updated);
            setInspectingStudent(updated);
          }}
        />
      )}
    </div>
  );
};
