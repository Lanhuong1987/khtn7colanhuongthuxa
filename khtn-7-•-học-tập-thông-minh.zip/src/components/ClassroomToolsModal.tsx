import React, { useState, useMemo } from 'react';
import {
  X,
  Sparkles,
  Trophy,
  Users,
  Award,
  CheckCircle2,
  RotateCcw,
  Sun,
  Droplets,
  Leaf,
  Flame,
  Zap,
  Atom,
  Volume2,
  Eye,
  EyeOff,
  Plus,
} from 'lucide-react';
import {
  StudentProfile,
  WeeklyAssignment,
  calculateStudentGradeMetrics,
  CommendationRecord,
} from '../data/classStore';
import { ALL_KNTT_LESSONS } from '../data/allLessons';
import { soundEngine } from '../utils/gameSoundEngine';
import {
  TenFootUiControls,
  TenFootFontScale,
  loadTenFootFontScale,
  saveTenFootFontScale,
} from './GamesView';

interface ClassroomToolsModalProps {
  students: StudentProfile[];
  currentStudent: StudentProfile;
  activeWeek: number;
  activeWeekAssignment: WeeklyAssignment;
  initialTab?: 'picker' | 'leaderboard' | 'tree';
  onClose: () => void;
  onUpdateStudent: (updated: StudentProfile) => void;
}

export const ClassroomToolsModal: React.FC<ClassroomToolsModalProps> = ({
  students,
  currentStudent,
  activeWeek,
  activeWeekAssignment,
  initialTab = 'picker',
  onClose,
  onUpdateStudent,
}) => {
  const [activeTab, setActiveTab] = useState<'picker' | 'leaderboard' | 'tree'>(initialTab);
  const [fontScale, setFontScale] = useState<TenFootFontScale>(() => loadTenFootFontScale());
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  const handleUpdateFontScale = (scale: TenFootFontScale) => {
    setFontScale(scale);
    saveTenFootFontScale(scale);
  };

  const handleToggleFullscreen = async () => {
    const next = !isFullscreen;
    setIsFullscreen(next);
    try {
      if (next && document.documentElement.requestFullscreen) {
        await document.documentElement.requestFullscreen();
      } else if (!next && document.fullscreenElement && document.exitFullscreen) {
        await document.exitFullscreen();
      }
    } catch {
      // Fallback CSS fullscreen overlay handles restricted environments
    }
  };

  // --- TAB 1: RANDOM STUDENT PICKER STATE ---
  const [spinning, setSpinning] = useState(false);
  const [avoidRepeat, setAvoidRepeat] = useState(true);
  const [calledIds, setCalledIds] = useState<string[]>([]);
  const [highlightedStudent, setHighlightedStudent] = useState<StudentProfile | null>(null);
  const [pickedStudent, setPickedStudent] = useState<StudentProfile | null>(null);
  const [oralQuestionIdx, setOralQuestionIdx] = useState(0);
  const [showOralAnswer, setShowOralAnswer] = useState(false);
  const [rewardFeedback, setRewardFeedback] = useState<string | null>(null);

  // --- TAB 3: VIRTUAL SCIENCE TREE STATE ---
  const [treeWaterCount, setTreeWaterCount] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('khtn7_tree_xp_v1')) || 45;
    } catch {
      return 45;
    }
  });

  // Questions from active week's assigned lessons for Oral Quiz
  const weekQuestions = useMemo(() => {
    const lessons = ALL_KNTT_LESSONS.filter((l) =>
      activeWeekAssignment.lessonIds.includes(l.id)
    );
    const pool = lessons.flatMap((l) => l.mcqs);
    return pool.length > 0 ? pool : ALL_KNTT_LESSONS[0].mcqs;
  }, [activeWeekAssignment]);

  const currentOralQ = weekQuestions[oralQuestionIdx % weekQuestions.length];

  const handleSpinStudentPicker = () => {
    if (spinning) return;
    const eligible = avoidRepeat
      ? students.filter((s) => !calledIds.includes(s.id))
      : students;
    const pool = eligible.length > 0 ? eligible : students;

    setSpinning(true);
    setPickedStudent(null);
    setShowOralAnswer(false);
    setRewardFeedback(null);

    let step = 0;
    const totalSteps = 18;
    const interval = setInterval(() => {
      soundEngine.playWheelTick();
      const randomCandidate = pool[Math.floor(Math.random() * pool.length)];
      setHighlightedStudent(randomCandidate);
      step++;
      if (step >= totalSteps) {
        clearInterval(interval);
        const winner = pool[Math.floor(Math.random() * pool.length)];
        setHighlightedStudent(winner);
        setPickedStudent(winner);
        setCalledIds((prev) => [...new Set([...prev, winner.id])]);
        setOralQuestionIdx((prev) => prev + 1);
        setSpinning(false);
        soundEngine.playVictory();
      }
    }, 95);
  };

  const handleRewardPickedStudent = (pts: number, reason: string) => {
    if (!pickedStudent) return;
    soundEngine.playCorrect();
    const rec: CommendationRecord = {
      id: `cm-${Date.now()}`,
      reason: `Kiểm tra miệng Tuần ${activeWeek}: ${reason}`,
      points: pts,
      weekNumber: activeWeek,
      createdAt: new Date().toLocaleDateString('vi-VN'),
    };
    const updated: StudentProfile = {
      ...pickedStudent,
      commendationPoints: Math.max(0, (pickedStudent.commendationPoints || 10) + pts),
      commendationHistory: [rec, ...(pickedStudent.commendationHistory || [])],
    };
    onUpdateStudent(updated);
    setPickedStudent(updated);
    setRewardFeedback(
      `🎉 Đã cộng +${pts} điểm tuyên dương cho ${updated.fullName} (Tổng: +${updated.commendationPoints} đ)!`
    );
  };

  // --- TAB 2: LEADERBOARD RANKING ---
  const rankedStudents = useMemo(() => {
    return [...students]
      .map((st) => {
        const metrics = calculateStudentGradeMetrics(st);
        const totalPoints = Math.round(
          metrics.average * 100 +
            (st.commendationPoints || 10) * 8 +
            st.baselineGameScore * 0.5 +
            st.baselineWeeksCompleted.length * 40
        );
        return {
          student: st,
          metrics,
          totalPoints,
        };
      })
      .sort((a, b) => b.totalPoints - a.totalPoints);
  }, [students]);

  // --- TAB 3: SCIENCE TREE & BADGES ---
  const treeStage =
    treeWaterCount >= 100
      ? {
          name: 'Cấp 4: Đại Thụ Khoa Học Ra Hoa Kết Trái 🍎🌳',
          emoji: '🌳🍎✨',
          desc: 'Quang hợp cực đại! Cây Tri Thức của em đã đơm hoa kết trái rực rỡ!',
        }
      : treeWaterCount >= 65
      ? {
          name: 'Cấp 3: Cây Trưởng Thành Xanh Tốt 🌳',
          emoji: '🌳☀️',
          desc: 'Hệ mạch gỗ và mạch rây vận chuyển nước – chất dinh dưỡng rất mạnh mẽ!',
        }
      : treeWaterCount >= 30
      ? {
          name: 'Cấp 2: Cây Non Quang Hợp 🌿',
          emoji: '🌿💧',
          desc: 'Lá non đang hấp thụ CO₂ và ánh sáng để tổng hợp chất hữu cơ!',
        }
      : {
          name: 'Cấp 1: Hạt Mầm Tri Thức 🌱',
          emoji: '🌱',
          desc: 'Hãy tưới nước và chiếu sáng bằng cách hoàn thành bài tập mỗi tuần!',
        };

  const handleNurtureTree = (delta: number) => {
    soundEngine.playGoldClink();
    const next = Math.min(120, treeWaterCount + delta);
    setTreeWaterCount(next);
    try {
      localStorage.setItem('khtn7_tree_xp_v1', String(next));
    } catch {
      // ignore
    }
  };

  const badges = [
    {
      title: 'Bậc Thầy Nguyên Tử',
      subtitle: 'Chinh phục Chương I & II Hóa học 7',
      emoji: '🧪',
      unlocked: true,
      color: 'from-amber-500 to-orange-600',
    },
    {
      title: 'Kiện Tướng Tốc Độ',
      subtitle: 'Vượt qua thử thách v = s / t & Đồ thị s-t',
      emoji: '⚡',
      unlocked: true,
      color: 'from-blue-500 to-indigo-600',
    },
    {
      title: 'Chuyên Gia Quang – Từ',
      subtitle: 'Nắm vững Phản xạ ánh sáng & Từ trường',
      emoji: '🧲',
      unlocked: currentStudent.baselineMcqDone >= 60,
      color: 'from-cyan-500 to-teal-600',
    },
    {
      title: 'Nhà Sinh Học Tương Lai',
      subtitle: 'Hiểu sâu Quang hợp, Hô hấp & Cảm ứng',
      emoji: '🌿',
      unlocked: currentStudent.baselineWeeksCompleted.length >= 3,
      color: 'from-emerald-500 to-green-600',
    },
    {
      title: 'Chiến Thần 12 Game',
      subtitle: 'Đạt trên 400 điểm Đấu trường Game bài học',
      emoji: '🎮',
      unlocked: currentStudent.baselineGameScore >= 400,
      color: 'from-purple-500 to-fuchsia-600',
    },
    {
      title: 'Ngọn Lửa Chuyên Cần',
      subtitle: 'Hoàn thành BTVN đúng hạn nhiều tuần liên tiếp',
      emoji: '🔥',
      unlocked: (currentStudent.commendationPoints || 10) >= 15,
      color: 'from-rose-500 to-red-600',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-2 sm:p-5">
      <div
        data-font-scale={fontScale}
        className={`ten-foot-game-stage bg-white flex flex-col shadow-2xl border border-slate-200 overflow-hidden transition-all ${
          isFullscreen
            ? 'fixed inset-0 z-[95] w-screen h-screen max-w-none max-h-none rounded-none'
            : 'rounded-3xl max-w-5xl w-full max-h-[92vh]'
        }`}
      >
        {/* Top Modal Header */}
        <div className="bg-gradient-to-r from-[#081e26] via-[#0e3240] to-[#081e26] text-white px-5 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black text-xl shrink-0">
              🎯
            </div>
            <div>
              <span className="text-[11px] font-black uppercase tracking-wider text-emerald-300">
                TIỆN ÍCH LỚP HỌC THÔNG MINH &amp; MÁY CHIẾU TIVI (10-FOOT UI) · TUẦN {activeWeek}
              </span>
              <h3 className="text-base sm:text-xl font-black">
                Vòng Quay Gọi Tên Học Sinh · Bảng Vàng Thi Đua · Cây Tri Thức KHTN 7
              </h3>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <TenFootUiControls
              fontScale={fontScale}
              onChangeFontScale={handleUpdateFontScale}
              isFullscreen={isFullscreen}
              onToggleFullscreen={handleToggleFullscreen}
              variant="dark"
            />
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
              title="Đóng"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 3 Switcher Tabs */}
        <div className="px-6 bg-slate-50 border-b border-slate-200 flex items-center gap-3 overflow-x-auto py-2.5">
          {[
            {
              id: 'picker' as const,
              label: '🎰 Vòng Quay Gọi Tên Học Sinh Trên Lớp',
            },
            {
              id: 'leaderboard' as const,
              label: `🏆 Bảng Vàng Thi Đua Tuần ${activeWeek} (Top 3 & Cả Lớp)`,
            },
            {
              id: 'tree' as const,
              label: '🌳 Cây Tri Thức Quang Hợp & 6 Huy Hiệu KHTN 7',
            },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                soundEngine.playClick();
                setActiveTab(tab.id);
              }}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-black transition whitespace-nowrap cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-[#081e26] text-amber-300 shadow'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* ================= TAB 1: RANDOM STUDENT PICKER FOR CLASSROOM PROJECTOR ================= */}
          {activeTab === 'picker' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left 5 Cols: Slot / Wheel Spinner */}
              <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 border-2 border-amber-400/50 shadow-xl space-y-5 text-center">
                <div className="space-y-1">
                  <span className="text-xs font-extrabold uppercase tracking-wider text-amber-300">
                    MÁY QUAY NGẪU NHIÊN DANH SÁCH LỚP ({students.length} HS)
                  </span>
                  <h4 className="text-lg font-black">
                    Gọi học sinh kiểm tra bài cũ / trả lời nhanh
                  </h4>
                </div>

                {/* Big Slot Display Box */}
                <div className="py-8 px-4 rounded-2xl bg-black/50 border-2 border-amber-400 shadow-inner min-h-[140px] flex flex-col items-center justify-center space-y-2">
                  {highlightedStudent ? (
                    <>
                      <span className="px-3 py-0.5 rounded-full bg-amber-400/20 text-amber-300 text-xs font-mono font-bold">
                        {highlightedStudent.code} · {highlightedStudent.className}
                      </span>
                      <div
                        className={`text-xl sm:text-2xl font-black tracking-tight ${
                          spinning ? 'text-white animate-pulse' : 'text-emerald-300'
                        }`}
                      >
                        {highlightedStudent.fullName}
                      </div>
                    </>
                  ) : (
                    <div className="text-slate-400 text-sm font-bold">
                      Bấm nút quay bên dưới để chọn ngẫu nhiên 1 học sinh!
                    </div>
                  )}
                </div>

                <button
                  onClick={handleSpinStudentPicker}
                  disabled={spinning}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-400 hover:from-amber-300 hover:to-yellow-200 text-slate-950 font-black text-sm sm:text-base shadow-lg transition cursor-pointer"
                >
                  {spinning ? '🎰 ĐANG QUAY TÊN HỌC SINH...' : '🎰 QUAY GỌI TÊN HỌC SINH'}
                </button>

                <div className="flex items-center justify-between text-xs text-slate-300 pt-2 border-t border-white/10">
                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={avoidRepeat}
                      onChange={(e) => setAvoidRepeat(e.target.checked)}
                      className="rounded text-amber-400"
                    />
                    <span>Không gọi lặp lại trong tiết</span>
                  </label>
                  {calledIds.length > 0 && (
                    <button
                      onClick={() => setCalledIds([])}
                      className="text-amber-300 hover:underline font-bold cursor-pointer"
                    >
                      Đặt lại ({calledIds.length} đã gọi)
                    </button>
                  )}
                </div>
              </div>

              {/* Right 7 Cols: Oral Question on Projector & Instant Point Award */}
              <div className="lg:col-span-7 space-y-4">
                {pickedStudent ? (
                  <div className="rounded-3xl border-2 border-emerald-400 bg-emerald-50/50 p-5 sm:p-6 space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <span className="text-xs font-black uppercase text-emerald-800">
                          🎯 HỌC SINH ĐƯỢC MỜI TRẢ LỜI TRÊN LỚP:
                        </span>
                        <h4 className="text-xl sm:text-2xl font-black text-slate-900">
                          {pickedStudent.fullName} ({pickedStudent.className})
                        </h4>
                      </div>
                      <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-black">
                        Điểm rèn luyện hiện tại: +{pickedStudent.commendationPoints || 10} đ
                      </span>
                    </div>

                    {rewardFeedback && (
                      <div className="p-3 rounded-xl bg-emerald-600 text-white text-xs sm:text-sm font-black">
                        {rewardFeedback}
                      </div>
                    )}

                    {/* Quick Reward Buttons */}
                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() =>
                          handleRewardPickedStudent(10, 'Trả lời xuất sắc câu hỏi kiểm tra miệng')
                        }
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 shadow-xs transition cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>🌟 +10 Điểm Trả lời Đúng</span>
                      </button>
                      <button
                        onClick={() =>
                          handleRewardPickedStudent(5, 'Xung phong xây dựng bài tích cực')
                        }
                        className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 shadow-xs transition cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>👏 +5 Điểm Cố Gắng</span>
                      </button>
                    </div>
                  </div>
                ) : null}

                {/* Classroom Projector Question Card */}
                <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-xs space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black uppercase text-indigo-600">
                      📺 CÂU HỎI TRÌNH CHIẾU TRÊN LỚP · TUẦN {activeWeek}
                    </span>
                    <button
                      onClick={() => {
                        setOralQuestionIdx((prev) => prev + 1);
                        setShowOralAnswer(false);
                      }}
                      className="px-3 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-extrabold cursor-pointer"
                    >
                      Đổi câu hỏi khác →
                    </button>
                  </div>

                  <p className="ten-foot-question text-base sm:text-xl font-black text-slate-900 leading-relaxed">
                    {currentOralQ.question}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {currentOralQ.options.map((opt, idx) => {
                      const isCorrect = idx === currentOralQ.correctIndex;
                      return (
                        <div
                          key={idx}
                          className={`ten-foot-option p-3.5 rounded-2xl border-2 text-xs sm:text-sm font-bold ${
                            showOralAnswer && isCorrect
                              ? 'bg-emerald-600 border-emerald-600 text-white shadow'
                              : 'bg-slate-50 border-slate-200 text-slate-800'
                          }`}
                        >
                          <strong>{String.fromCharCode(65 + idx)}.</strong> {opt}
                        </div>
                      );
                    })}
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <button
                      onClick={() => setShowOralAnswer(!showOralAnswer)}
                      className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-1.5 cursor-pointer"
                    >
                      {showOralAnswer ? (
                        <>
                          <EyeOff className="w-4 h-4" />
                          <span>Ẩn đáp án</span>
                        </>
                      ) : (
                        <>
                          <Eye className="w-4 h-4" />
                          <span>Hiện đáp án & Giải thích</span>
                        </>
                      )}
                    </button>
                  </div>

                  {showOralAnswer && (
                    <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs sm:text-sm text-emerald-950">
                      <strong>Giải thích:</strong> {currentOralQ.explanation}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ================= TAB 2: WEEKLY CLASS LEADERBOARD (TOP 3 PODIUM) ================= */}
          {activeTab === 'leaderboard' && (
            <div className="space-y-6">
              {/* Top 3 Podium Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {rankedStudents.slice(0, 3).map((item, idx) => {
                  const medals = ['🥇 QUÁN QUÂN TUẦN', '🥈 Á QUÂN TUẦN', '🥉 QUÝ QUÂN TUẦN'];
                  const styles = [
                    'bg-gradient-to-br from-amber-400 via-yellow-400 to-amber-500 text-slate-950 border-amber-300 shadow-xl',
                    'bg-gradient-to-br from-slate-200 via-slate-100 to-slate-300 text-slate-900 border-slate-300 shadow-md',
                    'bg-gradient-to-br from-orange-200 via-amber-100 to-orange-300 text-slate-900 border-orange-300 shadow-md',
                  ];
                  return (
                    <div
                      key={item.student.id}
                      className={`rounded-3xl p-5 border-2 flex flex-col justify-between gap-3 ${styles[idx]}`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="px-3 py-1 rounded-full bg-black/15 text-xs font-black">
                          {medals[idx]}
                        </span>
                        <span className="text-xs font-black opacity-80">
                          {item.student.code}
                        </span>
                      </div>

                      <div>
                        <h4 className="text-lg sm:text-xl font-black">
                          {item.student.fullName}
                        </h4>
                        <p className="text-xs font-bold opacity-85">
                          {item.student.className} · ĐTB: {item.metrics.average.toFixed(2)} (
                          {item.metrics.rankLabel})
                        </p>
                      </div>

                      <div className="pt-2 border-t border-black/10 flex items-center justify-between text-xs font-black">
                        <span>Điểm rèn luyện: +{item.student.commendationPoints || 10}</span>
                        <span className="text-sm">🏆 {item.totalPoints} XP</span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Full Class Leaderboard Table */}
              <div className="rounded-2xl border border-slate-200 overflow-hidden">
                <table className="w-full text-left border-collapse text-xs sm:text-sm">
                  <thead>
                    <tr className="bg-slate-100 text-slate-600 font-black text-[11px] uppercase border-b border-slate-200">
                      <th className="py-3 px-4">Hạng</th>
                      <th className="py-3 px-4">Học sinh</th>
                      <th className="py-3 px-4">ĐTB KHTN 7</th>
                      <th className="py-3 px-4">Điểm Rèn Luyện</th>
                      <th className="py-3 px-4">Điểm 12 Game</th>
                      <th className="py-3 px-4 text-right">Tổng Điểm Thi Đua</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200/80">
                    {rankedStudents.map((row, idx) => (
                      <tr
                        key={row.student.id}
                        className={
                          row.student.id === currentStudent.id ? 'bg-emerald-50/70 font-bold' : ''
                        }
                      >
                        <td className="py-3 px-4 font-black text-slate-700">#{idx + 1}</td>
                        <td className="py-3 px-4 font-black text-slate-900">
                          {row.student.fullName}{' '}
                          <span className="text-xs font-normal text-slate-500">
                            ({row.student.className})
                          </span>
                        </td>
                        <td className="py-3 px-4 font-black text-indigo-600">
                          {row.metrics.average.toFixed(2)}
                        </td>
                        <td className="py-3 px-4 text-emerald-700 font-extrabold">
                          +{row.student.commendationPoints || 10} đ
                        </td>
                        <td className="py-3 px-4 text-amber-700 font-extrabold">
                          {row.student.baselineGameScore} đ
                        </td>
                        <td className="py-3 px-4 text-right font-black text-slate-900">
                          {row.totalPoints} XP
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ================= TAB 3: VIRTUAL SCIENCE TREE & 6 BADGES ================= */}
          {activeTab === 'tree' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
              {/* Left 5 Cols: Interactive Photosynthesis Tree */}
              <div className="lg:col-span-5 rounded-3xl bg-gradient-to-b from-sky-100 via-emerald-50 to-amber-50 border-2 border-emerald-300 p-6 text-center space-y-4 shadow-md">
                <span className="px-3 py-1 rounded-full bg-emerald-700 text-white text-xs font-black uppercase">
                  CÂY TRI THỨC QUANG HỢP KHTN 7
                </span>

                <div className="text-6xl sm:text-7xl py-4 animate-bounce">
                  {treeStage.emoji}
                </div>

                <div className="space-y-1">
                  <h4 className="text-base sm:text-lg font-black text-emerald-950">
                    {treeStage.name}
                  </h4>
                  <p className="text-xs text-slate-600">{treeStage.desc}</p>
                </div>

                {/* Progress Bar */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-black text-emerald-800">
                    <span>Năng lượng Quang hợp (ATP)</span>
                    <span>{treeWaterCount} / 100 XP</span>
                  </div>
                  <div className="h-3 rounded-full bg-white border border-emerald-300 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 to-amber-400 transition-all duration-300"
                      style={{ width: `${Math.min(100, treeWaterCount)}%` }}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2.5 pt-2">
                  <button
                    onClick={() => handleNurtureTree(10)}
                    className="py-2.5 px-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow cursor-pointer"
                  >
                    <Sun className="w-4 h-4" />
                    <span>☀️ Chiếu sáng (+10 XP)</span>
                  </button>
                  <button
                    onClick={() => handleNurtureTree(10)}
                    className="py-2.5 px-3 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow cursor-pointer"
                  >
                    <Droplets className="w-4 h-4" />
                    <span>💧 Tưới nước (+10 XP)</span>
                  </button>
                </div>
              </div>

              {/* Right 7 Cols: 6 KHTN 7 Achievement Badges */}
              <div className="lg:col-span-7 space-y-3">
                <h4 className="text-base sm:text-lg font-black text-slate-900">
                  Bộ Sưu Tập 6 Huy Hiệu Danh Hiệu Nhà Khoa Học Lớp 7 ({currentStudent.fullName})
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {badges.map((b, i) => (
                    <div
                      key={i}
                      className={`p-4 rounded-2xl border-2 flex items-start gap-3.5 ${
                        b.unlocked
                          ? 'bg-white border-emerald-300 shadow-xs'
                          : 'bg-slate-50 border-slate-200 opacity-60'
                      }`}
                    >
                      <div
                        className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${b.color} text-white text-2xl flex items-center justify-center shrink-0 shadow`}
                      >
                        {b.emoji}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs sm:text-sm font-black text-slate-900">
                            {b.title}
                          </span>
                          {b.unlocked && (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          )}
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">{b.subtitle}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
