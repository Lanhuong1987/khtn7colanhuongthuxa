import React, { useState } from 'react';
import { X, Atom, Zap, BookOpen } from 'lucide-react';

interface PeriodicTableModalProps {
  onClose: () => void;
}

interface ElementItem {
  z: number;
  symbol: string;
  name: string;
  viName: string;
  mass: number;
  layers: string;
  period: number;
  group: string;
  valence: string;
  type: 'kim_loai' | 'phi_kim' | 'khi_hiem';
}

const KHTN7_ELEMENTS: ElementItem[] = [
  { z: 1, symbol: 'H', name: 'Hydrogen', viName: 'Hiđrô', mass: 1, layers: '1', period: 1, group: 'IA', valence: 'I', type: 'phi_kim' },
  { z: 2, symbol: 'He', name: 'Helium', viName: 'Hêli', mass: 4, layers: '2', period: 1, group: 'VIIIA', valence: '-', type: 'khi_hiem' },
  { z: 3, symbol: 'Li', name: 'Lithium', viName: 'Liti', mass: 7, layers: '2/1', period: 2, group: 'IA', valence: 'I', type: 'kim_loai' },
  { z: 4, symbol: 'Be', name: 'Beryllium', viName: 'Beri', mass: 9, layers: '2/2', period: 2, group: 'IIA', valence: 'II', type: 'kim_loai' },
  { z: 5, symbol: 'B', name: 'Boron', viName: 'Bo', mass: 11, layers: '2/3', period: 2, group: 'IIIA', valence: 'III', type: 'phi_kim' },
  { z: 6, symbol: 'C', name: 'Carbon', viName: 'Cacbon', mass: 12, layers: '2/4', period: 2, group: 'IVA', valence: 'II, IV', type: 'phi_kim' },
  { z: 7, symbol: 'N', name: 'Nitrogen', viName: 'Nitơ', mass: 14, layers: '2/5', period: 2, group: 'VA', valence: 'II, III, IV, V', type: 'phi_kim' },
  { z: 8, symbol: 'O', name: 'Oxygen', viName: 'Oxi', mass: 16, layers: '2/6', period: 2, group: 'VIA', valence: 'II', type: 'phi_kim' },
  { z: 9, symbol: 'F', name: 'Fluorine', viName: 'Flo', mass: 19, layers: '2/7', period: 2, group: 'VIIA', valence: 'I', type: 'phi_kim' },
  { z: 10, symbol: 'Ne', name: 'Neon', viName: 'Neon', mass: 20, layers: '2/8', period: 2, group: 'VIIIA', valence: '-', type: 'khi_hiem' },
  { z: 11, symbol: 'Na', name: 'Sodium', viName: 'Natri', mass: 23, layers: '2/8/1', period: 3, group: 'IA', valence: 'I', type: 'kim_loai' },
  { z: 12, symbol: 'Mg', name: 'Magnesium', viName: 'Magiê', mass: 24, layers: '2/8/2', period: 3, group: 'IIA', valence: 'II', type: 'kim_loai' },
  { z: 13, symbol: 'Al', name: 'Aluminium', viName: 'Nhôm', mass: 27, layers: '2/8/3', period: 3, group: 'IIIA', valence: 'III', type: 'kim_loai' },
  { z: 14, symbol: 'Si', name: 'Silicon', viName: 'Silic', mass: 28, layers: '2/8/4', period: 3, group: 'IVA', valence: 'IV', type: 'phi_kim' },
  { z: 15, symbol: 'P', name: 'Phosphorus', viName: 'Photpho', mass: 31, layers: '2/8/5', period: 3, group: 'VA', valence: 'III, V', type: 'phi_kim' },
  { z: 16, symbol: 'S', name: 'Sulfur', viName: 'Lưu huỳnh', mass: 32, layers: '2/8/6', period: 3, group: 'VIA', valence: 'II, IV, VI', type: 'phi_kim' },
  { z: 17, symbol: 'Cl', name: 'Chlorine', viName: 'Clo', mass: 35.5, layers: '2/8/7', period: 3, group: 'VIIA', valence: 'I', type: 'phi_kim' },
  { z: 18, symbol: 'Ar', name: 'Argon', viName: 'Acgon', mass: 40, layers: '2/8/8', period: 3, group: 'VIIIA', valence: '-', type: 'khi_hiem' },
  { z: 19, symbol: 'K', name: 'Potassium', viName: 'Kali', mass: 39, layers: '2/8/8/1', period: 4, group: 'IA', valence: 'I', type: 'kim_loai' },
  { z: 20, symbol: 'Ca', name: 'Calcium', viName: 'Canxi', mass: 40, layers: '2/8/8/2', period: 4, group: 'IIA', valence: 'II', type: 'kim_loai' },
  { z: 26, symbol: 'Fe', name: 'Iron', viName: 'Sắt', mass: 56, layers: '4 lớp', period: 4, group: 'VIIIB', valence: 'II, III', type: 'kim_loai' },
  { z: 29, symbol: 'Cu', name: 'Copper', viName: 'Đồng', mass: 64, layers: '4 lớp', period: 4, group: 'IB', valence: 'I, II', type: 'kim_loai' },
  { z: 30, symbol: 'Zn', name: 'Zinc', viName: 'Kẽm', mass: 65, layers: '4 lớp', period: 4, group: 'IIB', valence: 'II', type: 'kim_loai' },
  { z: 35, symbol: 'Br', name: 'Bromine', viName: 'Brom', mass: 80, layers: '4 lớp', period: 4, group: 'VIIA', valence: 'I', type: 'phi_kim' },
  { z: 47, symbol: 'Ag', name: 'Silver', viName: 'Bạc', mass: 108, layers: '5 lớp', period: 5, group: 'IB', valence: 'I', type: 'kim_loai' },
  { z: 53, symbol: 'I', name: 'Iodine', viName: 'I-ốt', mass: 127, layers: '5 lớp', period: 5, group: 'VIIA', valence: 'I', type: 'phi_kim' },
  { z: 56, symbol: 'Ba', name: 'Barium', viName: 'Bari', mass: 137, layers: '6 lớp', period: 6, group: 'IIA', valence: 'II', type: 'kim_loai' },
  { z: 79, symbol: 'Au', name: 'Gold', viName: 'Vàng', mass: 197, layers: '6 lớp', period: 6, group: 'IB', valence: 'III', type: 'kim_loai' },
  { z: 80, symbol: 'Hg', name: 'Mercury', viName: 'Thủy ngân', mass: 201, layers: '6 lớp', period: 6, group: 'IIB', valence: 'I, II', type: 'kim_loai' },
];

export const PeriodicTableModal: React.FC<PeriodicTableModalProps> = ({ onClose }) => {
  const [selectedEl, setSelectedEl] = useState<ElementItem>(KHTN7_ELEMENTS[10]); // Na
  const [tab, setTab] = useState<'elements' | 'formulas'>('elements');

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl max-w-5xl w-full max-h-[88vh] flex flex-col overflow-hidden border border-slate-200 shadow-2xl"
      >
        {/* Modal Top Bar */}
        <div className="px-6 py-4 bg-[#081e26] text-white flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Atom className="w-6 h-6 text-amber-400" />
            <div>
              <h3 className="text-base sm:text-lg font-extrabold">
                Sổ tay KHTN 7 &amp; Bảng Tuần Hoàn Hóa Học – Hóa Trị
              </h3>
              <p className="text-xs text-slate-300">
                Tra cứu nhanh nguyên tử khối (amu), cấu hình lớp electron, hóa trị và công thức Vật lí – Hóa học – Sinh học 7
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setTab('elements')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold cursor-pointer ${
                tab === 'elements'
                  ? 'bg-amber-400 text-slate-950'
                  : 'bg-white/10 text-white hover:bg-white/20'
              }`}
            >
              Bảng nguyên tố &amp; Hóa trị
            </button>
            <button
              onClick={() => setTab('formulas')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold cursor-pointer ${
                tab === 'formulas'
                  ? 'bg-emerald-400 text-slate-950'
                  : 'bg-white/10 text-white hover:bg-white/20'
              }`}
            >
              Công thức Vật lí – Hóa – Sinh 7
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-300 hover:bg-white/10 cursor-pointer ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {tab === 'elements' ? (
            <>
              {/* Selected Element Inspector Card */}
              <div className="p-5 rounded-2xl bg-slate-900 text-white grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
                <div className="md:col-span-3 flex items-center gap-4">
                  <div className="w-20 h-20 rounded-2xl bg-amber-400 text-slate-950 flex flex-col items-center justify-center font-mono shrink-0">
                    <span className="text-xs font-bold">Z = {selectedEl.z}</span>
                    <span className="text-3xl font-extrabold leading-none">
                      {selectedEl.symbol}
                    </span>
                    <span className="text-xs font-bold mt-0.5">{selectedEl.mass}</span>
                  </div>
                  <div>
                    <div className="text-xl font-extrabold">{selectedEl.name}</div>
                    <div className="text-xs text-slate-300">
                      Tên tiếng Việt: <strong>{selectedEl.viName}</strong>
                    </div>
                    <span className="inline-block mt-1.5 text-[11px] font-mono uppercase px-2 py-0.5 rounded-md bg-white/15 text-emerald-300 font-bold">
                      {selectedEl.type === 'kim_loai'
                        ? 'Kim loại'
                        : selectedEl.type === 'phi_kim'
                        ? 'Phi kim'
                        : 'Khí hiếm'}
                    </span>
                  </div>
                </div>

                <div className="md:col-span-9 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
                  <div className="p-3 rounded-xl bg-white/10">
                    <div className="text-slate-400">Số p = Số e (Z)</div>
                    <div className="text-base font-bold text-white mt-0.5">
                      {selectedEl.z} hạt
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-white/10">
                    <div className="text-slate-400">Khối lượng NT</div>
                    <div className="text-base font-bold text-amber-300 mt-0.5">
                      {selectedEl.mass} amu
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-white/10">
                    <div className="text-slate-400">Chu kì / Nhóm</div>
                    <div className="text-base font-bold text-emerald-300 mt-0.5">
                      CK {selectedEl.period} · {selectedEl.group}
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-white/10">
                    <div className="text-slate-400">Hóa trị / Lớp e</div>
                    <div className="text-base font-bold text-white mt-0.5">
                      HT: {selectedEl.valence} ({selectedEl.layers})
                    </div>
                  </div>
                </div>
              </div>

              {/* Elements Grid */}
              <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-8 gap-2.5">
                {KHTN7_ELEMENTS.map((el) => {
                  const active = selectedEl.z === el.z;
                  const typeStyle =
                    el.type === 'kim_loai'
                      ? 'bg-blue-50 border-blue-200 text-blue-950'
                      : el.type === 'phi_kim'
                      ? 'bg-amber-50 border-amber-200 text-amber-950'
                      : 'bg-emerald-50 border-emerald-200 text-emerald-950';

                  return (
                    <button
                      key={el.z}
                      onClick={() => setSelectedEl(el)}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                        active
                          ? 'ring-2 ring-slate-900 bg-slate-900 text-white border-slate-900'
                          : `${typeStyle} hover:scale-[1.02]`
                      }`}
                    >
                      <div className="flex items-center justify-between text-[11px] font-mono opacity-80">
                        <span>Z={el.z}</span>
                        <span>{el.mass}</span>
                      </div>
                      <div className="text-xl font-extrabold font-mono mt-0.5">
                        {el.symbol}
                      </div>
                      <div className="text-xs font-semibold truncate">{el.name}</div>
                      <div className="text-[10px] font-mono opacity-75 mt-0.5">
                        HT: {el.valence}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Common Acid Radicals / Polyatomic Ions Valence Table */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="text-xs font-mono uppercase font-bold text-slate-700">
                  BẢNG HÓA TRỊ CỦA CÁC NHÓM NGUYÊN TỬ THƯỜNG GẶP (BÀI 7 - KHTN 7):
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
                  <div className="p-3 rounded-xl bg-white border border-slate-200">
                    <strong className="text-blue-700">Hóa trị I:</strong> Nhóm -OH (Hydroxide), -NO₃ (Nitrate), -NH₄ (Ammonium), -HCO₃
                  </div>
                  <div className="p-3 rounded-xl bg-white border border-slate-200">
                    <strong className="text-amber-700">Hóa trị II:</strong> Nhóm =SO₄ (Sulfate), =CO₃ (Carbonate), =SO₃ (Sulfite), =HPO₄
                  </div>
                  <div className="p-3 rounded-xl bg-white border border-slate-200">
                    <strong className="text-emerald-700">Hóa trị III:</strong> Nhóm ≡PO₄ (Phosphate)
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-5 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-3">
                <div className="flex items-center gap-2 text-amber-900 font-bold">
                  <Atom className="w-5 h-5" />
                   Công thức Hóa học 7
                </div>
                <ul className="space-y-2 text-xs sm:text-sm text-slate-800 font-mono">
                  <li>• Số p = Số e = Z</li>
                  <li>• KLNT ≈ p + n (amu)</li>
                  <li>• Quy tắc hóa trị (AₓBᵧ): a · x = b · y ⇒ x/y = b/a</li>
                  <li>• %m_A = (x · M_A / M_AxBy) × 100%</li>
                </ul>
              </div>

              <div className="p-5 rounded-2xl bg-blue-50/70 border border-blue-200 space-y-3">
                <div className="flex items-center gap-2 text-blue-900 font-bold">
                  <Zap className="w-5 h-5" />
                  Công thức Vật lí 7
                </div>
                <ul className="space-y-2 text-xs sm:text-sm text-slate-800 font-mono">
                  <li>• Tốc độ: v = s / t  |  s = v · t  |  t = s / v</li>
                  <li>• Đổi đơn vị: 1 m/s = 3,6 km/h</li>
                  <li>• Quy tắc 3 giây: d (m) = v (m/s) × 3</li>
                  <li>• Tần số âm: f = N / t (Hz)</li>
                  <li>• Khoảng cách tiếng vang: d = (v · t) / 2 (d ≥ 11,35 m)</li>
                  <li>• Định luật phản xạ ánh sáng: i&apos; = i</li>
                </ul>
              </div>

              <div className="p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-3">
                <div className="flex items-center gap-2 text-emerald-900 font-bold">
                  <BookOpen className="w-5 h-5" />
                  Sơ đồ Sinh học 7
                </div>
                <ul className="space-y-2 text-xs sm:text-sm text-slate-800 font-mono">
                  <li>• Quang hợp: CO₂ + H₂O →(Ánh sáng/Diệp lục)→ Glucose + O₂</li>
                  <li>• Hô hấp tế bào: Glucose + O₂ → CO₂ + H₂O + ATP + Nhiệt</li>
                  <li>• Mạch gỗ: Rễ ↑ Thân ↑ Lá (Nước &amp; khoáng)</li>
                  <li>• Mạch rây: Lá ↓ Rễ, Củ, Quả (Chất hữu cơ)</li>
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
