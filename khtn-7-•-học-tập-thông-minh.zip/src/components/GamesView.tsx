import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Gamepad2,
  Trophy,
  Volume2,
  VolumeX,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  XCircle,
  ArrowLeft,
  Bell,
  HelpCircle,
  Zap,
  Shield,
  Flame,
  Flag,
  KeyRound,
  Search,
  Compass,
  Award,
  Clock,
  PhoneCall,
  Users,
  Percent,
  Play,
  Lock,
  Unlock,
  Gem,
  Maximize2,
  Minimize2,
  Monitor,
} from 'lucide-react';
import { ALL_KNTT_LESSONS } from '../data/allLessons';
import { KhtnLesson, McqItem } from '../data/lessonTypes';
import { SubSubject } from '../data/khtn7Data';
import { soundEngine } from '../utils/gameSoundEngine';

export type GameId =
  | 'golden_bell'
  | 'millionaire'
  | 'wheel_of_fortune'
  | 'gold_miner'
  | 'speed_racer'
  | 'minesweeper'
  | 'treasure_hunt'
  | 'escape_room'
  | 'memory_match'
  | 'science_detective'
  | 'crossword_decoder'
  | 'boss_battle';

interface GameMeta {
  id: GameId;
  number: number;
  title: string;
  subtitle: string;
  badge: string;
  emoji: string;
  gradient: string;
  accentBorder: string;
  description: string;
}

export const TWELVE_GAMES: GameMeta[] = [
  {
    id: 'golden_bell',
    number: 1,
    title: 'Rung Chuông Vàng',
    subtitle: 'Sàn đấu 100 thí sinh · Vượt 15 câu hỏi',
    badge: 'TV SHOW KINH ĐIỂN',
    emoji: '🔔',
    gradient: 'from-amber-500 via-yellow-500 to-orange-600',
    accentBorder: 'border-amber-400',
    description:
      'Bước lên sàn thi đấu cùng 100 thí sinh ảo, trả lời 15 câu hỏi của bài học trong 15 giây/câu và dùng Phao cứu trợ để chạm tới Chuông Vàng.',
  },
  {
    id: 'millionaire',
    number: 2,
    title: 'Ai Là Triệu Phú KHTN',
    subtitle: 'Ghế nóng 15 mốc điểm · 4 quyền trợ giúp',
    badge: 'GHẾ NÓNG TRÍ TUỆ',
    emoji: '💰',
    gradient: 'from-indigo-700 via-blue-800 to-purple-900',
    accentBorder: 'border-indigo-400',
    description:
      'Trải nghiệm trường quay Ai Là Triệu Phú với âm thanh hồi hộp, 15 mốc điểm thưởng và 4 quyền trợ giúp: 50:50, Hỏi khán giả, Gọi Nhà khoa học, Đổi câu.',
  },
  {
    id: 'wheel_of_fortune',
    number: 3,
    title: 'Chiếc Nón Kì Diệu',
    subtitle: 'Vòng quay Tri thức 12 ô điểm & Nhân đôi',
    badge: 'VÒNG QUAY MAY MẮN',
    emoji: '🎡',
    gradient: 'from-pink-600 via-rose-500 to-amber-500',
    accentBorder: 'border-pink-400',
    description:
      'Quay bánh xe 12 ô sắc màu (300, 500, 1000 điểm, Nhân đôi x2, Ô Bí Ẩn, Thêm lượt) và giải câu hỏi của bài học để tích lũy điểm thưởng.',
  },
  {
    id: 'gold_miner',
    number: 4,
    title: 'Đào Vàng KHTN',
    subtitle: 'Canh góc thả ngoàm gắp Vàng & Kim cương',
    badge: 'ARCADE HẤP DẪN',
    emoji: '⛏️',
    gradient: 'from-yellow-600 via-amber-600 to-stone-800',
    accentBorder: 'border-yellow-400',
    description:
      'Canh đúng góc móc câu đang đung đưa để gắp Cục Vàng Lớn, Kim Cương Tri Thức và Túi Bí Ẩn dưới lòng đất bằng kiến thức bài học.',
  },
  {
    id: 'speed_racer',
    number: 5,
    title: 'Đường Đua 9+ (Đua Xe)',
    subtitle: 'Kích hoạt Nitro Turbo vượt 3 đối thủ AI',
    badge: 'TỐC ĐỘ & PHẢN XẠ',
    emoji: '🏎️',
    gradient: 'from-red-600 via-orange-600 to-rose-700',
    accentBorder: 'border-red-400',
    description:
      'Điều khiển siêu xe F1 KHTN 7 trên đường đua 4 làn. Trả lời đúng và nhanh để nạp bình Nitro bứt tốc 320 km/h về đích đầu tiên.',
  },
  {
    id: 'minesweeper',
    number: 6,
    title: 'Dò Mìn Khoa Học',
    subtitle: 'Bản đồ radar 5×5 · Gỡ bom bằng kiến thức',
    badge: 'CHIẾN THUẬT RADAR',
    emoji: '💣',
    gradient: 'from-slate-700 via-zinc-800 to-emerald-900',
    accentBorder: 'border-emerald-400',
    description:
      'Quét radar 25 ô năng lượng, cắm cờ đánh dấu 5 quả mìn phóng xạ và trả lời câu hỏi bài học để tháo ngòi nổ an toàn.',
  },
  {
    id: 'treasure_hunt',
    number: 7,
    title: 'Truy Tìm Kho Báu',
    subtitle: 'Hành trình 8 hòn đảo mở Rương Hoàng Gia',
    badge: 'PHIÊU LƯU ĐẠI DƯƠNG',
    emoji: '🏴‍☠️',
    gradient: 'from-teal-600 via-cyan-700 to-blue-900',
    accentBorder: 'border-cyan-400',
    description:
      'Vượt qua 8 hòn đảo bí ẩn trên hải đồ KHTN 7, thu thập Chìa khóa Vàng qua từng câu hỏi của bài học để mở Rương Kho Báu.',
  },
  {
    id: 'escape_room',
    number: 8,
    title: 'Escape Room: Phòng Thí Nghiệm',
    subtitle: 'Giải mã 4 lớp cửa khóa từ · Tìm mật mã 4 số',
    badge: 'GIẢI CỨU PHÒNG LAB',
    emoji: '🔐',
    gradient: 'from-emerald-700 via-teal-800 to-slate-900',
    accentBorder: 'border-teal-400',
    description:
      'Phòng thí nghiệm KHTN 7 đang bị khóa! Vượt qua 4 buồng an ninh để thu thập đủ 4 chữ số mật mã mở cổng thoát hiểm trung tâm.',
  },
  {
    id: 'memory_match',
    number: 9,
    title: 'Ghép Cặp Thông Minh',
    subtitle: 'Lật thẻ nối Khái niệm ↔ Đáp án chuẩn xác',
    badge: 'TRÍ NHỚ SIÊU ĐẲNG',
    emoji: '🧩',
    gradient: 'from-violet-600 via-purple-600 to-fuchsia-700',
    accentBorder: 'border-purple-400',
    description:
      'Ghép nối chính xác 6 cặp Thẻ Câu hỏi / Công thức với Thẻ Đáp án tương ứng của bài học để đạt chuỗi Combo nhân điểm.',
  },
  {
    id: 'science_detective',
    number: 10,
    title: 'Thám Tử Khoa Học',
    subtitle: 'Soi kính lúp thu thập manh mối · Tìm thủ phạm',
    badge: 'PHÁ ÁN HIỆN TRƯỜNG',
    emoji: '🕵️',
    gradient: 'from-stone-700 via-amber-900 to-slate-900',
    accentBorder: 'border-amber-500',
    description:
      'Phân tích các mệnh đề Đúng/Sai và câu hỏi hiện trường để mở khóa 5 manh mối khoa học, loại trừ nghi phạm sai và phá án.',
  },
  {
    id: 'crossword_decoder',
    number: 11,
    title: 'Giải Mã Ô Chữ KHTN',
    subtitle: 'Giải 6 hàng ngang · Lật mở Từ khóa Bài học',
    badge: 'MẬT MÃ NGÔN TỪ',
    emoji: '🔤',
    gradient: 'from-blue-600 via-sky-600 to-indigo-700',
    accentBorder: 'border-sky-400',
    description:
      'Giải quyết 6 ô chữ hàng ngang trích xuất trực tiếp từ kiến thức trọng tâm của bài học để tìm ra Từ Khóa Chủ Đề.',
  },
  {
    id: 'boss_battle',
    number: 12,
    title: 'Đấu Trường Săn Boss KHTN',
    subtitle: 'Đề xuất mới: Chiến giáp KHTN đại chiến Boss!',
    badge: '🔥 ĐỀ XUẤT HOT LỚP 7',
    emoji: '👾',
    gradient: 'from-fuchsia-700 via-rose-700 to-indigo-950',
    accentBorder: 'border-fuchsia-400',
    description:
      'Game nhập vai RPG cực cuốn hút học sinh lớp 7: Dùng Tia Laser, Pháo Ion và Khiên Năng Lượng tấn công Boss của từng bài học!',
  },
];

interface GamesViewProps {
  initialLessonId?: string;
  highScore: number;
  onUpdateHighScore: (newScore: number) => void;
}

export type TenFootFontScale = 'A' | 'A+' | 'A++';

const TEN_FOOT_STORAGE_KEY = 'khtn7_10foot_font_scale_v1';

export function loadTenFootFontScale(): TenFootFontScale {
  try {
    const saved = localStorage.getItem(TEN_FOOT_STORAGE_KEY);
    if (saved === 'A' || saved === 'A+' || saved === 'A++') return saved;
  } catch {
    // ignore
  }
  return 'A+';
}

export function saveTenFootFontScale(scale: TenFootFontScale): void {
  try {
    localStorage.setItem(TEN_FOOT_STORAGE_KEY, scale);
  } catch {
    // ignore
  }
}

export const TenFootUiControls: React.FC<{
  fontScale: TenFootFontScale;
  onChangeFontScale: (scale: TenFootFontScale) => void;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  variant?: 'dark' | 'light';
}> = ({
  fontScale,
  onChangeFontScale,
  isFullscreen,
  onToggleFullscreen,
  variant = 'dark',
}) => {
  const scales: TenFootFontScale[] = ['A', 'A+', 'A++'];

  const handleCycleScale = () => {
    soundEngine.playClick();
    const idx = scales.indexOf(fontScale);
    const next = scales[(idx + 1) % scales.length];
    onChangeFontScale(next);
  };

  return (
    <div className="flex flex-wrap items-center gap-2 shrink-0">
      {/* 🔍 Chữ: A / A+ / A++ Control */}
      <div
        className={`inline-flex items-center rounded-xl border-2 p-1 shadow-xs transition ${
          variant === 'dark'
            ? 'bg-slate-950/90 border-amber-400/70 text-white'
            : 'bg-slate-900 border-teal-500 text-white'
        }`}
        title="Đổi cỡ chữ câu hỏi & đáp án cho Máy chiếu / Tivi lớp học (Khoảng cách 5–8 mét)"
      >
        <button
          type="button"
          onClick={handleCycleScale}
          className="px-2 py-1 text-xs font-black text-amber-300 hover:text-amber-200 flex items-center gap-1 cursor-pointer"
        >
          <span>🔍 Chữ:</span>
        </button>
        <div className="flex items-center gap-1">
          {scales.map((sc) => {
            const active = fontScale === sc;
            return (
              <button
                key={sc}
                type="button"
                onClick={() => {
                  soundEngine.playClick();
                  onChangeFontScale(sc);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-black transition cursor-pointer ${
                  active
                    ? 'bg-amber-400 text-slate-950 shadow-xs scale-105'
                    : 'bg-white/10 hover:bg-white/20 text-slate-200'
                }`}
              >
                {sc}
              </button>
            );
          })}
        </div>
      </div>

      {/* ⛶ Toàn màn hình Button */}
      <button
        type="button"
        onClick={() => {
          soundEngine.playClick();
          onToggleFullscreen();
        }}
        className={`px-3.5 py-2 rounded-xl font-black text-xs sm:text-sm flex items-center gap-1.5 border-2 shadow-sm transition cursor-pointer ${
          isFullscreen
            ? 'bg-rose-600 hover:bg-rose-500 border-rose-300 text-white'
            : 'bg-cyan-500 hover:bg-cyan-400 border-cyan-200 text-slate-950'
        }`}
        title="Bật/Tắt chế độ Toàn màn hình cho Máy chiếu & Tivi lớp học (5–8m)"
      >
        {isFullscreen ? (
          <>
            <Minimize2 className="w-4 h-4" />
            <span>⛶ Thoát toàn màn hình</span>
          </>
        ) : (
          <>
            <Maximize2 className="w-4 h-4" />
            <span>⛶ Toàn màn hình</span>
          </>
        )}
      </button>
    </div>
  );
};

const MILLIONAIRE_LADDER = [
  '100.000 XP',
  '200.000 XP',
  '300.000 XP',
  '500.000 XP',
  '1.000.000 XP (Mốc 1)',
  '2.000.000 XP',
  '3.600.000 XP',
  '6.000.000 XP',
  '9.000.000 XP',
  '15.000.000 XP (Mốc 2)',
  '25.000.000 XP',
  '40.000.000 XP',
  '65.000.000 XP',
  '100.000.000 XP',
  '150.000.000 XP (TRIỆU PHÚ KHTN)',
];

const WHEEL_WEDGES = [
  { label: '300 ĐIỂM', points: 300, type: 'points', color: '#ef4444' },
  { label: '500 ĐIỂM', points: 500, type: 'points', color: '#f59e0b' },
  { label: 'NHÂN ĐÔI x2', points: 0, type: 'double', color: '#8b5cf6' },
  { label: '200 ĐIỂM', points: 200, type: 'points', color: '#10b981' },
  { label: '1000 ĐIỂM', points: 1000, type: 'points', color: '#ec4899' },
  { label: 'THÊM LƯỢT', points: 400, type: 'bonus', color: '#06b6d4' },
  { label: '400 ĐIỂM', points: 400, type: 'points', color: '#3b82f6' },
  { label: 'Ô BÍ ẨN +1500', points: 1500, type: 'mystery', color: '#eab308' },
  { label: '600 ĐIỂM', points: 600, type: 'points', color: '#14b8a6' },
  { label: '800 ĐIỂM', points: 800, type: 'points', color: '#f97316' },
  { label: 'MAY MẮN +700', points: 700, type: 'points', color: '#6366f1' },
  { label: '900 ĐIỂM', points: 900, type: 'points', color: '#22c55e' },
];

export const GamesView: React.FC<GamesViewProps> = ({
  initialLessonId,
  highScore,
  onUpdateHighScore,
}) => {
  const [subjectFilter, setSubjectFilter] = useState<'all' | SubSubject>('all');
  const [selectedLessonId, setSelectedLessonId] = useState<string>(
    initialLessonId || ALL_KNTT_LESSONS[0].id
  );
  const [activeGameId, setActiveGameId] = useState<GameId | null>(null);
  const [soundMuted, setSoundMuted] = useState<boolean>(soundEngine.muted);
  const [fontScale, setFontScale] = useState<TenFootFontScale>(() => loadTenFootFontScale());
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const gameStageContainerRef = useRef<HTMLDivElement | null>(null);

  const handleUpdateFontScale = (nextScale: TenFootFontScale) => {
    setFontScale(nextScale);
    saveTenFootFontScale(nextScale);
  };

  const handleToggleFullscreen = async () => {
    const nextState = !isFullscreen;
    setIsFullscreen(nextState);
    try {
      if (nextState) {
        if (gameStageContainerRef.current && gameStageContainerRef.current.requestFullscreen) {
          await gameStageContainerRef.current.requestFullscreen();
        } else if (document.documentElement.requestFullscreen) {
          await document.documentElement.requestFullscreen();
        }
      } else {
        if (document.fullscreenElement && document.exitFullscreen) {
          await document.exitFullscreen();
        }
      }
    } catch {
      // Fallback CSS fullscreen overlay handles environments where native Fullscreen API is restricted
    }
  };

  useEffect(() => {
    const onFsChange = () => {
      if (!document.fullscreenElement && isFullscreen) {
        // Keep sync when user presses Esc in native fullscreen
      }
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isFullscreen) {
        setIsFullscreen(false);
      }
    };
    document.addEventListener('fullscreenchange', onFsChange);
    window.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('fullscreenchange', onFsChange);
      window.removeEventListener('keydown', onKeyDown);
    };
  }, [isFullscreen]);

  // Per-lesson saved game scores: key = `${lessonId}:${gameId}` -> best score
  const [lessonGameScores, setLessonGameScores] = useState<Record<string, number>>(() => {
    try {
      const raw = localStorage.getItem('khtn7_lesson_games_v2');
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    if (initialLessonId && ALL_KNTT_LESSONS.some((l) => l.id === initialLessonId)) {
      setSelectedLessonId(initialLessonId);
    }
  }, [initialLessonId]);

  const currentLesson: KhtnLesson = useMemo(() => {
    return (
      ALL_KNTT_LESSONS.find((l) => l.id === selectedLessonId) || ALL_KNTT_LESSONS[0]
    );
  }, [selectedLessonId]);

  const filteredLessons = useMemo(() => {
    return ALL_KNTT_LESSONS.filter(
      (l) => subjectFilter === 'all' || l.subject === subjectFilter
    );
  }, [subjectFilter]);

  const recordGameScore = (gameId: GameId, score: number) => {
    const key = `${currentLesson.id}:${gameId}`;
    setLessonGameScores((prev) => {
      const best = Math.max(prev[key] || 0, score);
      const next = { ...prev, [key]: best };
      try {
        localStorage.setItem('khtn7_lesson_games_v2', JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
    if (score > highScore) {
      onUpdateHighScore(score);
    }
  };

  const toggleSound = () => {
    soundEngine.muted = !soundMuted;
    setSoundMuted(soundEngine.muted);
    if (!soundEngine.muted) {
      soundEngine.playClick();
    }
  };

  // Count how many of the 12 games are completed for the current lesson
  const completedGamesForLesson = TWELVE_GAMES.filter(
    (g) => (lessonGameScores[`${currentLesson.id}:${g.id}`] || 0) > 0
  ).length;

  return (
    <div className="space-y-6">
      {/* ================= TOP LESSON & GAME HUB HEADER ================= */}
      <div className="rounded-3xl bg-gradient-to-r from-[#081e26] via-[#0e2f3d] to-[#0a2636] text-white p-5 sm:p-7 shadow-xl border border-teal-700/60 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 border border-amber-400/40 text-amber-300 text-xs font-extrabold">
              <Gamepad2 className="w-4 h-4" />
              <span>HỆ THỐNG 12 GAME ÔN LUYỆN THEO TỪNG BÀI HỌC (30 BÀI KHTN 7 KNTT)</span>
            </div>
            <h2 className="text-xl sm:text-2xl lg:text-3xl font-black tracking-tight">
              Đấu Trường 12 Game Tương Tác – Học Mà Chơi Theo Từng Bài
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-3xl">
              Mỗi bài học trong 30 bài SGK KHTN 7 KNTT đều có 12 trò chơi riêng biệt lấy trực tiếp ngân hàng câu hỏi của bài đó, kèm hiệu ứng âm thanh trường quay sống động.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-end gap-2.5 shrink-0">
            <TenFootUiControls
              fontScale={fontScale}
              onChangeFontScale={handleUpdateFontScale}
              isFullscreen={isFullscreen}
              onToggleFullscreen={handleToggleFullscreen}
              variant="dark"
            />

            <button
              onClick={toggleSound}
              className={`px-4 py-2.5 rounded-xl font-extrabold text-xs sm:text-sm flex items-center gap-2 border transition cursor-pointer ${
                !soundMuted
                  ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 hover:bg-emerald-500/30'
                  : 'bg-slate-800 border-slate-600 text-slate-400 hover:text-white'
              }`}
            >
              {!soundMuted ? (
                <>
                  <Volume2 className="w-4 h-4 text-emerald-400" />
                  <span>Âm thanh: BẬT</span>
                </>
              ) : (
                <>
                  <VolumeX className="w-4 h-4 text-rose-400" />
                  <span>Âm thanh: TẮT</span>
                </>
              )}
            </button>

            <div className="px-4 py-2.5 rounded-xl bg-amber-400 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow">
              <Trophy className="w-4 h-4" />
              <span>
                Đã chinh phục: {completedGamesForLesson}/12 Game (Bài {currentLesson.lessonNumber})
              </span>
            </div>
          </div>
        </div>

        {/* 10-Foot UI Classroom Projector & TV Banner */}
        <div className="rounded-2xl bg-gradient-to-r from-amber-400/15 via-cyan-400/15 to-emerald-400/15 border border-amber-300/40 p-3.5 sm:px-4 flex flex-col lg:flex-row lg:items-center justify-between gap-2.5">
          <div className="flex items-start sm:items-center gap-2.5 text-xs sm:text-sm">
            <span className="p-2 rounded-xl bg-amber-400 text-slate-950 font-black shrink-0">
              <Monitor className="w-4 h-4" />
            </span>
            <div>
              <span className="font-black text-amber-300">
                Tối ưu Hiển thị cho Máy chiếu &amp; Tivi Lớp học (10-Foot UI):{' '}
              </span>
              <span className="text-slate-100 font-semibold">
                Sử dụng nút <strong className="text-amber-300">🔍 Chữ: A / A+ / A++</strong> và{' '}
                <strong className="text-cyan-300">⛶ Toàn màn hình</strong> trên góc phải màn hình chơi để câu hỏi luôn rõ nét ở khoảng cách 5–8 mét trong phòng học nhiều ánh sáng.
              </span>
            </div>
          </div>
          <span className="px-3 py-1 rounded-full bg-black/40 border border-amber-300/40 text-[11px] font-black text-amber-300 shrink-0 self-start lg:self-center">
            Đang chọn cỡ chữ: {fontScale} {fontScale === 'A++' ? '(Cực đại 5–8m)' : fontScale === 'A+' ? '(Máy chiếu 5m)' : '(Chuẩn)'}
          </span>
        </div>

        {/* LESSON PICKER BAR */}
        <div className="bg-white/10 backdrop-blur-xs rounded-2xl p-4 border border-white/15 space-y-3">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-extrabold uppercase tracking-wider text-teal-300 mr-1">
                1. Chọn phân môn:
              </span>
              {[
                { id: 'all' as const, label: 'Tất cả (30 bài)' },
                { id: 'chemistry' as const, label: '🧪 Hóa học (6 bài)' },
                { id: 'physics' as const, label: '⚡ Vật lí (14 bài)' },
                { id: 'biology' as const, label: '🌿 Sinh học (10 bài)' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => {
                    soundEngine.playClick();
                    setSubjectFilter(tab.id);
                    const list = ALL_KNTT_LESSONS.filter(
                      (l) => tab.id === 'all' || l.subject === tab.id
                    );
                    if (list.length > 0 && !list.some((l) => l.id === selectedLessonId)) {
                      setSelectedLessonId(list[0].id);
                    }
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                    subjectFilter === tab.id
                      ? 'bg-emerald-400 text-slate-950 shadow'
                      : 'bg-slate-900/60 text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 text-xs text-amber-300 font-bold">
              <Sparkles className="w-4 h-4 shrink-0" />
              <span>
                Ngân hàng bài đang chọn: {currentLesson.mcqs.length} câu TN ·{' '}
                {currentLesson.trueFalseList.length * 4} mệnh đề Đ/S
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center gap-2.5">
            <label className="text-xs font-extrabold uppercase tracking-wider text-amber-300 shrink-0">
              2. Chọn Bài học cần chơi Game:
            </label>
            <select
              value={selectedLessonId}
              onChange={(e) => {
                soundEngine.playClick();
                setSelectedLessonId(e.target.value);
              }}
              className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950/90 text-white border border-teal-400/50 font-bold text-xs sm:text-sm focus:outline-none focus:border-amber-400 cursor-pointer"
            >
              {filteredLessons.map((lesson) => (
                <option key={lesson.id} value={lesson.id}>
                  {lesson.title} ({lesson.chapterTitle}) — {lesson.mcqs.length} câu TN
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* ================= IF NO GAME SELECTED: SHOW 12 GAME CARDS GRID ================= */}
      {!activeGameId ? (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-1">
            <div>
              <h3 className="text-lg sm:text-xl font-black text-slate-900">
                Chọn 1 trong 12 Game để ôn luyện: <span className="text-teal-700">{currentLesson.title}</span>
              </h3>
              <p className="text-xs sm:text-sm text-slate-600">
                Tất cả câu hỏi, mật mã, ô chữ và manh mối trong 12 game dưới đây đều thuộc riêng <strong>{currentLesson.title}</strong>.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
            {TWELVE_GAMES.map((game) => {
              const bestForThisLesson =
                lessonGameScores[`${currentLesson.id}:${game.id}`] || 0;

              return (
                <div
                  key={game.id}
                  onClick={() => {
                    soundEngine.playClick();
                    setActiveGameId(game.id);
                  }}
                  className="group relative rounded-3xl bg-white border-2 border-slate-200 hover:border-teal-500 shadow-sm hover:shadow-xl transition-all overflow-hidden flex flex-col justify-between cursor-pointer"
                >
                  {/* Top Visual Banner */}
                  <div
                    className={`bg-gradient-to-br ${game.gradient} p-5 text-white relative overflow-hidden`}
                  >
                    <div className="flex items-start justify-between gap-2 relative z-10">
                      <span className="px-2.5 py-1 rounded-full bg-black/30 backdrop-blur-xs text-[10px] font-black uppercase tracking-wider text-amber-300 border border-white/15">
                        GAME #{game.number} · {game.badge}
                      </span>
                      <span className="text-3xl sm:text-4xl transform group-hover:scale-110 transition-transform">
                        {game.emoji}
                      </span>
                    </div>

                    <div className="mt-3 relative z-10">
                      <h4 className="text-lg sm:text-xl font-black tracking-tight text-white">
                        {game.title}
                      </h4>
                      <p className="text-xs font-bold text-white/85 mt-0.5">
                        {game.subtitle}
                      </p>
                    </div>
                  </div>

                  {/* Card Body */}
                  <div className="p-5 flex-1 flex flex-col justify-between gap-4">
                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                      {game.description}
                    </p>

                    <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                      <div className="text-xs font-bold text-slate-600">
                        {bestForThisLesson > 0 ? (
                          <span className="inline-flex items-center gap-1 text-emerald-700 font-extrabold">
                            <Trophy className="w-3.5 h-3.5 text-amber-500" />
                            Kỷ lục bài này: {bestForThisLesson} đ
                          </span>
                        ) : (
                          <span className="text-slate-400">Chưa chơi ở bài này</span>
                        )}
                      </div>

                      <span className="px-4 py-2 rounded-xl bg-[#081e26] group-hover:bg-teal-600 text-white text-xs font-black transition flex items-center gap-1.5">
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Vào chơi ngay</span>
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* ================= ACTIVE GAME STAGE CONTAINER (10-FOOT UI READY) ================= */
        <div
          ref={gameStageContainerRef}
          data-font-scale={fontScale}
          className={`ten-foot-game-stage space-y-4 transition-all ${
            isFullscreen
              ? 'fixed inset-0 z-[90] overflow-y-auto bg-[#030b12] p-4 sm:p-6 lg:p-8'
              : ''
          }`}
        >
          {/* Top Bar inside Active Game — with Top-Right 10-Foot UI Controls (🔍 Chữ: A / A+ / A++ & ⛶ Toàn màn hình) */}
          <div className="bg-slate-900 text-white rounded-2xl border-2 border-teal-500/60 p-3.5 sm:px-5 flex flex-col xl:flex-row xl:items-center justify-between gap-3 shadow-lg">
            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={() => {
                  soundEngine.playClick();
                  if (isFullscreen) {
                    handleToggleFullscreen();
                  }
                  setActiveGameId(null);
                }}
                className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-extrabold text-xs sm:text-sm flex items-center gap-2 border border-white/15 transition cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Quay lại Sảnh 12 Game</span>
              </button>

              <div className="flex items-center gap-2 text-xs sm:text-sm font-black text-white">
                <span className="px-2.5 py-1 rounded-lg bg-teal-400 text-slate-950">
                  Bài {currentLesson.lessonNumber}
                </span>
                <span className="truncate max-w-xs sm:max-w-md text-amber-300">
                  {currentLesson.title}
                </span>
              </div>
            </div>

            {/* Quick Game Switcher Pills + Top-Right 10-Foot UI Controls */}
            <div className="flex flex-wrap items-center justify-between xl:justify-end gap-2.5">
              <div className="flex items-center gap-1 overflow-x-auto py-1 max-w-full">
                {TWELVE_GAMES.map((g) => (
                  <button
                    key={g.id}
                    onClick={() => {
                      soundEngine.playClick();
                      setActiveGameId(g.id);
                    }}
                    title={g.title}
                    className={`px-2 py-1.5 rounded-lg text-xs font-extrabold transition shrink-0 cursor-pointer ${
                      activeGameId === g.id
                        ? 'bg-teal-500 text-slate-950 shadow font-black'
                        : 'bg-white/10 hover:bg-white/20 text-slate-200'
                    }`}
                  >
                    {g.emoji} #{g.number}
                  </button>
                ))}
              </div>

              {/* Top-Right Corner: 🔍 Chữ: A / A+ / A++ and ⛶ Toàn màn hình */}
              <TenFootUiControls
                fontScale={fontScale}
                onChangeFontScale={handleUpdateFontScale}
                isFullscreen={isFullscreen}
                onToggleFullscreen={handleToggleFullscreen}
                variant="dark"
              />
            </div>
          </div>

          {/* Render the selected Game Stage */}
          {activeGameId === 'golden_bell' && (
            <GoldenBellGame
              key={currentLesson.id}
              lesson={currentLesson}
              onSaveScore={(s) => recordGameScore('golden_bell', s)}
            />
          )}
          {activeGameId === 'millionaire' && (
            <MillionaireGame
              key={currentLesson.id}
              lesson={currentLesson}
              onSaveScore={(s) => recordGameScore('millionaire', s)}
            />
          )}
          {activeGameId === 'wheel_of_fortune' && (
            <WheelOfFortuneGame
              key={currentLesson.id}
              lesson={currentLesson}
              onSaveScore={(s) => recordGameScore('wheel_of_fortune', s)}
            />
          )}
          {activeGameId === 'gold_miner' && (
            <GoldMinerGame
              key={currentLesson.id}
              lesson={currentLesson}
              onSaveScore={(s) => recordGameScore('gold_miner', s)}
            />
          )}
          {activeGameId === 'speed_racer' && (
            <SpeedRacerGame
              key={currentLesson.id}
              lesson={currentLesson}
              onSaveScore={(s) => recordGameScore('speed_racer', s)}
            />
          )}
          {activeGameId === 'minesweeper' && (
            <MinesweeperGame
              key={currentLesson.id}
              lesson={currentLesson}
              onSaveScore={(s) => recordGameScore('minesweeper', s)}
            />
          )}
          {activeGameId === 'treasure_hunt' && (
            <TreasureHuntGame
              key={currentLesson.id}
              lesson={currentLesson}
              onSaveScore={(s) => recordGameScore('treasure_hunt', s)}
            />
          )}
          {activeGameId === 'escape_room' && (
            <EscapeRoomGame
              key={currentLesson.id}
              lesson={currentLesson}
              onSaveScore={(s) => recordGameScore('escape_room', s)}
            />
          )}
          {activeGameId === 'memory_match' && (
            <MemoryMatchGame
              key={currentLesson.id}
              lesson={currentLesson}
              onSaveScore={(s) => recordGameScore('memory_match', s)}
            />
          )}
          {activeGameId === 'science_detective' && (
            <ScienceDetectiveGame
              key={currentLesson.id}
              lesson={currentLesson}
              onSaveScore={(s) => recordGameScore('science_detective', s)}
            />
          )}
          {activeGameId === 'crossword_decoder' && (
            <CrosswordDecoderGame
              key={currentLesson.id}
              lesson={currentLesson}
              onSaveScore={(s) => recordGameScore('crossword_decoder', s)}
            />
          )}
          {activeGameId === 'boss_battle' && (
            <BossBattleGame
              key={currentLesson.id}
              lesson={currentLesson}
              onSaveScore={(s) => recordGameScore('boss_battle', s)}
            />
          )}
        </div>
      )}
    </div>
  );
};

/* ============================================================================
   GAME 1: RUNG CHUÔNG VÀNG (GOLDEN BELL ARENA)
   ============================================================================ */
const GoldenBellGame: React.FC<{
  lesson: KhtnLesson;
  onSaveScore: (score: number) => void;
}> = ({ lesson, onSaveScore }) => {
  const questions = useMemo(() => lesson.mcqs.slice(0, 15), [lesson]);
  const [qIdx, setQIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [survivors, setSurvivors] = useState(100);
  const [timeLeft, setTimeLeft] = useState(15);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [usedPaperPlane, setUsedPaperPlane] = useState(false);
  const [usedTeacherRescue, setUsedTeacherRescue] = useState(false);
  const [eliminatedOpts, setEliminatedOpts] = useState<number[]>([]);
  const [gameOver, setGameOver] = useState(false);
  const [wonBell, setWonBell] = useState(false);

  const currentQ = questions[qIdx] || questions[0];

  useEffect(() => {
    if (gameOver || wonBell || selectedOpt !== null) return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          soundEngine.playWrong();
          setGameOver(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [qIdx, gameOver, wonBell, selectedOpt]);

  const handleAnswer = (idx: number) => {
    if (selectedOpt !== null || gameOver || wonBell) return;
    setSelectedOpt(idx);
    if (idx === currentQ.correctIndex) {
      soundEngine.playGoldenBell();
      const gained = 100 + timeLeft * 10;
      const nextScore = score + gained;
      setScore(nextScore);
      onSaveScore(nextScore);
      // Random AI contestants drop out each question
      setSurvivors((prev) => Math.max(1, prev - Math.floor(Math.random() * 7 + 3)));
    } else {
      soundEngine.playWrong();
      if (!usedTeacherRescue) {
        // Prompt teacher rescue option
      } else {
        setGameOver(true);
      }
    }
  };

  const handleNextQuestion = () => {
    if (qIdx + 1 >= questions.length) {
      soundEngine.playVictory();
      setWonBell(true);
      onSaveScore(score + 500);
    } else {
      setQIdx(qIdx + 1);
      setSelectedOpt(null);
      setEliminatedOpts([]);
      setTimeLeft(15);
    }
  };

  const handlePaperPlaneHint = () => {
    if (usedPaperPlane || selectedOpt !== null) return;
    soundEngine.playClick();
    setUsedPaperPlane(true);
    const wrongIndices = [0, 1, 2, 3].filter((i) => i !== currentQ.correctIndex);
    setEliminatedOpts(wrongIndices.slice(0, 2));
  };

  const handleTeacherRescue = () => {
    if (usedTeacherRescue) return;
    soundEngine.playGoldenBell();
    setUsedTeacherRescue(true);
    setSelectedOpt(currentQ.correctIndex);
    setGameOver(false);
  };

  const resetGame = () => {
    setQIdx(0);
    setScore(0);
    setSurvivors(100);
    setTimeLeft(15);
    setSelectedOpt(null);
    setUsedPaperPlane(false);
    setUsedTeacherRescue(false);
    setEliminatedOpts([]);
    setGameOver(false);
    setWonBell(false);
  };

  return (
    <div className="rounded-3xl bg-gradient-to-br from-amber-950 via-yellow-900 to-stone-950 text-white p-5 sm:p-8 shadow-2xl border-2 border-amber-400/60 space-y-6">
      {/* Studio Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-amber-400/30 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center shadow-lg">
            <Bell className="w-7 h-7 animate-bounce" />
          </div>
          <div>
            <span className="text-xs font-black uppercase tracking-wider text-amber-300">
              SÀN ĐẤU RUNG CHUÔNG VÀNG · CÂU {qIdx + 1}/{questions.length}
            </span>
            <h3 className="text-xl sm:text-2xl font-black text-white">{lesson.title}</h3>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="px-4 py-2 rounded-xl bg-black/40 border border-amber-400/40 text-xs sm:text-sm font-black">
            👨‍🎓 Thí sinh còn trên sàn: <span className="text-amber-300">{survivors}/100</span>
          </div>
          <div className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 text-xs sm:text-sm font-black">
            🏆 Điểm: {score}
          </div>
          <div
            className={`px-4 py-2 rounded-xl font-black text-sm flex items-center gap-1.5 ${
              timeLeft <= 5 ? 'bg-rose-600 text-white animate-pulse' : 'bg-emerald-600 text-white'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>{timeLeft}s</span>
          </div>
        </div>
      </div>

      {/* 100 Contestants Mini Floor Visualizer + Lifelines */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-4 bg-black/35 rounded-2xl p-4 border border-amber-400/30 space-y-4">
          <div className="flex items-center justify-between text-xs font-extrabold text-amber-200">
            <span>SÀN THI ĐẤU 100 THÍ SINH</span>
            <span>Còn {survivors} HS</span>
          </div>

          <div className="grid grid-cols-10 gap-1">
            {Array.from({ length: 100 }).map((_, idx) => {
              const isMe = idx === 0;
              const isAlive = idx < survivors;
              return (
                <div
                  key={idx}
                  className={`h-4 rounded-sm flex items-center justify-center text-[9px] font-black transition-all ${
                    isMe
                      ? 'bg-emerald-400 text-slate-950 ring-2 ring-white'
                      : isAlive
                      ? 'bg-amber-400/80 text-slate-950'
                      : 'bg-white/10 text-transparent'
                  }`}
                  title={isMe ? 'Bạn đang ở vị trí số 1' : `Thí sinh #${idx + 1}`}
                >
                  {isMe ? '★' : ''}
                </div>
              );
            })}
          </div>

          {/* Rescue Lifelines */}
          <div className="space-y-2 pt-2 border-t border-white/10">
            <p className="text-xs font-bold text-amber-300">QUYỀN CỨU TRỢ TRÊN SÀN:</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handlePaperPlaneHint}
                disabled={usedPaperPlane || selectedOpt !== null}
                className={`p-2.5 rounded-xl text-xs font-extrabold border transition cursor-pointer ${
                  usedPaperPlane
                    ? 'bg-white/5 border-white/10 text-white/40 cursor-not-allowed'
                    : 'bg-amber-500/20 hover:bg-amber-500/35 border-amber-400 text-amber-200'
                }`}
              >
                ✈️ Máy bay giấy (Loại 2 đáp án)
              </button>
              <button
                onClick={handleTeacherRescue}
                disabled={usedTeacherRescue}
                className={`p-2.5 rounded-xl text-xs font-extrabold border transition cursor-pointer ${
                  usedTeacherRescue
                    ? 'bg-white/5 border-white/10 text-white/40 cursor-not-allowed'
                    : 'bg-emerald-500/20 hover:bg-emerald-500/35 border-emerald-400 text-emerald-200'
                }`}
              >
                🛟 Phao cứu trợ Thầy Cô
              </button>
            </div>
          </div>
        </div>

        {/* Question Slate Board */}
        <div className="lg:col-span-8 space-y-4">
          {wonBell ? (
            <div className="bg-gradient-to-br from-amber-400 to-yellow-500 text-slate-950 rounded-3xl p-8 text-center space-y-4 shadow-2xl">
              <div className="text-6xl">🔔👑</div>
              <h4 className="text-2xl sm:text-3xl font-black">
                CHÚC MỪNG BẠN ĐÃ RUNG ĐƯỢC CHUÔNG VÀNG!
              </h4>
              <p className="text-sm sm:text-base font-bold">
                Bạn đã vượt qua toàn bộ 15 câu hỏi của {lesson.title} với tổng điểm{' '}
                <strong>{score + 500} điểm</strong>!
              </p>
              <button
                onClick={resetGame}
                className="px-6 py-3 rounded-xl bg-slate-950 text-amber-300 font-black text-sm cursor-pointer"
              >
                Chơi lại từ đầu
              </button>
            </div>
          ) : (
            <div className="bg-slate-900/90 border-4 border-amber-400 rounded-3xl p-6 space-y-5 shadow-xl">
              <div className="flex items-center justify-between text-xs font-extrabold text-amber-300">
                <span>BẢNG ĐEN THÍ SINH · CÂU SỐ {qIdx + 1}</span>
                <span>Mức độ: {currentQ.level || 'Thông hiểu'}</span>
              </div>

              <h4 className="ten-foot-question text-lg sm:text-xl font-black text-white leading-relaxed">
                {currentQ.question}
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {currentQ.options.map((opt, idx) => {
                  const isEliminated = eliminatedOpts.includes(idx);
                  if (isEliminated) {
                    return (
                      <div
                        key={idx}
                        className="ten-foot-option p-4 rounded-2xl border border-white/10 bg-white/5 text-white/30 text-sm font-bold line-through"
                      >
                        {String.fromCharCode(65 + idx)}. {opt}
                      </div>
                    );
                  }

                  let btnStyle =
                    'bg-white/10 hover:bg-amber-400/20 border-white/20 text-white';
                  if (selectedOpt !== null) {
                    if (idx === currentQ.correctIndex) {
                      btnStyle = 'bg-emerald-600 border-emerald-300 text-white shadow-lg';
                    } else if (idx === selectedOpt) {
                      btnStyle = 'bg-rose-600 border-rose-300 text-white';
                    }
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => handleAnswer(idx)}
                      disabled={selectedOpt !== null}
                      className={`ten-foot-option p-4 rounded-2xl border-2 text-left font-bold text-sm transition flex items-start gap-2.5 cursor-pointer ${btnStyle}`}
                    >
                      <span className="w-6 h-6 rounded-lg bg-amber-400 text-slate-950 font-black flex items-center justify-center shrink-0 text-xs">
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span>{opt}</span>
                    </button>
                  );
                })}
              </div>

              {selectedOpt !== null && (
                <div className="p-4 rounded-2xl bg-black/50 border border-amber-400/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-sm font-black ${
                        selectedOpt === currentQ.correctIndex
                          ? 'text-emerald-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {selectedOpt === currentQ.correctIndex
                        ? '🔔 CHÍNH XÁC! Bạn tiếp tục ở lại sàn thi đấu!'
                        : '❌ SAI RỒI! Bạn có nguy cơ bị loại khỏi sàn!'}
                    </span>

                    {selectedOpt === currentQ.correctIndex ? (
                      <button
                        onClick={handleNextQuestion}
                        className="px-5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm cursor-pointer"
                      >
                        Câu tiếp theo →
                      </button>
                    ) : !usedTeacherRescue ? (
                      <button
                        onClick={handleTeacherRescue}
                        className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-black text-xs cursor-pointer"
                      >
                        🛟 Dùng Phao cứu trợ để đi tiếp!
                      </button>
                    ) : (
                      <button
                        onClick={resetGame}
                        className="px-4 py-2 rounded-xl bg-rose-600 text-white font-black text-xs cursor-pointer"
                      >
                        Thi đấu lại
                      </button>
                    )}
                  </div>
                  <p className="text-xs text-slate-300">
                    <strong>Giải thích:</strong> {currentQ.explanation}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

/* ============================================================================
   GAME 2: AI LÀ TRIỆU PHÚ KHTN (WHO WANTS TO BE A MILLIONAIRE)
   ============================================================================ */
const MillionaireGame: React.FC<{
  lesson: KhtnLesson;
  onSaveScore: (score: number) => void;
}> = ({ lesson, onSaveScore }) => {
  const questions = useMemo(() => lesson.mcqs.slice(0, 15), [lesson]);
  const [qIdx, setQIdx] = useState(0);
  const [lockedIdx, setLockedIdx] = useState<number | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [victory, setVictory] = useState(false);

  // 4 Lifelines
  const [used5050, setUsed5050] = useState(false);
  const [usedAudience, setUsedAudience] = useState(false);
  const [usedPhone, setUsedPhone] = useState(false);
  const [usedSwap, setUsedSwap] = useState(false);

  const [hiddenOptions, setHiddenOptions] = useState<number[]>([]);
  const [helperMessage, setHelperMessage] = useState<string | null>(null);

  const currentQ = questions[qIdx] || questions[0];

  const handleSelectOption = (idx: number) => {
    if (lockedIdx !== null || gameOver || victory) return;
    soundEngine.playMillionaireLock();
    setLockedIdx(idx);

    setTimeout(() => {
      setRevealed(true);
      if (idx === currentQ.correctIndex) {
        soundEngine.playCorrect();
        onSaveScore((qIdx + 1) * 100);
      } else {
        soundEngine.playWrong();
        setGameOver(true);
      }
    }, 650);
  };

  const handleNextLevel = () => {
    if (qIdx + 1 >= questions.length) {
      soundEngine.playVictory();
      setVictory(true);
      onSaveScore(2000);
    } else {
      setQIdx(qIdx + 1);
      setLockedIdx(null);
      setRevealed(false);
      setHiddenOptions([]);
      setHelperMessage(null);
    }
  };

  const trigger5050 = () => {
    if (used5050 || lockedIdx !== null) return;
    soundEngine.playClick();
    setUsed5050(true);
    const wrongs = [0, 1, 2, 3].filter((i) => i !== currentQ.correctIndex);
    setHiddenOptions(wrongs.slice(0, 2));
  };

  const triggerAudience = () => {
    if (usedAudience || lockedIdx !== null) return;
    soundEngine.playClick();
    setUsedAudience(true);
    const correctLetter = String.fromCharCode(65 + currentQ.correctIndex);
    setHelperMessage(
      `📊 Khảo sát Khán giả trường quay: 76% khán giả bình chọn phương án ${correctLetter} là đáp án đúng!`
    );
  };

  const triggerPhone = () => {
    if (usedPhone || lockedIdx !== null) return;
    soundEngine.playClick();
    setUsedPhone(true);
    const correctLetter = String.fromCharCode(65 + currentQ.correctIndex);
    setHelperMessage(
      `📞 Giáo sư KHTN 7 tư vấn: "Theo kiến thức ${lesson.title}, tôi chắc chắn đáp án đúng là ${correctLetter}. ${currentQ.explanation}"`
    );
  };

  const triggerSwap = () => {
    if (usedSwap || lockedIdx !== null) return;
    soundEngine.playClick();
    setUsedSwap(true);
    setHelperMessage('🔄 Đã đổi sang góc nhìn gợi ý trực tiếp: Đáp án đúng là ' + String.fromCharCode(65 + currentQ.correctIndex));
  };

  const resetMillionaire = () => {
    setQIdx(0);
    setLockedIdx(null);
    setRevealed(false);
    setGameOver(false);
    setVictory(false);
    setUsed5050(false);
    setUsedAudience(false);
    setUsedPhone(false);
    setUsedSwap(false);
    setHiddenOptions([]);
    setHelperMessage(null);
  };

  return (
    <div className="rounded-3xl bg-gradient-to-b from-[#070b24] via-[#101942] to-[#080d26] text-white p-5 sm:p-8 shadow-2xl border-2 border-indigo-400/50 grid grid-cols-1 xl:grid-cols-12 gap-6">
      {/* Left 8 Cols: Studio Stage & Hexagonal Pods */}
      <div className="xl:col-span-8 space-y-5 flex flex-col justify-between">
        <div className="space-y-4">
          {/* Header & Lifelines */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-indigo-500/30 pb-4">
            <div>
              <span className="text-xs font-extrabold uppercase tracking-wider text-amber-400">
                TRƯỜNG QUAY AI LÀ TRIỆU PHÚ KHTN 7
              </span>
              <h3 className="text-xl font-black text-white">{lesson.title}</h3>
            </div>

            {/* 4 Iconic Lifelines */}
            <div className="flex items-center gap-2">
              <button
                onClick={trigger5050}
                disabled={used5050 || lockedIdx !== null}
                className={`px-3 py-2 rounded-full border-2 font-black text-xs transition cursor-pointer ${
                  used5050
                    ? 'border-slate-700 bg-slate-900 text-slate-600 line-through'
                    : 'border-amber-400 bg-indigo-950 hover:bg-indigo-800 text-amber-300'
                }`}
              >
                50:50
              </button>
              <button
                onClick={triggerAudience}
                disabled={usedAudience || lockedIdx !== null}
                className={`px-3 py-2 rounded-full border-2 font-black text-xs flex items-center gap-1 transition cursor-pointer ${
                  usedAudience
                    ? 'border-slate-700 bg-slate-900 text-slate-600 line-through'
                    : 'border-amber-400 bg-indigo-950 hover:bg-indigo-800 text-amber-300'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>Khán giả</span>
              </button>
              <button
                onClick={triggerPhone}
                disabled={usedPhone || lockedIdx !== null}
                className={`px-3 py-2 rounded-full border-2 font-black text-xs flex items-center gap-1 transition cursor-pointer ${
                  usedPhone
                    ? 'border-slate-700 bg-slate-900 text-slate-600 line-through'
                    : 'border-amber-400 bg-indigo-950 hover:bg-indigo-800 text-amber-300'
                }`}
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Gọi GS</span>
              </button>
              <button
                onClick={triggerSwap}
                disabled={usedSwap || lockedIdx !== null}
                className={`px-3 py-2 rounded-full border-2 font-black text-xs transition cursor-pointer ${
                  usedSwap
                    ? 'border-slate-700 bg-slate-900 text-slate-600 line-through'
                    : 'border-amber-400 bg-indigo-950 hover:bg-indigo-800 text-amber-300'
                }`}
              >
                🔄 Tư vấn
              </button>
            </div>
          </div>

          {helperMessage && (
            <div className="p-4 rounded-2xl bg-indigo-950/90 border border-amber-400 text-amber-200 text-xs sm:text-sm font-bold">
              {helperMessage}
            </div>
          )}

          {/* Hexagonal Question Banner */}
          <div className="rounded-3xl bg-gradient-to-r from-indigo-950 via-blue-950 to-indigo-950 border-2 border-indigo-400 p-6 shadow-inner space-y-2">
            <div className="flex items-center justify-between text-xs font-extrabold text-amber-400">
              <span>CÂU HỎI SỐ {qIdx + 1} / 15</span>
              <span>MỐC THƯỞNG: {MILLIONAIRE_LADDER[qIdx]}</span>
            </div>
            <p className="ten-foot-question text-base sm:text-lg font-black text-white leading-relaxed">
              {currentQ.question}
            </p>
          </div>

          {/* 4 Hexagonal Answer Pods */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {currentQ.options.map((opt, idx) => {
              if (hiddenOptions.includes(idx)) {
                return (
                  <div
                    key={idx}
                    className="ten-foot-option p-4 rounded-2xl border border-indigo-900/50 bg-indigo-950/30 text-transparent select-none"
                  >
                    .
                  </div>
                );
              }

              let podStyle =
                'bg-[#0d163a] hover:bg-indigo-900/80 border-indigo-400/70 text-white';
              if (lockedIdx === idx && !revealed) {
                podStyle = 'bg-amber-500 border-amber-200 text-slate-950 animate-pulse';
              } else if (revealed) {
                if (idx === currentQ.correctIndex) {
                  podStyle = 'bg-emerald-600 border-emerald-300 text-white shadow-lg';
                } else if (idx === lockedIdx) {
                  podStyle = 'bg-rose-600 border-rose-300 text-white';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  disabled={lockedIdx !== null}
                  className={`ten-foot-option p-4 rounded-2xl border-2 text-left font-bold text-sm transition flex items-start gap-3 cursor-pointer ${podStyle}`}
                >
                  <span className="text-amber-400 font-black shrink-0">
                    ♦ {String.fromCharCode(65 + idx)}:
                  </span>
                  <span>{opt}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom Status / Next Button */}
        {revealed && (
          <div className="p-4 rounded-2xl bg-black/50 border border-indigo-400/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="text-sm font-black text-amber-300">
                {gameOver
                  ? 'Rất tiếc! Bạn dừng cuộc chơi tại đây.'
                  : victory
                  ? '🏆 CHÚC MỪNG TRIỆU PHÚ KHOA HỌC TỰ NHIÊN 7!'
                  : `Chính xác! Bạn đã chinh phục mốc ${MILLIONAIRE_LADDER[qIdx]}`}
              </div>
              <p className="text-xs text-slate-300">{currentQ.explanation}</p>
            </div>

            {gameOver || victory ? (
              <button
                onClick={resetMillionaire}
                className="px-5 py-2.5 rounded-xl bg-amber-400 text-slate-950 font-black text-xs sm:text-sm shrink-0 cursor-pointer"
              >
                Chơi ván mới
              </button>
            ) : (
              <button
                onClick={handleNextLevel}
                className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs sm:text-sm shrink-0 cursor-pointer"
              >
                Lên mốc câu {qIdx + 2} →
              </button>
            )}
          </div>
        )}
      </div>

      {/* Right 4 Cols: 15-Level Money Tree Ladder */}
      <div className="xl:col-span-4 bg-[#060a1f] rounded-2xl p-4 border border-indigo-500/40 flex flex-col-reverse gap-1">
        {MILLIONAIRE_LADDER.map((prize, idx) => {
          const isCurrent = idx === qIdx;
          const isPassed = idx < qIdx;
          const isMilestone = idx === 4 || idx === 9 || idx === 14;

          return (
            <div
              key={idx}
              className={`px-3 py-1.5 rounded-lg text-xs font-black flex items-center justify-between ${
                isCurrent
                  ? 'bg-amber-400 text-slate-950 shadow'
                  : isPassed
                  ? 'text-emerald-400 bg-emerald-950/30'
                  : isMilestone
                  ? 'text-white bg-indigo-950/60'
                  : 'text-amber-400/80'
              }`}
            >
              <span>Câu {idx + 1}</span>
              <span>{prize}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* ============================================================================
   GAME 3: CHIẾC NÓN KÌ DIỆU – VÒNG QUAY TRI THỨC (WHEEL OF KNOWLEDGE)
   ============================================================================ */
const WheelOfFortuneGame: React.FC<{
  lesson: KhtnLesson;
  onSaveScore: (score: number) => void;
}> = ({ lesson, onSaveScore }) => {
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [currentWedge, setCurrentWedge] = useState<typeof WHEEL_WEDGES[0] | null>(null);
  const [qIdx, setQIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [answeredOpt, setAnsweredOpt] = useState<number | null>(null);

  const currentQ = lesson.mcqs[qIdx % lesson.mcqs.length];

  const handleSpinWheel = () => {
    if (spinning) return;
    setAnsweredOpt(null);
    setSpinning(true);

    // Play wheel tick sounds
    let ticks = 0;
    const tickInterval = setInterval(() => {
      soundEngine.playWheelTick();
      ticks++;
      if (ticks > 14) clearInterval(tickInterval);
    }, 140);

    const extraSpins = 360 * 4 + Math.floor(Math.random() * 360);
    const nextRot = rotation + extraSpins;
    setRotation(nextRot);

    setTimeout(() => {
      clearInterval(tickInterval);
      setSpinning(false);
      const wedgeIndex = Math.floor(((360 - (nextRot % 360)) % 360) / 30) % WHEEL_WEDGES.length;
      setCurrentWedge(WHEEL_WEDGES[wedgeIndex]);
      soundEngine.playGoldClink();
    }, 2200);
  };

  const handleAnswerWheelQuestion = (idx: number) => {
    if (answeredOpt !== null || !currentWedge) return;
    setAnsweredOpt(idx);
    if (idx === currentQ.correctIndex) {
      soundEngine.playCorrect();
      const nextScore =
        currentWedge.type === 'double'
          ? Math.max(600, score * 2)
          : score + currentWedge.points;
      setScore(nextScore);
      onSaveScore(nextScore);
    } else {
      soundEngine.playWrong();
    }
  };

  return (
    <div className="rounded-3xl bg-gradient-to-br from-rose-950 via-purple-950 to-slate-950 text-white p-5 sm:p-8 shadow-2xl border-2 border-pink-400/50 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
      {/* Left 5 Cols: Interactive Spinning SVG Wheel */}
      <div className="lg:col-span-5 flex flex-col items-center space-y-4">
        <div className="relative w-64 h-64 sm:w-72 sm:h-72 flex items-center justify-center">
          {/* Pointer Arrow at Top */}
          <div className="absolute -top-3 z-20 text-3xl drop-shadow-lg">🔻</div>

          <svg
            viewBox="0 0 200 200"
            className="w-full h-full rounded-full border-4 border-amber-300 shadow-2xl transition-transform duration-[2200ms] ease-out"
            style={{ transform: `rotate(${rotation}deg)` }}
          >
            {WHEEL_WEDGES.map((w, i) => {
              const startAngle = (i * 30 * Math.PI) / 180;
              const endAngle = ((i + 1) * 30 * Math.PI) / 180;
              const x1 = 100 + 100 * Math.sin(startAngle);
              const y1 = 100 - 100 * Math.cos(startAngle);
              const x2 = 100 + 100 * Math.sin(endAngle);
              const y2 = 100 - 100 * Math.cos(endAngle);
              const midAngle = i * 30 + 15;

              return (
                <g key={i}>
                  <path
                    d={`M 100 100 L ${x1} ${y1} A 100 100 0 0 1 ${x2} ${y2} Z`}
                    fill={w.color}
                    stroke="#ffffff"
                    strokeWidth="1"
                  />
                  <text
                    x="100"
                    y="32"
                    fill="#ffffff"
                    fontSize="6.5"
                    fontWeight="900"
                    textAnchor="middle"
                    transform={`rotate(${midAngle}, 100, 100)`}
                  >
                    {w.label}
                  </text>
                </g>
              );
            })}
            <circle cx="100" cy="100" r="18" fill="#fef08a" stroke="#ca8a04" strokeWidth="3" />
          </svg>
        </div>

        <button
          onClick={handleSpinWheel}
          disabled={spinning}
          className="px-7 py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-300 hover:from-amber-300 hover:to-yellow-200 text-slate-950 font-black text-sm shadow-xl transition cursor-pointer"
        >
          {spinning ? '🎡 Đang quay Chiếc Nón...' : '🎡 QUAY CHIẾC NÓN KÌ DIỆU'}
        </button>

        <div className="px-4 py-2 rounded-xl bg-white/10 border border-white/20 text-sm font-black">
          Tổng điểm tích lũy: <span className="text-amber-300">{score} điểm</span>
        </div>
      </div>

      {/* Right 7 Cols: Question Box */}
      <div className="lg:col-span-7 bg-white/10 backdrop-blur-xs rounded-3xl p-6 border border-white/20 space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-extrabold uppercase tracking-wider text-pink-300">
            VÒNG QUAY TRI THỨC · {lesson.title}
          </span>
          {currentWedge && (
            <span className="px-3 py-1 rounded-full bg-amber-400 text-slate-950 font-black text-xs">
              Ô vừa quay: {currentWedge.label}
            </span>
          )}
        </div>

        {!currentWedge ? (
          <div className="py-12 text-center space-y-2">
            <div className="text-4xl">🎡✨</div>
            <p className="text-base font-bold text-slate-200">
              Hãy bấm nút <strong>"QUAY CHIẾC NÓN KÌ DIỆU"</strong> bên trái để nhận ô điểm thưởng và mở câu hỏi!
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <h4 className="ten-foot-question text-lg font-black text-white">{currentQ.question}</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {currentQ.options.map((opt, idx) => {
                let style = 'bg-slate-900/80 hover:bg-pink-500/20 border-white/20 text-white';
                if (answeredOpt !== null) {
                  if (idx === currentQ.correctIndex) {
                    style = 'bg-emerald-600 border-emerald-300 text-white';
                  } else if (idx === answeredOpt) {
                    style = 'bg-rose-600 border-rose-300 text-white';
                  }
                }
                return (
                  <button
                    key={idx}
                    onClick={() => handleAnswerWheelQuestion(idx)}
                    disabled={answeredOpt !== null}
                    className={`ten-foot-option p-3.5 rounded-xl border-2 text-left font-bold text-xs sm:text-sm transition cursor-pointer ${style}`}
                  >
                    <strong>{String.fromCharCode(65 + idx)}.</strong> {opt}
                  </button>
                );
              })}
            </div>

            {answeredOpt !== null && (
              <div className="p-3.5 rounded-xl bg-black/40 border border-white/15 flex items-center justify-between gap-3">
                <p className="text-xs text-slate-200">{currentQ.explanation}</p>
                <button
                  onClick={() => {
                    setQIdx((prev) => prev + 1);
                    setCurrentWedge(null);
                    setAnsweredOpt(null);
                  }}
                  className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-black text-xs shrink-0 cursor-pointer"
                >
                  Quay lượt tiếp →
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

/* ============================================================================
   GAME 4: ĐÀO VÀNG KHTN (SCIENCE GOLD MINER)
   ============================================================================ */
interface MineItem {
  id: string;
  label: string;
  emoji: string;
  value: number;
  xPercent: number;
  yPercent: number;
  collected: boolean;
}

const GoldMinerGame: React.FC<{
  lesson: KhtnLesson;
  onSaveScore: (score: number) => void;
}> = ({ lesson, onSaveScore }) => {
  const initialItems: MineItem[] = useMemo(
    () => [
      { id: 'm1', label: 'Vàng Khối Lớn', emoji: '🪙', value: 500, xPercent: 18, yPercent: 68, collected: false },
      { id: 'm2', label: 'Kim Cương Xanh', emoji: '💎', value: 800, xPercent: 34, yPercent: 45, collected: false },
      { id: 'm3', label: 'Túi Bí Ẩn KHTN', emoji: '💰', value: 650, xPercent: 50, yPercent: 75, collected: false },
      { id: 'm4', label: 'Vàng Nguyên Chất', emoji: '🪙', value: 450, xPercent: 66, yPercent: 50, collected: false },
      { id: 'm5', label: 'Kim Cương Đỏ', emoji: '💎', value: 900, xPercent: 82, yPercent: 65, collected: false },
      { id: 'm6', label: 'Rương Khoáng Sản', emoji: '👑', value: 1000, xPercent: 48, yPercent: 38, collected: false },
    ],
    []
  );

  const [items, setItems] = useState<MineItem[]>(initialItems);
  const [hookAngle, setHookAngle] = useState(0);
  const [targetItem, setTargetItem] = useState<MineItem | null>(null);
  const [qIdx, setQIdx] = useState(0);
  const [goldScore, setGoldScore] = useState(0);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Swing hook angle continuously when no item is hooked
  useEffect(() => {
    if (targetItem) return;
    let dir = 1;
    const timer = setInterval(() => {
      setHookAngle((prev) => {
        if (prev >= 55) dir = -1;
        if (prev <= -55) dir = 1;
        return prev + dir * 5;
      });
    }, 60);
    return () => clearInterval(timer);
  }, [targetItem]);

  const currentQ = lesson.mcqs[qIdx % lesson.mcqs.length];

  const handleGrabItem = (item: MineItem) => {
    if (item.collected) return;
    soundEngine.playClick();
    setTargetItem(item);
    setFeedback(null);
  };

  const handleAnswerToReel = (optIdx: number) => {
    if (!targetItem) return;
    if (optIdx === currentQ.correctIndex) {
      soundEngine.playGoldClink();
      const nextScore = goldScore + targetItem.value;
      setGoldScore(nextScore);
      onSaveScore(nextScore);
      setItems((prev) =>
        prev.map((it) => (it.id === targetItem.id ? { ...it, collected: true } : it))
      );
      setFeedback(`⛏️ Kéo thành công ${targetItem.label} (+${targetItem.value}$)!`);
    } else {
      soundEngine.playWrong();
      setFeedback(`❌ Đứt dây cáp! Đáp án đúng là: ${currentQ.options[currentQ.correctIndex]}`);
    }
    setTargetItem(null);
    setQIdx((prev) => prev + 1);
  };

  return (
    <div className="rounded-3xl bg-gradient-to-b from-amber-900 via-yellow-950 to-stone-950 text-white p-5 sm:p-7 shadow-2xl border-2 border-amber-500/50 space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <span className="text-xs font-extrabold uppercase tracking-wider text-amber-300">
            HẦM MỎ ĐÀO VÀNG KHTN 7 · {lesson.title}
          </span>
          <h3 className="text-xl font-black">Bấm vào Cục Vàng / Kim Cương để thả ngoàm gắp!</h3>
        </div>
        <div className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-black text-sm">
          💰 Vàng thu được: {goldScore}$
        </div>
      </div>

      {feedback && (
        <div className="p-3 rounded-xl bg-amber-400/20 border border-amber-300 text-amber-200 text-xs sm:text-sm font-bold">
          {feedback}
        </div>
      )}

      {/* Underground Mine Shaft Stage */}
      <div className="relative h-72 sm:h-80 rounded-2xl bg-gradient-to-b from-amber-950 via-stone-900 to-stone-950 border-2 border-amber-600/40 overflow-hidden">
        {/* Miner & Swinging Hook at Top Center */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 flex flex-col items-center z-10">
          <div className="px-3 py-1 rounded-full bg-amber-400 text-slate-950 text-xs font-black shadow">
            👷 Thợ Mỏ KHTN 7
          </div>
          <div
            className="w-1 h-16 bg-amber-300 origin-top transition-transform duration-75"
            style={{ transform: `rotate(${hookAngle}deg)` }}
          >
            <div className="w-4 h-4 -ml-1.5 mt-14 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center text-xs font-black">
              ⚓
            </div>
          </div>
        </div>

        {/* Underground Treasures */}
        {items.map((item) => (
          <button
            key={item.id}
            onClick={() => handleGrabItem(item)}
            disabled={item.collected}
            style={{ left: `${item.xPercent}%`, top: `${item.yPercent}%` }}
            className={`absolute -translate-x-1/2 -translate-y-1/2 p-3 rounded-2xl border-2 transition transform hover:scale-110 cursor-pointer ${
              item.collected
                ? 'opacity-20 border-stone-700 bg-stone-900 cursor-not-allowed'
                : 'border-amber-300 bg-amber-500/20 hover:bg-amber-400/40 shadow-lg'
            }`}
          >
            <div className="text-2xl sm:text-3xl">{item.emoji}</div>
            <div className="text-[10px] font-black text-amber-200">{item.value}$</div>
          </button>
        ))}
      </div>

      {/* Question Modal when Hook Grabs an Item */}
      {targetItem && (
        <div className="p-5 rounded-2xl bg-stone-900 border-2 border-amber-400 space-y-4">
          <div className="flex items-center justify-between text-xs font-black text-amber-300">
            <span>
              ⚓ NGOÀM ĐÃ GẮP ĐƯỢC: {targetItem.emoji} {targetItem.label} (+{targetItem.value}$)
            </span>
            <span>Trả lời đúng để kéo lên!</span>
          </div>
          <h4 className="ten-foot-question text-base sm:text-lg font-black text-white">{currentQ.question}</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {currentQ.options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => handleAnswerToReel(idx)}
                className="ten-foot-option p-3.5 rounded-xl bg-white/10 hover:bg-amber-400 hover:text-slate-950 border border-white/20 text-left font-bold text-xs sm:text-sm transition cursor-pointer"
              >
                <strong>{String.fromCharCode(65 + idx)}.</strong> {opt}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

/* ============================================================================
   GAME 5: ĐƯỜNG ĐUA 9+ (SPEED FORMULA RACER)
   ============================================================================ */
const SpeedRacerGame: React.FC<{
  lesson: KhtnLesson;
  onSaveScore: (score: number) => void;
}> = ({ lesson, onSaveScore }) => {
  const [playerProgress, setPlayerProgress] = useState(10);
  const [aiProgress, setAiProgress] = useState([12, 15, 8]);
  const [speedKmh, setSpeedKmh] = useState(120);
  const [qIdx, setQIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [raceStatus, setRaceStatus] = useState<string>(
    'Trả lời đúng để kích hoạt NITRO bứt tốc về đích 100%!'
  );

  const currentQ = lesson.mcqs[qIdx % lesson.mcqs.length];

  const handleAnswerRace = (idx: number) => {
    if (playerProgress >= 100) return;
    if (idx === currentQ.correctIndex) {
      soundEngine.playNitroBoost();
      const nextProg = Math.min(100, playerProgress + 18);
      setPlayerProgress(nextProg);
      setSpeedKmh(280 + Math.floor(Math.random() * 45));
      const nextScore = score + 150;
      setScore(nextScore);
      onSaveScore(nextScore);
      setRaceStatus('🔥 NITRO BOOST! Xe của bạn vọt lên dẫn đầu!');
      if (nextProg >= 100) {
        soundEngine.playVictory();
        setRaceStatus('🏁 VỀ ĐÍCH HẠNG NHẤT! Bạn đã chiến thắng Đường Đua 9+!');
      }
    } else {
      soundEngine.playWrong();
      setSpeedKmh(90);
      setRaceStatus(`⚠️ Giảm tốc! Đáp án đúng là: ${currentQ.options[currentQ.correctIndex]}`);
    }

    setAiProgress((prev) =>
      prev.map((p) => Math.min(96, p + Math.floor(Math.random() * 12 + 5)))
    );
    setQIdx((prev) => prev + 1);
  };

  return (
    <div className="rounded-3xl bg-gradient-to-br from-slate-900 via-red-950 to-slate-950 text-white p-5 sm:p-8 shadow-2xl border-2 border-red-500/50 space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <span className="text-xs font-extrabold uppercase tracking-wider text-red-400">
            ĐƯỜNG ĐUA CÔNG THỨC 9+ · {lesson.title}
          </span>
          <h3 className="text-xl font-black">{raceStatus}</h3>
        </div>
        <div className="flex items-center gap-3">
          <div className="px-4 py-2 rounded-xl bg-red-600 font-black text-xs sm:text-sm">
            ⚡ Tốc độ: {speedKmh} km/h
          </div>
          <div className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-black text-xs sm:text-sm">
            🏆 Điểm đua: {score}
          </div>
        </div>
      </div>

      {/* 4-Lane Highway Racetrack */}
      <div className="bg-slate-950 rounded-2xl p-4 border-2 border-slate-700 space-y-3">
        {[
          { name: '🏎️ BẠN (Siêu Xe KHTN 7)', prog: playerProgress, color: 'bg-emerald-500' },
          { name: '🚙 Đối thủ AI #1 (Tia Chớp)', prog: aiProgress[0], color: 'bg-amber-500' },
          { name: '🚕 Đối thủ AI #2 (Bão Tố)', prog: aiProgress[1], color: 'bg-blue-500' },
          { name: '🚓 Đối thủ AI #3 (Sao Băng)', prog: aiProgress[2], color: 'bg-purple-500' },
        ].map((lane, i) => (
          <div key={i} className="space-y-1">
            <div className="flex justify-between text-xs font-bold text-slate-300">
              <span>{lane.name}</span>
              <span>{lane.prog}% quãng đường</span>
            </div>
            <div className="h-6 rounded-full bg-slate-800 relative overflow-hidden border border-slate-700">
              <div
                className={`h-full ${lane.color} transition-all duration-500 flex items-center justify-end pr-2 text-xs font-black`}
                style={{ width: `${lane.prog}%` }}
              >
                🏎️
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Question Pitstop Box */}
      {playerProgress < 100 ? (
        <div className="bg-white/10 rounded-2xl p-5 border border-white/15 space-y-4">
          <h4 className="ten-foot-question text-base sm:text-lg font-black">{currentQ.question}</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {currentQ.options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => handleAnswerRace(idx)}
                className="ten-foot-option p-3.5 rounded-xl bg-slate-900/90 hover:bg-red-600 border border-white/20 text-left font-bold text-xs sm:text-sm transition cursor-pointer"
              >
                <strong>{String.fromCharCode(65 + idx)}.</strong> {opt}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="text-center py-6">
          <button
            onClick={() => {
              setPlayerProgress(10);
              setAiProgress([12, 15, 8]);
              setScore(0);
            }}
            className="px-6 py-3 rounded-xl bg-amber-400 text-slate-950 font-black text-sm cursor-pointer"
          >
            Đua vòng mới
          </button>
        </div>
      )}
    </div>
  );
};

/* ============================================================================
   GAME 6: DÒ MÌN KHOA HỌC (SCIENCE MINESWEEPER GRID)
   ============================================================================ */
const MinesweeperGame: React.FC<{
  lesson: KhtnLesson;
  onSaveScore: (score: number) => void;
}> = ({ lesson, onSaveScore }) => {
  const minePositions = useMemo(() => new Set([3, 7, 12, 18, 22]), []);
  const [revealedCells, setRevealedCells] = useState<number[]>([]);
  const [flaggedCells, setFlaggedCells] = useState<number[]>([]);
  const [flagMode, setFlagMode] = useState(false);
  const [pendingCell, setPendingCell] = useState<number | null>(null);
  const [qIdx, setQIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [statusMsg, setStatusMsg] = useState(
    'Chọn 1 ô trên lưới Radar 5×5 và trả lời câu hỏi để quét mìn an toàn!'
  );

  const currentQ = lesson.mcqs[qIdx % lesson.mcqs.length];

  const countAdjacentMines = (cellIdx: number) => {
    const r = Math.floor(cellIdx / 5);
    const c = cellIdx % 5;
    let count = 0;
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (dr === 0 && dc === 0) continue;
        const nr = r + dr;
        const nc = c + dc;
        if (nr >= 0 && nr < 5 && nc >= 0 && nc < 5) {
          if (minePositions.has(nr * 5 + nc)) count++;
        }
      }
    }
    return count;
  };

  const handleCellClick = (idx: number) => {
    if (revealedCells.includes(idx)) return;
    if (flagMode) {
      soundEngine.playClick();
      setFlaggedCells((prev) =>
        prev.includes(idx) ? prev.filter((i) => i !== idx) : [...prev, idx]
      );
      return;
    }
    soundEngine.playClick();
    setPendingCell(idx);
  };

  const handleAnswerRadar = (optIdx: number) => {
    if (pendingCell === null) return;
    if (optIdx === currentQ.correctIndex) {
      soundEngine.playCorrect();
      if (minePositions.has(pendingCell)) {
        setFlaggedCells((prev) => [...new Set([...prev, pendingCell])]);
        setStatusMsg('🛡️ Bạn đã phát hiện và vô hiệu hóa thành công 1 Quả Mìn Phóng Xạ (+200đ)!');
      } else {
        setRevealedCells((prev) => [...new Set([...prev, pendingCell])]);
        setStatusMsg('✅ Ô an toàn đã được mở (+150đ)!');
      }
      const nextScore = score + 150;
      setScore(nextScore);
      onSaveScore(nextScore);
    } else {
      soundEngine.playExplosion();
      setStatusMsg(`💥 CẢNH BÁO! Trả lời sai khi gỡ mìn! Đáp án đúng: ${currentQ.options[currentQ.correctIndex]}`);
    }
    setPendingCell(null);
    setQIdx((prev) => prev + 1);
  };

  return (
    <div className="rounded-3xl bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-950 text-white p-5 sm:p-8 shadow-2xl border-2 border-emerald-500/50 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
      {/* Left 5 Cols: 5x5 Radar Grid */}
      <div className="lg:col-span-5 space-y-4">
        <div className="flex items-center justify-between">
          <button
            onClick={() => setFlagMode(!flagMode)}
            className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 cursor-pointer ${
              flagMode ? 'bg-amber-400 text-slate-950' : 'bg-white/10 text-white'
            }`}
          >
            <Flag className="w-4 h-4" />
            <span>{flagMode ? 'Chế độ: Cắm cờ 🚩' : 'Chế độ: Mở ô Radar'}</span>
          </button>
          <span className="text-xs font-black text-emerald-300">Điểm: {score}</span>
        </div>

        <div className="grid grid-cols-5 gap-2 bg-black/40 p-3 rounded-2xl border border-emerald-500/30">
          {Array.from({ length: 25 }).map((_, idx) => {
            const isRevealed = revealedCells.includes(idx);
            const isFlagged = flaggedCells.includes(idx);
            const isPending = pendingCell === idx;
            const adj = countAdjacentMines(idx);

            return (
              <button
                key={idx}
                onClick={() => handleCellClick(idx)}
                className={`h-12 sm:h-14 rounded-xl font-black text-sm border transition flex items-center justify-center cursor-pointer ${
                  isPending
                    ? 'bg-amber-400 text-slate-950 border-white animate-pulse'
                    : isRevealed
                    ? 'bg-emerald-900/60 border-emerald-400/50 text-emerald-200'
                    : isFlagged
                    ? 'bg-rose-900/70 border-rose-400 text-white'
                    : 'bg-slate-800 hover:bg-slate-700 border-slate-600 text-slate-400'
                }`}
              >
                {isFlagged ? '🚩' : isRevealed ? (adj === 0 ? '💎' : adj) : '?'}
              </button>
            );
          })}
        </div>
      </div>

      {/* Right 7 Cols: Disarm Question */}
      <div className="lg:col-span-7 bg-white/10 rounded-3xl p-6 border border-white/15 space-y-4">
        <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-300">
          TRẠM RADAR DÒ MÌN KHTN 7 · {lesson.title}
        </span>
        <p className="text-sm font-bold text-amber-300">{statusMsg}</p>

        {pendingCell !== null ? (
          <div className="space-y-4 pt-2 border-t border-white/10">
            <h4 className="ten-foot-question text-base sm:text-lg font-black">
              Giải câu hỏi để quét Ô Radar #{pendingCell + 1}: {currentQ.question}
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {currentQ.options.map((opt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAnswerRadar(idx)}
                  className="ten-foot-option p-3.5 rounded-xl bg-slate-900/90 hover:bg-emerald-600 border border-white/20 text-left font-bold text-xs sm:text-sm transition cursor-pointer"
                >
                  <strong>{String.fromCharCode(65 + idx)}.</strong> {opt}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="py-8 text-center text-slate-300 text-sm font-bold">
            👈 Hãy bấm vào một ô <strong>[?]</strong> bất kỳ trên bản đồ Radar 5×5 bên trái để quét!
          </div>
        )}
      </div>
    </div>
  );
};

/* ============================================================================
   GAME 7: TRUY TÌM KHO BÁU ĐẠI DƯƠNG (TREASURE ISLAND EXPEDITION)
   ============================================================================ */
const ISLANDS = [
  '1. Bến Cảng Xuất Phát',
  '2. Đảo Nguyên Tử',
  '3. Vịnh Tốc Độ',
  '4. Rạn San Hô Âm Thanh',
  '5. Hang Pha Lê Ánh Sáng',
  '6. Đảo Từ Trường',
  '7. Rừng Nguyên Sinh',
  '8. RƯƠNG KHO BÁU HOÀNG GIA',
];

const TreasureHuntGame: React.FC<{
  lesson: KhtnLesson;
  onSaveScore: (score: number) => void;
}> = ({ lesson, onSaveScore }) => {
  const [islandIdx, setIslandIdx] = useState(0);
  const [keysCollected, setKeysCollected] = useState(0);
  const [qIdx, setQIdx] = useState(0);
  const [feedback, setFeedback] = useState<string | null>(null);

  const currentQ = lesson.mcqs[qIdx % lesson.mcqs.length];

  const handleAnswerIsland = (optIdx: number) => {
    if (optIdx === currentQ.correctIndex) {
      soundEngine.playGoldClink();
      const nextIsland = Math.min(ISLANDS.length - 1, islandIdx + 1);
      setIslandIdx(nextIsland);
      const nextKeys = keysCollected + 1;
      setKeysCollected(nextKeys);
      onSaveScore(nextKeys * 200);
      setFeedback(`🗝️ Chính xác! Tàu căng buồm tiến tới ${ISLANDS[nextIsland]}!`);
    } else {
      soundEngine.playWrong();
      setFeedback(`🌊 Sóng lớn cản đường! Đáp án đúng: ${currentQ.options[currentQ.correctIndex]}`);
    }
    setQIdx((prev) => prev + 1);
  };

  return (
    <div className="rounded-3xl bg-gradient-to-br from-cyan-950 via-teal-900 to-blue-950 text-white p-5 sm:p-8 shadow-2xl border-2 border-cyan-400/50 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <span className="text-xs font-extrabold uppercase tracking-wider text-cyan-300">
            HẢI ĐỒ TRUY TÌM KHO BÁU · {lesson.title}
          </span>
          <h3 className="text-xl font-black">Vượt qua 8 Hòn Đảo để mở Rương Hoàng Gia!</h3>
        </div>
        <div className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-black text-sm">
          🗝️ Chìa khóa Vàng: {keysCollected}/8
        </div>
      </div>

      {/* 8 Islands Map Trail */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {ISLANDS.map((name, idx) => {
          const isCurrent = idx === islandIdx;
          const isPassed = idx < islandIdx;
          return (
            <div
              key={idx}
              className={`p-3.5 rounded-2xl border-2 text-xs font-black flex items-center justify-between ${
                isCurrent
                  ? 'bg-amber-400 text-slate-950 border-white shadow-lg'
                  : isPassed
                  ? 'bg-emerald-600/40 border-emerald-400 text-emerald-200'
                  : 'bg-white/5 border-white/15 text-slate-400'
              }`}
            >
              <span>{name}</span>
              <span>{isCurrent ? '⛵' : isPassed ? '✅' : idx === 7 ? '👑' : '🏝️'}</span>
            </div>
          );
        })}
      </div>

      {feedback && (
        <div className="p-3.5 rounded-xl bg-cyan-500/20 border border-cyan-300 text-xs sm:text-sm font-bold">
          {feedback}
        </div>
      )}

      {/* Question Challenge */}
      <div className="bg-slate-950/75 rounded-2xl p-6 border border-cyan-400/40 space-y-4">
        <h4 className="ten-foot-question text-base sm:text-lg font-black">
          Thử thách tại {ISLANDS[islandIdx]}: {currentQ.question}
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {currentQ.options.map((opt, idx) => (
            <button
              key={idx}
              onClick={() => handleAnswerIsland(idx)}
              className="ten-foot-option p-3.5 rounded-xl bg-white/10 hover:bg-cyan-500 hover:text-slate-950 border border-white/20 text-left font-bold text-xs sm:text-sm transition cursor-pointer"
            >
              <strong>{String.fromCharCode(65 + idx)}.</strong> {opt}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

/* ============================================================================
   GAME 8: ESCAPE ROOM – GIẢI CỨU PHÒNG THÍ NGHIỆM (LAB ESCAPE ROOM)
   ============================================================================ */
const EscapeRoomGame: React.FC<{
  lesson: KhtnLesson;
  onSaveScore: (score: number) => void;
}> = ({ lesson, onSaveScore }) => {
  const secretDigits = [7, 2, 9, 4];
  const [unlockedDoors, setUnlockedDoors] = useState<number[]>([]);
  const [activeDoor, setActiveDoor] = useState<number>(0);
  const [escaped, setEscaped] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const currentQ = lesson.mcqs[activeDoor % lesson.mcqs.length];

  const handleUnlockDoor = (optIdx: number) => {
    if (optIdx === currentQ.correctIndex) {
      soundEngine.playCorrect();
      const nextUnlocked = [...new Set([...unlockedDoors, activeDoor])];
      setUnlockedDoors(nextUnlocked);
      onSaveScore(nextUnlocked.length * 250);
      setFeedback(
        `🔓 Đã mở khóa Cửa #${activeDoor + 1}! Mật mã tìm được: số [${secretDigits[activeDoor]}]`
      );
      if (nextUnlocked.length >= 4) {
        soundEngine.playVictory();
        setEscaped(true);
      } else {
        setActiveDoor(Math.min(3, activeDoor + 1));
      }
    } else {
      soundEngine.playWrong();
      setFeedback(`🚨 Cửa báo động đỏ! Đáp án đúng là: ${currentQ.options[currentQ.correctIndex]}`);
    }
  };

  return (
    <div className="rounded-3xl bg-gradient-to-br from-slate-950 via-teal-950 to-emerald-950 text-white p-5 sm:p-8 shadow-2xl border-2 border-teal-400/50 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <span className="text-xs font-extrabold uppercase tracking-wider text-teal-300">
            ESCAPE ROOM · GIẢI CỨU PHÒNG LAB KHTN 7
          </span>
          <h3 className="text-xl font-black">{lesson.title}</h3>
        </div>
        <div className="flex items-center gap-2 bg-black/50 px-4 py-2 rounded-xl border border-teal-400/40 font-mono text-sm font-black">
          <span>MẬT MÃ 4 SỐ:</span>
          {[0, 1, 2, 3].map((d) => (
            <span
              key={d}
              className="w-7 h-7 rounded bg-teal-500/20 border border-teal-400 flex items-center justify-center text-amber-300"
            >
              {unlockedDoors.includes(d) ? secretDigits[d] : '*'}
            </span>
          ))}
        </div>
      </div>

      {/* 4 Security Doors */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          'Cửa 1: Khoang Nguyên Tử',
          'Cửa 2: Buồng Quang Học',
          'Cửa 3: Lò Phản Ứng',
          'Cửa 4: Cổng Trung Tâm',
        ].map((doorName, idx) => {
          const isOpen = unlockedDoors.includes(idx);
          const isSelected = activeDoor === idx;
          return (
            <button
              key={idx}
              onClick={() => setActiveDoor(idx)}
              className={`p-4 rounded-2xl border-2 text-left transition cursor-pointer ${
                isOpen
                  ? 'bg-emerald-600/30 border-emerald-400 text-emerald-200'
                  : isSelected
                  ? 'bg-amber-400 text-slate-950 border-white font-black'
                  : 'bg-white/5 border-white/15 text-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                {isOpen ? <Unlock className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
                <span className="text-xs font-black">
                  {isOpen ? `Mã: ${secretDigits[idx]}` : 'Đang khóa'}
                </span>
              </div>
              <div className="text-xs font-bold">{doorName}</div>
            </button>
          );
        })}
      </div>

      {feedback && (
        <div className="p-3.5 rounded-xl bg-teal-500/20 border border-teal-300 text-xs sm:text-sm font-bold">
          {feedback}
        </div>
      )}

      {escaped ? (
        <div className="p-8 rounded-3xl bg-emerald-600 text-white text-center space-y-3">
          <div className="text-5xl">🔓🎉</div>
          <h4 className="text-2xl font-black">
            CHÚC MỪNG! BẠN ĐÃ MỞ KHÓA MẬT MÃ 7-2-9-4 VÀ THOÁT KHỎI PHÒNG LAB!
          </h4>
          <button
            onClick={() => {
              setUnlockedDoors([]);
              setActiveDoor(0);
              setEscaped(false);
            }}
            className="px-6 py-2.5 rounded-xl bg-slate-950 text-amber-300 font-black text-xs sm:text-sm cursor-pointer"
          >
            Chơi lại Escape Room
          </button>
        </div>
      ) : (
        <div className="bg-black/45 rounded-2xl p-6 border border-teal-400/40 space-y-4">
          <h4 className="ten-foot-question text-base sm:text-lg font-black">
            Câu hỏi bảo mật Cửa #{activeDoor + 1}: {currentQ.question}
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {currentQ.options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => handleUnlockDoor(idx)}
                className="ten-foot-option p-3.5 rounded-xl bg-white/10 hover:bg-teal-500 hover:text-slate-950 border border-white/20 text-left font-bold text-xs sm:text-sm transition cursor-pointer"
              >
                <strong>{String.fromCharCode(65 + idx)}.</strong> {opt}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

/* ============================================================================
   GAME 9: GHÉP CẶP THÔNG MINH (MEMORY & CONCEPT MATCH)
   ============================================================================ */
const MemoryMatchGame: React.FC<{
  lesson: KhtnLesson;
  onSaveScore: (score: number) => void;
}> = ({ lesson, onSaveScore }) => {
  const pairs = useMemo(() => {
    return lesson.mcqs.slice(0, 6).map((q, i) => ({
      pairId: `pair-${i}`,
      questionText: q.question,
      answerText: q.options[q.correctIndex],
    }));
  }, [lesson]);

  const [selectedLeft, setSelectedLeft] = useState<string | null>(null);
  const [matchedIds, setMatchedIds] = useState<string[]>([]);
  const [score, setScore] = useState(0);

  const shuffledRight = useMemo(() => {
    return [...pairs].reverse();
  }, [pairs]);

  const handleMatchRight = (pairId: string) => {
    if (!selectedLeft || matchedIds.includes(pairId)) return;
    if (selectedLeft === pairId) {
      soundEngine.playCorrect();
      const next = [...matchedIds, pairId];
      setMatchedIds(next);
      const nextScore = score + 200;
      setScore(nextScore);
      onSaveScore(nextScore);
      setSelectedLeft(null);
    } else {
      soundEngine.playWrong();
      setSelectedLeft(null);
    }
  };

  return (
    <div className="rounded-3xl bg-gradient-to-br from-violet-950 via-purple-900 to-indigo-950 text-white p-5 sm:p-8 shadow-2xl border-2 border-purple-400/50 space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <span className="text-xs font-extrabold uppercase tracking-wider text-purple-300">
            GHÉP CẶP THÔNG MINH · {lesson.title}
          </span>
          <h3 className="text-xl font-black">
            Chọn 1 Thẻ Câu Hỏi (Cột Trái) rồi ghép với Thẻ Đáp Án Đúng (Cột Phải)
          </h3>
        </div>
        <div className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-black text-sm">
          🧩 Đã ghép: {matchedIds.length}/6 cặp ({score} đ)
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Left Column: Questions */}
        <div className="space-y-2.5">
          <div className="text-xs font-extrabold uppercase text-amber-300">
            CỘT A: MỆNH ĐỀ / CÂU HỎI BÀI HỌC
          </div>
          {pairs.map((p, idx) => {
            const isMatched = matchedIds.includes(p.pairId);
            const isSelected = selectedLeft === p.pairId;
            return (
              <button
                key={p.pairId}
                onClick={() => !isMatched && setSelectedLeft(p.pairId)}
                disabled={isMatched}
                className={`ten-foot-option w-full p-3.5 rounded-2xl border-2 text-left text-xs sm:text-sm font-bold transition cursor-pointer ${
                  isMatched
                    ? 'bg-emerald-600/30 border-emerald-400 text-emerald-200 line-through'
                    : isSelected
                    ? 'bg-amber-400 text-slate-950 border-white shadow-lg'
                    : 'bg-white/10 hover:bg-white/20 border-white/20 text-white'
                }`}
              >
                <strong>#{idx + 1}.</strong> {p.questionText}
              </button>
            );
          })}
        </div>

        {/* Right Column: Answers */}
        <div className="space-y-2.5">
          <div className="text-xs font-extrabold uppercase text-emerald-300">
            CỘT B: ĐÁP ÁN / KẾT LUẬN TƯƠNG ỨNG
          </div>
          {shuffledRight.map((p) => {
            const isMatched = matchedIds.includes(p.pairId);
            return (
              <button
                key={p.pairId}
                onClick={() => handleMatchRight(p.pairId)}
                disabled={isMatched}
                className={`ten-foot-option w-full p-3.5 rounded-2xl border-2 text-left text-xs sm:text-sm font-bold transition cursor-pointer ${
                  isMatched
                    ? 'bg-emerald-600/30 border-emerald-400 text-emerald-200'
                    : 'bg-slate-900/80 hover:bg-purple-600/40 border-purple-400/50 text-amber-200'
                }`}
              >
                💡 {p.answerText}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

/* ============================================================================
   GAME 10: THÁM TỬ KHOA HỌC (SCIENCE DETECTIVE)
   ============================================================================ */
const ScienceDetectiveGame: React.FC<{
  lesson: KhtnLesson;
  onSaveScore: (score: number) => void;
}> = ({ lesson, onSaveScore }) => {
  const statements = useMemo(() => {
    return lesson.trueFalseList.flatMap((tf) => tf.statements).slice(0, 6);
  }, [lesson]);

  const [idx, setIdx] = useState(0);
  const [cluesFound, setCluesFound] = useState(0);
  const [feedback, setFeedback] = useState<string | null>(null);

  const currentSt = statements[idx % statements.length];

  const handleJudgeEvidence = (choice: boolean) => {
    if (choice === currentSt.isTrue) {
      soundEngine.playCorrect();
      const nextClues = cluesFound + 1;
      setCluesFound(nextClues);
      onSaveScore(nextClues * 200);
      setFeedback(`🔍 Manh mối #${nextClues} xác thực! ${currentSt.explanation}`);
    } else {
      soundEngine.playWrong();
      setFeedback(`❌ Giám định sai! Thực tế: ${currentSt.explanation}`);
    }
    setIdx((prev) => prev + 1);
  };

  return (
    <div className="rounded-3xl bg-gradient-to-br from-stone-900 via-amber-950 to-slate-950 text-white p-5 sm:p-8 shadow-2xl border-2 border-amber-500/50 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <span className="text-xs font-extrabold uppercase tracking-wider text-amber-400">
            HỒ SƠ THÁM TỬ KHOA HỌC · {lesson.title}
          </span>
          <h3 className="text-xl font-black">
            Giám định Mệnh đề Đúng hay Sai để thu thập đủ 5 Manh mối phá án!
          </h3>
        </div>
        <div className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-black text-sm">
          🕵️ Manh mối: {cluesFound}/5
        </div>
      </div>

      {feedback && (
        <div className="p-4 rounded-2xl bg-amber-500/20 border border-amber-400 text-xs sm:text-sm font-bold">
          {feedback}
        </div>
      )}

      <div className="bg-black/50 rounded-3xl p-6 border border-amber-400/40 space-y-5">
        <div className="text-xs font-extrabold text-amber-300 uppercase">
          BẰNG CHỨNG HIỆN TRƯỜNG SỐ {idx + 1}:
        </div>
        <p className="ten-foot-question text-lg sm:text-xl font-black leading-relaxed">"{currentSt.text}"</p>

        <div className="grid grid-cols-2 gap-4 pt-2">
          <button
            onClick={() => handleJudgeEvidence(true)}
            className="ten-foot-option py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-sm sm:text-base shadow-lg transition cursor-pointer"
          >
            ✅ BẰNG CHỨNG ĐÚNG (TRUE)
          </button>
          <button
            onClick={() => handleJudgeEvidence(false)}
            className="ten-foot-option py-4 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-black text-sm sm:text-base shadow-lg transition cursor-pointer"
          >
            ❌ BẰNG CHỨNG GIẢ (FALSE)
          </button>
        </div>
      </div>
    </div>
  );
};

/* ============================================================================
   GAME 11: GIẢI MÃ Ô CHỮ KHTN (CROSSWORD & KEYWORD DECODER)
   ============================================================================ */
const CrosswordDecoderGame: React.FC<{
  lesson: KhtnLesson;
  onSaveScore: (score: number) => void;
}> = ({ lesson, onSaveScore }) => {
  const rows = useMemo(() => lesson.mcqs.slice(0, 6), [lesson]);
  const [solvedRows, setSolvedRows] = useState<number[]>([]);
  const [activeRow, setActiveRow] = useState<number>(0);

  const currentQ = rows[activeRow] || rows[0];

  const handleSolveRow = (optIdx: number) => {
    if (optIdx === currentQ.correctIndex) {
      soundEngine.playCorrect();
      const next = [...new Set([...solvedRows, activeRow])];
      setSolvedRows(next);
      onSaveScore(next.length * 200);
      if (activeRow + 1 < rows.length) {
        setActiveRow(activeRow + 1);
      }
    } else {
      soundEngine.playWrong();
    }
  };

  return (
    <div className="rounded-3xl bg-gradient-to-br from-blue-950 via-indigo-950 to-slate-950 text-white p-5 sm:p-8 shadow-2xl border-2 border-sky-400/50 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <span className="text-xs font-extrabold uppercase tracking-wider text-sky-300">
            GIẢI MÃ Ô CHỮ TRỌNG TÂM · {lesson.title}
          </span>
          <h3 className="text-xl font-black">Giải 6 Hàng Ngang để lật mở Từ Khóa Chủ Đề!</h3>
        </div>
        <div className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-black text-sm">
          🔤 Đã mở: {solvedRows.length}/6 hàng ngang
        </div>
      </div>

      {/* 6 Horizontal Crossword Bars */}
      <div className="space-y-2">
        {rows.map((r, i) => {
          const isSolved = solvedRows.includes(i);
          const ansText = r.options[r.correctIndex].toUpperCase();
          return (
            <button
              key={r.id}
              onClick={() => setActiveRow(i)}
              className={`w-full p-3.5 rounded-2xl border-2 flex items-center justify-between gap-3 transition cursor-pointer ${
                isSolved
                  ? 'bg-emerald-600/30 border-emerald-400 text-emerald-200'
                  : activeRow === i
                  ? 'bg-amber-400 text-slate-950 border-white font-black'
                  : 'bg-white/5 border-white/15 text-slate-300'
              }`}
            >
              <span className="text-xs font-black">HÀNG NGANG #{i + 1}</span>
              <span className="font-mono text-xs sm:text-sm font-black tracking-widest">
                {isSolved ? ansText : '▒ ▒ ▒ ▒ ▒ ▒ ▒ ▒ ▒ ▒'}
              </span>
              <span className="text-xs">{isSolved ? '✅ Đã mở' : '🔒 Đang khóa'}</span>
            </button>
          );
        })}
      </div>

      {/* Active Row Clue */}
      <div className="bg-black/45 rounded-2xl p-6 border border-sky-400/40 space-y-4">
        <div className="text-xs font-extrabold text-amber-300">
          GỢI Ý HÀNG NGANG #{activeRow + 1}:
        </div>
        <h4 className="ten-foot-question text-base sm:text-lg font-black">{currentQ.question}</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {currentQ.options.map((opt, idx) => (
            <button
              key={idx}
              onClick={() => handleSolveRow(idx)}
              className="ten-foot-option p-3.5 rounded-xl bg-white/10 hover:bg-sky-500 hover:text-slate-950 border border-white/20 text-left font-bold text-xs sm:text-sm transition cursor-pointer"
            >
              <strong>{String.fromCharCode(65 + idx)}.</strong> {opt}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

/* ============================================================================
   GAME 12: ĐẤU TRƯỜNG SĂN BOSS KHTN (GALACTIC BOSS BATTLE - NEW FAVORITE!)
   ============================================================================ */
const BossBattleGame: React.FC<{
  lesson: KhtnLesson;
  onSaveScore: (score: number) => void;
}> = ({ lesson, onSaveScore }) => {
  const [bossHp, setBossHp] = useState(1000);
  const [playerHp, setPlayerHp] = useState(500);
  const [selectedSkill, setSelectedSkill] = useState<'laser' | 'ion' | 'shield'>('laser');
  const [qIdx, setQIdx] = useState(0);
  const [combo, setCombo] = useState(0);
  const [battleLog, setBattleLog] = useState<string>(
    'Chọn Vũ khí Khoa học và trả lời đúng câu hỏi để tung đòn chí mạng vào Boss!'
  );

  const currentQ = lesson.mcqs[qIdx % lesson.mcqs.length];

  const handleAttackBoss = (optIdx: number) => {
    if (bossHp <= 0 || playerHp <= 0) return;

    if (optIdx === currentQ.correctIndex) {
      soundEngine.playLaserZap();
      const nextCombo = combo + 1;
      setCombo(nextCombo);
      const dmg =
        selectedSkill === 'ion'
          ? 300 + nextCombo * 30
          : selectedSkill === 'laser'
          ? 220 + nextCombo * 20
          : 150;

      if (selectedSkill === 'shield') {
        setPlayerHp((prev) => Math.min(500, prev + 120));
      }

      const nextBossHp = Math.max(0, bossHp - dmg);
      setBossHp(nextBossHp);
      onSaveScore((1000 - nextBossHp) + nextCombo * 50);

      if (nextBossHp === 0) {
        soundEngine.playVictory();
        setBattleLog(`💥 CHIẾN THẮNG LỊCH SỬ! Bạn đã hạ gục Boss của ${lesson.title}!`);
      } else {
        setBattleLog(
          `⚡ COMBO x${nextCombo}! Đòn tấn công chính xác gây ${dmg} sát thương lên Boss!`
        );
      }
    } else {
      soundEngine.playExplosion();
      setCombo(0);
      const nextPlayerHp = Math.max(0, playerHp - 125);
      setPlayerHp(nextPlayerHp);
      setBattleLog(
        `🔥 Boss phản đòn (-125 HP)! Đáp án đúng phải là: ${currentQ.options[currentQ.correctIndex]}`
      );
    }

    setQIdx((prev) => prev + 1);
  };

  return (
    <div className="rounded-3xl bg-gradient-to-br from-fuchsia-950 via-indigo-950 to-slate-950 text-white p-5 sm:p-8 shadow-2xl border-2 border-fuchsia-400/50 space-y-6">
      {/* Top Arena Fighters Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Player Mecha */}
        <div className="bg-black/40 rounded-2xl p-4 border border-cyan-400/40 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-black text-cyan-300">
              🤖 CHIẾN GIÁP HỌC SINH KHTN 7
            </span>
            <span className="text-xs font-black bg-cyan-500/20 px-2.5 py-1 rounded-full text-cyan-200">
              HP: {playerHp}/500 · Combo x{combo}
            </span>
          </div>
          <div className="h-4 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 to-emerald-400 transition-all duration-300"
              style={{ width: `${(playerHp / 500) * 100}%` }}
            />
          </div>
        </div>

        {/* Lesson Boss */}
        <div className="bg-black/40 rounded-2xl p-4 border border-rose-400/40 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-black text-rose-300">
              👾 BOSS BÀI {lesson.lessonNumber}: QUÁI VẬT HỖN LOẠN
            </span>
            <span className="text-xs font-black bg-rose-500/20 px-2.5 py-1 rounded-full text-rose-200">
              HP: {bossHp}/1000
            </span>
          </div>
          <div className="h-4 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-rose-600 to-amber-500 transition-all duration-300"
              style={{ width: `${(bossHp / 1000) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* Battle Log Banner */}
      <div className="p-3.5 rounded-xl bg-fuchsia-500/20 border border-fuchsia-400/50 text-xs sm:text-sm font-black text-center text-amber-200">
        {battleLog}
      </div>

      {/* Skill Selector */}
      <div className="flex flex-wrap items-center justify-center gap-3">
        {[
          { id: 'laser' as const, label: '⚡ Tia Laser Chuẩn Xác (220 DMG)', icon: <Zap className="w-4 h-4" /> },
          { id: 'ion' as const, label: '🔥 Đại Pháo Ion Siêu Cấp (300 DMG)', icon: <Flame className="w-4 h-4" /> },
          { id: 'shield' as const, label: '🛡️ Khiên Năng Lượng (+120 HP & 150 DMG)', icon: <Shield className="w-4 h-4" /> },
        ].map((sk) => (
          <button
            key={sk.id}
            onClick={() => {
              soundEngine.playClick();
              setSelectedSkill(sk.id);
            }}
            className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 border-2 transition cursor-pointer ${
              selectedSkill === sk.id
                ? 'bg-amber-400 text-slate-950 border-white shadow-lg'
                : 'bg-white/10 border-white/20 text-white hover:bg-white/20'
            }`}
          >
            {sk.icon}
            <span>{sk.label}</span>
          </button>
        ))}
      </div>

      {/* Question Combat Box */}
      {bossHp > 0 && playerHp > 0 ? (
        <div className="bg-slate-950/80 rounded-3xl p-6 border border-fuchsia-400/40 space-y-4">
          <div className="text-xs font-extrabold uppercase text-fuchsia-300">
            NẠP ĐẠN NĂNG LƯỢNG · CÂU HỎI SỐ {qIdx + 1}:
          </div>
          <h4 className="ten-foot-question text-base sm:text-lg font-black">{currentQ.question}</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {currentQ.options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => handleAttackBoss(idx)}
                className="ten-foot-option p-3.5 rounded-xl bg-white/10 hover:bg-fuchsia-600 border border-white/20 text-left font-bold text-xs sm:text-sm transition cursor-pointer"
              >
                <strong>{String.fromCharCode(65 + idx)}.</strong> {opt}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="text-center py-6">
          <button
            onClick={() => {
              setBossHp(1000);
              setPlayerHp(500);
              setCombo(0);
            }}
            className="px-6 py-3 rounded-xl bg-amber-400 text-slate-950 font-black text-sm cursor-pointer"
          >
            Tái đấu Boss Bài {lesson.lessonNumber}
          </button>
        </div>
      )}
    </div>
  );
};
