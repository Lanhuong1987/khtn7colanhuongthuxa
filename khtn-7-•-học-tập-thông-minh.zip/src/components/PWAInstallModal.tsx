import React, { useEffect, useState } from 'react';
import {
  Smartphone,
  Download,
  Share,
  PlusSquare,
  CheckCircle2,
  X,
  Sparkles,
  WifiOff,
  MoreVertical,
  Copy,
  Check,
} from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsInstalled(isStandalone);

    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);
    setIsIOS(isIOSDevice);

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const install = async () => {
    if (!deferredPrompt) return false;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsInstalled(true);
      setDeferredPrompt(null);
      return true;
    }
    return false;
  };

  return {
    isInstallable: !!deferredPrompt,
    isInstalled,
    isIOS,
    install,
  };
}

export function useOnlineStatus() {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return isOnline;
}

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-500 px-3.5 py-2 text-xs font-extrabold text-slate-950 shadow-xl border border-amber-300">
      <WifiOff className="w-4 h-4 shrink-0" />
      <span>Chế độ Ngoại tuyến (Offline) — Đang sử dụng dữ liệu KHTN 7 đã lưu trong máy.</span>
    </div>
  );
};

/**
 * Custom KHTN 7 App Logo SVG Component
 * Combines Physics (Rutherford-Bohr Atom Orbits), Chemistry (Erlenmeyer Flask + Bubbles),
 * and Biology (Green Sprout Leaf) with a bold "KHTN 7" emblem.
 */
export const Khtn7BrandLogo: React.FC<{ className?: string }> = ({ className = 'w-10 h-10' }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 512 512"
      className={`${className} shrink-0 select-none`}
      aria-label="Logo KHTN 7 Học tập thông minh"
    >
      <defs>
        <linearGradient id="khtn7BgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#061922" />
          <stop offset="50%" stopColor="#0b2e3b" />
          <stop offset="100%" stopColor="#063932" />
        </linearGradient>
        <linearGradient id="khtn7RingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fbbf24" />
          <stop offset="50%" stopColor="#2dd4bf" />
          <stop offset="100%" stopColor="#38bdf8" />
        </linearGradient>
        <linearGradient id="khtn7FlaskGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#38bdf8" />
          <stop offset="100%" stopColor="#10b981" />
        </linearGradient>
        <linearGradient id="khtn7BadgeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#f59e0b" />
          <stop offset="100%" stopColor="#fbbf24" />
        </linearGradient>
      </defs>

      <rect x="0" y="0" width="512" height="512" rx="116" fill="url(#khtn7BgGrad)" />
      <rect
        x="16"
        y="16"
        width="480"
        height="480"
        rx="100"
        fill="none"
        stroke="url(#khtn7RingGrad)"
        strokeWidth="8"
        opacity="0.6"
      />

      <circle cx="256" cy="220" r="145" fill="#0d9488" opacity="0.2" />

      <g transform="translate(256, 214)">
        <ellipse
          rx="158"
          ry="58"
          fill="none"
          stroke="#38bdf8"
          strokeWidth="10"
          opacity="0.9"
          transform="rotate(-30)"
        />
        <ellipse
          rx="158"
          ry="58"
          fill="none"
          stroke="#fbbf24"
          strokeWidth="10"
          opacity="0.9"
          transform="rotate(30)"
        />
        <ellipse
          rx="158"
          ry="58"
          fill="none"
          stroke="#34d399"
          strokeWidth="8"
          opacity="0.75"
          transform="rotate(90)"
        />

        <circle cx="-136" cy="-78" r="14" fill="#38bdf8" />
        <circle cx="136" cy="-78" r="14" fill="#fbbf24" />
        <circle cx="0" cy="-158" r="13" fill="#34d399" />
      </g>

      <g transform="translate(256, 214)">
        <path
          d="M-24 -64 L24 -64 L24 -24 L68 58 C75 71 66 86 50 86 L-50 86 C-66 86 -75 71 -68 58 L-24 -24 Z"
          fill="#082430"
          stroke="#f8fafc"
          strokeWidth="11"
          strokeLinejoin="round"
        />
        <rect x="-34" y="-72" width="68" height="13" rx="6.5" fill="#f8fafc" />
        <path
          d="M-40 16 Q0 6 40 16 L60 54 C65 64 58 76 46 76 L-46 76 C-58 76 -65 64 -60 54 Z"
          fill="url(#khtn7FlaskGrad)"
        />
        <circle cx="-16" cy="48" r="7.5" fill="#ffffff" opacity="0.9" />
        <circle cx="14" cy="36" r="5.5" fill="#ffffff" opacity="0.9" />
        <circle cx="4" cy="58" r="6.5" fill="#fde047" opacity="0.95" />

        <path
          d="M2 -12 C2 -44 38 -56 54 -40 C46 -14 22 -4 2 -12 Z"
          fill="#10b981"
          stroke="#a7f3d0"
          strokeWidth="3.5"
        />
        <path
          d="M-2 -6 C-2 -34 -32 -44 -46 -30 C-38 -8 -18 -2 -2 -6 Z"
          fill="#34d399"
        />
      </g>

      <rect x="76" y="380" width="360" height="84" rx="42" fill="url(#khtn7BadgeGrad)" />
      <rect x="83" y="387" width="346" height="70" rx="35" fill="#071c24" />
      <text
        x="256"
        y="436"
        textAnchor="middle"
        fill="#fbbf24"
        fontFamily="system-ui, -apple-system, sans-serif"
        fontWeight="900"
        fontSize="50"
        letterSpacing="3"
      >
        KHTN 7
      </text>
    </svg>
  );
};

interface PWAInstallButtonProps {
  onOpenInstallModal: () => void;
  variant?: 'header' | 'hero' | 'sidebar';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  onOpenInstallModal,
  variant = 'header',
}) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();

  if (isInstalled) {
    return null;
  }

  const handleClick = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (!accepted) {
        onOpenInstallModal();
      }
    } else {
      onOpenInstallModal();
    }
  };

  if (variant === 'hero') {
    return (
      <button
        type="button"
        onClick={handleClick}
        className="px-4 py-3.5 rounded-xl bg-gradient-to-r from-teal-400 to-emerald-400 hover:from-teal-300 hover:to-emerald-300 text-slate-950 font-black text-sm shadow-lg transition flex items-center gap-2 cursor-pointer"
      >
        <Smartphone className="w-4 h-4 text-slate-950" />
        <span>📱 Đưa App lên Màn hình chính</span>
      </button>
    );
  }

  if (variant === 'sidebar') {
    return (
      <button
        type="button"
        onClick={handleClick}
        className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-extrabold shadow-xs transition cursor-pointer"
      >
        <span className="flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-amber-300" />
          <span>Cài App KHTN 7 lên Điện thoại</span>
        </span>
        <Download className="w-3.5 h-3.5 text-amber-300" />
      </button>
    );
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 text-slate-950 font-black text-xs shadow-sm transition cursor-pointer"
      title="Đưa ứng dụng KHTN 7 lên màn hình chính của điện thoại (Android / iPhone)"
    >
      <Smartphone className="w-4 h-4 text-slate-950" />
      <span className="hidden md:inline">Cài App ĐT</span>
    </button>
  );
};

interface PWAInstallModalProps {
  onClose: () => void;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({ onClose }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [selectedOS, setSelectedOS] = useState<'ios' | 'android'>(isIOS ? 'ios' : 'android');
  const [copiedUrl, setCopiedUrl] = useState(false);

  const appUrl = typeof window !== 'undefined' ? window.location.origin : '';

  const handleCopyUrl = () => {
    try {
      navigator.clipboard.writeText(appUrl);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2500);
    } catch {
      // ignore
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-teal-200 flex flex-col">
        {/* Top Modal Header */}
        <div className="bg-gradient-to-r from-[#061922] via-[#0b2e3b] to-[#063932] text-white p-5 sm:p-6 rounded-t-3xl flex items-center justify-between gap-4 border-b border-teal-800">
          <div className="flex items-center gap-3.5">
            <Khtn7BrandLogo className="w-14 h-14 rounded-2xl shadow-lg border border-amber-400/40" />
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-[11px] font-black uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>Progressive Web App (PWA) · Chuẩn Android & iOS</span>
              </div>
              <h3 className="text-lg sm:text-xl font-black text-white mt-1">
                Đưa App KHTN 7 lên Màn hình chính Điện thoại
              </h3>
              <p className="text-xs text-slate-300">
                Thiết kế bộ nhận diện & Logo độc quyền môn Khoa học tự nhiên 7 (Vật lí · Hóa học · Sinh học)
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition cursor-pointer shrink-0"
            aria-label="Đóng"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-5 sm:p-6 space-y-6">
          {/* Grid: Left Phone Home Screen Mockup + Right Install Instructions */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            {/* Left 5 Cols: Visual Phone Home Screen Preview & Logo Download */}
            <div className="lg:col-span-5 bg-gradient-to-b from-slate-900 via-[#081e26] to-slate-950 rounded-3xl p-5 text-white border border-teal-800/80 shadow-xl flex flex-col items-center text-center space-y-4">
              <div className="text-[11px] font-extrabold uppercase tracking-wider text-amber-300">
                MÔ PHỎNG BIỂU TƯỢNG TRÊN MÀN HÌNH CHÍNH ĐIỆN THOẠI
              </div>

              {/* Phone Screen Mockup */}
              <div className="w-56 bg-gradient-to-br from-[#0f2942] via-[#09353c] to-[#051d24] rounded-[32px] p-4 border-4 border-slate-700 shadow-2xl space-y-5">
                {/* Notch */}
                <div className="w-20 h-3 bg-slate-950 rounded-full mx-auto" />

                {/* App Grid */}
                <div className="grid grid-cols-3 gap-3 pt-1">
                  {/* Other sample phone icons */}
                  <div className="flex flex-col items-center gap-1 opacity-40">
                    <div className="w-12 h-12 rounded-2xl bg-blue-500/40 border border-white/20 flex items-center justify-center text-base">
                      📅
                    </div>
                    <span className="text-[10px] text-slate-300">Lịch</span>
                  </div>

                  {/* Highlighted KHTN 7 App Icon */}
                  <div className="flex flex-col items-center gap-1 scale-110">
                    <div className="relative">
                      <Khtn7BrandLogo className="w-14 h-14 rounded-2xl shadow-lg ring-2 ring-amber-400" />
                      <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-slate-950 flex items-center justify-center text-[9px] font-black">
                        ✓
                      </span>
                    </div>
                    <span className="text-[11px] font-black text-amber-300 tracking-tight">
                      KHTN 7
                    </span>
                  </div>

                  <div className="flex flex-col items-center gap-1 opacity-40">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-500/40 border border-white/20 flex items-center justify-center text-base">
                      📚
                    </div>
                    <span className="text-[10px] text-slate-300">Ghi chú</span>
                  </div>
                </div>

                <div className="py-2 px-3 rounded-xl bg-white/10 text-[10px] text-emerald-300 font-bold">
                  Mở toàn màn hình (Standalone) mượt như App gốc!
                </div>
              </div>

              {/* Meaning of the KHTN 7 Logo */}
              <div className="text-xs text-slate-300 leading-relaxed space-y-1 text-left bg-white/5 p-3.5 rounded-2xl border border-white/10 w-full">
                <div className="font-extrabold text-amber-300 text-center mb-1">
                  Ý nghĩa Thiết kế Logo KHTN 7
                </div>
                <div>• ⚛️ <strong>Quỹ đạo Nguyên tử:</strong> Phân môn Vật lí & Hóa học 7</div>
                <div>• 🧪 <strong>Bình tam giác phát sáng:</strong> Thí nghiệm Hóa học 7</div>
                <div>• 🌿 <strong>Chồi lá xanh Sinh học:</strong> Trao đổi chất & Cơ thể sống</div>
              </div>

              {/* Download Logo Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-2 w-full pt-1">
                <a
                  href="/pwa-512x512.png"
                  download="Logo-KHTN-7-512x512.png"
                  className="flex-1 px-3 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 transition"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Tải Logo PNG (512px)</span>
                </a>
                <a
                  href="/icon.svg"
                  download="Logo-KHTN-7.svg"
                  className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>SVG</span>
                </a>
              </div>
            </div>

            {/* Right 7 Cols: One-Click Install + iOS / Android Step-by-Step Guide */}
            <div className="lg:col-span-7 space-y-4">
              {/* Direct One-Click Install Card (if supported by browser) */}
              {isInstalled ? (
                <div className="p-4 rounded-2xl bg-emerald-50 border-2 border-emerald-400 flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                  <div>
                    <div className="text-sm font-black text-emerald-950">
                      Ứng dụng KHTN 7 đã được cài đặt trên thiết bị của bạn!
                    </div>
                    <div className="text-xs text-emerald-800">
                      Bạn có thể mở trực tiếp từ biểu tượng <strong>KHTN 7</strong> trên màn hình chính.
                    </div>
                  </div>
                </div>
              ) : isInstallable ? (
                <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="text-xs font-black uppercase text-amber-300">
                      CÀI ĐẶT NHANH TRỰC TIẾP (1 CHẠM)
                    </div>
                    <div className="text-sm font-extrabold">
                      Trình duyệt của bạn hỗ trợ cài đặt ngay lên màn hình chính!
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={install}
                    className="px-5 py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm shrink-0 shadow cursor-pointer flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    <span>Cài đặt App ngay</span>
                  </button>
                </div>
              ) : null}

              {/* OS Tabs: Android vs iPhone/iPad */}
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-black uppercase tracking-wider text-slate-500">
                    HƯỚNG DẪN ĐƯA LÊN MÀN HÌNH CHÍNH ĐIỆN THOẠI:
                  </span>
                  <div className="inline-flex rounded-xl bg-slate-100 p-1 border border-slate-200">
                    <button
                      type="button"
                      onClick={() => setSelectedOS('android')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition cursor-pointer ${
                        selectedOS === 'android'
                          ? 'bg-[#081e26] text-white shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      🤖 Điện thoại Android
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedOS('ios')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition cursor-pointer ${
                        selectedOS === 'ios'
                          ? 'bg-[#081e26] text-white shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      🍎 iPhone / iPad (iOS)
                    </button>
                  </div>
                </div>

                {selectedOS === 'android' ? (
                  <div className="bg-slate-50 rounded-2xl p-4 sm:p-5 border border-slate-200 space-y-3.5">
                    <h4 className="text-sm sm:text-base font-black text-slate-900 flex items-center gap-2">
                      <span>🤖 Cách cài lên Màn hình chính điện thoại Android (Chrome / Cốc Cốc):</span>
                    </h4>
                    <div className="space-y-2.5 text-xs sm:text-sm text-slate-700">
                      <div className="flex items-start gap-3 p-3 rounded-xl bg-white border border-slate-200/80">
                        <span className="w-6 h-6 rounded-full bg-teal-600 text-white font-black text-xs flex items-center justify-center shrink-0">
                          1
                        </span>
                        <div>
                          Mở đường dẫn ứng dụng bằng trình duyệt <strong>Google Chrome</strong> trên điện thoại Android.
                        </div>
                      </div>
                      <div className="flex items-start gap-3 p-3 rounded-xl bg-white border border-slate-200/80">
                        <span className="w-6 h-6 rounded-full bg-teal-600 text-white font-black text-xs flex items-center justify-center shrink-0">
                          2
                        </span>
                        <div className="flex items-center flex-wrap gap-1">
                          <span>Chạm vào biểu tượng menu</span>
                          <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-slate-100 border border-slate-300 font-bold text-slate-800">
                            <MoreVertical className="w-3.5 h-3.5" /> (3 chấm dọc)
                          </span>
                          <span>ở góc trên bên phải trình duyệt.</span>
                        </div>
                      </div>
                      <div className="flex items-start gap-3 p-3 rounded-xl bg-white border border-slate-200/80">
                        <span className="w-6 h-6 rounded-full bg-teal-600 text-white font-black text-xs flex items-center justify-center shrink-0">
                          3
                        </span>
                        <div>
                          Chọn <strong>&ldquo;Cài đặt ứng dụng&rdquo; (Install app)</strong> hoặc{' '}
                          <strong>&ldquo;Thêm vào Màn hình chính&rdquo; (Add to Home screen)</strong>. Biểu tượng{' '}
                          <strong className="text-teal-700">KHTN 7</strong> sẽ xuất hiện ngay trên màn hình điện thoại!
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-slate-50 rounded-2xl p-4 sm:p-5 border border-slate-200 space-y-3.5">
                    <h4 className="text-sm sm:text-base font-black text-slate-900 flex items-center gap-2">
                      <span>🍎 Cách cài lên Màn hình chính iPhone / iPad (Trình duyệt Safari):</span>
                    </h4>
                    <div className="space-y-2.5 text-xs sm:text-sm text-slate-700">
                      <div className="flex items-start gap-3 p-3 rounded-xl bg-white border border-slate-200/80">
                        <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-black text-xs flex items-center justify-center shrink-0">
                          1
                        </span>
                        <div>
                          Mở đường dẫn ứng dụng trong trình duyệt <strong>Safari</strong> trên iPhone hoặc iPad.
                        </div>
                      </div>
                      <div className="flex items-start gap-3 p-3 rounded-xl bg-white border border-slate-200/80">
                        <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-black text-xs flex items-center justify-center shrink-0">
                          2
                        </span>
                        <div className="flex items-center flex-wrap gap-1">
                          <span>Nhấn vào nút</span>
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-50 border border-blue-200 font-bold text-blue-700">
                            <Share className="w-3.5 h-3.5" /> Chia sẻ (Share)
                          </span>
                          <span>ở thanh công cụ phía dưới màn hình.</span>
                        </div>
                      </div>
                      <div className="flex items-start gap-3 p-3 rounded-xl bg-white border border-slate-200/80">
                        <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-black text-xs flex items-center justify-center shrink-0">
                          3
                        </span>
                        <div className="flex items-center flex-wrap gap-1">
                          <span>Cuộn xuống và chọn</span>
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-50 border border-emerald-200 font-bold text-emerald-800">
                            <PlusSquare className="w-3.5 h-3.5" /> Thêm vào MH chính (Add to Home Screen)
                          </span>
                          <span>rồi bấm <strong>Thêm (Add)</strong> ở góc phải trên cùng.</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Copy App Link to open on Phone */}
              <div className="p-3.5 rounded-2xl bg-teal-50/70 border border-teal-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <div className="text-xs text-teal-950">
                  <span className="font-extrabold block">🔗 Sao chép đường dẫn App để gửi qua Zalo / Điện thoại:</span>
                  <span className="text-slate-600 font-mono text-[11px] break-all">{appUrl}</span>
                </div>
                <button
                  type="button"
                  onClick={handleCopyUrl}
                  className="px-3.5 py-2 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-xs flex items-center gap-1.5 shrink-0 cursor-pointer transition"
                >
                  {copiedUrl ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-amber-300" />
                      <span>Đã sao chép Link!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Sao chép Link</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 rounded-b-3xl flex items-center justify-between">
          <span className="text-xs text-slate-500 font-semibold">
            Hỗ trợ hoạt động mượt mà cả trên Máy tính, Máy tính bảng & Điện thoại (iOS / Android)
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-[#081e26] hover:bg-teal-950 text-white font-extrabold text-xs sm:text-sm cursor-pointer transition"
          >
            Đóng cửa sổ
          </button>
        </div>
      </div>
    </div>
  );
};
