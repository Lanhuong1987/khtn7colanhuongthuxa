import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  X,
  Flame,
  Zap,
  Award,
  Clock,
  CheckCircle2,
  XCircle,
  Download,
  Sparkles,
  RotateCcw,
  ArrowRight,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  StudentProfile,
  WeeklyAssignment,
  calculateStudentGradeMetrics,
  CommendationRecord,
} from '../data/classStore';
import { ALL_KNTT_LESSONS } from '../data/allLessons';
import { SubSubject } from '../data/khtn7Data';
import { soundEngine } from '../utils/gameSoundEngine';

export interface StreakData {
  streakDays: number;
  lastCompletedDate: string;
  totalSprintsCompleted: number;
  bestSprintScore: number;
}

const STREAK_STORAGE_KEY = 'khtn7_daily_streak_v2';

export function loadStreakData(): StreakData {
  try {
    const raw = localStorage.getItem(STREAK_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (typeof parsed.streakDays === 'number') return parsed;
    }
  } catch {
    // ignore
  }
  return {
    streakDays: 3,
    lastCompletedDate: '',
    totalSprintsCompleted: 2,
    bestSprintScore: 5,
  };
}

export function saveStreakData(data: StreakData) {
  try {
    localStorage.setItem(STREAK_STORAGE_KEY, JSON.stringify(data));
  } catch {
    // ignore
  }
}

interface DailySprintAndCertificateModalProps {
  initialTab?: 'sprint' | 'certificate';
  student: StudentProfile;
  activeWeek: number;
  activeWeekAssignment: WeeklyAssignment;
  streakData: StreakData;
  onUpdateStreak: (next: StreakData) => void;
  onUpdateStudent: (updated: StudentProfile) => void;
  onClose: () => void;
}

interface SprintQuestionItem {
  uid: string;
  lessonTitle: string;
  question: string;
  options: [string, string, string, string];
  correctIndex: number;
  explanation: string;
}

const CERTIFICATE_TOPICS = [
  {
    id: 'topic-weekly',
    badge: 'DANH HIỆU TUẦN HỌC',
    title: 'NHÀ KHOA HỌC TRẺ XUẤT SẮC TUẦN',
    subtitle: 'Hoàn thành xuất sắc nhiệm vụ học tập & rèn luyện môn KHTN 7',
  },
  {
    id: 'topic-chem-1',
    badge: 'CHỦ ĐỀ 1 · HÓA HỌC 7',
    title: 'CHINH PHỤC NGUYÊN TỬ & BẢNG TUẦN HOÀN CÁC NTHH',
    subtitle: 'Nắm vững cấu tạo nguyên tử Rutherford–Bohr & quy luật Bảng tuần hoàn (Bài 2–4)',
  },
  {
    id: 'topic-chem-2',
    badge: 'CHỦ ĐỀ 2 · HÓA HỌC 7',
    title: 'CHUYÊN GIA PHÂN TỬ & LIÊN KẾT HÓA HỌC',
    subtitle: 'Làm chủ Đơn chất, Hợp chất, Liên kết Ion, Cộng hóa trị & Hóa trị (Bài 5–7)',
  },
  {
    id: 'topic-phys-1',
    badge: 'CHỦ ĐỀ 3 · VẬT LÍ 7',
    title: 'KĨ SƯ TỐC ĐỘ & ĐỒ THỊ QUÃNG ĐƯỜNG – THỜI GIAN',
    subtitle: 'Vận dụng thành thạo công thức v = s/t, cổng quang điện & an toàn giao thông (Bài 8–11)',
  },
  {
    id: 'topic-phys-2',
    badge: 'CHỦ ĐỀ 4 · VẬT LÍ 7',
    title: 'NHÀ THÁM HIỂM SÓNG ÂM & TẦN SỐ DAO ĐỘNG',
    subtitle: 'Hiểu sâu bản chất truyền âm, độ to (biên độ), độ cao (tần số Hz) & phản xạ âm (Bài 12–14)',
  },
  {
    id: 'topic-phys-3',
    badge: 'CHỦ ĐỀ 5 · VẬT LÍ 7',
    title: 'BẬC THẦY QUANG HỌC & PHẢN XẠ ÁNH SÁNG',
    subtitle: 'Làm chủ định luật phản xạ ánh sáng (i = i′) và tạo ảnh qua gương phẳng (Bài 15–17)',
  },
  {
    id: 'topic-phys-4',
    badge: 'CHỦ ĐỀ 6 · VẬT LÍ 7',
    title: 'CHUYÊN GIA TỪ TRƯỜNG & NAM CHÂM ĐIỆN',
    subtitle: 'Khám phá từ phổ, đường sức từ, từ trường Trái Đất & chế tạo nam châm điện (Bài 18–21)',
  },
  {
    id: 'topic-bio-all',
    badge: 'CHỦ ĐỀ 7–10 · SINH HỌC 7',
    title: 'NHÀ SINH HỌC TRẺ: TRAO ĐỔI CHẤT & CƠ THỂ SỐNG',
    subtitle: 'Chinh phục Quang hợp, Hô hấp tế bào, Cảm ứng, Sinh trưởng & Sinh sản ở sinh vật (Bài 22–38)',
  },
];

export const DailySprintAndCertificateModal: React.FC<DailySprintAndCertificateModalProps> = ({
  initialTab = 'sprint',
  student,
  activeWeek,
  activeWeekAssignment,
  streakData,
  onUpdateStreak,
  onUpdateStudent,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'sprint' | 'certificate'>(initialTab);

  // ================= TAB 1: DAILY 5-MINUTE SPRINT STATE =================
  const [sprintScope, setSprintScope] = useState<'week' | 'all' | SubSubject>('week');
  const [sprintRoundSeed, setSprintRoundSeed] = useState<number>(1);
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [secondsLeft, setSecondsLeft] = useState<number>(300); // 5 minutes = 300s
  const [sprintFinished, setSprintFinished] = useState<boolean>(false);
  const [rewardClaimed, setRewardClaimed] = useState<boolean>(false);

  // Build 5 curated sprint questions
  const sprintQuestions: SprintQuestionItem[] = useMemo(() => {
    let lessonsPool = ALL_KNTT_LESSONS;
    if (sprintScope === 'week') {
      const assigned = ALL_KNTT_LESSONS.filter((l) =>
        activeWeekAssignment.lessonIds.includes(l.id)
      );
      if (assigned.length > 0) lessonsPool = assigned;
    } else if (sprintScope !== 'all') {
      lessonsPool = ALL_KNTT_LESSONS.filter((l) => l.subject === sprintScope);
    }

    const allCandidateMcqs: SprintQuestionItem[] = [];
    lessonsPool.forEach((lesson) => {
      lesson.mcqs.slice(0, 10).forEach((q) => {
        allCandidateMcqs.push({
          uid: `${lesson.id}:${q.id}`,
          lessonTitle: `Bài ${lesson.lessonNumber}: ${lesson.title}`,
          question: q.question,
          options: q.options,
          correctIndex: q.correctIndex,
          explanation: q.explanation,
        });
      });
    });

    // Deterministic rotation using sprintRoundSeed so user gets fresh 5 questions on replay
    const shifted = [...allCandidateMcqs];
    const offset = ((sprintRoundSeed - 1) * 5) % Math.max(1, shifted.length);
    const rotated = [...shifted.slice(offset), ...shifted.slice(0, offset)];
    return rotated.slice(0, 5);
  }, [sprintScope, activeWeekAssignment, sprintRoundSeed]);

  // Countdown timer for 5-Minute Sprint
  useEffect(() => {
    if (activeTab !== 'sprint' || sprintFinished) return;
    const timer = window.setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          window.clearInterval(timer);
          setSprintFinished(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [activeTab, sprintFinished, sprintRoundSeed]);

  const startNewSprint = (nextScope: 'week' | 'all' | SubSubject = sprintScope) => {
    setSprintScope(nextScope);
    setSprintRoundSeed((prev) => prev + 1);
    setCurrentIdx(0);
    setSelectedAnswers({});
    setSecondsLeft(300);
    setSprintFinished(false);
    setRewardClaimed(false);
  };

  const fireCelebration = () => {
    soundEngine.playVictory();
    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.6 },
    });
  };

  const handleSelectOption = (qIndex: number, optIdx: number) => {
    if (sprintFinished || selectedAnswers[qIndex] !== undefined) return;
    const isRight = optIdx === sprintQuestions[qIndex].correctIndex;
    if (isRight) {
      soundEngine.playCorrect();
    } else {
      soundEngine.playWrong();
    }

    const nextAnswers = { ...selectedAnswers, [qIndex]: optIdx };
    setSelectedAnswers(nextAnswers);

    // Check if all 5 questions are now answered
    if (Object.keys(nextAnswers).length === sprintQuestions.length) {
      setTimeout(() => {
        completeSprintSession(nextAnswers);
      }, 650);
    }
  };

  const completeSprintSession = (finalAnswers: Record<number, number> = selectedAnswers) => {
    setSprintFinished(true);
    const correctCount = sprintQuestions.filter(
      (q, i) => finalAnswers[i] === q.correctIndex
    ).length;

    fireCelebration();

    if (!rewardClaimed) {
      setRewardClaimed(true);
      const todayStr = new Date().toLocaleDateString('vi-VN');
      const isNewDay = streakData.lastCompletedDate !== todayStr;
      const nextStreak: StreakData = {
        streakDays: isNewDay ? streakData.streakDays + 1 : streakData.streakDays,
        lastCompletedDate: todayStr,
        totalSprintsCompleted: streakData.totalSprintsCompleted + 1,
        bestSprintScore: Math.max(streakData.bestSprintScore, correctCount),
      };
      saveStreakData(nextStreak);
      onUpdateStreak(nextStreak);

      const bonusPts = correctCount >= 4 ? 15 : 10;
      const newComm: CommendationRecord = {
        id: `cm-sprint-${Date.now()}`,
        reason: `Hoàn thành Thử thách 5 Phút Đầu Giờ (Đúng ${correctCount}/5 câu · Chuỗi 🔥 ${nextStreak.streakDays} ngày)`,
        points: bonusPts,
        weekNumber: activeWeek,
        createdAt: todayStr,
      };
      onUpdateStudent({
        ...student,
        commendationPoints: (student.commendationPoints || 10) + bonusPts,
        commendationHistory: [newComm, ...(student.commendationHistory || [])],
      });
    }
  };

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const sprintCorrectCount = sprintQuestions.filter(
    (q, idx) => selectedAnswers[idx] === q.correctIndex
  ).length;

  // ================= TAB 2: CERTIFICATE GENERATOR STATE =================
  const [selectedTopicId, setSelectedTopicId] = useState<string>(CERTIFICATE_TOPICS[0].id);
  const [customTeacherName, setCustomTeacherName] = useState<string>('Giáo viên Bộ môn KHTN 7');
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const selectedCertTopic =
    CERTIFICATE_TOPICS.find((t) => t.id === selectedTopicId) || CERTIFICATE_TOPICS[0];
  const metrics = calculateStudentGradeMetrics(student);

  // Draw High-Resolution Certificate onto HTML5 Canvas whenever inputs change
  useEffect(() => {
    if (activeTab !== 'certificate') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = 1200;
    const H = 840;
    canvas.width = W;
    canvas.height = H;

    // 1. Cream & Mint Parchment Background Gradient
    const bgGrad = ctx.createLinearGradient(0, 0, W, H);
    bgGrad.addColorStop(0, '#fffdf7');
    bgGrad.addColorStop(0.5, '#f4fbf9');
    bgGrad.addColorStop(1, '#fef9e7');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, W, H);

    // 2. Outer Deep Teal Frame & Inner Royal Gold Double Border
    ctx.strokeStyle = '#081e26';
    ctx.lineWidth = 16;
    ctx.strokeRect(28, 28, W - 56, H - 56);

    ctx.strokeStyle = '#d97706';
    ctx.lineWidth = 4;
    ctx.strokeRect(48, 48, W - 96, H - 96);

    ctx.strokeStyle = '#0d9488';
    ctx.lineWidth = 2;
    ctx.strokeRect(58, 58, W - 116, H - 116);

    // Corner Ornaments
    const corners = [
      [58, 58],
      [W - 58, 58],
      [58, H - 58],
      [W - 58, H - 58],
    ];
    corners.forEach(([cx, cy]) => {
      ctx.fillStyle = '#d97706';
      ctx.beginPath();
      ctx.arc(cx, cy, 10, 0, Math.PI * 2);
      ctx.fill();
    });

    // 3. Top Header Banner
    ctx.fillStyle = '#0d9488';
    ctx.font = 'bold 20px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(
      'HỆ THỐNG HỌC TẬP THÔNG MINH · MÔN KHOA HỌC TỰ NHIÊN 7 (SÁCH KẾT NỐI TRI THỨC)',
      W / 2,
      118
    );

    // 4. Main Certificate Title
    ctx.fillStyle = '#b45309';
    ctx.font = '900 46px serif';
    ctx.fillText('GIẤY CHỨNG NHẬN CHINH PHỤC KHTN 7', W / 2, 182);

    // Topic Badge Pill
    ctx.fillStyle = '#081e26';
    ctx.fillRect(W / 2 - 210, 206, 420, 38);
    ctx.fillStyle = '#fde047';
    ctx.font = 'bold 18px monospace';
    ctx.fillText(selectedCertTopic.badge, W / 2, 231);

    // 5. "Trao tặng cho Học sinh"
    ctx.fillStyle = '#475569';
    ctx.font = 'italic 22px serif';
    ctx.fillText('Trân trọng trao tặng cho nhà khoa học trẻ:', W / 2, 290);

    // Student Full Name
    ctx.fillStyle = '#0f172a';
    ctx.font = '900 50px sans-serif';
    ctx.fillText(student.fullName.toUpperCase(), W / 2, 355);

    // Student Class & Code
    ctx.fillStyle = '#0f766e';
    ctx.font = 'bold 24px sans-serif';
    ctx.fillText(
      `Lớp: ${student.className}   ·   Mã học sinh: ${student.code}   ·   Tuần học: Tuần ${activeWeek}`,
      W / 2,
      398
    );

    // Divider Line
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(220, 422);
    ctx.lineTo(W - 220, 422);
    ctx.stroke();

    // 6. Topic Achievement Title & Subtitle
    ctx.fillStyle = '#b45309';
    ctx.font = '900 30px sans-serif';
    ctx.fillText(selectedCertTopic.title, W / 2, 472);

    ctx.fillStyle = '#334155';
    ctx.font = '21px sans-serif';
    ctx.fillText(selectedCertTopic.subtitle, W / 2, 512);

    // 7. 3 Metrics Boxes (Average Score, Commendation Points, Streak)
    const boxes = [
      {
        label: 'ĐIỂM TRUNG BÌNH KHTN 7',
        val: `${metrics.average.toFixed(2)} (${metrics.rankLabel})`,
        x: 240,
      },
      {
        label: 'ĐIỂM RÈN LUYỆN & TUYÊN DƯƠNG',
        val: `+${student.commendationPoints || 10} Điểm thưởng`,
        x: 600,
      },
      {
        label: 'CHUỖI NGÀY HỌC LIÊN TIẾP',
        val: `🔥 ${streakData.streakDays} Ngày Streak`,
        x: 960,
      },
    ];

    boxes.forEach((b) => {
      ctx.fillStyle = '#ffffff';
      ctx.strokeStyle = '#99f6e4';
      ctx.lineWidth = 3;
      ctx.fillRect(b.x - 150, 545, 300, 92);
      ctx.strokeRect(b.x - 150, 545, 300, 92);

      ctx.fillStyle = '#64748b';
      ctx.font = 'bold 14px sans-serif';
      ctx.fillText(b.label, b.x, 578);

      ctx.fillStyle = '#0f172a';
      ctx.font = '900 24px sans-serif';
      ctx.fillText(b.val, b.x, 616);
    });

    // 8. Bottom Seal & Signatures
    const dateStr = new Date().toLocaleDateString('vi-VN');
    ctx.fillStyle = '#475569';
    ctx.font = 'italic 19px serif';
    ctx.fillText(`Cấp ngày ${dateStr}`, 270, 715);
    ctx.font = 'bold 20px sans-serif';
    ctx.fillStyle = '#0f172a';
    ctx.fillText('HỘI ĐỒNG KHOA HỌC TRẺ KHTN 7', 270, 748);

    // Center Golden Seal Circle
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.arc(W / 2, 720, 48, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#fef3c7';
    ctx.lineWidth = 4;
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.font = '900 18px sans-serif';
    ctx.fillText('★ KHTN 7 ★', W / 2, 716);
    ctx.font = 'bold 13px sans-serif';
    ctx.fillText('XUẤT SẮC', W / 2, 736);

    // Right Teacher Signature
    ctx.fillStyle = '#475569';
    ctx.font = 'italic 19px serif';
    ctx.fillText('Xác nhận của Giáo viên bộ môn', W - 270, 715);
    ctx.fillStyle = '#0d9488';
    ctx.font = 'bold 22px sans-serif';
    ctx.fillText(customTeacherName, W - 270, 750);
  }, [activeTab, selectedCertTopic, student, activeWeek, metrics, streakData, customTeacherName]);

  const handleDownloadCertificatePng = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `Giay_Khen_KHTN7_${student.code}_Tuan_${activeWeek}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    fireCelebration();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white rounded-3xl max-w-5xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
        {/* Top Modal Header */}
        <div className="bg-gradient-to-r from-[#081e26] via-[#0d3842] to-[#081e26] text-white px-6 py-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shadow">
              <Flame className="w-6 h-6 text-rose-600 fill-rose-500" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-amber-300">
                  PHÒNG RÈN LUYỆN PHẢN XẠ & VINH DANH KHOA HỌC TRẺ KHTN 7
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-rose-600 text-white text-xs font-black flex items-center gap-1">
                  🔥 Chuỗi {streakData.streakDays} ngày liên tiếp
                </span>
              </div>
              <h3 className="text-lg sm:text-xl font-black text-white">
                Học sinh: {student.fullName} ({student.code} – {student.className})
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('sprint')}
              className={`px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer ${
                activeTab === 'sprint'
                  ? 'bg-amber-400 text-slate-950 shadow'
                  : 'bg-white/10 hover:bg-white/20 text-white'
              }`}
            >
              <Zap className="w-4 h-4" />
              <span>⚡ Thử Thách 5 Phút & Streak 🔥</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('certificate')}
              className={`px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer ${
                activeTab === 'certificate'
                  ? 'bg-emerald-400 text-slate-950 shadow'
                  : 'bg-white/10 hover:bg-white/20 text-white'
              }`}
            >
              <Award className="w-4 h-4" />
              <span>🏅 Xuất Giấy Khen KHTN 7</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 bg-slate-50/60">
          {activeTab === 'sprint' ? (
            <div className="space-y-5">
              {/* Streak & 7-Day Flame Tracker Bar */}
              <div className="bg-gradient-to-r from-amber-50 via-orange-50 to-rose-50 border border-amber-200 rounded-2xl p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 to-rose-500 text-white flex flex-col items-center justify-center shadow-sm shrink-0">
                    <span className="text-xl font-black leading-none">{streakData.streakDays}</span>
                    <span className="text-[10px] font-extrabold uppercase">Ngày 🔥</span>
                  </div>
                  <div>
                    <h4 className="text-base font-black text-slate-900">
                      Chuỗi Ngày Học Liên Tiếp (Daily Streak 🔥)
                    </h4>
                    <p className="text-xs sm:text-sm text-slate-600">
                      Hoàn thành 5 câu hỏi nhanh trong 5 phút để giữ lửa Streak và nhận ngay{' '}
                      <strong className="text-emerald-700">+15 điểm rèn luyện</strong> vào hồ sơ tuần!
                    </p>
                  </div>
                </div>

                {/* Scope Selector */}
                <div className="flex flex-wrap items-center gap-1.5">
                  {[
                    { id: 'week' as const, label: `📌 Tuần ${activeWeek}` },
                    { id: 'all' as const, label: 'Tất cả 30 bài' },
                    { id: 'chemistry' as const, label: '🧪 Hóa 7' },
                    { id: 'physics' as const, label: '⚡ Lí 7' },
                    { id: 'biology' as const, label: '🌿 Sinh 7' },
                  ].map((sc) => (
                    <button
                      key={sc.id}
                      type="button"
                      onClick={() => startNewSprint(sc.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                        sprintScope === sc.id
                          ? 'bg-slate-900 text-white'
                          : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                      }`}
                    >
                      {sc.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Parallel Layout: Active Sprint Question (8 cols) + 5-Question Coordinator & Timer (4 cols) */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
                <div className="lg:col-span-8 space-y-4">
                  {sprintFinished ? (
                    <div className="bg-white rounded-2xl border-2 border-emerald-400 p-6 text-center space-y-4 shadow-md">
                      <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                        <Sparkles className="w-8 h-8" />
                      </div>
                      <h4 className="text-2xl font-black text-slate-900">
                        🎉 Hoàn thành Thử Thách 5 Phút Đầu Giờ!
                      </h4>
                      <p className="text-sm text-slate-600">
                        Em trả lời đúng{' '}
                        <strong className="text-emerald-700 text-base">
                          {sprintCorrectCount} / {sprintQuestions.length} câu
                        </strong>{' '}
                        · Chuỗi Streak hiện tại:{' '}
                        <strong className="text-rose-600">🔥 {streakData.streakDays} ngày liên tiếp</strong>!
                      </p>
                      <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                        <button
                          type="button"
                          onClick={() => startNewSprint(sprintScope)}
                          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 cursor-pointer"
                        >
                          <RotateCcw className="w-4 h-4" />
                          <span>Thử thách 5 câu mới</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setActiveTab('certificate')}
                          className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-1.5 cursor-pointer"
                        >
                          <Award className="w-4 h-4" />
                          <span>Nhận Giấy Khen KHTN 7 ngay →</span>
                        </button>
                      </div>
                    </div>
                  ) : null}

                  {/* Active Sprint Question Card */}
                  {sprintQuestions[currentIdx] && (
                    <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
                        <span className="px-3 py-1 rounded-lg bg-slate-900 text-white font-mono text-xs font-bold">
                          Câu {currentIdx + 1} / {sprintQuestions.length}
                        </span>
                        <span className="text-xs font-bold text-teal-700">
                          {sprintQuestions[currentIdx].lessonTitle}
                        </span>
                      </div>

                      <p className="text-base sm:text-lg font-bold text-slate-900 leading-relaxed">
                        {sprintQuestions[currentIdx].question}
                      </p>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {sprintQuestions[currentIdx].options.map((opt, optIdx) => {
                          const letter = ['A', 'B', 'C', 'D'][optIdx];
                          const chosen = selectedAnswers[currentIdx];
                          const isAnswered = chosen !== undefined;
                          const isRight =
                            optIdx === sprintQuestions[currentIdx].correctIndex;

                          let btnStyle =
                            'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800';
                          if (isAnswered) {
                            if (isRight) {
                              btnStyle =
                                'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold';
                            } else if (chosen === optIdx) {
                              btnStyle =
                                'bg-rose-50 border-rose-400 text-rose-900 line-through';
                            } else {
                              btnStyle = 'bg-slate-50/50 border-slate-200 text-slate-400';
                            }
                          }

                          return (
                            <button
                              key={optIdx}
                              type="button"
                              onClick={() => handleSelectOption(currentIdx, optIdx)}
                              className={`p-3.5 rounded-xl border text-left text-sm transition flex items-start gap-2.5 cursor-pointer ${btnStyle}`}
                            >
                              <span className="w-6 h-6 rounded-md bg-white border border-slate-300 font-mono text-xs font-bold flex items-center justify-center shrink-0">
                                {letter}
                              </span>
                              <span>{opt}</span>
                            </button>
                          );
                        })}
                      </div>

                      {selectedAnswers[currentIdx] !== undefined && (
                        <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm text-slate-700 flex items-start justify-between gap-3">
                          <div>
                            <strong className="text-slate-900">Giải thích nhanh:</strong>{' '}
                            {sprintQuestions[currentIdx].explanation}
                          </div>
                          {currentIdx < sprintQuestions.length - 1 && (
                            <button
                              type="button"
                              onClick={() => setCurrentIdx((prev) => prev + 1)}
                              className="px-3.5 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold shrink-0 flex items-center gap-1 cursor-pointer"
                            >
                              <span>Câu tiếp</span>
                              <ArrowRight className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Right Column (4 cols): Parallel 5-Question Coordinator & Countdown */}
                <div className="lg:col-span-4 bg-white rounded-2xl border-2 border-teal-500/80 p-5 space-y-4 shadow-xs">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <span className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-rose-600" />
                      <span>Thời gian 5 phút:</span>
                    </span>
                    <span className="font-mono text-xl font-black text-slate-900 tabular-nums">
                      {formatTimer(secondsLeft)}
                    </span>
                  </div>

                  <div className="space-y-2">
                    <div className="text-xs font-extrabold text-slate-800">
                      Bảng điều phối 5 câu thử thách:
                    </div>
                    <div className="grid grid-cols-5 gap-2">
                      {sprintQuestions.map((q, idx) => {
                        const ans = selectedAnswers[idx];
                        const isDone = ans !== undefined;
                        const isRight = isDone && ans === q.correctIndex;
                        const isCurrent = idx === currentIdx;

                        return (
                          <button
                            key={q.uid}
                            type="button"
                            onClick={() => setCurrentIdx(idx)}
                            className={`h-10 rounded-xl font-mono text-xs font-black border transition cursor-pointer ${
                              isCurrent ? 'ring-2 ring-blue-600 ' : ''
                            }${
                              !isDone
                                ? 'bg-slate-50 border-dashed border-slate-300 text-slate-700'
                                : isRight
                                ? 'bg-emerald-600 border-emerald-600 text-white'
                                : 'bg-rose-600 border-rose-600 text-white'
                            }`}
                          >
                            {idx + 1}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="text-xs text-slate-600 space-y-1 pt-2 border-t border-slate-100">
                    <div>
                      • Đã làm:{' '}
                      <strong>
                        {Object.keys(selectedAnswers).length}/{sprintQuestions.length} câu
                      </strong>
                    </div>
                    <div>
                      • Còn thiếu:{' '}
                      <strong className="text-rose-600">
                        {sprintQuestions.length - Object.keys(selectedAnswers).length} câu
                      </strong>
                    </div>
                  </div>

                  {!sprintFinished && (
                    <button
                      type="button"
                      onClick={() => completeSprintSession(selectedAnswers)}
                      className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs cursor-pointer"
                    >
                      Hoàn thành & Nhận +15 điểm Streak
                    </button>
                  )}
                </div>
              </div>
            </div>
          ) : (
            /* ================= TAB 2: CERTIFICATE GENERATOR & PNG EXPORT ================= */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left 4 Cols: Certificate Topic & Teacher Signature Controls */}
              <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-xs">
                <div>
                  <h4 className="text-base font-black text-slate-900">
                    Tuỳ chỉnh Giấy Khen KHTN 7
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Chọn chủ đề đã chinh phục để cấp Giấy chứng nhận mang tên{' '}
                    <strong>{student.fullName}</strong>.
                  </p>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-extrabold text-slate-700">
                    Chọn Chủ đề / Danh hiệu vinh danh:
                  </label>
                  <div className="space-y-1.5 max-h-64 overflow-y-auto pr-1">
                    {CERTIFICATE_TOPICS.map((topic) => (
                      <button
                        key={topic.id}
                        type="button"
                        onClick={() => setSelectedTopicId(topic.id)}
                        className={`w-full p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedTopicId === topic.id
                            ? 'bg-slate-900 text-white border-slate-900'
                            : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                        }`}
                      >
                        <div
                          className={`text-[10px] font-mono font-bold ${
                            selectedTopicId === topic.id ? 'text-amber-300' : 'text-teal-700'
                          }`}
                        >
                          {topic.badge}
                        </div>
                        <div className="text-xs font-extrabold leading-snug mt-0.5">
                          {topic.title}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-slate-700 mb-1">
                    Tên Giáo viên ký xác nhận trên Giấy khen:
                  </label>
                  <input
                    type="text"
                    value={customTeacherName}
                    onChange={(e) => setCustomTeacherName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold focus:outline-none focus:border-teal-600"
                  />
                </div>

                <div className="pt-2 space-y-2">
                  <button
                    type="button"
                    onClick={handleDownloadCertificatePng}
                    className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>📥 Tải Giấy Khen về máy (Ảnh PNG)</span>
                  </button>
                  <button
                    type="button"
                    onClick={fireCelebration}
                    className="w-full py-2.5 px-4 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-950 font-extrabold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4 text-amber-700" />
                    <span>🎆 Bắn pháo hoa vinh danh học sinh</span>
                  </button>
                </div>
              </div>

              {/* Right 8 Cols: Live High-Res Certificate Canvas Preview */}
              <div className="lg:col-span-8 bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-800 flex flex-col items-center space-y-3">
                <div className="w-full flex items-center justify-between text-xs text-slate-300">
                  <span className="font-bold text-amber-300">
                    🏅 Bản xem trước Giấy Chứng Nhận KHTN 7 (Độ phân giải cao 1200×840 px)
                  </span>
                  <span>Học sinh: {student.fullName}</span>
                </div>
                <canvas
                  ref={canvasRef}
                  className="w-full h-auto rounded-xl shadow-2xl border border-amber-400/40 bg-white"
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
