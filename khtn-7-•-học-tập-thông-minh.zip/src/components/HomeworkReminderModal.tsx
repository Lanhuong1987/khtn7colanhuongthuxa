import React, { useState } from 'react';
import {
  Bell,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Send,
  Users,
  Calendar,
  ArrowRight,
  Volume2,
  X,
  Check,
  Sparkles,
} from 'lucide-react';
import { StudentProfile, WeeklyAssignment } from '../data/classStore';
import { ALL_KNTT_LESSONS } from '../data/allLessons';
import { EssaySubmission } from '../data/lessonTypes';
import { soundEngine } from '../utils/gameSoundEngine';

export interface HomeworkReminderSchedule {
  enabled: boolean;
  timeOfDay: string; // e.g. '19:30'
  daysOfWeek: string[]; // ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN']
  soundEnabled: boolean;
  browserNotificationEnabled: boolean;
  note: string;
}

export interface TeacherHomeworkReminderLog {
  id: string;
  weekNumber: number;
  weekTitle: string;
  dueDate: string;
  targetStudentIds: string[]; // empty or ['ALL_INCOMPLETE'] or specific student IDs
  targetStudentNames: string[];
  message: string;
  createdAt: string;
  acknowledgedByStudentIds: string[];
}

const REMINDER_SCHEDULE_KEY = 'khtn7_hw_reminder_schedule_v2';
const TEACHER_REMINDER_LOGS_KEY = 'khtn7_teacher_hw_reminders_v2';

export function loadReminderSchedule(): HomeworkReminderSchedule {
  try {
    const raw = localStorage.getItem(REMINDER_SCHEDULE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch {
    // ignore
  }
  return {
    enabled: true,
    timeOfDay: '19:30',
    daysOfWeek: ['T2', 'T3', 'T4', 'T5', 'T6', 'T7'],
    soundEnabled: true,
    browserNotificationEnabled: false,
    note: 'Hoàn thành bài tập Trắc nghiệm, Đúng/Sai và Tự luận KHTN 7 trước hạn nộp mỗi tuần.',
  };
}

export function saveReminderSchedule(sched: HomeworkReminderSchedule): void {
  try {
    localStorage.setItem(REMINDER_SCHEDULE_KEY, JSON.stringify(sched));
  } catch {
    // ignore
  }
}

export function loadTeacherReminderLogs(): TeacherHomeworkReminderLog[] {
  try {
    const raw = localStorage.getItem(TEACHER_REMINDER_LOGS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // ignore
  }
  return [
    {
      id: 'rem-default-1',
      weekNumber: 6,
      weekTitle: 'Tuần 6: Ôn tập & BTVN KHTN 7 KNTT',
      dueDate: 'Thứ Sáu tuần này',
      targetStudentIds: ['ALL_INCOMPLETE'],
      targetStudentNames: ['Tất cả học sinh chưa hoàn thành BTVN Tuần 6'],
      message:
        'Các em chú ý hoàn thành đủ câu hỏi Trắc nghiệm, Đúng/Sai và đính kèm ảnh vở bài tập Tự luận trước Thứ Sáu để thầy/cô tổng hợp điểm thường xuyên nhé!',
      createdAt: 'Hôm nay, 07:30',
      acknowledgedByStudentIds: [],
    },
  ];
}

export function saveTeacherReminderLogs(logs: TeacherHomeworkReminderLog[]): void {
  try {
    localStorage.setItem(TEACHER_REMINDER_LOGS_KEY, JSON.stringify(logs));
  } catch {
    // ignore
  }
}

export function computeActiveStudentWeekHomeworkGap(
  student: StudentProfile,
  week: WeeklyAssignment
) {
  let liveMcqDone = 0;
  let liveTfDone = 0;
  let liveEssayDone = 0;

  try {
    const mcqAnswers: Record<string, number> = JSON.parse(
      localStorage.getItem('khtn7_kntt_mcq_v2') || '{}'
    );
    const tfAnswers: Record<string, boolean> = JSON.parse(
      localStorage.getItem('khtn7_kntt_tf_v2') || '{}'
    );
    const essaySubmissions: Record<string, EssaySubmission> = JSON.parse(
      localStorage.getItem('khtn7_kntt_essay_v2') || '{}'
    );

    for (const lessonId of week.lessonIds) {
      const lesson = ALL_KNTT_LESSONS.find((l) => l.id === lessonId);
      if (!lesson) continue;

      for (const mcq of lesson.mcqs) {
        if (mcqAnswers[`${lesson.id}:${mcq.id}`] !== undefined) {
          liveMcqDone++;
        }
      }
      for (const tf of lesson.trueFalseList) {
        const allAnswered = tf.statements.every(
          (st) => tfAnswers[`${lesson.id}:${tf.id}:${st.id}`] !== undefined
        );
        if (allAnswered) liveTfDone++;
      }
      for (const es of lesson.essays) {
        const sub = essaySubmissions[`${lesson.id}:${es.id}`];
        if (sub && (sub.textAnswer?.trim() || (sub.attachedImages && sub.attachedImages.length > 0))) {
          liveEssayDone++;
        }
      }
    }
  } catch {
    // ignore
  }

  const hasBaselineDone = student.baselineWeeksCompleted.includes(week.weekNumber);

  const mcqDone = hasBaselineDone ? week.targetMcq : Math.min(week.targetMcq, liveMcqDone);
  const tfDone = hasBaselineDone ? week.targetTf : Math.min(week.targetTf, liveTfDone);
  const essayDone = hasBaselineDone ? week.targetEssay : Math.min(week.targetEssay, liveEssayDone);

  const mcqMissing = Math.max(0, week.targetMcq - mcqDone);
  const tfMissing = Math.max(0, week.targetTf - tfDone);
  const essayMissing = Math.max(0, week.targetEssay - essayDone);

  const totalTarget = Math.max(1, week.targetMcq + week.targetTf + week.targetEssay);
  const totalDone = mcqDone + tfDone + essayDone;
  const percent = Math.min(100, Math.round((totalDone / totalTarget) * 100));

  return {
    mcqDone,
    tfDone,
    essayDone,
    mcqMissing,
    tfMissing,
    essayMissing,
    totalMissing: mcqMissing + tfMissing + essayMissing,
    percent,
    isCompleted: percent >= 100,
  };
}

interface HomeworkReminderModalProps {
  currentStudent: StudentProfile;
  students: StudentProfile[];
  activeWeek: number;
  activeWeekAssignment: WeeklyAssignment;
  isTeacherAuthenticated: boolean;
  reminderSchedule: HomeworkReminderSchedule;
  reminderLogs: TeacherHomeworkReminderLog[];
  onUpdateSchedule: (next: HomeworkReminderSchedule) => void;
  onUpdateReminderLogs: (next: TeacherHomeworkReminderLog[]) => void;
  onStartHomeworkNow: (lessonId: string) => void;
  onClose: () => void;
}

export const HomeworkReminderModal: React.FC<HomeworkReminderModalProps> = ({
  currentStudent,
  students,
  activeWeek,
  activeWeekAssignment,
  isTeacherAuthenticated,
  reminderSchedule,
  reminderLogs,
  onUpdateSchedule,
  onUpdateReminderLogs,
  onStartHomeworkNow,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'student_schedule' | 'teacher_send' | 'logs'>(
    'student_schedule'
  );
  const [scheduleDraft, setScheduleDraft] = useState<HomeworkReminderSchedule>(reminderSchedule);
  const [statusToast, setStatusToast] = useState<string | null>(null);

  // Teacher broadcast reminder state
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);
  const [customReminderMsg, setCustomReminderMsg] = useState<string>(
    `Nhắc nhở BTVN Tuần ${activeWeek} (${activeWeekAssignment.title}): Các em hoàn thành đầy đủ câu hỏi Trắc nghiệm, Đúng/Sai và nộp bài Tự luận trước hạn ${activeWeekAssignment.dueDate} nhé!`
  );

  const studentGap = computeActiveStudentWeekHomeworkGap(
    currentStudent,
    activeWeekAssignment
  );

  const incompleteStudents = students.filter(
    (s) => !s.baselineWeeksCompleted.includes(activeWeek)
  );

  const assignedLessons = ALL_KNTT_LESSONS.filter((l) =>
    activeWeekAssignment.lessonIds.includes(l.id)
  );

  const showToast = (msg: string) => {
    setStatusToast(msg);
    setTimeout(() => setStatusToast(null), 4000);
  };

  const handleToggleDay = (day: string) => {
    setScheduleDraft((prev) => {
      const exists = prev.daysOfWeek.includes(day);
      const nextDays = exists
        ? prev.daysOfWeek.filter((d) => d !== day)
        : [...prev.daysOfWeek, day];
      return { ...prev, daysOfWeek: nextDays };
    });
  };

  const handleSaveSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSchedule(scheduleDraft);
    saveReminderSchedule(scheduleDraft);
    soundEngine.playCorrect();
    showToast(
      `⏰ Đã lưu lịch nhắc nhở học BTVN lúc ${scheduleDraft.timeOfDay} (${scheduleDraft.daysOfWeek.join(', ')})!`
    );
  };

  const handleTestNotification = async () => {
    soundEngine.playVictory();
    if ('Notification' in window) {
      if (Notification.permission === 'granted') {
        new Notification('🔔 Nhắc nhở Bài tập về nhà KHTN 7 MASTER', {
          body: `${currentStudent.fullName} ơi! Đã đến giờ ôn bài Tuần ${activeWeek}: ${activeWeekAssignment.title} (Hạn: ${activeWeekAssignment.dueDate}).`,
          icon: '/pwa-192x192.png',
        });
        setScheduleDraft((prev) => ({ ...prev, browserNotificationEnabled: true }));
        showToast('🔔 Đã phát chuông và gửi thông báo nhắc nhở BTVN trên trình duyệt!');
        return;
      } else if (Notification.permission !== 'denied') {
        const perm = await Notification.requestPermission();
        if (perm === 'granted') {
          new Notification('🔔 Nhắc nhở Bài tập về nhà KHTN 7 MASTER', {
            body: `${currentStudent.fullName} ơi! Đã đến giờ hoàn thành BTVN Tuần ${activeWeek}.`,
            icon: '/pwa-192x192.png',
          });
          setScheduleDraft((prev) => ({ ...prev, browserNotificationEnabled: true }));
          showToast('🔔 Đã cấp quyền và gửi thông báo nhắc nhở BTVN thành công!');
          return;
        }
      }
    }
    showToast(
      `🔔 Chuông nhắc nhở: "${currentStudent.fullName} ơi, hãy hoàn thành nốt ${studentGap.totalMissing} mục BTVN Tuần ${activeWeek} trước hạn ${activeWeekAssignment.dueDate} nhé!"`
    );
  };

  const handleToggleSelectStudent = (id: string) => {
    setSelectedStudentIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSendTeacherReminder = (sendToAllIncomplete: boolean) => {
    const targets = sendToAllIncomplete
      ? incompleteStudents
      : students.filter((s) => selectedStudentIds.includes(s.id));

    if (targets.length === 0) {
      showToast('⚠️ Vui lòng chọn ít nhất 1 học sinh để gửi nhắc nhở BTVN!');
      return;
    }

    const nowStr = new Date().toLocaleString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });

    const newLog: TeacherHomeworkReminderLog = {
      id: `rem-${Date.now()}`,
      weekNumber: activeWeek,
      weekTitle: activeWeekAssignment.title,
      dueDate: activeWeekAssignment.dueDate,
      targetStudentIds: targets.map((t) => t.id),
      targetStudentNames: targets.map((t) => `${t.fullName} (${t.className})`),
      message: customReminderMsg.trim(),
      createdAt: nowStr,
      acknowledgedByStudentIds: [],
    };

    const nextLogs = [newLog, ...reminderLogs];
    onUpdateReminderLogs(nextLogs);
    saveTeacherReminderLogs(nextLogs);
    soundEngine.playCorrect();
    showToast(
      `📣 Đã gửi thông báo nhắc nhở hoàn thành BTVN Tuần ${activeWeek} tới ${targets.length} học sinh và Sổ liên lạc Phụ huynh!`
    );
  };

  const handleAcknowledgeReminder = (logId: string) => {
    const nextLogs = reminderLogs.map((log) => {
      if (log.id !== logId) return log;
      if (log.acknowledgedByStudentIds.includes(currentStudent.id)) return log;
      return {
        ...log,
        acknowledgedByStudentIds: [...log.acknowledgedByStudentIds, currentStudent.id],
      };
    });
    onUpdateReminderLogs(nextLogs);
    saveTeacherReminderLogs(nextLogs);
    soundEngine.playCorrect();
    showToast(`✅ Đã xác nhận "${currentStudent.fullName}" đã xem nhắc nhở và cam kết hoàn thành BTVN!`);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Top Modal Header */}
        <div className="bg-gradient-to-r from-[#071936] via-[#0a2748] to-[#063d3f] px-6 py-5 text-white flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center shadow-md shrink-0">
              <Bell className="w-6 h-6" />
            </div>
            <div>
              <div className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-300">
                HỆ THỐNG NHẮC NHỞ HỌC TẬP THÔNG MINH · TUẦN {activeWeek} ({activeWeekAssignment.semesterLabel || 'HK1'})
              </div>
              <h3 className="text-lg sm:text-xl font-black text-white">
                Nhắc Nhở Hoàn Thành Bài Tập Về Nhà KHTN 7
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 3-Tab Switcher */}
        <div className="px-6 pt-4 bg-slate-50 border-b border-slate-200 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('student_schedule')}
            className={`px-4 py-2.5 rounded-t-2xl text-xs sm:text-sm font-extrabold transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'student_schedule'
                ? 'bg-white text-[#0d6efd] border-t border-x border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>1. Tiến độ & Hẹn giờ Nhắc học BTVN</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('teacher_send')}
            className={`px-4 py-2.5 rounded-t-2xl text-xs sm:text-sm font-extrabold transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'teacher_send'
                ? 'bg-white text-[#0d6efd] border-t border-x border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Send className="w-4 h-4" />
            <span>
              2. Giáo viên Gửi Nhắc nhở ({incompleteStudents.length} HS chưa xong)
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('logs')}
            className={`px-4 py-2.5 rounded-t-2xl text-xs sm:text-sm font-extrabold transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'logs'
                ? 'bg-white text-[#0d6efd] border-t border-x border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Bell className="w-4 h-4" />
            <span>3. Phiếu Nhắc nhở từ Giáo viên ({reminderLogs.length})</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 overflow-y-auto">
          {statusToast && (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs sm:text-sm font-extrabold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{statusToast}</span>
            </div>
          )}

          {/* TAB 1: TIẾN ĐỘ BTVN TUẦN HIỆN TẠI & HẸN GIỜ NHẮC HỌC HẰNG NGÀY */}
          {activeTab === 'student_schedule' && (
            <div className="space-y-6">
              {/* Current Week Homework Checklist Card */}
              <div
                className={`rounded-3xl border-2 p-5 space-y-4 ${
                  studentGap.isCompleted
                    ? 'bg-emerald-50/60 border-emerald-400'
                    : 'bg-amber-50/70 border-amber-300'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="text-xs font-black uppercase text-slate-700">
                      KIỂM TRA BÀI TẬP VỀ NHÀ CỦA HỌC SINH:{' '}
                      <span className="text-indigo-700">{currentStudent.fullName}</span> (
                      {currentStudent.className})
                    </div>
                    <h4 className="text-base sm:text-lg font-black text-slate-900 mt-0.5">
                      {activeWeekAssignment.title}
                    </h4>
                    <p className="text-xs text-slate-600">
                      Hạn hoàn thành:{' '}
                      <strong className="text-rose-600">{activeWeekAssignment.dueDate}</strong> ·
                      Tiến độ hiện tại: <strong>{studentGap.percent}%</strong>
                    </p>
                  </div>

                  {studentGap.isCompleted ? (
                    <span className="px-4 py-2 rounded-2xl bg-emerald-600 text-white text-xs font-black flex items-center gap-1.5 shrink-0">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Đã hoàn thành 100% BTVN</span>
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        const firstLessonId =
                          activeWeekAssignment.lessonIds[0] || ALL_KNTT_LESSONS[0].id;
                        onStartHomeworkNow(firstLessonId);
                        onClose();
                      }}
                      className="px-4 py-2.5 rounded-2xl bg-[#0d6efd] hover:bg-blue-700 text-white text-xs sm:text-sm font-black flex items-center gap-1.5 shadow-md transition shrink-0 cursor-pointer"
                    >
                      <span>Làm ngay bài tập còn thiếu</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* 3 Progress Breakdown Boxes */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="bg-white rounded-2xl border border-slate-200 p-3.5 flex items-center justify-between">
                    <div>
                      <span className="text-[11px] font-bold text-slate-500 block">
                        1. Câu hỏi Trắc nghiệm
                      </span>
                      <span className="text-sm font-black text-slate-900">
                        Đã làm {studentGap.mcqDone}/{activeWeekAssignment.targetMcq} câu
                      </span>
                    </div>
                    {studentGap.mcqMissing > 0 ? (
                      <span className="text-xs font-extrabold text-rose-600">
                        Còn thiếu {studentGap.mcqMissing} câu
                      </span>
                    ) : (
                      <span className="text-xs font-extrabold text-emerald-600">✓ Đủ</span>
                    )}
                  </div>

                  <div className="bg-white rounded-2xl border border-slate-200 p-3.5 flex items-center justify-between">
                    <div>
                      <span className="text-[11px] font-bold text-slate-500 block">
                        2. Bài tập Đúng / Sai
                      </span>
                      <span className="text-sm font-black text-slate-900">
                        Đã làm {studentGap.tfDone}/{activeWeekAssignment.targetTf} bài
                      </span>
                    </div>
                    {studentGap.tfMissing > 0 ? (
                      <span className="text-xs font-extrabold text-rose-600">
                        Còn thiếu {studentGap.tfMissing} bài
                      </span>
                    ) : (
                      <span className="text-xs font-extrabold text-emerald-600">✓ Đủ</span>
                    )}
                  </div>

                  <div className="bg-white rounded-2xl border border-slate-200 p-3.5 flex items-center justify-between">
                    <div>
                      <span className="text-[11px] font-bold text-slate-500 block">
                        3. Bài tập Tự luận
                      </span>
                      <span className="text-sm font-black text-slate-900">
                        Đã làm {studentGap.essayDone}/{activeWeekAssignment.targetEssay} bài
                      </span>
                    </div>
                    {studentGap.essayMissing > 0 ? (
                      <span className="text-xs font-extrabold text-rose-600">
                        Còn thiếu {studentGap.essayMissing} bài
                      </span>
                    ) : (
                      <span className="text-xs font-extrabold text-emerald-600">✓ Đủ</span>
                    )}
                  </div>
                </div>

                {/* Direct Links to Assigned Lessons of the Week */}
                {assignedLessons.length > 0 && (
                  <div className="pt-2 border-t border-amber-200/80 flex flex-wrap items-center gap-2">
                    <span className="text-xs font-bold text-slate-700">
                      Bài học cần hoàn thành trong Tuần {activeWeek}:
                    </span>
                    {assignedLessons.map((lesson) => (
                      <button
                        key={lesson.id}
                        type="button"
                        onClick={() => {
                          onStartHomeworkNow(lesson.id);
                          onClose();
                        }}
                        className="px-3 py-1.5 rounded-xl bg-white hover:bg-blue-50 border border-slate-300 text-xs font-extrabold text-blue-700 transition cursor-pointer"
                      >
                        {lesson.title} →
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Daily Homework Alarm & Reminder Settings Form */}
              <form
                onSubmit={handleSaveSchedule}
                className="bg-slate-50 rounded-3xl border border-slate-200 p-5 space-y-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h4 className="text-base font-black text-slate-900 flex items-center gap-2">
                      <Clock className="w-5 h-5 text-blue-600" />
                      <span>Cài đặt Khung giờ Nhắc nhở Làm Bài tập về nhà hằng ngày</span>
                    </h4>
                    <p className="text-xs text-slate-500">
                      Thiết lập giờ cố định buổi tối để ứng dụng phát chuông và hiển thị lời nhắc hoàn thành BTVN
                    </p>
                  </div>

                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={scheduleDraft.enabled}
                      onChange={(e) =>
                        setScheduleDraft((prev) => ({ ...prev, enabled: e.target.checked }))
                      }
                      className="w-4 h-4 accent-blue-600 rounded"
                    />
                    <span className="text-xs font-extrabold text-slate-800">
                      Đang bật nhắc nhở tự động
                    </span>
                  </label>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                  <div className="md:col-span-4">
                    <label className="block text-xs font-black uppercase text-slate-700 mb-1.5">
                      Giờ nhắc học mỗi tối
                    </label>
                    <input
                      type="time"
                      value={scheduleDraft.timeOfDay}
                      onChange={(e) =>
                        setScheduleDraft((prev) => ({ ...prev, timeOfDay: e.target.value }))
                      }
                      className="w-full px-4 py-2.5 rounded-2xl border border-slate-300 bg-white text-base font-black text-slate-900 focus:outline-none focus:border-blue-600"
                    />
                  </div>

                  <div className="md:col-span-8">
                    <label className="block text-xs font-black uppercase text-slate-700 mb-1.5">
                      Các ngày nhắc học trong tuần
                    </label>
                    <div className="flex flex-wrap gap-1.5">
                      {['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'].map((day) => {
                        const active = scheduleDraft.daysOfWeek.includes(day);
                        return (
                          <button
                            key={day}
                            type="button"
                            onClick={() => handleToggleDay(day)}
                            className={`px-3.5 py-2 rounded-xl text-xs font-black transition cursor-pointer ${
                              active
                                ? 'bg-[#0d6efd] text-white shadow-xs'
                                : 'bg-white border border-slate-300 text-slate-600 hover:bg-slate-100'
                            }`}
                          >
                            {day === 'CN' ? 'Chủ nhật' : `Thứ ${day.slice(1)}`}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                    Lời nhắc mục tiêu cá nhân của Học sinh / Phụ huynh
                  </label>
                  <input
                    type="text"
                    value={scheduleDraft.note}
                    onChange={(e) =>
                      setScheduleDraft((prev) => ({ ...prev, note: e.target.value }))
                    }
                    className="w-full px-3.5 py-2.5 rounded-2xl border border-slate-300 bg-white text-xs sm:text-sm font-medium text-slate-800"
                  />
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handleTestNotification}
                    className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black flex items-center gap-1.5 shadow-xs transition cursor-pointer"
                  >
                    <Volume2 className="w-4 h-4" />
                    <span>Nghe thử Chuông & Bật Thông báo Trình duyệt</span>
                  </button>

                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-black shadow-sm transition cursor-pointer"
                  >
                    💾 Lưu Lịch Nhắc Học BTVN
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 2: GIÁO VIÊN GỬI NHẮC NHỞ BTVN CHO HỌC SINH CHƯA HOÀN THÀNH */}
          {activeTab === 'teacher_send' && (
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-blue-50/80 border border-blue-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-sm sm:text-base font-black text-slate-900">
                    Danh sách Học sinh cần nhắc nhở BTVN Tuần {activeWeek} ({incompleteStudents.length}/{students.length} học sinh chưa hoàn thành)
                  </h4>
                  <p className="text-xs text-slate-600">
                    Giáo viên gửi phiếu nhắc nhở tự động tới màn hình học tập của Học sinh và Sổ Liên Lạc của Phụ huynh.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => handleSendTeacherReminder(true)}
                  className="px-4 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black flex items-center gap-1.5 shadow-sm shrink-0 cursor-pointer"
                >
                  <Bell className="w-4 h-4" />
                  <span>Gửi nhắc tất cả {incompleteStudents.length} HS chưa xong</span>
                </button>
              </div>

              {/* Message Editor */}
              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-1.5">
                  Nội dung phiếu nhắc nhở hoàn thành BTVN gửi Học sinh & Phụ huynh
                </label>
                <textarea
                  rows={3}
                  value={customReminderMsg}
                  onChange={(e) => setCustomReminderMsg(e.target.value)}
                  className="w-full p-3.5 rounded-2xl border border-slate-300 text-xs sm:text-sm text-slate-900 focus:outline-none focus:border-blue-600"
                />
              </div>

              {/* Student Selection List */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-600">
                  <span>Chọn học sinh để gửi nhắc nhở riêng ({selectedStudentIds.length} đã chọn):</span>
                  <button
                    type="button"
                    onClick={() =>
                      setSelectedStudentIds(incompleteStudents.map((s) => s.id))
                    }
                    className="text-blue-600 hover:underline font-extrabold cursor-pointer"
                  >
                    Chọn tất cả HS chưa hoàn thành
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-60 overflow-y-auto pr-1">
                  {students.map((st) => {
                    const isDone = st.baselineWeeksCompleted.includes(activeWeek);
                    const isSelected = selectedStudentIds.includes(st.id);
                    return (
                      <label
                        key={st.id}
                        className={`p-3 rounded-2xl border flex items-center justify-between gap-2 cursor-pointer transition ${
                          isSelected
                            ? 'bg-blue-50 border-blue-500'
                            : isDone
                            ? 'bg-slate-50/60 border-slate-200 opacity-75'
                            : 'bg-white border-amber-300 hover:border-blue-400'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => handleToggleSelectStudent(st.id)}
                            className="w-4 h-4 accent-blue-600 rounded shrink-0"
                          />
                          <div className="truncate">
                            <div className="text-xs font-black text-slate-900 truncate">
                              {st.fullName}
                            </div>
                            <div className="text-[11px] text-slate-500">
                              {st.code} · {st.className}
                            </div>
                          </div>
                        </div>

                        {isDone ? (
                          <span className="text-[11px] font-bold text-emerald-700 shrink-0">
                            ✓ Đã xong
                          </span>
                        ) : (
                          <span className="text-[11px] font-extrabold text-rose-600 shrink-0">
                            Chưa xong Tuần {activeWeek}
                          </span>
                        )}
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => handleSendTeacherReminder(false)}
                  className="px-5 py-2.5 rounded-2xl bg-[#0d6efd] hover:bg-blue-700 text-white text-xs sm:text-sm font-black flex items-center gap-2 shadow-md cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Gửi Nhắc nhở tới {selectedStudentIds.length} Học sinh đã chọn</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: DANH SÁCH PHIẾU NHẮC NHỞ BTVN TỪ GIÁO VIÊN */}
          {activeTab === 'logs' && (
            <div className="space-y-3.5">
              {reminderLogs.map((log) => {
                const isAck = log.acknowledgedByStudentIds.includes(currentStudent.id);
                return (
                  <div
                    key={log.id}
                    className="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 space-y-2.5"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2 text-xs font-black text-indigo-900">
                        <Bell className="w-4 h-4 text-amber-500" />
                        <span>
                          Phiếu nhắc nhở BTVN Tuần {log.weekNumber} · Hạn: {log.dueDate}
                        </span>
                      </div>
                      <span className="text-[11px] font-semibold text-slate-500">
                        Gửi lúc: {log.createdAt}
                      </span>
                    </div>

                    <p className="text-xs sm:text-sm text-slate-800 font-medium leading-relaxed bg-white p-3.5 rounded-xl border border-slate-200/80">
                      “{log.message}”
                    </p>

                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                      <span className="text-[11px] text-slate-500">
                        Gửi tới: <strong>{log.targetStudentNames.slice(0, 3).join(', ')}</strong>
                        {log.targetStudentNames.length > 3 &&
                          ` và ${log.targetStudentNames.length - 3} HS khác`}
                      </span>

                      <div className="flex items-center gap-2">
                        {isAck ? (
                          <span className="px-3 py-1.5 rounded-xl bg-emerald-100 text-emerald-800 text-xs font-extrabold flex items-center gap-1">
                            <Check className="w-3.5 h-3.5" />
                            <span>{currentStudent.fullName} đã xác nhận xem</span>
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleAcknowledgeReminder(log.id)}
                            className="px-3.5 py-1.5 rounded-xl bg-[#0d6efd] hover:bg-blue-700 text-white text-xs font-extrabold cursor-pointer"
                          >
                            ✓ Xác nhận đã xem & Làm bài ngay
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
