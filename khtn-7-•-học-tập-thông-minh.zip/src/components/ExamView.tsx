import React, { useState, useEffect, useRef } from 'react';
import {
  Clock,
  Flag,
  CheckCircle2,
  RotateCcw,
  ArrowRight,
  ArrowLeft,
  FileCheck2,
  Home,
  AlertCircle,
  Upload,
  FileText,
  BookOpen,
  Sparkles,
  Trash2,
  Lock,
  Plus,
  Camera,
  X,
  Shuffle,
  Layers,
  Table2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import mammoth from 'mammoth';
import { SUBJECT_LABELS, SubSubject } from '../data/khtn7Data';
import {
  KNTT_STANDARD_EXAMS,
  KNTT_EXAM_PERIOD_GROUPS,
  KnttExamPaper,
  StandardExamMcq,
  StandardExamEssay,
  CognitiveLevel,
} from '../data/knttStandardExams';
import { soundEngine } from '../utils/gameSoundEngine';
import {
  MatrixExamBuilderModal,
  SavedExamMatrixConfig,
  loadSavedExamMatrices,
  saveExamMatricesToStorage,
  generatePapersFromMatrixConfig,
} from './MatrixExamBuilderModal';

interface ExamViewProps {
  onSaveBestScore: (scoreOutOf10: number) => void;
  bestExamScore: number | null;
  onBackToHome?: () => void;
  isTeacherAuthenticated?: boolean;
  onAuthenticateTeacher?: (pin: string) => boolean;
}

const CUSTOM_EXAMS_STORAGE_KEY = 'khtn7_custom_teacher_exams_v2';

function loadCustomTeacherExams(): KnttExamPaper[] {
  try {
    const raw = localStorage.getItem(CUSTOM_EXAMS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // ignore
  }
  return [];
}

function saveCustomTeacherExams(list: KnttExamPaper[]): void {
  try {
    localStorage.setItem(CUSTOM_EXAMS_STORAGE_KEY, JSON.stringify(list));
  } catch {
    // ignore
  }
}

// Helper to shuffle an array using Fisher-Yates
function shuffleArray<T>(items: T[]): T[] {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// Shuffle MCQ options A/B/C/D while tracking the new correctIndex
function shuffleMcqOptions(mcq: StandardExamMcq, newId: string): StandardExamMcq {
  const correctText = mcq.options[mcq.correctIndex];
  const shuffledOpts = shuffleArray([...mcq.options]) as [string, string, string, string];
  const newCorrectIdx = Math.max(0, shuffledOpts.indexOf(correctText));
  return {
    ...mcq,
    id: newId,
    options: shuffledOpts,
    correctIndex: newCorrectIdx,
  };
}

// Generate a randomized exam paper for a given period ('gk1' | 'hk1' | 'gk2' | 'hk2')
// strictly adhering to the required cognitive matrix & lesson scope:
// 21 MCQs (7 Chemistry, 7 Physics, 7 Biology; 6 Nhận biết [30%], 7 Thông hiểu [30%], 4 Vận dụng [20%], 4 Vận dụng cao [20%])
// + 6 Essays (2 Physics [VD, VDC], 2 Chemistry [VD, VDC], 2 Biology [TH, VD])
function generateRandomizedPeriodExam(
  periodCode: 'gk1' | 'hk1' | 'gk2' | 'hk2',
  randomIndex: number
): KnttExamPaper {
  const group =
    KNTT_EXAM_PERIOD_GROUPS.find((g) => g.code === periodCode) ||
    KNTT_EXAM_PERIOD_GROUPS[0];

  const poolMcqs = group.papers.flatMap((p) => p.mcqs);
  const poolEssays = group.papers.flatMap((p) => p.essays);

  // Target matrix per subject so that total = 21 MCQs (7 chem + 7 phys + 7 bio)
  // and cognitive levels across the 21 MCQs = 6 Nhận biết, 7 Thông hiểu, 4 Vận dụng, 4 Vận dụng cao
  const subjectLevelQuotas: {
    subject: SubSubject;
    quotas: { level: CognitiveLevel; count: number }[];
  }[] = [
    {
      subject: 'chemistry',
      quotas: [
        { level: 'Nhận biết', count: 2 },
        { level: 'Thông hiểu', count: 2 },
        { level: 'Vận dụng', count: 2 },
        { level: 'Vận dụng cao', count: 1 },
      ],
    },
    {
      subject: 'physics',
      quotas: [
        { level: 'Nhận biết', count: 2 },
        { level: 'Thông hiểu', count: 2 },
        { level: 'Vận dụng', count: 1 },
        { level: 'Vận dụng cao', count: 2 },
      ],
    },
    {
      subject: 'biology',
      quotas: [
        { level: 'Nhận biết', count: 2 },
        { level: 'Thông hiểu', count: 3 },
        { level: 'Vận dụng', count: 1 },
        { level: 'Vận dụng cao', count: 1 },
      ],
    },
  ];

  const pickedMcqs: StandardExamMcq[] = [];
  const usedQuestions = new Set<string>();

  for (const subSpec of subjectLevelQuotas) {
    for (const qSpec of subSpec.quotas) {
      const candidates = shuffleArray(
        poolMcqs.filter(
          (m) =>
            m.subject === subSpec.subject &&
            m.level === qSpec.level &&
            !usedQuestions.has(m.question)
        )
      );
      for (let i = 0; i < qSpec.count && i < candidates.length; i++) {
        usedQuestions.add(candidates[i].question);
        pickedMcqs.push(candidates[i]);
      }
    }
  }

  // Fallback if any slot was short
  if (pickedMcqs.length < 21) {
    const remaining = shuffleArray(
      poolMcqs.filter((m) => !usedQuestions.has(m.question))
    );
    for (const rem of remaining) {
      if (pickedMcqs.length >= 21) break;
      usedQuestions.add(rem.question);
      pickedMcqs.push(rem);
    }
  }

  const randExamId = `rand-${periodCode}-${Date.now()}`;
  const finalMcqs = pickedMcqs.map((m, idx) =>
    shuffleMcqOptions(m, `${randExamId}-mcq-${idx + 1}`)
  );

  // Pick 6 Essays following exact structure:
  // 2 Physics (1 Vận dụng + 1 Vận dụng cao), 2 Chemistry (1 Vận dụng + 1 Vận dụng cao), 2 Biology (1 Thông hiểu + 1 Vận dụng)
  const essaySpecs: { subject: SubSubject; level: CognitiveLevel }[] = [
    { subject: 'physics', level: 'Vận dụng' },
    { subject: 'physics', level: 'Vận dụng cao' },
    { subject: 'chemistry', level: 'Vận dụng' },
    { subject: 'chemistry', level: 'Vận dụng cao' },
    { subject: 'biology', level: 'Thông hiểu' },
    { subject: 'biology', level: 'Vận dụng' },
  ];

  const pickedEssays: StandardExamEssay[] = [];
  const usedEssays = new Set<string>();

  essaySpecs.forEach((spec, idx) => {
    const candidates = shuffleArray(
      poolEssays.filter(
        (e) =>
          e.subject === spec.subject &&
          e.level === spec.level &&
          !usedEssays.has(e.question)
      )
    );
    const chosen =
      candidates[0] ||
      shuffleArray(
        poolEssays.filter((e) => e.subject === spec.subject && !usedEssays.has(e.question))
      )[0] ||
      poolEssays[idx % poolEssays.length];
    if (chosen) {
      usedEssays.add(chosen.question);
      pickedEssays.push({
        ...chosen,
        id: `${randExamId}-tl-${idx + 1}`,
      });
    }
  });

  const periodUpper = periodCode.toUpperCase();
  return {
    id: randExamId,
    code: periodCode,
    paperNumber: 4 + randomIndex,
    title: `${group.name} – Đề Ngẫu Nhiên #${randomIndex} (Trộn Ma Trận Phân Hóa Cao)`,
    shortTitle: `${periodUpper} – Đề Ngẫu Nhiên #${randomIndex}`,
    durationMinutes: 60,
    scopeSummary: group.scopeSummary,
    matrixSummary:
      'Đề sinh ngẫu nhiên chuẩn ma trận: 21 câu Trắc nghiệm (7 Hóa, 7 Lí, 7 Sinh: 30% Biết [6 câu], 30% Hiểu [7 câu], 20% Vận dụng [4 câu], 20% Vận dụng cao [4 câu]) + 6 câu Tự luận (Lí, Hóa: Vận dụng & Vận dụng cao; Sinh: Hiểu & Vận dụng).',
    mcqs: finalMcqs,
    essays: pickedEssays,
    createdAt: new Date().toLocaleTimeString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit',
    }),
  };
}

// Parse uploaded Word / text content into MCQs and Essays for a custom teacher exam
function parseCustomExamText(rawText: string, examId: string): {
  mcqs: StandardExamMcq[];
  essays: StandardExamEssay[];
} {
  const lines = rawText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  const mcqs: StandardExamMcq[] = [];
  const essays: StandardExamEssay[] = [];

  let inEssaySection = false;
  let currentQ = '';
  let currentOpts: string[] = [];
  let correctIdx = 0;

  const inferSubject = (text: string, idx: number): SubSubject => {
    const lower = text.toLowerCase();
    if (
      lower.includes('nguyên tử') ||
      lower.includes('hóa trị') ||
      lower.includes('phân tử') ||
      lower.includes('liên kết') ||
      lower.includes('nguyên tố') ||
      lower.includes('amu')
    ) {
      return 'chemistry';
    }
    if (
      lower.includes('tốc độ') ||
      lower.includes('quãng đường') ||
      lower.includes('gương') ||
      lower.includes('ánh sáng') ||
      lower.includes('nam châm') ||
      lower.includes('tần số') ||
      lower.includes('sóng âm')
    ) {
      return 'physics';
    }
    if (
      lower.includes('tế bào') ||
      lower.includes('hô hấp') ||
      lower.includes('quang hợp') ||
      lower.includes('sinh sản') ||
      lower.includes('sinh trưởng') ||
      lower.includes('khí khổng') ||
      lower.includes('mạch gỗ')
    ) {
      return 'biology';
    }
    const cycle: SubSubject[] = ['chemistry', 'physics', 'biology'];
    return cycle[idx % 3];
  };

  const inferLevel = (idx: number): CognitiveLevel => {
    const mod = idx % 21;
    if (mod < 6) return 'Nhận biết';
    if (mod < 13) return 'Thông hiểu';
    if (mod < 17) return 'Vận dụng';
    return 'Vận dụng cao';
  };

  const flushQuestion = () => {
    if (!currentQ) return;
    if (!inEssaySection && currentOpts.length >= 4) {
      const idx = mcqs.length;
      mcqs.push({
        id: `${examId}-mcq-${idx + 1}`,
        subject: inferSubject(currentQ, idx),
        lessonRef: 'Đề Giáo viên',
        level: inferLevel(idx),
        question: currentQ,
        options: [
          currentOpts[0],
          currentOpts[1],
          currentOpts[2],
          currentOpts[3],
        ],
        correctIndex: correctIdx,
        explanation: 'Câu hỏi thuộc đề riêng do Giáo viên bộ môn tải lên.',
      });
    } else if (inEssaySection || currentOpts.length === 0) {
      const idx = essays.length;
      const sub = inferSubject(currentQ, idx);
      essays.push({
        id: `${examId}-essay-${idx + 1}`,
        subject: sub,
        lessonRef: 'Tự luận Đề GV',
        level: sub === 'biology' ? 'Thông hiểu' : 'Vận dụng',
        points: 0.5,
        question: currentQ,
        sampleAnswer:
          'Học sinh trình bày đầy đủ các bước lập luận, công thức và giải thích theo hướng dẫn của giáo viên bộ môn.',
        rubricCriteria: [
          'Trình bày đúng kiến thức trọng tâm và công thức liên quan (0,25đ).',
          'Tính toán chính xác hoặc giải thích đầy đủ ý nghĩa thực tiễn (0,25đ).',
        ],
      });
    }
    currentQ = '';
    currentOpts = [];
    correctIdx = 0;
  };

  for (const line of lines) {
    if (/^(PHẦN\s*II|PHẦN\s*2|II\.|TỰ LUẬN)/i.test(line)) {
      flushQuestion();
      inEssaySection = true;
      continue;
    }
    if (/^(Câu|Bài|Question)\s*\d+[\.:\)]/i.test(line)) {
      flushQuestion();
      currentQ = line.replace(/^(Câu|Bài|Question)\s*\d+[\.:\)]\s*/i, '').trim();
    } else if (!inEssaySection && /^[A-D][\.:\)]\s+/i.test(line)) {
      const parts = line.split(/(?=[A-D][\.:\)]\s+)/i).map((p) => p.trim());
      for (const p of parts) {
        const cleanOpt = p.replace(/^[A-D][\.:\)]\s*/i, '').trim();
        if (cleanOpt.startsWith('*')) {
          correctIdx = currentOpts.length;
          currentOpts.push(cleanOpt.replace(/^\*+/, '').trim());
        } else {
          currentOpts.push(cleanOpt);
        }
      }
    } else if (/^(Đáp án|Dap an)[\s:]*([A-D])/i.test(line)) {
      const match = line.match(/^(?:Đáp án|Dap an)[\s:]*([A-D])/i);
      if (match) {
        const letter = match[1].toUpperCase();
        correctIdx = ['A', 'B', 'C', 'D'].indexOf(letter);
        if (correctIdx < 0) correctIdx = 0;
      }
    } else if (currentQ && currentOpts.length === 0) {
      currentQ += '\n' + line;
    }
  }
  flushQuestion();

  return { mcqs, essays };
}

export const ExamView: React.FC<ExamViewProps> = ({
  onSaveBestScore,
  bestExamScore,
  onBackToHome,
  isTeacherAuthenticated = false,
  onAuthenticateTeacher,
}) => {
  const [customExams, setCustomExams] = useState<KnttExamPaper[]>(() =>
    loadCustomTeacherExams()
  );
  const [savedMatrices, setSavedMatrices] = useState<SavedExamMatrixConfig[]>(() =>
    loadSavedExamMatrices()
  );
  const [generatedRandomExams, setGeneratedRandomExams] = useState<KnttExamPaper[]>([]);
  const [showMatrixBuilderModal, setShowMatrixBuilderModal] = useState<boolean>(false);

  const allExams: KnttExamPaper[] = [
    ...KNTT_STANDARD_EXAMS,
    ...generatedRandomExams,
    ...customExams,
  ];

  const [selectedPeriodCode, setSelectedPeriodCode] = useState<'gk1' | 'hk1' | 'gk2' | 'hk2'>('gk1');
  const [selectedExamId, setSelectedExamId] = useState<string>(KNTT_STANDARD_EXAMS[0].id);

  const activeExam =
    allExams.find((ex) => ex.id === selectedExamId) || KNTT_STANDARD_EXAMS[0];

  const activePeriodGroup =
    KNTT_EXAM_PERIOD_GROUPS.find((g) => g.code === selectedPeriodCode) ||
    KNTT_EXAM_PERIOD_GROUPS[0];

  // Active item index: 0..mcqs.length-1 are MCQs, mcqs.length..(mcqs.length+essays.length-1) are Essays
  const [currentItemIdx, setCurrentItemIdx] = useState<number>(0);
  const [mcqAnswers, setMcqAnswers] = useState<Record<string, number>>({});
  const [essayAnswers, setEssayAnswers] = useState<Record<string, string>>({});
  const [essayPhotos, setEssayPhotos] = useState<Record<string, string[]>>({});
  const [essaySelfScores, setEssaySelfScores] = useState<Record<string, number>>({});
  const [flaggedIds, setFlaggedIds] = useState<string[]>([]);
  const [secondsLeft, setSecondsLeft] = useState<number>(60 * 60);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [examRunning, setExamRunning] = useState<boolean>(true);
  const [randomBannerNotice, setRandomBannerNotice] = useState<string | null>(null);

  // Teacher Upload Custom Exam Modal State
  const [showUploadModal, setShowUploadModal] = useState<boolean>(false);
  const [teacherPinForUpload, setTeacherPinForUpload] = useState<string>('');
  const [uploadPinError, setUploadPinError] = useState<string>('');
  const [localTeacherUnlocked, setLocalTeacherUnlocked] = useState<boolean>(
    isTeacherAuthenticated
  );

  const [customTitle, setCustomTitle] = useState<string>('');
  const [customCategoryCode, setCustomCategoryCode] = useState<'gk1' | 'hk1' | 'gk2' | 'hk2'>('gk1');
  const [customDuration, setCustomDuration] = useState<number>(60);
  const [customRawText, setCustomRawText] = useState<string>('');
  const [customHtmlPreview, setCustomHtmlPreview] = useState<string>('');
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [uploadNotice, setUploadNotice] = useState<string | null>(null);

  const wordFileInputRef = useRef<HTMLInputElement | null>(null);
  const photoInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isTeacherAuthenticated) {
      setLocalTeacherUnlocked(true);
    }
  }, [isTeacherAuthenticated]);

  useEffect(() => {
    if (!examRunning || isSubmitted) return;
    const timer = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setIsSubmitted(true);
          setExamRunning(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [examRunning, isSubmitted]);

  const handleSelectExamPaper = (examId: string, explicitList?: KnttExamPaper[]) => {
    const searchPool = explicitList || allExams;
    const target = searchPool.find((e) => e.id === examId) || KNTT_STANDARD_EXAMS[0];
    if (
      target.code === 'gk1' ||
      target.code === 'hk1' ||
      target.code === 'gk2' ||
      target.code === 'hk2'
    ) {
      setSelectedPeriodCode(target.code);
    }
    setSelectedExamId(target.id);
    setCurrentItemIdx(0);
    setMcqAnswers({});
    setEssayAnswers({});
    setEssayPhotos({});
    setEssaySelfScores({});
    setFlaggedIds([]);
    setSecondsLeft((target.durationMinutes || 60) * 60);
    setIsSubmitted(false);
    setExamRunning(true);
  };

  const handleSelectPeriod = (periodCode: 'gk1' | 'hk1' | 'gk2' | 'hk2') => {
    setSelectedPeriodCode(periodCode);
    const group = KNTT_EXAM_PERIOD_GROUPS.find((g) => g.code === periodCode);
    if (group && group.papers.length > 0) {
      handleSelectExamPaper(group.papers[0].id);
    }
  };

  const handleGenerateRandomExamForPeriod = () => {
    const existingCountForPeriod = generatedRandomExams.filter(
      (e) => e.code === selectedPeriodCode
    ).length;
    const newPaper = generateRandomizedPeriodExam(
      selectedPeriodCode,
      existingCountForPeriod + 1
    );
    const nextRandList = [newPaper, ...generatedRandomExams];
    setGeneratedRandomExams(nextRandList);
    handleSelectExamPaper(newPaper.id, [
      ...KNTT_STANDARD_EXAMS,
      ...nextRandList,
      ...customExams,
    ]);
    setRandomBannerNotice(
      `🎲 Đã khởi tạo "${newPaper.shortTitle}" mới với 21 câu Trắc nghiệm (đảo phương án A/B/C/D) + 6 câu Tự luận phân hóa cao theo đúng cấu trúc ${activePeriodGroup.shortName}!`
    );
    setTimeout(() => setRandomBannerNotice(null), 5000);
  };

  const totalMcqCount = activeExam.mcqs.length;
  const totalEssayCount = activeExam.essays.length;
  const totalItemCount = totalMcqCount + totalEssayCount;
  const isCurrentItemEssay = currentItemIdx >= totalMcqCount;
  const currentMcq: StandardExamMcq | undefined = !isCurrentItemEssay
    ? activeExam.mcqs[currentItemIdx]
    : undefined;
  const currentEssay: StandardExamEssay | undefined = isCurrentItemEssay
    ? activeExam.essays[currentItemIdx - totalMcqCount]
    : undefined;
  const currentEssayNumber = isCurrentItemEssay ? currentItemIdx - totalMcqCount + 1 : 1;

  const isEssayDone = (essayId: string) => {
    const text = (essayAnswers[essayId] || '').trim();
    const photos = essayPhotos[essayId] || [];
    return text.length > 0 || photos.length > 0;
  };

  const handleSelectMcqAnswer = (qId: string, optIdx: number) => {
    if (isSubmitted) return;
    setMcqAnswers((prev) => ({ ...prev, [qId]: optIdx }));
  };

  const toggleFlag = (itemId: string) => {
    setFlaggedIds((prev) =>
      prev.includes(itemId) ? prev.filter((id) => id !== itemId) : [...prev, itemId]
    );
  };

  const handleAttachEssayPhoto = (essayId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setEssayPhotos((prev) => ({
          ...prev,
          [essayId]: [...(prev[essayId] || []), reader.result as string],
        }));
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Scoring Math:
  // 21 MCQs = 7.0 points total (each MCQ = 7 / totalMcqCount points)
  // 6 Essays = 3.0 points total (each Essay = 0.5 points)
  const correctMcqCount = activeExam.mcqs.filter(
    (q) => mcqAnswers[q.id] === q.correctIndex
  ).length;
  const mcqPointsOutOf7 =
    totalMcqCount > 0 ? Number(((correctMcqCount / totalMcqCount) * 7).toFixed(2)) : 0;

  const completedEssayCount = activeExam.essays.filter((es) => isEssayDone(es.id)).length;
  const essayPointsOutOf3 = activeExam.essays.reduce((sum, es) => {
    if (essaySelfScores[es.id] !== undefined) {
      return sum + essaySelfScores[es.id];
    }
    return sum + (isEssayDone(es.id) ? es.points : 0);
  }, 0);

  const totalScoreOutOf10 = Number(
    Math.min(10, mcqPointsOutOf7 + essayPointsOutOf3).toFixed(2)
  );

  const handleSubmitExam = () => {
    // Initialize default rubric scores (0.5pt for each answered essay) so student/teacher can refine
    const initialSelfScores: Record<string, number> = {};
    for (const es of activeExam.essays) {
      initialSelfScores[es.id] = isEssayDone(es.id) ? es.points : 0;
    }
    setEssaySelfScores(initialSelfScores);
    setIsSubmitted(true);
    setExamRunning(false);

    const finalScore = Number(
      Math.min(
        10,
        mcqPointsOutOf7 +
          activeExam.essays.reduce(
            (acc, es) => acc + (isEssayDone(es.id) ? es.points : 0),
            0
          )
      ).toFixed(2)
    );
    onSaveBestScore(finalScore);
    soundEngine.playVictory();
    confetti({
      particleCount: 110,
      spread: 80,
      origin: { y: 0.6 },
    });
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
  };

  // Answered & Missing tracking across all 27 items (21 TN + 6 TL)
  const answeredMcqCount = Object.keys(mcqAnswers).length;
  const totalAnsweredItems = answeredMcqCount + completedEssayCount;

  const missingItemIndices: number[] = [];
  activeExam.mcqs.forEach((q, idx) => {
    if (mcqAnswers[q.id] === undefined) missingItemIndices.push(idx);
  });
  activeExam.essays.forEach((es, idx) => {
    if (!isEssayDone(es.id)) missingItemIndices.push(totalMcqCount + idx);
  });

  const jumpToNextMissingItem = () => {
    if (missingItemIndices.length === 0) return;
    const nextAfter = missingItemIndices.find((idx) => idx > currentItemIdx);
    setCurrentItemIdx(nextAfter !== undefined ? nextAfter : missingItemIndices[0]);
  };

  // Cognitive Level Matrix Statistics for the active exam
  const levelCounts = {
    'Nhận biết': activeExam.mcqs.filter((q) => q.level === 'Nhận biết').length,
    'Thông hiểu': activeExam.mcqs.filter((q) => q.level === 'Thông hiểu').length,
    'Vận dụng': activeExam.mcqs.filter((q) => q.level === 'Vận dụng').length,
    'Vận dụng cao': activeExam.mcqs.filter((q) => q.level === 'Vận dụng cao').length,
  };

  const getSubjectStats = (sub: SubSubject) => {
    const subMcqs = activeExam.mcqs.filter((q) => q.subject === sub);
    const subCorrect = subMcqs.filter((q) => mcqAnswers[q.id] === q.correctIndex).length;
    const subEssays = activeExam.essays.filter((e) => e.subject === sub);
    const subEssayDone = subEssays.filter((e) => isEssayDone(e.id)).length;
    const ratio = subMcqs.length > 0 ? subCorrect / subMcqs.length : 0;
    return {
      mcqTotal: subMcqs.length,
      mcqCorrect: subCorrect,
      essayTotal: subEssays.length,
      essayDone: subEssayDone,
      pct: Math.round(ratio * 100),
      levelLabel:
        ratio >= 0.8
          ? '● VỮNG VÀNG (Đạt chuẩn Tốt)'
          : ratio >= 0.5
          ? '▲ ĐẠT YÊU CẦU (Cần ôn thêm câu Vận dụng)'
          : '◆ CẦN ÔN LẠI KIẾN THỨC TRỌNG TÂM',
    };
  };

  // Handle uploading a custom teacher Word (.docx / .doc / .txt) exam file
  const handleUploadWordExamFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    setUploadedFileName(file.name);
    if (!customTitle.trim()) {
      setCustomTitle(file.name.replace(/\.(docx|doc|txt)$/i, '').replace(/[_-]+/g, ' '));
    }

    try {
      if (ext === 'docx') {
        const arrayBuffer = await file.arrayBuffer();
        const textResult = await mammoth.extractRawText({ arrayBuffer });
        const htmlResult = await mammoth.convertToHtml({ arrayBuffer });
        setCustomRawText(textResult.value || '');
        setCustomHtmlPreview(htmlResult.value || '');
        setUploadNotice(
          `📄 Đã đọc file Word "${file.name}". Hệ thống tự động bóc tách câu hỏi Trắc nghiệm & Tự luận!`
        );
      } else {
        const text = await file.text();
        setCustomRawText(text);
        setCustomHtmlPreview(`<div style="white-space: pre-wrap">${text}</div>`);
        setUploadNotice(`📄 Đã tải nội dung từ file "${file.name}".`);
      }
    } catch {
      setUploadNotice('⚠️ Không thể đọc tự động file này. Thầy/cô có thể dán nội dung đề vào ô bên dưới.');
    }
    e.target.value = '';
  };

  const handleSaveCustomTeacherExam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTitle.trim()) {
      setUploadNotice('⚠️ Vui lòng nhập tên đề kiểm tra của giáo viên!');
      return;
    }

    const newExamId = `custom-exam-${Date.now()}`;
    const parsed = parseCustomExamText(customRawText, newExamId);
    const baseTemplate =
      KNTT_STANDARD_EXAMS.find((ex) => ex.code === customCategoryCode) ||
      KNTT_STANDARD_EXAMS[0];

    const finalMcqs = parsed.mcqs.length > 0 ? parsed.mcqs : baseTemplate.mcqs;
    const finalEssays = parsed.essays.length > 0 ? parsed.essays : baseTemplate.essays;

    const newPaper: KnttExamPaper = {
      id: newExamId,
      code: customCategoryCode,
      title: customTitle.trim(),
      shortTitle: `Đề GV: ${customTitle.trim().slice(0, 22)}`,
      durationMinutes: customDuration || 60,
      scopeSummary: baseTemplate.scopeSummary,
      matrixSummary: `Đề riêng của Giáo viên tải lên (${finalMcqs.length} câu Trắc nghiệm + ${finalEssays.length} câu Tự luận).`,
      mcqs: finalMcqs,
      essays: finalEssays,
      isCustomTeacherExam: true,
      rawHtmlPreview: customHtmlPreview || undefined,
      createdAt: new Date().toLocaleDateString('vi-VN'),
    };

    const nextList = [newPaper, ...customExams];
    setCustomExams(nextList);
    saveCustomTeacherExams(nextList);

    setCustomTitle('');
    setCustomRawText('');
    setCustomHtmlPreview('');
    setUploadedFileName('');
    setUploadNotice(null);
    setShowUploadModal(false);
    handleSelectExamPaper(newPaper.id, [
      ...KNTT_STANDARD_EXAMS,
      ...generatedRandomExams,
      ...nextList,
    ]);
  };

  const handleDeleteCustomExam = (examId: string) => {
    const nextList = customExams.filter((ex) => ex.id !== examId);
    setCustomExams(nextList);
    saveCustomTeacherExams(nextList);
    if (selectedExamId === examId) {
      handleSelectExamPaper(KNTT_STANDARD_EXAMS[0].id);
    }
  };

  const handleSaveMatrix = (matrix: SavedExamMatrixConfig) => {
    setSavedMatrices((prev) => {
      const filtered = prev.filter((m) => m.id !== matrix.id && m.title !== matrix.title);
      const next = [matrix, ...filtered];
      saveExamMatricesToStorage(next);
      return next;
    });
  };

  const handleDeleteMatrix = (matrixId: string) => {
    setSavedMatrices((prev) => {
      const next = prev.filter((m) => m.id !== matrixId);
      saveExamMatricesToStorage(next);
      return next;
    });
  };

  const handleGenerateAndSaveExamsFromMatrix = (
    papers: KnttExamPaper[],
    matrix: SavedExamMatrixConfig,
    openImmediately: boolean
  ) => {
    const nextCustomList = [...papers, ...customExams];
    setCustomExams(nextCustomList);
    saveCustomTeacherExams(nextCustomList);

    if (openImmediately && papers.length > 0) {
      setShowMatrixBuilderModal(false);
      handleSelectExamPaper(papers[0].id, [
        ...KNTT_STANDARD_EXAMS,
        ...generatedRandomExams,
        ...nextCustomList,
      ]);
      setRandomBannerNotice(
        `🎉 Đã lưu Ma trận "${matrix.title}", lưu ${papers.length} Đề kiểm tra và mở ngay "${papers[0].title}" cho học sinh làm bài!`
      );
      setTimeout(() => setRandomBannerNotice(null), 6000);
    }
  };

  const handleQuickGenerateFromSavedMatrix = (matrix: SavedExamMatrixConfig) => {
    const parsedSource = matrix.uploadedSourceExamText
      ? parseCustomExamText(matrix.uploadedSourceExamText, `src-${Date.now()}`)
      : { mcqs: [], essays: [] };
    const papers = generatePapersFromMatrixConfig(
      matrix,
      1,
      parsedSource.mcqs,
      parsedSource.essays
    );
    if (papers.length > 0) {
      const nextCustomList = [papers[0], ...customExams];
      setCustomExams(nextCustomList);
      saveCustomTeacherExams(nextCustomList);
      handleSelectExamPaper(papers[0].id, [
        ...KNTT_STANDARD_EXAMS,
        ...generatedRandomExams,
        ...nextCustomList,
      ]);
      setRandomBannerNotice(
        `⚡ Đã sinh đề mới từ Ma trận "${matrix.title}", tự động Lưu Đề và mở cho học sinh làm bài ngay!`
      );
      setTimeout(() => setRandomBannerNotice(null), 5500);
    }
  };

  const periodRandomExams = generatedRandomExams.filter(
    (ex) => ex.code === selectedPeriodCode
  );

  return (
    <section className="space-y-6">
      {/* ================= TOP EXAM HEADER & TEACHER UPLOAD BUTTON ================= */}
      <div className="bg-white rounded-3xl border border-slate-200/90 p-5 sm:p-6 shadow-xs space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="text-xs font-extrabold uppercase tracking-wider text-teal-700">
              NGÂN HÀNG 16 ĐỀ KIỂM TRA ĐỊNH KÌ PHÂN HÓA CAO (4 ĐỀ/KÌ + SINH ĐỀ THEO MA TRẬN) · KHTN 7 KNTT
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 mt-1">
              Phòng Kiểm Tra Giữa Kì & Cuối Kì (21 Trắc Nghiệm + 6 Tự Luận)
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setShowMatrixBuilderModal(true)}
              className="px-4 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs sm:text-sm flex items-center gap-2 shadow-sm transition cursor-pointer"
            >
              <Table2 className="w-4 h-4" />
              <span>📐 Tải Đề & Ma Trận → Sinh Đề Theo Ma Trận</span>
            </button>

            <button
              type="button"
              onClick={handleGenerateRandomExamForPeriod}
              className="px-3.5 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm flex items-center gap-1.5 shadow-sm transition cursor-pointer"
            >
              <Shuffle className="w-4 h-4" />
              <span>🎲 Tạo Đề Ngẫu Nhiên ({activePeriodGroup.code.toUpperCase()})</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setShowUploadModal(true);
                setUploadPinError('');
              }}
              className="px-3.5 py-2.5 rounded-2xl bg-[#0d6efd] hover:bg-blue-700 text-white font-black text-xs sm:text-sm flex items-center gap-1.5 shadow-sm transition cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>Tải Đề Word (.DOCX)</span>
            </button>

            {bestExamScore !== null && (
              <div className="text-xs font-mono text-slate-700 bg-slate-50 border border-slate-200 px-3.5 py-2.5 rounded-2xl tabular-nums">
                Điểm cao nhất: <strong className="text-blue-700">{bestExamScore} / 10</strong>
              </div>
            )}
          </div>
        </div>

        {randomBannerNotice && (
          <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs sm:text-sm font-bold flex items-center justify-between gap-3">
            <span>{randomBannerNotice}</span>
            <button
              type="button"
              onClick={() => setRandomBannerNotice(null)}
              className="text-xs font-black text-emerald-800 hover:underline cursor-pointer"
            >
              Đóng
            </button>
          </div>
        )}

        {/* ================= STEP 1: CHỌN KÌ KIỂM TRA (GK1, HK1, GK2, HK2) ================= */}
        <div className="space-y-3">
          <div className="text-xs font-extrabold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-blue-600" />
            <span>BƯỚC 1 — CHỌN KÌ KIỂM TRA (MỖI KÌ CÓ 4 ĐỀ CHUẨN KHÁC NHAU HOÀN TOÀN + ĐỀ NGẪU NHIÊN):</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
            {KNTT_EXAM_PERIOD_GROUPS.map((group) => {
              const isSelectedPeriod = selectedPeriodCode === group.code;
              const randCount = generatedRandomExams.filter(
                (r) => r.code === group.code
              ).length;
              return (
                <button
                  key={group.code}
                  type="button"
                  onClick={() => handleSelectPeriod(group.code)}
                  className={`p-4 rounded-2xl border text-left transition flex flex-col justify-between gap-2 cursor-pointer ${
                    isSelectedPeriod
                      ? 'bg-[#081c38] text-white border-[#081c38] shadow-md'
                      : 'bg-slate-50/80 hover:bg-white text-slate-800 border-slate-200/90 hover:border-blue-400'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <span
                        className={`text-xs font-black uppercase ${
                          isSelectedPeriod ? 'text-emerald-300' : 'text-blue-700'
                        }`}
                      >
                        {group.shortName}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-lg text-[10px] font-mono font-extrabold ${
                          isSelectedPeriod
                            ? 'bg-emerald-500/20 text-amber-300'
                            : 'bg-blue-100 text-blue-800'
                        }`}
                      >
                        {group.papers.length} Đề chuẩn{randCount > 0 ? ` + ${randCount} Đề trộn` : ''}
                      </span>
                    </div>
                    <div className="text-[11px] mt-1.5 space-y-0.5 leading-snug opacity-90">
                      <div>• {group.scopeSummary.physics}</div>
                      <div>• {group.scopeSummary.chemistry}</div>
                      <div>• {group.scopeSummary.biology}</div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* ================= STEP 2: CHỌN 1 TRONG 4 ĐỀ RIÊNG BIỆT CỦA KÌ ĐÃ CHỌN HOẶC TẠO ĐỀ NGẪU NHIÊN ================= */}
        <div className="p-4 rounded-2xl bg-slate-50/90 border border-slate-200 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="text-xs font-extrabold uppercase tracking-wider text-indigo-950">
              BƯỚC 2 — CHỌN ĐỀ THI TRONG KÌ {activePeriodGroup.shortName.toUpperCase()} (4 ĐỀ ĐỘC LẬP, NỘI DUNG KHÔNG TRÙNG LẶP):
            </div>
            <button
              type="button"
              onClick={handleGenerateRandomExamForPeriod}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold flex items-center gap-1.5 self-start sm:self-auto shadow-xs cursor-pointer"
            >
              <Shuffle className="w-3.5 h-3.5" />
              <span>+ Sinh thêm Đề Ngẫu Nhiên ({activePeriodGroup.code.toUpperCase()})</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
            {activePeriodGroup.papers.map((paper, idx) => {
              const isSelectedPaper = activeExam.id === paper.id;
              return (
                <button
                  key={paper.id}
                  type="button"
                  onClick={() => handleSelectExamPaper(paper.id)}
                  className={`p-3.5 rounded-2xl border text-left transition flex flex-col justify-between gap-1.5 cursor-pointer ${
                    isSelectedPaper
                      ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                      : 'bg-white hover:bg-blue-50/50 text-slate-800 border-slate-200 hover:border-blue-400'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-black uppercase">
                      Đề số {paper.paperNumber || idx + 1} ({paper.code.toUpperCase()})
                    </span>
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                        isSelectedPaper
                          ? 'bg-white/20 text-white'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      21 TN + 6 TL
                    </span>
                  </div>
                  <div
                    className={`text-[11px] line-clamp-1 font-medium ${
                      isSelectedPaper ? 'text-blue-100' : 'text-slate-500'
                    }`}
                  >
                    Câu 1: {paper.mcqs[0]?.question}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Generated Randomized Exams for the selected period */}
          {periodRandomExams.length > 0 && (
            <div className="pt-2 border-t border-slate-200/80 space-y-2">
              <div className="text-[11px] font-extrabold uppercase text-emerald-800">
                🎲 ĐỀ THI NGẪU NHIÊN ĐÃ TẠO CHO KÌ {activePeriodGroup.shortName.toUpperCase()} ({periodRandomExams.length} ĐỀ):
              </div>
              <div className="flex flex-wrap gap-2">
                {periodRandomExams.map((rExam) => {
                  const isSelected = activeExam.id === rExam.id;
                  return (
                    <button
                      key={rExam.id}
                      type="button"
                      onClick={() => handleSelectExamPaper(rExam.id)}
                      className={`px-3.5 py-2 rounded-xl border text-xs font-extrabold flex items-center gap-2 transition cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                          : 'bg-emerald-50 text-emerald-950 border-emerald-300 hover:bg-emerald-100'
                      }`}
                    >
                      <Shuffle className="w-3.5 h-3.5" />
                      <span>{rExam.shortTitle}</span>
                      {rExam.createdAt && (
                        <span className="text-[10px] opacity-80">({rExam.createdAt})</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Saved Matrices Bank & One-Click Matrix Exam Generator */}
          <div className="pt-3 border-t border-slate-200/80 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="text-xs font-extrabold text-indigo-950 flex items-center gap-1.5">
                <Table2 className="w-4 h-4 text-indigo-600" />
                <span>
                  📐 KHO MA TRẬN ĐÃ LƯU ({savedMatrices.length} MA TRẬN) — BẤM ĐỂ SINH ĐỀ THEO MA TRẬN & LƯU CHO HỌC SINH LÀM:
                </span>
              </div>
              <button
                type="button"
                onClick={() => setShowMatrixBuilderModal(true)}
                className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold flex items-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>+ Tải Đề & Ma Trận Mới Lên</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-2.5">
              {savedMatrices.slice(0, 8).map((mat) => {
                const mMcqTotal =
                  mat.mcqQuotas.physics.nhanBiet +
                  mat.mcqQuotas.physics.thongHieu +
                  mat.mcqQuotas.physics.vanDung +
                  mat.mcqQuotas.physics.vanDungCao +
                  mat.mcqQuotas.chemistry.nhanBiet +
                  mat.mcqQuotas.chemistry.thongHieu +
                  mat.mcqQuotas.chemistry.vanDung +
                  mat.mcqQuotas.chemistry.vanDungCao +
                  mat.mcqQuotas.biology.nhanBiet +
                  mat.mcqQuotas.biology.thongHieu +
                  mat.mcqQuotas.biology.vanDung +
                  mat.mcqQuotas.biology.vanDungCao;
                const mEssayTotal =
                  mat.essayQuotas.physicsCount +
                  mat.essayQuotas.chemistryCount +
                  mat.essayQuotas.biologyCount;

                return (
                  <div
                    key={mat.id}
                    className="p-3 rounded-2xl bg-white border border-indigo-200/90 flex flex-col justify-between gap-2 shadow-2xs"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-1.5">
                        <span className="px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 text-[10px] font-black uppercase">
                          {mat.periodCode.toUpperCase()} · {mMcqTotal} TN + {mEssayTotal} TL
                        </span>
                        <span className="text-[10px] text-slate-400">{mat.createdAt}</span>
                      </div>
                      <div className="text-xs font-black text-slate-900 mt-1 line-clamp-1">
                        {mat.title}
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5 line-clamp-1">
                        {mat.scopeSummary.physics} · {mat.scopeSummary.chemistry} ·{' '}
                        {mat.scopeSummary.biology}
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-1.5 pt-1 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() => handleQuickGenerateFromSavedMatrix(mat)}
                        className="flex-1 py-1.5 px-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-extrabold flex items-center justify-center gap-1 transition cursor-pointer"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>⚡ Sinh Đề & Lưu Đề</span>
                      </button>
                      {localTeacherUnlocked && !mat.id.startsWith('matrix-default-') && (
                        <button
                          type="button"
                          onClick={() => handleDeleteMatrix(mat.id)}
                          className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 cursor-pointer"
                          title="Xóa ma trận này"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Custom Teacher Uploaded & Matrix-Generated Saved Exams List */}
          {customExams.length > 0 && (
            <div className="pt-2 border-t border-slate-200/80 space-y-2">
              <div className="text-xs font-extrabold text-indigo-800">
                📂 ĐỀ ĐÃ LƯU (SINH TỪ MA TRẬN & ĐỀ RIÊNG GIÁO VIÊN TẢI LÊN — {customExams.length} ĐỀ):
              </div>
              <div className="flex flex-wrap gap-2.5">
                {customExams.map((cExam) => {
                  const isSelected = activeExam.id === cExam.id;
                  return (
                    <div
                      key={cExam.id}
                      className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-2xl border text-xs font-bold transition ${
                        isSelected
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                          : 'bg-indigo-50/80 text-indigo-950 border-indigo-200 hover:bg-indigo-100'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => handleSelectExamPaper(cExam.id)}
                        className="flex items-center gap-1.5 cursor-pointer"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>{cExam.title}</span>
                        <span className="opacity-75">
                          ({cExam.mcqs.length} TN + {cExam.essays.length} TL)
                        </span>
                      </button>
                      {localTeacherUnlocked && (
                        <button
                          type="button"
                          onClick={() => handleDeleteCustomExam(cExam.id)}
                          className="p-1 rounded-lg hover:bg-rose-500/20 text-rose-300 hover:text-rose-200 cursor-pointer"
                          title="Xóa đề riêng này"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* ================= ACTIVE EXAM SCOPE & COGNITIVE MATRIX SUMMARY BAR ================= */}
        <div className="rounded-2xl bg-slate-50 border border-slate-200/90 p-4 flex flex-col xl:flex-row xl:items-center justify-between gap-3 text-xs">
          <div className="space-y-1">
            <div className="font-black text-slate-900 text-sm">{activeExam.title}</div>
            <div className="text-slate-600 flex flex-wrap items-center gap-x-3 gap-y-1">
              <span>
                <strong>Phạm vi:</strong> {activeExam.scopeSummary.physics}
              </span>
              <span>·</span>
              <span>{activeExam.scopeSummary.chemistry}</span>
              <span>·</span>
              <span>{activeExam.scopeSummary.biology}</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0 text-[11px] font-bold">
            <span className="text-slate-700">
              Ma trận {totalMcqCount} câu TN (7,0đ):
            </span>
            <span className="text-emerald-700">
              Nhận biết 30% ({levelCounts['Nhận biết']} câu)
            </span>
            <span>·</span>
            <span className="text-blue-700">
              Thông hiểu 30% ({levelCounts['Thông hiểu']} câu)
            </span>
            <span>·</span>
            <span className="text-amber-700">
              Vận dụng 20% ({levelCounts['Vận dụng']} câu)
            </span>
            <span>·</span>
            <span className="text-rose-700">
              Vận dụng cao 20% ({levelCounts['Vận dụng cao']} câu)
            </span>
            <span>+</span>
            <span className="text-indigo-700 font-extrabold">
              {totalEssayCount} câu Tự luận (3,0đ)
            </span>
          </div>
        </div>
      </div>

      {/* ================= MAIN TWO-COLUMN EXAM WORKSPACE ================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column (8 cols): Section Switcher + Active Question (MCQ or Essay) + Rubric Report */}
        <div className="lg:col-span-8 space-y-5">
          {/* Quick Part Switcher: Phần I (21 Trắc nghiệm) vs Phần II (6 Tự luận) */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-2 flex flex-wrap items-center justify-between gap-2">
            <div className="grid grid-cols-2 gap-1.5 bg-slate-100 p-1 rounded-xl flex-1">
              <button
                type="button"
                onClick={() => setCurrentItemIdx(0)}
                className={`py-2 px-3 rounded-lg text-xs sm:text-sm font-extrabold transition cursor-pointer ${
                  !isCurrentItemEssay
                    ? 'bg-white text-[#0d6efd] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Phần I: Trắc nghiệm ({answeredMcqCount}/{totalMcqCount} câu · 7,0 điểm)
              </button>
              <button
                type="button"
                onClick={() => setCurrentItemIdx(totalMcqCount)}
                className={`py-2 px-3 rounded-lg text-xs sm:text-sm font-extrabold transition cursor-pointer ${
                  isCurrentItemEssay
                    ? 'bg-white text-[#0d6efd] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Phần II: Tự luận ({completedEssayCount}/{totalEssayCount} câu · 3,0 điểm)
              </button>
            </div>
          </div>

          {/* AUTOMATED RUBRIC GRADING REPORT WHEN SUBMITTED */}
          {isSubmitted && (
            <div className="bg-white border-2 border-emerald-500/80 rounded-3xl p-6 space-y-5 shadow-md">
              <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
                <div>
                  <div className="text-xs font-bold text-emerald-700">
                    KẾT QUẢ CHẤM ĐIỂM ĐỀ KIỂM TRA · {activeExam.shortTitle}
                  </div>
                  <h3 className="text-xl font-black text-slate-900 mt-0.5">
                    Bảng Điểm Tổng Hợp & Đánh Giá Năng Lực Liên Môn KHTN 7
                  </h3>
                </div>
                <div className="text-right font-mono">
                  <div className="text-2xl sm:text-3xl font-black text-blue-700 tabular-nums">
                    {totalScoreOutOf10} / 10 điểm
                  </div>
                  <div className="text-xs text-slate-600 tabular-nums">
                    TN: <strong>{mcqPointsOutOf7}/7,0đ</strong> ({correctMcqCount}/{totalMcqCount} câu) · Tự luận: <strong>{essayPointsOutOf3.toFixed(2)}/3,0đ</strong>
                  </div>
                </div>
              </div>

              {/* Sub-subject Breakdown Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500">
                      <th className="py-2.5 pr-4 font-bold">Phân môn</th>
                      <th className="py-2.5 px-4 font-bold text-right">Trắc nghiệm</th>
                      <th className="py-2.5 px-4 font-bold text-right">Tự luận đã làm</th>
                      <th className="py-2.5 pl-4 font-bold">Đánh giá mức độ đạt chuẩn</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {(['physics', 'chemistry', 'biology'] as SubSubject[]).map((sub) => {
                      const stats = getSubjectStats(sub);
                      return (
                        <tr key={sub}>
                          <td className="py-3 pr-4 font-bold text-slate-900">
                            {SUBJECT_LABELS[sub].name}
                          </td>
                          <td className="py-3 px-4 font-mono text-right font-bold text-slate-900 tabular-nums">
                            {stats.mcqCorrect}/{stats.mcqTotal} câu ({stats.pct}%)
                          </td>
                          <td className="py-3 px-4 font-mono text-right font-bold text-indigo-700 tabular-nums">
                            {stats.essayDone}/{stats.essayTotal} bài
                          </td>
                          <td className="py-3 pl-4 font-mono text-slate-700">
                            {stats.levelLabel}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100">
                <p className="text-xs text-slate-600">
                  Bấm vào từng ô câu hỏi (Câu 1–21 hoặc Tự luận 1–6) ở bảng điều phối bên phải để xem lời giải chi tiết và biểu điểm chấm.
                </p>
                <button
                  type="button"
                  onClick={() => handleSelectExamPaper(activeExam.id)}
                  className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl hover:bg-slate-800 transition cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Làm lại đề này</span>
                </button>
              </div>
            </div>
          )}

          {/* ================= ACTIVE ITEM: EITHER MCQ (1..21) OR ESSAY (1..6) ================= */}
          {!isCurrentItemEssay && currentMcq ? (
            /* PART I: MCQ CARD */
            <div className="bg-white border border-slate-200/90 rounded-3xl p-6 space-y-5 shadow-xs">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
                  <span className="font-mono font-black text-slate-900 text-sm tabular-nums">
                    Phần I · Câu {currentItemIdx + 1} / {totalMcqCount}
                  </span>
                  <span>·</span>
                  <span className="font-extrabold text-teal-800">
                    {SUBJECT_LABELS[currentMcq.subject].name} ({currentMcq.lessonRef})
                  </span>
                  <span>·</span>
                  <span className="font-bold text-indigo-700">
                    Mức độ: {currentMcq.level}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => toggleFlag(currentMcq.id)}
                  className={`flex items-center gap-1.5 text-xs font-bold transition cursor-pointer ${
                    flaggedIds.includes(currentMcq.id)
                      ? 'text-amber-700'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  <Flag className="w-3.5 h-3.5" />
                  <span>
                    {flaggedIds.includes(currentMcq.id)
                      ? 'Đã đánh dấu xem lại'
                      : 'Đánh dấu xem lại'}
                  </span>
                </button>
              </div>

              <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-relaxed">
                {currentMcq.question}
              </h3>

              <div className="space-y-2.5">
                {currentMcq.options.map((opt, optIdx) => {
                  const letter = ['A', 'B', 'C', 'D'][optIdx];
                  const chosen = mcqAnswers[currentMcq.id] === optIdx;
                  const isRight = currentMcq.correctIndex === optIdx;

                  let style =
                    'bg-slate-50 border-slate-200 text-slate-800 hover:border-blue-400';
                  if (!isSubmitted && chosen) {
                    style = 'bg-blue-50 border-blue-600 text-blue-950 font-semibold';
                  } else if (isSubmitted) {
                    if (isRight) {
                      style = 'bg-emerald-50 border-emerald-500 text-emerald-950 font-semibold';
                    } else if (chosen && !isRight) {
                      style = 'bg-rose-50 border-rose-400 text-rose-950';
                    }
                  }

                  return (
                    <button
                      key={optIdx}
                      type="button"
                      onClick={() => handleSelectMcqAnswer(currentMcq.id, optIdx)}
                      className={`w-full flex items-start justify-between gap-3 p-4 rounded-2xl border text-left text-sm transition cursor-pointer ${style}`}
                    >
                      <div className="flex items-start gap-3">
                        <span className="font-mono font-bold text-slate-900 shrink-0">
                          {letter}.
                        </span>
                        <span>{opt}</span>
                      </div>
                      {isSubmitted && isRight && (
                        <span className="text-xs font-mono font-bold text-emerald-700 shrink-0">
                          ● ĐÁP ÁN ĐÚNG
                        </span>
                      )}
                      {isSubmitted && chosen && !isRight && (
                        <span className="text-xs font-mono font-bold text-rose-700 shrink-0">
                          ▲ ĐÃ CHỌN SAI
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {isSubmitted && (
                <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl text-xs space-y-1.5">
                  <div className="font-black text-emerald-950">
                    💡 Giải thích chi tiết ({currentMcq.lessonRef} – Mức {currentMcq.level}):
                  </div>
                  <p className="text-slate-800 leading-relaxed">{currentMcq.explanation}</p>
                </div>
              )}

              {/* Prev / Next Navigation */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                <button
                  type="button"
                  disabled={currentItemIdx === 0}
                  onClick={() => setCurrentItemIdx((prev) => Math.max(0, prev - 1))}
                  className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 rounded-xl transition cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Câu trước</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    setCurrentItemIdx((prev) => Math.min(totalItemCount - 1, prev + 1))
                  }
                  className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold text-white bg-[#0d6efd] hover:bg-blue-700 rounded-xl transition cursor-pointer"
                >
                  <span>
                    {currentItemIdx === totalMcqCount - 1
                      ? 'Chuyển sang Phần II: Tự luận (6 câu) →'
                      : 'Câu tiếp theo'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : currentEssay ? (
            /* PART II: ESSAY CARD (6 CÂU TỰ LUẬN: LÍ, HÓA VẬN DỤNG/VẬN DỤNG CAO; SINH HIỂU/VẬN DỤNG) */
            <div className="bg-white border border-slate-200/90 rounded-3xl p-6 space-y-5 shadow-xs">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
                  <span className="font-mono font-black text-indigo-950 text-sm tabular-nums">
                    Phần II · Tự luận {currentEssayNumber} / {totalEssayCount}
                  </span>
                  <span>·</span>
                  <span className="font-extrabold text-teal-800">
                    {SUBJECT_LABELS[currentEssay.subject].name} ({currentEssay.lessonRef})
                  </span>
                  <span>·</span>
                  <span className="font-extrabold text-rose-700">
                    Mức độ: {currentEssay.level} ({currentEssay.points} điểm)
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => toggleFlag(currentEssay.id)}
                  className={`flex items-center gap-1.5 text-xs font-bold transition cursor-pointer ${
                    flaggedIds.includes(currentEssay.id)
                      ? 'text-amber-700'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  <Flag className="w-3.5 h-3.5" />
                  <span>
                    {flaggedIds.includes(currentEssay.id)
                      ? 'Đã đánh dấu xem lại'
                      : 'Đánh dấu xem lại'}
                  </span>
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/90">
                <p className="text-sm sm:text-base font-bold text-slate-900 whitespace-pre-line leading-relaxed">
                  {currentEssay.question}
                </p>
              </div>

              {/* Student Essay Input Box & Photo Attachment */}
              <div className="space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="text-xs font-black uppercase text-slate-700">
                    BÀI LÀM TỰ LUẬN CỦA HỌC SINH (NHẬP BÀI GIẢI HOẶC ĐÍNH KÈM ẢNH VỞ LÀM BÀI)
                  </label>
                  <div>
                    <input
                      ref={photoInputRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleAttachEssayPhoto(currentEssay.id, e)}
                      className="hidden"
                    />
                    <button
                      type="button"
                      disabled={isSubmitted}
                      onClick={() => photoInputRef.current?.click()}
                      className="px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-extrabold flex items-center gap-1.5 transition disabled:opacity-50 cursor-pointer"
                    >
                      <Camera className="w-3.5 h-3.5" />
                      <span>Đính kèm ảnh bài làm</span>
                    </button>
                  </div>
                </div>

                <textarea
                  rows={5}
                  disabled={isSubmitted}
                  value={essayAnswers[currentEssay.id] || ''}
                  onChange={(e) =>
                    setEssayAnswers((prev) => ({
                      ...prev,
                      [currentEssay.id]: e.target.value,
                    }))
                  }
                  placeholder="Trình bày lời giải, công thức, các bước tính toán hoặc giải thích sinh học tại đây..."
                  className="w-full p-4 rounded-2xl border-2 border-slate-200 focus:border-blue-500 focus:outline-none text-sm text-slate-900 disabled:bg-slate-50"
                />

                {/* Attached Photos Preview */}
                {(essayPhotos[currentEssay.id] || []).length > 0 && (
                  <div className="flex flex-wrap gap-2.5">
                    {(essayPhotos[currentEssay.id] || []).map((imgUrl, idx) => (
                      <div
                        key={idx}
                        className="relative w-24 h-24 rounded-xl overflow-hidden border border-slate-300 shadow-xs"
                      >
                        <img
                          src={imgUrl}
                          alt={`Ảnh bài tự luận ${idx + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Model Answer & Rubric Grading Criteria when submitted */}
              {isSubmitted && (
                <div className="p-5 rounded-2xl bg-emerald-50/80 border border-emerald-300 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs font-black uppercase text-emerald-950">
                      ✅ ĐÁP ÁN MẪU & BIỂU ĐIỂM CHẤM TỰ LUẬN ({currentEssay.points} ĐIỂM)
                    </span>

                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="font-bold text-slate-700">Điểm đạt được:</span>
                      {[0, 0.25, 0.5].map((pt) => (
                        <button
                          key={pt}
                          type="button"
                          onClick={() =>
                            setEssaySelfScores((prev) => ({
                              ...prev,
                              [currentEssay.id]: pt,
                            }))
                          }
                          className={`px-2.5 py-1 rounded-lg font-mono font-extrabold cursor-pointer ${
                            (essaySelfScores[currentEssay.id] ?? 0) === pt
                              ? 'bg-emerald-600 text-white'
                              : 'bg-white border border-slate-300 text-slate-700'
                          }`}
                        >
                          {pt}đ
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-white border border-emerald-200 text-xs sm:text-sm text-slate-800 whitespace-pre-line leading-relaxed">
                    {currentEssay.sampleAnswer}
                  </div>

                  <div className="space-y-1">
                    <div className="text-xs font-extrabold text-emerald-900">
                      Biểu điểm chấm chi tiết (Rubric):
                    </div>
                    <ul className="list-disc pl-5 text-xs text-slate-700 space-y-1">
                      {currentEssay.rubricCriteria.map((crit, cIdx) => (
                        <li key={cIdx}>{crit}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {/* Prev / Next Navigation */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setCurrentItemIdx((prev) => Math.max(0, prev - 1))}
                  className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Câu trước</span>
                </button>

                <button
                  type="button"
                  disabled={currentItemIdx === totalItemCount - 1}
                  onClick={() =>
                    setCurrentItemIdx((prev) => Math.min(totalItemCount - 1, prev + 1))
                  }
                  className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-40 rounded-xl transition cursor-pointer"
                >
                  <span>Câu tự luận tiếp theo</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : null}
        </div>

        {/* Right Column (4 cols): Sticky Parallel Question Coordinator (21 TN + 6 TL) & Timer */}
        <div className="lg:col-span-4 lg:sticky lg:top-20 bg-white border-2 border-teal-500/80 rounded-3xl overflow-hidden shadow-md">
          <div className="bg-gradient-to-r from-[#071936] via-[#0a2748] to-[#063d3f] text-white px-5 py-4 flex items-center justify-between gap-2">
            <div>
              <div className="text-[10px] font-mono uppercase tracking-wider text-emerald-300 font-bold">
                BẢNG ĐIỀU PHỐI PHÒNG THI
              </div>
              <h4 className="text-sm font-black text-white">
                {totalMcqCount} Câu TN + {totalEssayCount} Câu Tự Luận
              </h4>
            </div>
            {onBackToHome && (
              <button
                type="button"
                onClick={onBackToHome}
                className="px-2.5 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-[11px] font-extrabold flex items-center gap-1 cursor-pointer"
              >
                <Home className="w-3.5 h-3.5 text-amber-300" />
                <span>Trang chủ</span>
              </button>
            )}
          </div>

          <div className="p-5 space-y-4">
            {/* Countdown Timer */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
                <Clock className="w-4 h-4 text-blue-600" />
                <span>Thời gian làm bài:</span>
              </div>
              <div
                className={`font-mono text-xl font-black tabular-nums ${
                  secondsLeft < 120 && !isSubmitted ? 'text-rose-600' : 'text-slate-900'
                }`}
              >
                {formatTime(secondsLeft)}
              </div>
            </div>

            {/* Live Status Counters */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2 rounded-xl bg-blue-50 border border-blue-200">
                <div className="text-[10px] font-extrabold uppercase text-blue-700">
                  Đã làm
                </div>
                <div className="text-base font-black text-blue-950 tabular-nums">
                  {totalAnsweredItems}/{totalItemCount}
                </div>
              </div>
              <div className="p-2 rounded-xl bg-rose-50 border border-rose-200">
                <div className="text-[10px] font-extrabold uppercase text-rose-700">
                  Còn thiếu
                </div>
                <div className="text-base font-black text-rose-950 tabular-nums">
                  {missingItemIndices.length}
                </div>
              </div>
              <div className="p-2 rounded-xl bg-amber-50 border border-amber-200">
                <div className="text-[10px] font-extrabold uppercase text-amber-700">
                  Đánh dấu
                </div>
                <div className="text-base font-black text-amber-950 tabular-nums">
                  {flaggedIds.length}
                </div>
              </div>
            </div>

            {/* Missing Questions Jump Button */}
            {!isSubmitted && missingItemIndices.length > 0 && (
              <button
                type="button"
                onClick={jumpToNextMissingItem}
                className="w-full py-2 px-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <AlertCircle className="w-3.5 h-3.5" />
                <span>Chuyển tới câu còn thiếu tiếp theo ({missingItemIndices.length} câu)</span>
              </button>
            )}

            {/* PART I: 21 MCQs Grid */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-extrabold text-slate-800">
                <span>Phần I: {totalMcqCount} Câu Trắc nghiệm (7,0đ)</span>
                <span className="text-[11px] text-slate-500">
                  {answeredMcqCount}/{totalMcqCount} đã chọn
                </span>
              </div>
              <div className="grid grid-cols-7 gap-1.5">
                {activeExam.mcqs.map((q, idx) => {
                  const isCurrent = idx === currentItemIdx;
                  const isAnswered = mcqAnswers[q.id] !== undefined;
                  const isFlagged = flaggedIds.includes(q.id);
                  const isRight = mcqAnswers[q.id] === q.correctIndex;

                  let cellClass =
                    'bg-slate-50 border-dashed border-slate-300 text-slate-600 hover:border-blue-500';
                  if (isSubmitted) {
                    cellClass = isRight
                      ? 'bg-emerald-600 border-emerald-600 text-white font-bold'
                      : 'bg-rose-600 border-rose-600 text-white font-bold';
                  } else if (isCurrent) {
                    cellClass =
                      'bg-slate-900 border-slate-900 text-white font-black ring-2 ring-blue-500/40';
                  } else if (isFlagged) {
                    cellClass = 'bg-amber-100 border-amber-400 text-amber-900 font-bold';
                  } else if (isAnswered) {
                    cellClass = 'bg-blue-600 border-blue-600 text-white font-bold';
                  }

                  return (
                    <button
                      key={q.id}
                      type="button"
                      onClick={() => setCurrentItemIdx(idx)}
                      title={`Câu ${idx + 1}: ${q.lessonRef} (${q.level})`}
                      className={`py-1.5 rounded-lg border text-xs font-mono tabular-nums transition cursor-pointer ${cellClass}`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* PART II: 6 Essays Grid */}
            <div className="space-y-1.5 pt-2 border-t border-slate-100">
              <div className="flex items-center justify-between text-xs font-extrabold text-slate-800">
                <span>Phần II: {totalEssayCount} Câu Tự luận (3,0đ)</span>
                <span className="text-[11px] text-slate-500">
                  {completedEssayCount}/{totalEssayCount} đã làm
                </span>
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {activeExam.essays.map((es, idx) => {
                  const globalIdx = totalMcqCount + idx;
                  const isCurrent = currentItemIdx === globalIdx;
                  const done = isEssayDone(es.id);
                  const isFlagged = flaggedIds.includes(es.id);
                  const shortSub =
                    es.subject === 'physics'
                      ? 'Lí'
                      : es.subject === 'chemistry'
                      ? 'Hóa'
                      : 'Sinh';

                  let cellClass =
                    'bg-slate-50 border-dashed border-slate-300 text-slate-700 hover:border-indigo-500';
                  if (isSubmitted) {
                    cellClass = done
                      ? 'bg-emerald-600 border-emerald-600 text-white font-bold'
                      : 'bg-amber-500 border-amber-500 text-white font-bold';
                  } else if (isCurrent) {
                    cellClass =
                      'bg-slate-900 border-slate-900 text-white font-black ring-2 ring-indigo-500/40';
                  } else if (isFlagged) {
                    cellClass = 'bg-amber-100 border-amber-400 text-amber-900 font-bold';
                  } else if (done) {
                    cellClass = 'bg-indigo-600 border-indigo-600 text-white font-bold';
                  }

                  return (
                    <button
                      key={es.id}
                      type="button"
                      onClick={() => setCurrentItemIdx(globalIdx)}
                      title={`${es.lessonRef} (${es.level})`}
                      className={`py-2 px-1.5 rounded-xl border text-[11px] font-bold transition cursor-pointer ${cellClass}`}
                    >
                      TL {idx + 1} ({shortSub})
                    </button>
                  );
                })}
              </div>
            </div>

            {!isSubmitted ? (
              <button
                type="button"
                onClick={handleSubmitExam}
                className="w-full flex items-center justify-center gap-2 py-3.5 px-4 bg-[#0d6efd] hover:bg-blue-700 text-white text-xs sm:text-sm font-black rounded-2xl shadow-md transition cursor-pointer"
              >
                <FileCheck2 className="w-4 h-4" />
                <span>Nộp bài & Chấm điểm (21 TN + 6 TL)</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleSelectExamPaper(activeExam.id)}
                className="w-full flex items-center justify-center gap-2 py-3.5 px-4 bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-black rounded-2xl transition cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Làm lại lượt thi mới</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ================= MODAL: TẢI ĐỀ RIÊNG CỦA GIÁO VIÊN LÊN (.DOCX / .TXT) ================= */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 overflow-hidden">
            <div className="bg-gradient-to-r from-[#071936] via-[#0a2748] to-[#063d3f] px-6 py-5 text-white flex items-center justify-between gap-3">
              <div>
                <div className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-300">
                  DÀNH CHO GIÁO VIÊN BỘ MÔN KHTN 7
                </div>
                <h3 className="text-lg sm:text-xl font-black mt-0.5">
                  Tải Đề Kiểm Tra Riêng của Giáo viên lên (.DOCX / .TXT)
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowUploadModal(false)}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {!localTeacherUnlocked ? (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const ok = onAuthenticateTeacher
                    ? onAuthenticateTeacher(teacherPinForUpload)
                    : teacherPinForUpload.trim() === '0385379344';
                  if (ok) {
                    setLocalTeacherUnlocked(true);
                    setUploadPinError('');
                    setTeacherPinForUpload('');
                  } else {
                    setUploadPinError('Mật khẩu Giáo viên không chính xác! Vui lòng kiểm tra lại.');
                  }
                }}
                className="p-6 space-y-4"
              >
                <div>
                  <label className="block text-xs font-black uppercase text-slate-800 mb-2">
                    NHẬP MẬT KHẨU BẢO MẬT CỦA GIÁO VIÊN ĐỂ TẢI ĐỀ LÊN
                  </label>
                  <input
                    type="password"
                    value={teacherPinForUpload}
                    onChange={(e) => setTeacherPinForUpload(e.target.value)}
                    placeholder="Nhập mật khẩu riêng của giáo viên..."
                    className="w-full px-4 py-3 rounded-2xl border-2 border-blue-400 text-sm font-semibold text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                  <p className="text-xs text-slate-500 mt-1.5">
                    Bảo vệ ngân hàng đề kiểm tra: Chỉ giáo viên có mật khẩu mới được phép tải thêm đề mới hoặc xóa đề.
                  </p>
                  {uploadPinError && (
                    <p className="text-xs font-extrabold text-rose-600 mt-2">{uploadPinError}</p>
                  )}
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-[#0d6efd] hover:bg-blue-700 text-white font-black text-sm shadow-md cursor-pointer"
                >
                  Xác nhận Mật khẩu Giáo viên →
                </button>
              </form>
            ) : (
              <form onSubmit={handleSaveCustomTeacherExam} className="p-6 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                      Tên Đề kiểm tra riêng của Giáo viên
                    </label>
                    <input
                      type="text"
                      value={customTitle}
                      onChange={(e) => setCustomTitle(e.target.value)}
                      placeholder="VD: Đề Kiểm Tra Giữa Kì 1 – Lớp 7A1 (Đề số 2)"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-900 focus:outline-none focus:border-blue-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                      Kì kiểm tra
                    </label>
                    <select
                      value={customCategoryCode}
                      onChange={(e) =>
                        setCustomCategoryCode(
                          e.target.value as 'gk1' | 'hk1' | 'gk2' | 'hk2'
                        )
                      }
                      className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-bold text-slate-900 bg-white"
                    >
                      <option value="gk1">Giữa Kì 1 (GK1)</option>
                      <option value="hk1">Cuối Học Kì 1 (HK1)</option>
                      <option value="gk2">Giữa Kì 2 (GK2)</option>
                      <option value="hk2">Cuối Học Kì 2 (HK2)</option>
                    </select>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-blue-50/70 border-2 border-dashed border-blue-300 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="text-xs font-black text-blue-950">
                      Chọn file Đề kiểm tra Word (.docx) hoặc Text (.txt) từ máy tính
                    </div>
                    <p className="text-[11px] text-slate-600">
                      {uploadedFileName
                        ? `Đã chọn file: ${uploadedFileName}`
                        : 'Hỗ trợ tự động nhận diện câu hỏi Trắc nghiệm (Câu 1... A. B. C. D.) và câu hỏi Tự luận.'}
                    </p>
                  </div>

                  <div>
                    <input
                      ref={wordFileInputRef}
                      type="file"
                      accept=".docx,.doc,.txt"
                      onChange={handleUploadWordExamFile}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => wordFileInputRef.current?.click()}
                      className="px-4 py-2.5 rounded-xl bg-[#0d6efd] hover:bg-blue-700 text-white text-xs font-black flex items-center gap-1.5 shadow-xs whitespace-nowrap cursor-pointer"
                    >
                      <Upload className="w-4 h-4" />
                      <span>Chọn file Word (.docx)</span>
                    </button>
                  </div>
                </div>

                {uploadNotice && (
                  <p className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3.5 py-2 rounded-xl">
                    {uploadNotice}
                  </p>
                )}

                <div>
                  <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                    Nội dung câu hỏi trong đề (Tự động trích xuất từ file Word hoặc dán trực tiếp)
                  </label>
                  <textarea
                    rows={6}
                    value={customRawText}
                    onChange={(e) => setCustomRawText(e.target.value)}
                    placeholder={`Câu 1: Công thức tính tốc độ là gì?\nA. *v = s / t\nB. v = s . t\nC. v = t / s\nD. s = v / t\n...\nPHẦN II: TỰ LUẬN\nCâu 22: Một ô tô đi quãng đường 90 km trong 1,5 giờ...`}
                    className="w-full p-3.5 rounded-2xl border border-slate-300 text-xs sm:text-sm font-mono text-slate-800 focus:outline-none focus:border-blue-600"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">
                    Mẹo: Đặt dấu <code className="font-bold text-indigo-700">*</code> trước đáp án đúng (VD: <code className="font-bold">*A.</code>) hoặc thêm dòng <code className="font-bold">Đáp án: A</code> bên dưới câu hỏi để hệ thống tự chấm điểm.
                  </p>
                </div>

                <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowUploadModal(false)}
                    className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
                  >
                    Hủy
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-black shadow-md cursor-pointer"
                  >
                    💾 Lưu Đề Riêng & Mở Làm Bài Ngay
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* ================= MODAL: TẢI ĐỀ & MA TRẬN LÊN → SINH ĐỀ THEO MA TRẬN, LƯU ĐỀ & LƯU MA TRẬN ================= */}
      <MatrixExamBuilderModal
        isOpen={showMatrixBuilderModal}
        onClose={() => setShowMatrixBuilderModal(false)}
        isTeacherAuthenticated={localTeacherUnlocked}
        onAuthenticateTeacher={(pin) => {
          const ok = onAuthenticateTeacher
            ? onAuthenticateTeacher(pin)
            : pin.trim() === '0385379344';
          if (ok) setLocalTeacherUnlocked(true);
          return ok;
        }}
        savedMatrices={savedMatrices}
        onSaveMatrix={handleSaveMatrix}
        onDeleteMatrix={handleDeleteMatrix}
        onGenerateAndSaveExams={handleGenerateAndSaveExamsFromMatrix}
        parseCustomExamTextFn={parseCustomExamText}
      />
    </section>
  );
};
