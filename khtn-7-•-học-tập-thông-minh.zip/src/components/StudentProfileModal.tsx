import React, { useState } from 'react';
import {
  X,
  ArrowLeftRight,
  AlertTriangle,
  Award,
  UserCheck,
  Sparkles,
  BarChart3,
  Plus,
  CheckCircle2,
  TrendingDown,
  TrendingUp,
  Minus,
  Edit3,
  Save,
  Send,
  FileText,
} from 'lucide-react';
import {
  StudentProfile,
  StudentAssessmentScores,
  calculateStudentGradeMetrics,
  getDefaultScoresForStudent,
  TeacherCommentRecord,
  CommendationRecord,
} from '../data/classStore';
import { ALL_KNTT_LESSONS } from '../data/allLessons';
import { EssaySubmission } from '../data/lessonTypes';

interface StudentProfileModalProps {
  student: StudentProfile;
  isCurrentActiveStudent: boolean;
  userRole: 'student' | 'teacher';
  activeWeek: number;
  onClose: () => void;
  onUpdateStudent: (updated: StudentProfile) => void;
}

type ModalTab = 'scores' | 'commendation' | 'strengths' | 'comments';

export const StudentProfileModal: React.FC<StudentProfileModalProps> = ({
  student,
  isCurrentActiveStudent,
  userRole,
  activeWeek,
  onClose,
  onUpdateStudent,
}) => {
  const [activeTab, setActiveTab] = useState<ModalTab>('scores');
  const [isEditingScores, setIsEditingScores] = useState(false);
  const [isEditingIdentity, setIsEditingIdentity] = useState(false);
  const [draftFullName, setDraftFullName] = useState(student.fullName);
  const [draftClassName, setDraftClassName] = useState(student.className);

  const initialScores = getDefaultScoresForStudent(student);
  const [draftScores, setDraftScores] = useState<StudentAssessmentScores>(initialScores);

  // Tab 3 states
  const [absorptionLevel, setAbsorptionLevel] = useState<
    'Xuất sắc' | 'Khá' | 'Trung bình' | 'Cần hỗ trợ'
  >(student.absorptionLevel || 'Khá');
  const [strengthsText, setStrengthsText] = useState(
    student.strengths || 'Yêu thích khám phá thí nghiệm KHTN 7, tích cực làm bài luyện tập.'
  );
  const [privateNoteText, setPrivateNoteText] = useState(
    student.privateNote || 'Theo dõi sát tiến độ hoàn thành BTVN hàng tuần.'
  );
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  // Tab 4 states (Teacher & Smart Comments)
  const [newCommentText, setNewCommentText] = useState('');
  const [newCommentTrend, setNewCommentTrend] = useState<
    'Tiến bộ vượt bậc' | 'Duy trì tốt' | 'Cần cố gắng thêm' | 'Cần phụ đạo sát'
  >('Tiến bộ vượt bậc');

  const metrics = calculateStudentGradeMetrics({
    ...student,
    scores: isEditingScores ? draftScores : student.scores || initialScores,
  });

  // Read live Essay Submissions if this is the active logged-in student
  const essaySubmissions: Record<string, EssaySubmission> = (() => {
    try {
      const raw = localStorage.getItem('khtn7_kntt_essay_v2');
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  })();

  const handleCycleClass = () => {
    const classes = ['Lớp 7A1', 'Lớp 7A2', 'Lớp 7A3', 'Lớp 7A4'];
    const currentIdx = classes.indexOf(student.className);
    const nextClass = classes[(currentIdx + 1) % classes.length];
    onUpdateStudent({
      ...student,
      className: nextClass,
    });
  };

  const handleSaveIdentity = () => {
    const cleanedName = draftFullName.trim().toUpperCase();
    if (!cleanedName) return;
    const cleanedClass = draftClassName.trim() || student.className || 'Lớp 7A1';
    onUpdateStudent({
      ...student,
      fullName: cleanedName,
      className: cleanedClass,
    });
    setIsEditingIdentity(false);
    setSavedNotice(`Đã cập nhật tên học sinh thành "${cleanedName}" (${cleanedClass})!`);
    setTimeout(() => setSavedNotice(null), 2800);
  };

  const handleSaveScores = () => {
    const nextAbsorption =
      metrics.average >= 8.0
        ? 'Xuất sắc'
        : metrics.average >= 6.5
        ? 'Khá'
        : metrics.average >= 5.0
        ? 'Trung bình'
        : 'Cần hỗ trợ';

    onUpdateStudent({
      ...student,
      scores: draftScores,
      absorptionLevel: nextAbsorption,
    });
    setIsEditingScores(false);
    setSavedNotice('Đã lưu bảng điểm và cập nhật biểu đồ tiến độ!');
    setTimeout(() => setSavedNotice(null), 2500);
  };

  const handleScoreInputChange = (key: keyof StudentAssessmentScores, rawVal: string) => {
    if (rawVal.trim() === '') {
      setDraftScores((prev) => ({ ...prev, [key]: null }));
      return;
    }
    const num = Number(rawVal);
    if (!Number.isNaN(num) && num >= 0 && num <= 10) {
      setDraftScores((prev) => ({ ...prev, [key]: num }));
    }
  };

  const handleAddCommendation = (reason: string, pts: number) => {
    const newRecord: CommendationRecord = {
      id: `cm-${Date.now()}`,
      reason,
      points: pts,
      weekNumber: activeWeek,
      createdAt: new Date().toLocaleDateString('vi-VN'),
    };
    const nextPoints = Math.max(0, (student.commendationPoints || 0) + pts);
    const nextHistory = [newRecord, ...(student.commendationHistory || [])];
    onUpdateStudent({
      ...student,
      commendationPoints: nextPoints,
      commendationHistory: nextHistory,
    });
    setSavedNotice(`Đã cập nhật ${pts > 0 ? `+${pts}` : pts} điểm rèn luyện cho ${student.fullName}!`);
    setTimeout(() => setSavedNotice(null), 2500);
  };

  const handleSaveStrengthsAndNotes = () => {
    onUpdateStudent({
      ...student,
      absorptionLevel,
      strengths: strengthsText,
      privateNote: privateNoteText,
    });
    setSavedNotice('Đã lưu hồ sơ sở trường & ghi chú riêng!');
    setTimeout(() => setSavedNotice(null), 2500);
  };

  const handleGenerateSmartComment = () => {
    if (metrics.needsWarning) {
      setNewCommentTrend('Cần phụ đạo sát');
      setNewCommentText(
        `Tuần ${activeWeek}: Điểm trung bình hiện tại của ${student.fullName} là ${metrics.average} (có cột điểm thấp nhất ${metrics.lowest}). Em cần vào mục "Ôn tập câu sai" làm lại các câu trắc nghiệm chưa vững và nộp đầy đủ bài tập tự luận của Tuần ${activeWeek}.`
      );
    } else if (metrics.average >= 8.0) {
      setNewCommentTrend('Tiến bộ vượt bậc');
      setNewCommentText(
        `Tuần ${activeWeek}: Tuyên dương ${student.fullName} đạt điểm trung bình ${metrics.average} (${metrics.rankLabel}), hoàn thành tốt nhiệm vụ BTVN Tuần ${activeWeek}. Em nắm vững kiến thức KHTN 7 và trình bày bài tự luận rất khoa học!`
      );
    } else {
      setNewCommentTrend('Duy trì tốt');
      setNewCommentText(
        `Tuần ${activeWeek}: ${student.fullName} đạt điểm trung bình ${metrics.average} (${metrics.rankLabel}). Em có ý thức hoàn thành bài tập về nhà, cần rèn luyện thêm các bài tập vận dụng và trò chơi bài học để bứt phá lên mức Giỏi.`
      );
    }
  };

  const handleAddTeacherComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;
    const record: TeacherCommentRecord = {
      id: `tc-${Date.now()}`,
      weekNumber: activeWeek,
      content: newCommentText.trim(),
      trendTag: newCommentTrend,
      createdAt: new Date().toLocaleDateString('vi-VN'),
    };
    onUpdateStudent({
      ...student,
      teacherComments: [record, ...(student.teacherComments || [])],
    });
    setNewCommentText('');
    setSavedNotice(`Đã gửi nhận xét Tuần ${activeWeek} tới học sinh ${student.fullName}!`);
    setTimeout(() => setSavedNotice(null), 2500);
  };

  const handleStampEssayFeedback = (lessonTitle: string, stampLabel: string, bonusPts: number) => {
    const record: TeacherCommentRecord = {
      id: `tc-stamp-${Date.now()}`,
      weekNumber: activeWeek,
      content: `[Chấm bài Tự luận - ${lessonTitle}]: ${stampLabel}`,
      trendTag: bonusPts > 0 ? 'Tiến bộ vượt bậc' : 'Cần cố gắng thêm',
      createdAt: new Date().toLocaleDateString('vi-VN'),
    };
    const nextPoints = Math.max(0, (student.commendationPoints || 10) + bonusPts);
    const nextCommHistory: CommendationRecord[] =
      bonusPts !== 0
        ? [
            {
              id: `cm-stamp-${Date.now()}`,
              reason: `Chấm bài Tự luận (${lessonTitle}): ${stampLabel}`,
              points: bonusPts,
              weekNumber: activeWeek,
              createdAt: new Date().toLocaleDateString('vi-VN'),
            },
            ...(student.commendationHistory || []),
          ]
        : student.commendationHistory || [];

    onUpdateStudent({
      ...student,
      commendationPoints: nextPoints,
      commendationHistory: nextCommHistory,
      teacherComments: [record, ...(student.teacherComments || [])],
    });
    setSavedNotice(`Đã đóng dấu nhận xét "${stampLabel}" cho bài tự luận của ${student.fullName}!`);
    setTimeout(() => setSavedNotice(null), 2800);
  };

  const buildParentWeeklyReportText = () => {
    const latestComment =
      student.teacherComments && student.teacherComments.length > 0
        ? student.teacherComments[0].content
        : `Em ${student.fullName} có ý thức tham gia học tập bộ môn KHTN 7 (Sách KNTT) trong Tuần ${activeWeek}.`;
    const semesterStr = activeWeek <= 18 ? 'Học kì I' : 'Học kì II';
    return [
      `📊 PHIẾU BÁO KẾT QUẢ HỌC TẬP MÔN KHTN 7 (SÁCH KNTT)`,
      `• Tuần học: Tuần ${activeWeek} (${semesterStr})`,
      `• Học sinh: ${student.fullName} (${student.code}) – ${student.className}`,
      `• Điểm trung bình hiện tại: ${metrics.average.toFixed(2)} (${metrics.rankLabel})`,
      `• Xu hướng tiến bộ: ${metrics.trendLabel}`,
      `• Điểm rèn luyện & Tuyên dương: +${student.commendationPoints || 10} điểm`,
      `• Số bài tập đã hoàn thành: ${student.baselineMcqDone} câu TN · ${student.baselineTfDone} bài Đ/S · ${student.baselineEssayDone} bài Tự luận`,
      `• Nhận xét của Giáo viên bộ môn: "${latestComment}"`,
      `--- Hệ thống KHTN 7 – Học Tập Thông Minh ---`,
    ].join('\n');
  };

  const handleCopyParentReportZalo = async () => {
    const text = buildParentWeeklyReportText();
    try {
      await navigator.clipboard.writeText(text);
      setSavedNotice('📋 Đã sao chép Phiếu báo kết quả Tuần! Thầy/Cô có thể dán gửi ngay qua Zalo cho Phụ huynh.');
    } catch {
      setSavedNotice('📋 Đã tạo nội dung Phiếu báo kết quả học tập tuần!');
    }
    setTimeout(() => setSavedNotice(null), 3200);
  };

  const handleDownloadParentReportDoc = () => {
    const latestComment =
      student.teacherComments && student.teacherComments.length > 0
        ? student.teacherComments[0].content
        : `Em ${student.fullName} tích cực hoàn thành nhiệm vụ học tập môn KHTN 7 trong Tuần ${activeWeek}.`;
    const htmlContent = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
      <head><meta charset="utf-8"><title>Phieu Bao Ket Qua Tuan ${activeWeek} - ${student.fullName}</title></head>
      <body style="font-family: 'Times New Roman', serif; line-height: 1.6; padding: 24px;">
        <h2 style="color: #0d9488; text-align: center; margin-bottom: 4px;">PHIẾU BÁO KẾT QUẢ HỌC TẬP MÔN KHOA HỌC TỰ NHIÊN 7</h2>
        <p style="text-align: center; font-weight: bold; margin-top: 0;">Sách Kết nối tri thức với cuộc sống — Tuần ${activeWeek} (${activeWeek <= 18 ? 'Học kì I' : 'Học kì II'})</p>
        <hr />
        <p><strong>Họ và tên học sinh:</strong> ${student.fullName} &nbsp;&nbsp;|&nbsp;&nbsp; <strong>Mã HS:</strong> ${student.code} &nbsp;&nbsp;|&nbsp;&nbsp; <strong>Lớp:</strong> ${student.className}</p>
        <p><strong>Điểm trung bình môn hiện tại:</strong> ${metrics.average.toFixed(2)} (${metrics.rankLabel}) — <strong>Xu hướng:</strong> ${metrics.trendLabel}</p>
        <p><strong>Điểm rèn luyện & chuyên cần tích lũy:</strong> +${student.commendationPoints || 10} điểm thưởng</p>
        <p><strong>Tiến độ bài tập về nhà:</strong> Đã hoàn thành ${student.baselineMcqDone} câu Trắc nghiệm, ${student.baselineTfDone} bài Đúng/Sai, ${student.baselineEssayDone} bài Tự luận.</p>
        <p><strong>Nhận xét của Giáo viên bộ môn KHTN 7:</strong></p>
        <div style="border: 1px solid #94a3b8; padding: 12px; background: #f8fafc;">${latestComment}</div>
        <p style="margin-top: 24px; text-align: right;"><em>Ngày xuất phiếu: ${new Date().toLocaleDateString('vi-VN')} — Giáo viên bộ môn KHTN 7</em></p>
      </body>
      </html>
    `;
    const blob = new Blob(['\ufeff', htmlContent], {
      type: 'application/msword;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Phieu_Bao_KHTN7_Tuan_${activeWeek}_${student.code}.doc`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setSavedNotice(`🖨️ Đã tải Phiếu báo kết quả học tập Tuần ${activeWeek} (.doc) của ${student.fullName}!`);
    setTimeout(() => setSavedNotice(null), 3000);
  };

  // Build SVG line chart coordinates for the 7 evaluation columns
  const svgWidth = 360;
  const svgHeight = 140;
  const padLeft = 32;
  const padRight = 20;
  const padTop = 24;
  const padBottom = 26;
  const plotW = svgWidth - padLeft - padRight;
  const plotH = svgHeight - padTop - padBottom;

  const plottedNodes = metrics.chartPoints
    .map((pt, idx) => {
      const x = padLeft + (idx / 6) * plotW;
      const y =
        pt.value !== null
          ? padTop + ((10 - Math.max(0, Math.min(10, pt.value))) / 10) * plotH
          : null;
      return { ...pt, x, y };
    })
    .filter((n) => n.y !== null) as {
    key: string;
    label: string;
    coeff: number;
    value: number;
    x: number;
    y: number;
  }[];

  const polylinePoints = plottedNodes.map((n) => `${n.x},${n.y}`).join(' ');
  const areaPoints =
    plottedNodes.length >= 2
      ? `${plottedNodes[0].x},${padTop + plotH} ${polylinePoints} ${
          plottedNodes[plottedNodes.length - 1].x
        },${padTop + plotH}`
      : '';

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* ================= MODAL HEADER (MATCHING IMAGE 2) ================= */}
        <div className="px-6 pt-5 pb-3 flex flex-wrap items-center justify-between gap-4 border-b border-slate-100">
          <div className="flex items-center gap-3.5">
            <div
              className={`w-12 h-12 rounded-2xl ${student.avatarColor || 'bg-indigo-600'} text-white font-black text-lg flex items-center justify-center shadow-sm shrink-0`}
            >
              {student.fullName.trim().split(' ').pop()?.charAt(0) || 'H'}
            </div>
            <div>
              {isEditingIdentity && userRole === 'teacher' ? (
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="text"
                    value={draftFullName}
                    onChange={(e) => setDraftFullName(e.target.value)}
                    placeholder="Họ và tên học sinh..."
                    className="px-3 py-1.5 rounded-xl border-2 border-blue-500 text-sm font-black text-slate-900 focus:outline-none"
                  />
                  <input
                    type="text"
                    value={draftClassName}
                    onChange={(e) => setDraftClassName(e.target.value)}
                    placeholder="Lớp 7A1"
                    className="w-28 px-2.5 py-1.5 rounded-xl border-2 border-blue-400 text-xs font-bold text-slate-900 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleSaveIdentity}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black flex items-center gap-1 cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Cập nhật</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsEditingIdentity(false)}
                    className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
                  >
                    Hủy
                  </button>
                </div>
              ) : (
                <>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-lg sm:text-xl font-black text-slate-900">
                      {student.fullName}
                    </h3>
                    {metrics.needsWarning ? (
                      <span className="px-2.5 py-0.5 rounded-full bg-rose-600 text-white text-[11px] font-extrabold">
                        Cần hỗ trợ
                      </span>
                    ) : (
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-600 text-white text-[11px] font-extrabold">
                        {student.absorptionLevel || 'Khá'}
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-500 font-semibold flex items-center gap-2 mt-0.5">
                    <span>
                      Lớp: <strong className="text-slate-800">{student.className.replace('Lớp ', '')}</strong>
                    </span>
                    <span>·</span>
                    <span>
                      Tiếp thu: <strong className="text-indigo-700">{student.absorptionLevel || 'Khá'}</strong> 🔥
                    </span>
                  </div>
                </>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            {userRole === 'teacher' && !isEditingIdentity && (
              <button
                type="button"
                onClick={() => {
                  setDraftFullName(student.fullName);
                  setDraftClassName(student.className);
                  setIsEditingIdentity(true);
                }}
                className="px-3 py-1.5 rounded-xl border border-amber-200 bg-amber-50 hover:bg-amber-100 text-amber-900 font-extrabold text-xs flex items-center gap-1.5 transition cursor-pointer"
                title="Sửa tên hoặc lớp của học sinh"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Sửa tên / Lớp</span>
              </button>
            )}
            {userRole === 'teacher' && (
              <button
                onClick={handleCycleClass}
                className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
                title="Chuyển lớp cho học sinh"
              >
                <ArrowLeftRight className="w-3.5 h-3.5" />
                <span>Chuyển lớp</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-xl hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* ================= 4 NAVIGATION TABS (MATCHING IMAGE 2) ================= */}
        <div className="px-6 border-b border-slate-200 bg-slate-50/60 flex items-center gap-6 overflow-x-auto">
          {[
            {
              id: 'scores' as ModalTab,
              label: 'Điểm số & Biểu đồ',
              icon: <BarChart3 className="w-4 h-4 text-indigo-600" />,
            },
            {
              id: 'commendation' as ModalTab,
              label: `Rèn luyện & Tuyên dương (+${student.commendationPoints || 10})`,
              icon: <Award className="w-4 h-4 text-amber-500" />,
            },
            {
              id: 'strengths' as ModalTab,
              label: 'Sở trường & Ghi chú riêng',
              icon: <UserCheck className="w-4 h-4 text-teal-600" />,
            },
            {
              id: 'comments' as ModalTab,
              label: 'Nhận xét AI & Giáo viên',
              icon: <Sparkles className="w-4 h-4 text-purple-600" />,
            },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-3 text-xs sm:text-sm font-extrabold flex items-center gap-2 border-b-2 transition whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'border-indigo-600 text-indigo-700'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/*Saved Toast Notice */}
        {savedNotice && (
          <div className="mx-6 mt-3 px-4 py-2 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-extrabold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{savedNotice}</span>
          </div>
        )}

        {/* ================= MODAL BODY ================= */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* TAB 1: ĐIỂM SỐ & BIỂU ĐỒ (EXACT MATCH TO IMAGE 2) */}
          {activeTab === 'scores' && (
            <div className="space-y-5">
              {/* 4 Top KPI Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
                {/* Card 1: Điểm trung bình */}
                <div className="rounded-2xl border border-slate-200/90 bg-white p-4 shadow-2xs space-y-1">
                  <div className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400">
                    ĐIỂM TRUNG BÌNH
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-indigo-600">
                    {metrics.average.toFixed(2)}
                  </div>
                  <div className="text-xs font-semibold text-slate-500">
                    {metrics.rankLabel}
                  </div>
                </div>

                {/* Card 2: Điểm cao nhất */}
                <div className="rounded-2xl border border-slate-200/90 bg-white p-4 shadow-2xs space-y-1">
                  <div className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400">
                    ĐIỂM CAO NHẤT
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-emerald-600">
                    {metrics.highest}
                  </div>
                  <div className="text-xs font-semibold text-slate-500">
                    Thấp nhất: {metrics.lowest}
                  </div>
                </div>

                {/* Card 3: Số cột điểm */}
                <div className="rounded-2xl border border-slate-200/90 bg-white p-4 shadow-2xs space-y-1">
                  <div className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400">
                    SỐ CỘT ĐIỂM
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-slate-900">
                    {metrics.filledCount}/{metrics.totalColumns}
                  </div>
                  <div className="text-xs font-semibold text-slate-500">
                    TX1–5, ĐGGK, ĐGCK
                  </div>
                </div>

                {/* Card 4: Xu hướng tiến bộ */}
                <div className="rounded-2xl border border-slate-200/90 bg-white p-4 shadow-2xs space-y-1.5">
                  <div className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400">
                    XU HƯỚNG TIẾN BỘ
                  </div>
                  <div>
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-extrabold ${
                        metrics.trend === 'down'
                          ? 'bg-amber-100 text-amber-800'
                          : metrics.trend === 'up'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      {metrics.trend === 'down' && <TrendingDown className="w-3.5 h-3.5" />}
                      {metrics.trend === 'up' && <TrendingUp className="w-3.5 h-3.5" />}
                      {metrics.trend === 'stable' && <Minus className="w-3.5 h-3.5" />}
                      <span>{metrics.trendLabel}</span>
                    </span>
                  </div>
                  <div className="text-xs font-semibold text-slate-500">
                    Theo biến động thực tế
                  </div>
                </div>
              </div>

              {/* Academic Warning Alert Banner (Exact Match to Image 2) */}
              {metrics.needsWarning ? (
                <div className="rounded-2xl bg-rose-50/90 border border-rose-200 p-4 flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                  <div className="space-y-1 text-xs sm:text-sm">
                    <div className="font-black text-rose-900">
                      Cảnh báo học tập: Học sinh có nguy cơ dưới mức đạt (&lt; 5.0)
                    </div>
                    <p className="text-rose-700 leading-relaxed">
                      Điểm trung bình hiện tại ({metrics.average}) hoặc có bài kiểm tra dưới{' '}
                      {metrics.lowest <= 4.0 ? metrics.lowest : '5.0'}. Cần lên kế hoạch phụ đạo và
                      giao các bài tập rèn luyện củng cố kiến thức cơ bản.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="rounded-2xl bg-emerald-50/80 border border-emerald-200 p-4 flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div className="space-y-0.5 text-xs sm:text-sm">
                    <div className="font-black text-emerald-950">
                      Đánh giá tiến độ: Học sinh duy trì phong độ học tập {metrics.rankLabel} (ĐTB:{' '}
                      {metrics.average})
                    </div>
                    <p className="text-emerald-800">
                      Hoàn thành tốt các đợt kiểm tra thường xuyên và bài tập về nhà theo tuần.
                    </p>
                  </div>
                </div>
              )}

              {/* Bottom 2-Column Grid: Left Score History + Right SVG Trend Chart */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
                {/* Left 6 Cols: LỊCH SỬ CÁC ĐỢT ĐÁNH GIÁ */}
                <div className="lg:col-span-6 rounded-2xl border border-slate-200 p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black uppercase tracking-wider text-slate-600">
                      LỊCH SỬ CÁC ĐỢT ĐÁNH GIÁ
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-semibold text-slate-400">
                        Hệ số 1, 2, 3
                      </span>
                      {userRole === 'teacher' && (
                        <button
                          onClick={() =>
                            isEditingScores ? handleSaveScores() : setIsEditingScores(true)
                          }
                          className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-extrabold text-xs flex items-center gap-1 cursor-pointer"
                        >
                          {isEditingScores ? (
                            <>
                              <Save className="w-3.5 h-3.5" />
                              <span>Lưu điểm</span>
                            </>
                          ) : (
                            <>
                              <Edit3 className="w-3.5 h-3.5" />
                              <span>Nhập điểm</span>
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  </div>

                  {/* TX1 - TX5 Grid */}
                  <div className="grid grid-cols-2 gap-2.5">
                    {(
                      [
                        { key: 'tx1', label: 'TX1', coeff: 'HS 1' },
                        { key: 'tx2', label: 'TX2', coeff: 'HS 1' },
                        { key: 'tx3', label: 'TX3', coeff: 'HS 1' },
                        { key: 'tx4', label: 'TX4', coeff: 'HS 1' },
                        { key: 'tx5', label: 'TX5', coeff: 'HS 1' },
                      ] as const
                    ).map((col) => {
                      const val = isEditingScores
                        ? draftScores[col.key]
                        : metrics.scores[col.key];
                      const isLow = val !== null && val < 5.0;

                      return (
                        <div
                          key={col.key}
                          className="px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between"
                        >
                          <span className="text-xs font-black text-slate-700">
                            {col.label}{' '}
                            <span className="font-normal text-slate-400">({col.coeff})</span>
                          </span>
                          {isEditingScores ? (
                            <input
                              type="number"
                              step="0.25"
                              min="0"
                              max="10"
                              value={val ?? ''}
                              onChange={(e) => handleScoreInputChange(col.key, e.target.value)}
                              placeholder="-"
                              className="w-16 px-2 py-0.5 text-right rounded border border-indigo-300 text-xs font-black"
                            />
                          ) : (
                            <span
                              className={`text-sm font-black ${
                                val === null
                                  ? 'text-slate-300'
                                  : isLow
                                  ? 'text-rose-600'
                                  : 'text-indigo-600'
                              }`}
                            >
                              {val !== null ? val : '-'}
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* ĐGGK (HS 2) & ĐGCK (HS 3) Full-Width Rows */}
                  <div className="space-y-2.5 pt-1">
                    <div className="px-4 py-2.5 rounded-xl bg-amber-50/70 border border-amber-200/90 flex items-center justify-between">
                      <span className="text-xs font-black text-amber-950">
                        ĐGGK <span className="font-normal text-amber-700">(HS 2)</span>
                      </span>
                      {isEditingScores ? (
                        <input
                          type="number"
                          step="0.25"
                          min="0"
                          max="10"
                          value={draftScores.dggk ?? ''}
                          onChange={(e) => handleScoreInputChange('dggk', e.target.value)}
                          placeholder="-"
                          className="w-16 px-2 py-0.5 text-right rounded border border-amber-400 text-xs font-black bg-white"
                        />
                      ) : (
                        <span className="text-sm font-black text-amber-900">
                          {metrics.scores.dggk !== null ? metrics.scores.dggk : '-'}
                        </span>
                      )}
                    </div>

                    <div className="px-4 py-2.5 rounded-xl bg-rose-50/70 border border-rose-200/90 flex items-center justify-between">
                      <span className="text-xs font-black text-rose-950">
                        ĐGCK <span className="font-normal text-rose-700">(HS 3)</span>
                      </span>
                      {isEditingScores ? (
                        <input
                          type="number"
                          step="0.25"
                          min="0"
                          max="10"
                          value={draftScores.dgck ?? ''}
                          onChange={(e) => handleScoreInputChange('dgck', e.target.value)}
                          placeholder="-"
                          className="w-16 px-2 py-0.5 text-right rounded border border-rose-400 text-xs font-black bg-white"
                        />
                      ) : (
                        <span className="text-sm font-black text-rose-900">
                          {metrics.scores.dgck !== null ? metrics.scores.dgck : '-'}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right 6 Cols: TIẾN TRÌNH THAY ĐỔI ĐIỂM THEO THỜI GIAN (SVG CHART) */}
                <div className="lg:col-span-6 rounded-2xl border border-slate-200 p-5 flex flex-col justify-between space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black uppercase tracking-wider text-slate-600">
                      TIẾN TRÌNH THAY ĐỔI ĐIỂM THEO THỜI GIAN
                    </span>
                    <span
                      className={`px-2.5 py-1 rounded-xl text-[11px] font-extrabold ${
                        metrics.trend === 'down'
                          ? 'bg-amber-50 text-amber-800 border border-amber-200'
                          : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      }`}
                    >
                      {metrics.trend === 'down'
                        ? 'Giảm điểm'
                        : metrics.trend === 'up'
                        ? 'Tăng điểm'
                        : 'Ổn định'}
                    </span>
                  </div>

                  {/* SVG Line & Area Chart */}
                  <div className="w-full pt-2">
                    <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-40 overflow-visible">
                      {/* Horizontal Reference Lines (8.0 and 5.0) */}
                      {[8, 5].map((refScore) => {
                        const yRef = padTop + ((10 - refScore) / 10) * plotH;
                        return (
                          <g key={refScore}>
                            <line
                              x1={padLeft}
                              y1={yRef}
                              x2={svgWidth - padRight}
                              y2={yRef}
                              stroke="#e2e8f0"
                              strokeDasharray="3 3"
                              strokeWidth="1"
                            />
                            <text
                              x={padLeft - 6}
                              y={yRef + 3}
                              textAnchor="end"
                              fontSize="8"
                              fill="#94a3b8"
                              fontWeight="bold"
                            >
                              {refScore}.0
                            </text>
                          </g>
                        );
                      })}

                      {/* Shaded Area under curve */}
                      {areaPoints && (
                        <polygon points={areaPoints} fill="rgba(245, 158, 11, 0.16)" />
                      )}

                      {/* Connecting Polyline */}
                      {plottedNodes.length >= 2 && (
                        <polyline
                          fill="none"
                          stroke="#d97706"
                          strokeWidth="2.5"
                          points={polylinePoints}
                        />
                      )}

                      {/* X-Axis Labels */}
                      {metrics.chartPoints.map((pt, idx) => {
                        const x = padLeft + (idx / 6) * plotW;
                        return (
                          <text
                            key={pt.key}
                            x={x}
                            y={svgHeight - 6}
                            textAnchor="middle"
                            fontSize="8.5"
                            fill="#94a3b8"
                            fontWeight="bold"
                          >
                            {pt.label}
                          </text>
                        );
                      })}

                      {/* Plotted Data Circles & Score Labels */}
                      {plottedNodes.map((node) => (
                        <g key={node.key}>
                          <circle
                            cx={node.x}
                            cy={node.y}
                            r="4"
                            fill="#ffffff"
                            stroke="#d97706"
                            strokeWidth="2.5"
                          />
                          <text
                            x={node.x}
                            y={node.y - 8}
                            textAnchor="middle"
                            fontSize="9"
                            fill="#b45309"
                            fontWeight="900"
                          >
                            {node.value}
                          </text>
                        </g>
                      ))}
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: RÈN LUYỆN & TUYÊN DƯƠNG (+10) & ẢNH TỰ LUẬN */}
          {activeTab === 'commendation' && (
            <div className="space-y-5">
              <div className="rounded-2xl bg-amber-50 border border-amber-200 p-4 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="text-xs font-extrabold uppercase text-amber-700">
                    ĐIỂM RÈN LUYỆN & TUYÊN DƯƠNG TÍCH LŨY
                  </div>
                  <div className="text-2xl font-black text-amber-950">
                    +{student.commendationPoints || 10} điểm thưởng chuyên cần
                  </div>
                </div>

                {userRole === 'teacher' && (
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() =>
                        handleAddCommendation(
                          `Hoàn thành đầy đủ BTVN Tuần ${activeWeek} đúng hạn`,
                          10
                        )
                      }
                      className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>+10 Chăm chỉ BTVN</span>
                    </button>
                    <button
                      onClick={() =>
                        handleAddCommendation(
                          `Đạt điểm cao trong Trò chơi & Luyện tập Tuần ${activeWeek}`,
                          10
                        )
                      }
                      className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>+10 Tích cực phát biểu</span>
                    </button>
                    <button
                      onClick={() =>
                        handleAddCommendation(
                          `Chưa hoàn thành đủ bài tập tự luận Tuần ${activeWeek}`,
                          -5
                        )
                      }
                      className="px-3 py-2 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-800 text-xs font-extrabold cursor-pointer"
                    >
                      -5 Nhắc nhở nộp muộn
                    </button>
                  </div>
                )}
              </div>

              {/* Commendation History */}
              <div className="space-y-2">
                <h4 className="text-xs font-black uppercase text-slate-500">
                  LỊCH SỬ TUYÊN DƯƠNG & NHẮC NHỞ THEO TUẦN
                </h4>
                {(student.commendationHistory || []).length === 0 ? (
                  <p className="text-xs text-slate-500 italic">
                    Chưa có ghi nhận tuyên dương riêng trong học kì này.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {(student.commendationHistory || []).map((rec) => (
                      <div
                        key={rec.id}
                        className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between gap-3"
                      >
                        <div>
                          <div className="text-xs sm:text-sm font-bold text-slate-900">
                            {rec.reason}
                          </div>
                          <div className="text-[11px] text-slate-500">
                            Tuần {rec.weekNumber} · Ngày {rec.createdAt}
                          </div>
                        </div>
                        <span
                          className={`px-2.5 py-1 rounded-lg text-xs font-black ${
                            rec.points > 0
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {rec.points > 0 ? `+${rec.points}` : rec.points} đ
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Submitted Essay Work & Attached Photos Preview */}
              <div className="space-y-3 pt-2 border-t border-slate-200">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h4 className="text-xs font-black uppercase text-slate-500 flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-teal-600" />
                    <span>BÀI LÀM TỰ LUẬN & ĐÓNG DẤU CHẤM BÀI TRỰC TIẾP</span>
                  </h4>
                  {userRole === 'teacher' && (
                    <div className="flex flex-wrap gap-1.5">
                      <button
                        type="button"
                        onClick={() =>
                          handleStampEssayFeedback(
                            `BTVN Tuần ${activeWeek}`,
                            '🌟 Đúng 100% - Trình bày sạch đẹp (+10đ)',
                            10
                          )
                        }
                        className="px-2.5 py-1 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-900 text-[11px] font-black cursor-pointer"
                      >
                        🌟 Đúng 100% (+10đ)
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          handleStampEssayFeedback(
                            `BTVN Tuần ${activeWeek}`,
                            '⚠️ Lưu ý ghi đầy đủ đơn vị đo (km/h, m/s, Hz, dB)',
                            5
                          )
                        }
                        className="px-2.5 py-1 rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-900 text-[11px] font-black cursor-pointer"
                      >
                        ⚠️ Thiếu đơn vị đo (+5đ)
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          handleStampEssayFeedback(
                            `BTVN Tuần ${activeWeek}`,
                            '🔍 Cần xem lại công thức & bước tóm tắt đề bài',
                            0
                          )
                        }
                        className="px-2.5 py-1 rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-900 text-[11px] font-black cursor-pointer"
                      >
                        🔍 Xem lại công thức
                      </button>
                    </div>
                  )}
                </div>

                {isCurrentActiveStudent && Object.keys(essaySubmissions).length > 0 ? (
                  <div className="space-y-3">
                    {Object.entries(essaySubmissions).map(([key, sub]) => {
                      const [lessonId, essayId] = key.split(':');
                      const lesson = ALL_KNTT_LESSONS.find((l) => l.id === lessonId);
                      const essay = lesson?.essays.find((e) => e.id === essayId);
                      return (
                        <div
                          key={key}
                          className="p-4 rounded-2xl border border-teal-200 bg-teal-50/40 space-y-2.5"
                        >
                          <div className="text-xs font-black text-teal-900">
                            {lesson?.title} — {essay?.question || essayId}
                          </div>
                          {sub.textAnswer && (
                            <p className="text-xs text-slate-700 bg-white p-2.5 rounded-xl border border-slate-200">
                              {sub.textAnswer}
                            </p>
                          )}
                          {sub.attachedImages && sub.attachedImages.length > 0 && (
                            <div className="flex flex-wrap gap-2">
                              {sub.attachedImages.map((img, i) => (
                                <img
                                  key={i}
                                  src={img}
                                  alt="Bài làm tự luận"
                                  className="h-24 w-auto rounded-xl border border-teal-300 object-cover"
                                />
                              ))}
                            </div>
                          )}
                          {userRole === 'teacher' && (
                            <div className="flex flex-wrap items-center gap-1.5 pt-1">
                              <span className="text-[11px] font-bold text-slate-500">
                                Đóng dấu nhanh bài này:
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  handleStampEssayFeedback(
                                    lesson?.title || lessonId,
                                    '🌟 Bài giải chính xác, trình bày khoa học (+10đ)',
                                    10
                                  )
                                }
                                className="px-2 py-0.5 rounded bg-emerald-600 text-white text-[11px] font-extrabold cursor-pointer"
                              >
                                🌟 Đúng 100% (+10đ)
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  handleStampEssayFeedback(
                                    lesson?.title || lessonId,
                                    '⚠️ Kết quả đúng nhưng thiếu đơn vị đo (+5đ)',
                                    5
                                  )
                                }
                                className="px-2 py-0.5 rounded bg-amber-500 text-slate-950 text-[11px] font-extrabold cursor-pointer"
                              >
                                ⚠️ Thiếu đơn vị
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  handleStampEssayFeedback(
                                    lesson?.title || lessonId,
                                    '🔍 Cần kiểm tra lại công thức vận dụng',
                                    0
                                  )
                                }
                                className="px-2 py-0.5 rounded bg-rose-600 text-white text-[11px] font-extrabold cursor-pointer"
                              >
                                🔍 Xem lại công thức
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-xs text-slate-500">
                    Học sinh đã hoàn thành <strong>{student.baselineEssayDone} bài tập tự luận</strong> trong các tuần trước. Giáo viên có thể bấm các nút đóng dấu nhanh phía trên để ghi nhận vào sổ nhận xét tuần.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: SỞ TRƯỜNG & GHI CHÚ RIÊNG */}
          {activeTab === 'strengths' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-extrabold uppercase text-slate-600 mb-2">
                  Mức độ tiếp thu kiến thức KHTN 7:
                </label>
                <div className="flex flex-wrap gap-2">
                  {(['Xuất sắc', 'Khá', 'Trung bình', 'Cần hỗ trợ'] as const).map((lvl) => (
                    <button
                      key={lvl}
                      type="button"
                      disabled={userRole !== 'teacher'}
                      onClick={() => setAbsorptionLevel(lvl)}
                      className={`px-4 py-2 rounded-xl text-xs font-extrabold border transition cursor-pointer ${
                        absorptionLevel === lvl
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-extrabold uppercase text-slate-600 mb-1.5">
                  Sở trường & Điểm mạnh môn KHTN 7:
                </label>
                <textarea
                  rows={3}
                  readOnly={userRole !== 'teacher'}
                  value={strengthsText}
                  onChange={(e) => setStrengthsText(e.target.value)}
                  className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs sm:text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-extrabold uppercase text-slate-600 mb-1.5">
                  Ghi chú riêng & Kế hoạch bồi dưỡng / phụ đạo:
                </label>
                <textarea
                  rows={3}
                  readOnly={userRole !== 'teacher'}
                  value={privateNoteText}
                  onChange={(e) => setPrivateNoteText(e.target.value)}
                  className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs sm:text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>

              {userRole === 'teacher' && (
                <div className="flex justify-end">
                  <button
                    onClick={handleSaveStrengthsAndNotes}
                    className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs sm:text-sm flex items-center gap-2 cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Lưu Sở trường & Ghi chú</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: NHẬN XÉT AI & GIÁO VIÊN THEO TUẦN + XUẤT PHIẾU BÁO KẾT QUẢ GỬI PHỤ HUYNH */}
          {activeTab === 'comments' && (
            <div className="space-y-5">
              {/* Parent Weekly Report Card (Copy Zalo / Download Word) */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-teal-50 via-emerald-50 to-cyan-50 border border-teal-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="text-xs font-black uppercase text-teal-900 flex items-center gap-1.5">
                    <span>📨 PHIẾU BÁO KẾT QUẢ HỌC TẬP TUẦN {activeWeek} GỬI PHỤ HUYNH</span>
                  </div>
                  <p className="text-xs text-slate-600">
                    Tổng hợp tự động Điểm TB ({metrics.average.toFixed(2)}), Xu hướng ({metrics.trendLabel}), Điểm rèn luyện (+{student.commendationPoints || 10}đ) và Nhận xét GV.
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={handleCopyParentReportZalo}
                    className="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-extrabold shadow-2xs cursor-pointer"
                  >
                    📋 Copy gửi Zalo Phụ huynh
                  </button>
                  <button
                    type="button"
                    onClick={handleDownloadParentReportDoc}
                    className="px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 text-teal-900 border border-teal-300 text-xs font-extrabold cursor-pointer"
                  >
                    🖨️ Tải Phiếu Báo (.doc)
                  </button>
                </div>
              </div>

              {userRole === 'teacher' && (
                <form
                  onSubmit={handleAddTeacherComment}
                  className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-200 space-y-3"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs font-black uppercase text-indigo-950">
                      VIẾT NHẬN XÉT TIẾN BỘ CHO HỌC SINH (TUẦN {activeWeek})
                    </span>
                    <button
                      type="button"
                      onClick={handleGenerateSmartComment}
                      className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold flex items-center gap-1.5 shadow-2xs cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Tạo nhận xét tự động từ Điểm & BTVN</span>
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {(
                      [
                        'Tiến bộ vượt bậc',
                        'Duy trì tốt',
                        'Cần cố gắng thêm',
                        'Cần phụ đạo sát',
                      ] as const
                    ).map((tag) => (
                      <button
                        key={tag}
                        type="button"
                        onClick={() => setNewCommentTrend(tag)}
                        className={`px-3 py-1 rounded-lg text-xs font-bold border cursor-pointer ${
                          newCommentTrend === tag
                            ? 'bg-indigo-900 text-white border-indigo-900'
                            : 'bg-white text-slate-700 border-slate-200'
                        }`}
                      >
                        {tag}
                      </button>
                    ))}
                  </div>

                  <textarea
                    rows={3}
                    value={newCommentText}
                    onChange={(e) => setNewCommentText(e.target.value)}
                    placeholder={`Nhập nhận xét của Giáo viên cho ${student.fullName} trong Tuần ${activeWeek}...`}
                    className="w-full p-3 rounded-xl bg-white border border-indigo-200 text-xs sm:text-sm focus:outline-none focus:border-indigo-500"
                  />

                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Gửi nhận xét Tuần {activeWeek}</span>
                    </button>
                  </div>
                </form>
              )}

              {/* Comment History List */}
              <div className="space-y-3">
                <h4 className="text-xs font-black uppercase text-slate-500">
                  LỊCH SỬ NHẬN XÉT CỦA GIÁO VIÊN & ĐÁNH GIÁ ĐỊNH KÌ
                </h4>

                {(student.teacherComments || []).length === 0 ? (
                  <div className="p-6 rounded-2xl border border-slate-200 text-center text-xs sm:text-sm text-slate-500">
                    Chưa có nhận xét riêng cho học sinh này. Giáo viên có thể bấm{' '}
                    <strong>"Tạo nhận xét tự động từ Điểm & BTVN"</strong> ở trên.
                  </div>
                ) : (
                  (student.teacherComments || []).map((cmt) => (
                    <div
                      key={cmt.id}
                      className="p-4 rounded-2xl border border-slate-200 bg-white shadow-2xs space-y-2"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-xs font-black">
                          Tuần {cmt.weekNumber} · {cmt.trendTag}
                        </span>
                        <span className="text-[11px] font-semibold text-slate-400">
                          Ngày {cmt.createdAt}
                        </span>
                      </div>
                      <p className="text-xs sm:text-sm text-slate-800 leading-relaxed">
                        {cmt.content}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* ================= MODAL FOOTER (MATCHING IMAGE 2) ================= */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>
            Mã học sinh: <strong className="text-slate-800">{student.code}</strong>
          </span>
          <button
            onClick={onClose}
            className="font-extrabold text-slate-700 hover:text-slate-950 cursor-pointer"
          >
            Đóng hồ sơ
          </button>
        </div>
      </div>
    </div>
  );
};
