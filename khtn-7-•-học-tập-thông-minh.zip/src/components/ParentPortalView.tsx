import React, { useState } from 'react';
import {
  Search,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Award,
  BookOpen,
  Calendar,
  MessageSquare,
  Send,
  UserCheck,
  BarChart3,
  RotateCcw,
  FileSpreadsheet,
  Sparkles,
} from 'lucide-react';
import {
  StudentProfile,
  WeeklyAssignment,
  calculateStudentGradeMetrics,
  findStudentByNameOrCode,
  suggestStudentsByPartialName,
} from '../data/classStore';
import { ALL_KNTT_LESSONS } from '../data/allLessons';
import { Khtn7BrandLogo } from './PWAInstallModal';

interface ParentPortalViewProps {
  students: StudentProfile[];
  verifiedChild: StudentProfile | null;
  activeWeek: number;
  weeklyAssignments: WeeklyAssignment[];
  onVerifyChild: (student: StudentProfile) => void;
  onClearVerifiedChild: () => void;
  onOpenDetailModal: (student: StudentProfile) => void;
  onOpenCertificate: (student: StudentProfile) => void;
}

interface ParentFeedbackNote {
  id: string;
  studentId: string;
  studentName: string;
  parentMessage: string;
  weekNumber: number;
  createdAt: string;
}

const PARENT_FEEDBACK_STORAGE_KEY = 'khtn7_parent_feedback_notes_v2';

function loadParentFeedback(): ParentFeedbackNote[] {
  try {
    const raw = localStorage.getItem(PARENT_FEEDBACK_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // ignore
  }
  return [];
}

export const ParentPortalView: React.FC<ParentPortalViewProps> = ({
  students,
  verifiedChild,
  activeWeek,
  weeklyAssignments,
  onVerifyChild,
  onClearVerifiedChild,
  onOpenDetailModal,
  onOpenCertificate,
}) => {
  const [childNameInput, setChildNameInput] = useState('');
  const [lookupError, setLookupError] = useState('');
  const [selectedSemesterTab, setSelectedSemesterTab] = useState<'hk1' | 'hk2'>(
    activeWeek <= 18 ? 'hk1' : 'hk2'
  );
  const [feedbackList, setFeedbackList] = useState<ParentFeedbackNote[]>(() =>
    loadParentFeedback()
  );
  const [parentNoteInput, setParentNoteInput] = useState('');
  const [noteSavedToast, setNoteSavedToast] = useState<string | null>(null);

  const handleLookupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = childNameInput.trim();
    if (!q) {
      setLookupError('Quý phụ huynh vui lòng nhập đầy đủ Họ và Tên của con trong danh sách lớp!');
      return;
    }

    const matched = findStudentByNameOrCode(students, q);

    if (!matched) {
      setLookupError(
        'Không tìm thấy tên học sinh khớp với danh sách lớp của giáo viên! Quý phụ huynh vui lòng kiểm tra lại đúng Họ và Tên đầy đủ của con.'
      );
      return;
    }

    setLookupError('');
    setChildNameInput('');
    onVerifyChild(matched);
  };

  const handleSendParentNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifiedChild || !parentNoteInput.trim()) return;
    const nowStr = new Date().toLocaleString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
    const newNote: ParentFeedbackNote = {
      id: `pf-${Date.now()}`,
      studentId: verifiedChild.id,
      studentName: verifiedChild.fullName,
      parentMessage: parentNoteInput.trim(),
      weekNumber: activeWeek,
      createdAt: nowStr,
    };
    const next = [newNote, ...feedbackList];
    setFeedbackList(next);
    try {
      localStorage.setItem(PARENT_FEEDBACK_STORAGE_KEY, JSON.stringify(next));
    } catch {
      // ignore
    }
    setParentNoteInput('');
    setNoteSavedToast('✅ Đã gửi xác nhận & ý kiến của Phụ huynh tới Giáo viên bộ môn!');
    setTimeout(() => setNoteSavedToast(null), 4000);
  };

  // If parent hasn't entered a valid student name yet, show the clean Lookup Card
  if (!verifiedChild) {
    return (
      <div className="max-w-2xl mx-auto my-6 bg-white rounded-3xl border border-slate-200/90 shadow-xl overflow-hidden">
        <div className="bg-gradient-to-r from-[#071936] via-[#0a2748] to-[#063d3f] px-6 py-5 sm:p-7 text-white flex items-center justify-between gap-4">
          <div>
            <div className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-300">
              CỔNG THÔNG TIN PHỤ HUYNH — KHOA HỌC TỰ NHIÊN 7 (KNTT)
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight mt-1">
              SỔ LIÊN LẠC & THEO DÕI HỌC TẬP
            </h2>
            <p className="text-xs sm:text-sm text-slate-200 mt-1">
              Phụ huynh nhập đúng Họ và Tên của con theo danh sách lớp để xem điểm số, biểu đồ tiến bộ và tình hình làm bài tập về nhà.
            </p>
          </div>
          <div className="p-1.5 rounded-2xl bg-white/10 border border-white/20 shrink-0">
            <Khtn7BrandLogo className="w-14 h-14 rounded-xl" />
          </div>
        </div>

        <div className="p-6 sm:p-8 space-y-5">
          <datalist id="parent-portal-students-datalist">
            {students.map((st) => (
              <option key={st.id} value={st.fullName}>
                {st.className} ({st.code})
              </option>
            ))}
          </datalist>
          <form onSubmit={handleLookupSubmit} className="space-y-4">
            <div>
              <label className="block text-xs sm:text-sm font-black uppercase tracking-wide text-slate-800 mb-2">
                HỌ VÀ TÊN CON (HỌC SINH TRONG LỚP)
              </label>
              <div className="relative">
                <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  list="parent-portal-students-datalist"
                  value={childNameInput}
                  onChange={(e) => {
                    setChildNameInput(e.target.value);
                    if (lookupError) setLookupError('');
                  }}
                  placeholder="Nhập đúng họ và tên của con (VD: VÕ THỊ THANH HÀ, LÊ PHAN BẢO CHÂU)..."
                  className="w-full pl-11 pr-4 py-3.5 rounded-2xl border-2 border-blue-400 text-sm sm:text-base font-semibold text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-500/15 transition"
                />
              </div>
              {(() => {
                const suggestions = suggestStudentsByPartialName(students, childNameInput, 5);
                if (suggestions.length === 0) return null;
                return (
                  <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] font-bold text-slate-500">
                      Chạm chọn tên con:
                    </span>
                    {suggestions.map((st) => (
                      <button
                        key={st.id}
                        type="button"
                        onClick={() => {
                          setLookupError('');
                          setChildNameInput('');
                          onVerifyChild(st);
                        }}
                        className="px-2.5 py-1 rounded-xl bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-900 text-xs font-extrabold transition cursor-pointer"
                      >
                        {st.fullName} ({st.className})
                      </button>
                    ))}
                  </div>
                );
              })()}
              <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                Hệ thống bảo mật thông tin học sinh: Phụ huynh chỉ xem được hồ sơ học tập khi nhập đúng họ và tên của con mình trong lớp học (hỗ trợ cả có dấu, không dấu và gợi ý nhanh).
              </p>
            </div>

            {lookupError && (
              <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs sm:text-sm font-bold flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
                <span>{lookupError}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-4 rounded-2xl bg-[#0d6efd] hover:bg-blue-700 text-white font-black text-sm sm:text-base shadow-lg shadow-blue-600/20 transition cursor-pointer"
            >
              Tra cứu Tình hình Học tập của Con →
            </button>
          </form>
        </div>
      </div>
    );
  }

  const metrics = calculateStudentGradeMetrics(verifiedChild);
  const accuracyPct =
    verifiedChild.baselineMcqDone > 0
      ? Math.round((verifiedChild.baselineMcqCorrect / verifiedChild.baselineMcqDone) * 100)
      : 0;
  const activeWeekAssign =
    weeklyAssignments.find((w) => w.weekNumber === activeWeek) || weeklyAssignments[0];
  const isCurrentWeekDone = verifiedChild.baselineWeeksCompleted.includes(activeWeek);

  const semesterWeeks = weeklyAssignments.filter((w) =>
    selectedSemesterTab === 'hk1' ? w.weekNumber <= 18 : w.weekNumber >= 19
  );

  const childParentNotes = feedbackList.filter((n) => n.studentId === verifiedChild.id);

  return (
    <div className="space-y-6">
      {/* ================= TOP PARENT HEADER CARD ================= */}
      <div className="bg-gradient-to-r from-[#071936] via-[#0a2748] to-[#063d3f] text-white rounded-3xl p-6 sm:p-7 shadow-lg border border-teal-800/60 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
        <div className="flex items-start sm:items-center gap-4">
          <div
            className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl ${
              verifiedChild.avatarColor || 'bg-emerald-600'
            } flex items-center justify-center text-xl sm:text-2xl font-black text-white shadow-md shrink-0 border-2 border-white/30`}
          >
            {verifiedChild.fullName
              .split(' ')
              .slice(-2)
              .map((w) => w[0])
              .join('')}
          </div>
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2 text-xs font-bold text-emerald-300">
              <span>👨‍👩‍👧 SỔ LIÊN LẠC PHỤ HUYNH</span>
              <span>·</span>
              <span>{verifiedChild.className}</span>
              <span>·</span>
              <span>Mã HS: {verifiedChild.code}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white">
              Học sinh: {verifiedChild.fullName}
            </h2>
            <p className="text-xs sm:text-sm text-slate-200">
              Mức độ tiếp thu:{' '}
              <strong className="text-amber-300">
                {verifiedChild.absorptionLevel || 'Khá'}
              </strong>{' '}
              · Đã hoàn thành{' '}
              <strong className="text-emerald-300">
                {verifiedChild.baselineWeeksCompleted.length}/35 tuần
              </strong>{' '}
              · Điểm tuyên dương:{' '}
              <strong className="text-amber-300">
                +{verifiedChild.commendationPoints || 10} điểm
              </strong>
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => onOpenDetailModal(verifiedChild)}
            className="px-4 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white border border-white/20 text-xs sm:text-sm font-extrabold flex items-center gap-1.5 transition cursor-pointer"
          >
            <BarChart3 className="w-4 h-4 text-emerald-300" />
            <span>Xem Biểu đồ Chi tiết</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenCertificate(verifiedChild)}
            className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs sm:text-sm font-black flex items-center gap-1.5 shadow transition cursor-pointer"
          >
            <Award className="w-4 h-4" />
            <span>Xem Giấy khen của Con</span>
          </button>

          <button
            type="button"
            onClick={onClearVerifiedChild}
            className="px-3.5 py-2.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-400/40 text-rose-200 text-xs sm:text-sm font-bold flex items-center gap-1.5 transition cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Tra cứu HS khác</span>
          </button>
        </div>
      </div>

      {/* ================= 4 KEY METRIC SUMMARY TILES ================= */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-xs">
          <span className="text-xs font-bold text-slate-500 block">
            ĐIỂM TRUNG BÌNH MÔN KHTN 7
          </span>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-indigo-600 tabular-nums">
              {metrics.average.toFixed(2)}
            </span>
            <span className="text-xs font-extrabold text-emerald-700">
              Học lực: {metrics.rankLabel}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Cao nhất: {metrics.highest}đ · Thấp nhất: {metrics.lowest}đ
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-xs">
          <span className="text-xs font-bold text-slate-500 block">
            XU HƯỚNG TIẾN BỘ HỌC TẬP
          </span>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className="text-xl sm:text-2xl font-black text-emerald-600">
              {metrics.trendLabel}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Đã có {metrics.filledCount}/{metrics.totalColumns} cột điểm chính thức
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-xs">
          <span className="text-xs font-bold text-slate-500 block">
            TỶ LỆ LÀM ĐÚNG BÀI TẬP
          </span>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-teal-600 tabular-nums">
              {accuracyPct}%
            </span>
            <span className="text-xs font-bold text-slate-600">
              ({verifiedChild.baselineMcqCorrect}/{verifiedChild.baselineMcqDone} câu TN)
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Đúng/Sai: {verifiedChild.baselineTfDone} bài · Tự luận: {verifiedChild.baselineEssayDone} bài
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-xs">
          <span className="text-xs font-bold text-slate-500 block">
            BÀI TẬP TUẦN HIỆN TẠI (TUẦN {activeWeek})
          </span>
          <div className="mt-1.5 flex items-center gap-2">
            {isCurrentWeekDone ? (
              <span className="text-base sm:text-lg font-black text-emerald-600 flex items-center gap-1.5">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>Đã hoàn thành đúng hạn</span>
              </span>
            ) : (
              <span className="text-base sm:text-lg font-black text-amber-600 flex items-center gap-1.5">
                <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
                <span>Đang làm (Hạn: {activeWeekAssign.dueDate})</span>
              </span>
            )}
          </div>
          <p className="text-[11px] text-slate-500 mt-1 truncate">
            {activeWeekAssign.title}
          </p>
        </div>
      </div>

      {/* ================= SCORE TABLE & TEACHER COMMENTS SPLIT ================= */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Left 7 Cols: Bảng điểm & Biểu đồ trực quan */}
        <div className="xl:col-span-7 bg-white rounded-3xl border border-slate-200/90 p-5 sm:p-6 shadow-xs space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-base sm:text-lg font-black text-slate-900">
                Bảng Điểm Kiểm Tra Thường Xuyên & Định Kì Môn KHTN 7
              </h3>
              <p className="text-xs text-slate-500">
                Cập nhật trực tiếp từ sổ điểm của Giáo viên bộ môn ({verifiedChild.className})
              </p>
            </div>
            <span className="text-xs font-extrabold text-indigo-700">
              ĐTB hiện tại: {metrics.average.toFixed(2)} ({metrics.rankLabel})
            </span>
          </div>

          {/* 7 Score Columns Grid */}
          <div className="grid grid-cols-4 sm:grid-cols-7 gap-2.5">
            {metrics.chartPoints.map((pt) => (
              <div
                key={pt.key}
                className={`rounded-2xl border p-3 text-center ${
                  pt.value !== null
                    ? 'bg-slate-50 border-slate-200'
                    : 'bg-slate-50/40 border-dashed border-slate-200 text-slate-400'
                }`}
              >
                <span className="text-[11px] font-black text-slate-500 block">
                  {pt.label} (HS{pt.coeff})
                </span>
                <span
                  className={`text-lg sm:text-xl font-black tabular-nums mt-1 block ${
                    pt.value === null
                      ? 'text-slate-300'
                      : pt.value >= 8
                      ? 'text-emerald-600'
                      : pt.value >= 6.5
                      ? 'text-blue-600'
                      : 'text-amber-600'
                  }`}
                >
                  {pt.value !== null ? pt.value : '—'}
                </span>
              </div>
            ))}
          </div>

          {/* Visual Bar Chart of Score Progression */}
          <div className="pt-2">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-3">
              <span className="font-bold text-slate-700">
                Biểu đồ trực quan tiến độ các cột điểm (Thang điểm 10)
              </span>
              <span>Điểm chuẩn: 8.0+ (Giỏi)</span>
            </div>
            <div className="h-40 bg-slate-50 rounded-2xl border border-slate-200/80 p-4 flex items-end justify-around gap-3">
              {metrics.chartPoints.map((pt) => {
                const heightPct = pt.value !== null ? Math.max(12, (pt.value / 10) * 100) : 8;
                return (
                  <div
                    key={pt.key}
                    className="flex-1 flex flex-col items-center justify-end h-full gap-1.5"
                  >
                    <span className="text-[11px] font-black text-slate-700 tabular-nums">
                      {pt.value !== null ? pt.value : ''}
                    </span>
                    <div className="w-full max-w-[38px] bg-slate-200/70 rounded-xl h-24 flex items-end overflow-hidden">
                      <div
                        style={{ height: `${heightPct}%` }}
                        className={`w-full rounded-xl transition-all ${
                          pt.value === null
                            ? 'bg-slate-300/50'
                            : pt.value >= 8
                            ? 'bg-gradient-to-t from-emerald-600 to-teal-400'
                            : pt.value >= 6.5
                            ? 'bg-gradient-to-t from-blue-600 to-cyan-400'
                            : 'bg-gradient-to-t from-amber-500 to-yellow-400'
                        }`}
                      />
                    </div>
                    <span className="text-[11px] font-bold text-slate-600">{pt.label}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Strengths & Teacher Evaluation Summary */}
          <div className="rounded-2xl bg-teal-50/70 border border-teal-200/80 p-4 space-y-1.5">
            <div className="text-xs font-black uppercase text-teal-900 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-teal-600" />
              <span>Đánh giá năng lực & Điểm mạnh môn KHTN 7 của con</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
              {verifiedChild.strengths ||
                'Học sinh có ý thức tự giác ôn luyện câu hỏi trắc nghiệm và hoàn thành bài tập về nhà theo tuần.'}
            </p>
          </div>
        </div>

        {/* Right 5 Cols: Nhận xét của Giáo viên & Phản hồi của Phụ huynh */}
        <div className="xl:col-span-5 bg-white rounded-3xl border border-slate-200/90 p-5 sm:p-6 shadow-xs flex flex-col justify-between space-y-5">
          <div className="space-y-4">
            <div>
              <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-indigo-600" />
                <span>Nhận xét của Giáo viên & Trao đổi Phụ huynh</span>
              </h3>
              <p className="text-xs text-slate-500">
                Nhận xét định kì theo tuần học và sổ liên lạc hai chiều giữa Phụ huynh – Giáo viên
              </p>
            </div>

            {/* Teacher Comments List */}
            <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
              {verifiedChild.teacherComments && verifiedChild.teacherComments.length > 0 ? (
                verifiedChild.teacherComments.map((c) => (
                  <div
                    key={c.id}
                    className="p-3.5 rounded-2xl bg-indigo-50/60 border border-indigo-200/80 space-y-1"
                  >
                    <div className="flex items-center justify-between text-[11px] font-extrabold text-indigo-900">
                      <span>👩‍🏫 Giáo viên nhận xét · Tuần {c.weekNumber}</span>
                      <span className="text-slate-500">{c.createdAt}</span>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-800 leading-relaxed">
                      {c.content}
                    </p>
                    <span className="inline-block text-[11px] font-bold text-teal-700">
                      Đánh giá: {c.trendTag}
                    </span>
                  </div>
                ))
              ) : (
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-600">
                  Giáo viên đã ghi nhận kết quả làm bài tập Tuần {activeWeek} của em{' '}
                  <strong>{verifiedChild.fullName}</strong>. Em đang duy trì tiến độ học tập ổn định.
                </div>
              )}

              {/* Parent Sent Feedback History */}
              {childParentNotes.map((note) => (
                <div
                  key={note.id}
                  className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-1"
                >
                  <div className="flex items-center justify-between text-[11px] font-extrabold text-emerald-900">
                    <span>👨‍👩‍👧 Phụ huynh phản hồi · Tuần {note.weekNumber}</span>
                    <span className="text-slate-500">{note.createdAt}</span>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-800">{note.parentMessage}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Parent Feedback Form */}
          <form
            onSubmit={handleSendParentNote}
            className="pt-3 border-t border-slate-200/80 space-y-2.5"
          >
            <label className="block text-xs font-black uppercase text-slate-700">
              Gửi lời nhắn / Xác nhận của Phụ huynh tới Giáo viên
            </label>
            <textarea
              rows={2}
              value={parentNoteInput}
              onChange={(e) => setParentNoteInput(e.target.value)}
              placeholder={`Ví dụ: Gia đình đã xem điểm và nhắc cháu ${verifiedChild.fullName} hoàn thành BTVN Tuần ${activeWeek}...`}
              className="w-full px-3.5 py-2.5 rounded-2xl border border-slate-300 text-xs sm:text-sm text-slate-900 focus:outline-none focus:border-blue-600"
            />
            {noteSavedToast && (
              <p className="text-xs font-extrabold text-emerald-700">{noteSavedToast}</p>
            )}
            <div className="flex flex-wrap items-center justify-between gap-2">
              <button
                type="button"
                onClick={() =>
                  setParentNoteInput(
                    `Phụ huynh em ${verifiedChild.fullName} đã xem kết quả học tập Tuần ${activeWeek} và nhắc nhở con ôn bài đầy đủ.`
                  )
                }
                className="text-[11px] font-bold text-indigo-600 hover:underline cursor-pointer"
              >
                + Điền nhanh mẫu xác nhận đã xem
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-[#0d6efd] hover:bg-blue-700 text-white text-xs font-black flex items-center gap-1.5 shadow-xs transition cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Gửi Giáo viên</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* ================= WEEKLY HOMEWORK TRACKER FOR PARENTS (TUẦN 1 - 35) ================= */}
      <div className="bg-white rounded-3xl border border-slate-200/90 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-teal-600" />
              <span>Bảng Theo Dõi Hoàn Thành Bài Tập Về Nhà 35 Tuần của Con</span>
            </h3>
            <p className="text-xs text-slate-500">
              Phụ huynh kiểm tra các tuần học con đã hoàn thành (màu xanh) và nhiệm vụ tuần hiện tại (Tuần {activeWeek})
            </p>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => setSelectedSemesterTab('hk1')}
              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition cursor-pointer ${
                selectedSemesterTab === 'hk1'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Học kì I (Tuần 1–18)
            </button>
            <button
              type="button"
              onClick={() => setSelectedSemesterTab('hk2')}
              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition cursor-pointer ${
                selectedSemesterTab === 'hk2'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Học kì II (Tuần 19–35)
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
          {semesterWeeks.map((w) => {
            const isCompleted = verifiedChild.baselineWeeksCompleted.includes(w.weekNumber);
            const isCurrent = w.weekNumber === activeWeek;
            const assignedLessons = ALL_KNTT_LESSONS.filter((l) =>
              w.lessonIds.includes(l.id)
            );

            return (
              <div
                key={w.weekNumber}
                className={`rounded-2xl border p-4 flex flex-col justify-between gap-2.5 transition ${
                  isCurrent
                    ? 'border-blue-500 bg-blue-50/30'
                    : isCompleted
                    ? 'border-emerald-200 bg-emerald-50/20'
                    : 'border-slate-200 bg-slate-50/50'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-black text-slate-800">
                      Tuần {w.weekNumber} ({w.semesterLabel || (w.weekNumber <= 18 ? 'HK1' : 'HK2')})
                      {isCurrent && (
                        <span className="ml-1.5 text-blue-600 font-extrabold">· Tuần hiện tại</span>
                      )}
                    </span>
                    {isCompleted ? (
                      <span className="text-[11px] font-extrabold text-emerald-700 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        Đã hoàn thành
                      </span>
                    ) : (
                      <span className="text-[11px] font-bold text-slate-500">
                        Hạn: {w.dueDate}
                      </span>
                    )}
                  </div>
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900 leading-snug">
                    {w.title}
                  </h4>
                  {assignedLessons.length > 0 && (
                    <p className="text-[11px] text-slate-500 line-clamp-1">
                      Bài học: {assignedLessons.map((l) => `Bài ${l.lessonNumber}`).join(', ')}
                    </p>
                  )}
                </div>

                <div className="pt-2 border-t border-slate-200/70 flex items-center justify-between text-[11px] text-slate-600">
                  <span>
                    Mục tiêu: {w.targetMcq} câu TN · {w.targetTf} Đ/S · {w.targetEssay} Tự luận
                  </span>
                  <span className="font-bold text-teal-700">{w.subjectLabel}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
