import React, { useState, useMemo } from 'react';
import {
  RotateCw,
  CheckCircle2,
  RefreshCw,
  ArrowLeft,
  ArrowRight,
  Sparkles,
  BookOpen,
  Lightbulb,
  Shuffle,
} from 'lucide-react';
import { ALL_KNTT_LESSONS } from '../data/allLessons';
import { KhtnLesson } from '../data/lessonTypes';
import { SubSubject } from '../data/khtn7Data';
import { soundEngine } from '../utils/gameSoundEngine';

interface FlashcardItem {
  id: string;
  category: 'Công thức & Trọng tâm' | 'Câu hỏi Cốt lõi' | 'Mệnh đề Đúng/Sai';
  frontText: string;
  backAnswer: string;
  backDetail: string;
}

interface FlashcardsViewProps {
  initialLessonId?: string;
  onStartLessonPractice?: (lessonId: string) => void;
}

export const FlashcardsView: React.FC<FlashcardsViewProps> = ({
  initialLessonId,
  onStartLessonPractice,
}) => {
  const [subjectFilter, setSubjectFilter] = useState<'all' | SubSubject>('all');
  const [selectedLessonId, setSelectedLessonId] = useState<string>(
    initialLessonId || ALL_KNTT_LESSONS[0].id
  );
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [knownIds, setKnownIds] = useState<Record<string, boolean>>(() => {
    try {
      const raw = localStorage.getItem('khtn7_flashcards_known_v1');
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  });
  const [reviewIds, setReviewIds] = useState<Record<string, boolean>>({});
  const [filterMode, setFilterMode] = useState<'all' | 'review_only'>('all');

  const currentLesson: KhtnLesson = useMemo(() => {
    return (
      ALL_KNTT_LESSONS.find((l) => l.id === selectedLessonId) || ALL_KNTT_LESSONS[0]
    );
  }, [selectedLessonId]);

  const filteredLessons = useMemo(() => {
    return ALL_KNTT_LESSONS.filter(
      (l) => subjectFilter === 'all' || l.subject === subjectFilter
    );
  }, [subjectFilter]);

  // Build 16 rich flashcards dynamically for the selected lesson
  const allCards: FlashcardItem[] = useMemo(() => {
    const list: FlashcardItem[] = [];

    // 1. From keyFormulas
    currentLesson.keyFormulas.forEach((formula, idx) => {
      list.push({
        id: `${currentLesson.id}:fc-form-${idx}`,
        category: 'Công thức & Trọng tâm',
        frontText: `Kiến thức trọng tâm #${idx + 1} của ${currentLesson.title} là gì?`,
        backAnswer: formula,
        backDetail: currentLesson.summary,
      });
    });

    // 2. From top MCQs
    currentLesson.mcqs.slice(0, 10).forEach((mcq, idx) => {
      list.push({
        id: `${currentLesson.id}:fc-mcq-${idx}`,
        category: 'Câu hỏi Cốt lõi',
        frontText: mcq.question,
        backAnswer: mcq.options[mcq.correctIndex],
        backDetail: mcq.explanation,
      });
    });

    // 3. From True/False statements
    currentLesson.trueFalseList.slice(0, 2).forEach((tf, tfIdx) => {
      tf.statements.slice(0, 2).forEach((st, stIdx) => {
        list.push({
          id: `${currentLesson.id}:fc-tf-${tfIdx}-${stIdx}`,
          category: 'Mệnh đề Đúng/Sai',
          frontText: `Đúng hay Sai: "${st.text}"?`,
          backAnswer: st.isTrue ? '✅ MỆNH ĐỀ ĐÚNG' : '❌ MỆNH ĐỀ SAI',
          backDetail: st.explanation,
        });
      });
    });

    return list;
  }, [currentLesson]);

  const activeDeck = useMemo(() => {
    if (filterMode === 'review_only') {
      const needReview = allCards.filter((c) => reviewIds[c.id] || !knownIds[c.id]);
      return needReview.length > 0 ? needReview : allCards;
    }
    return allCards;
  }, [allCards, filterMode, reviewIds, knownIds]);

  const safeIdx = Math.min(currentIndex, Math.max(0, activeDeck.length - 1));
  const currentCard = activeDeck[safeIdx] || allCards[0];

  const knownCountForLesson = allCards.filter((c) => knownIds[c.id]).length;

  const handleFlip = () => {
    soundEngine.playClick();
    setIsFlipped(!isFlipped);
  };

  const handleMarkKnown = () => {
    soundEngine.playCorrect();
    const nextKnown = { ...knownIds, [currentCard.id]: true };
    setKnownIds(nextKnown);
    try {
      localStorage.setItem('khtn7_flashcards_known_v1', JSON.stringify(nextKnown));
    } catch {
      // ignore
    }
    setReviewIds((prev) => {
      const copy = { ...prev };
      delete copy[currentCard.id];
      return copy;
    });
    setIsFlipped(false);
    if (safeIdx + 1 < activeDeck.length) {
      setCurrentIndex(safeIdx + 1);
    } else {
      setCurrentIndex(0);
    }
  };

  const handleMarkNeedReview = () => {
    soundEngine.playClick();
    setReviewIds((prev) => ({ ...prev, [currentCard.id]: true }));
    setKnownIds((prev) => {
      const copy = { ...prev };
      delete copy[currentCard.id];
      return copy;
    });
    setIsFlipped(false);
    if (safeIdx + 1 < activeDeck.length) {
      setCurrentIndex(safeIdx + 1);
    } else {
      setCurrentIndex(0);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Lesson Selector */}
      <div className="bg-gradient-to-r from-indigo-950 via-teal-900 to-emerald-950 text-white rounded-3xl p-5 sm:p-7 shadow-xl border border-teal-500/40 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 border border-amber-400/40 text-amber-300 text-xs font-extrabold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>THẺ GHI NHỚ FLASHCARD LẬT 2 MẶT (30 BÀI KHTN 7 KNTT)</span>
            </span>
            <h3 className="text-xl sm:text-2xl font-black">
              Học thuộc nhanh Công thức, Khái niệm & Mẹo giải bài theo từng Bài
            </h3>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <div className="px-4 py-2 rounded-xl bg-emerald-500/20 border border-emerald-400 text-emerald-200 text-xs sm:text-sm font-black">
              Đã thuộc lòng: {knownCountForLesson}/{allCards.length} thẻ (Bài{' '}
              {currentLesson.lessonNumber})
            </div>
            {onStartLessonPractice && (
              <button
                onClick={() => onStartLessonPractice(currentLesson.id)}
                className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm transition cursor-pointer"
              >
                Vào làm 30 câu bài này →
              </button>
            )}
          </div>
        </div>

        {/* Filter & Lesson Dropdown */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 pt-2 border-t border-white/15 items-center">
          <div className="lg:col-span-5 flex flex-wrap gap-1.5">
            {[
              { id: 'all' as const, label: 'Tất cả (30 bài)' },
              { id: 'chemistry' as const, label: '🧪 Hóa (6)' },
              { id: 'physics' as const, label: '⚡ Lí (14)' },
              { id: 'biology' as const, label: '🌿 Sinh (10)' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  setSubjectFilter(tab.id);
                  const list = ALL_KNTT_LESSONS.filter(
                    (l) => tab.id === 'all' || l.subject === tab.id
                  );
                  if (list.length > 0 && !list.some((l) => l.id === selectedLessonId)) {
                    setSelectedLessonId(list[0].id);
                    setCurrentIndex(0);
                    setIsFlipped(false);
                  }
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                  subjectFilter === tab.id
                    ? 'bg-amber-400 text-slate-950'
                    : 'bg-white/10 text-slate-200 hover:bg-white/20'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="lg:col-span-7">
            <select
              value={selectedLessonId}
              onChange={(e) => {
                setSelectedLessonId(e.target.value);
                setCurrentIndex(0);
                setIsFlipped(false);
              }}
              className="w-full px-4 py-2.5 rounded-xl bg-slate-950/90 text-white border border-teal-400/50 font-bold text-xs sm:text-sm focus:outline-none cursor-pointer"
            >
              {filteredLessons.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.title} ({l.chapterTitle})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Flashcard Stage */}
      <div className="max-w-3xl mx-auto space-y-5">
        {/* Top Deck Controls */}
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-extrabold text-slate-600">
          <div className="flex items-center gap-2">
            <span>
              Thẻ số <strong className="text-slate-900">{safeIdx + 1}</strong> / {activeDeck.length}
            </span>
            <span className="px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
              {currentCard.category}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setFilterMode(filterMode === 'all' ? 'review_only' : 'all');
                setCurrentIndex(0);
                setIsFlipped(false);
              }}
              className={`px-3 py-1.5 rounded-xl border transition cursor-pointer ${
                filterMode === 'review_only'
                  ? 'bg-rose-600 text-white border-rose-600'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
            >
              {filterMode === 'review_only'
                ? 'Đang lọc: Thẻ chưa thuộc'
                : 'Lọc thẻ chưa thuộc'}
            </button>
          </div>
        </div>

        {/* 2-Sided Interactive Flip Card */}
        <div
          onClick={handleFlip}
          className={`min-h-[300px] sm:min-h-[340px] rounded-3xl p-6 sm:p-10 shadow-xl border-2 transition-all duration-300 flex flex-col justify-between cursor-pointer select-none ${
            !isFlipped
              ? 'bg-white border-indigo-200 hover:border-indigo-400 text-slate-900'
              : 'bg-gradient-to-br from-[#081e26] via-[#0d3542] to-[#062925] border-emerald-400 text-white'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-extrabold">
            <span
              className={`px-3 py-1 rounded-full ${
                !isFlipped
                  ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                  : 'bg-emerald-400/20 text-emerald-300 border border-emerald-400/40'
              }`}
            >
              {!isFlipped ? 'MẶT TRƯỚC: CÂU HỎI / KHÁI NIỆM' : 'MẶT SAU: ĐÁP ÁN & GIẢI THÍCH'}
            </span>

            <span className="flex items-center gap-1 opacity-75">
              <RotateCw className="w-3.5 h-3.5" />
              <span>Bấm vào thẻ để lật</span>
            </span>
          </div>

          {!isFlipped ? (
            <div className="my-auto py-8 text-center space-y-3">
              <h4 className="text-lg sm:text-2xl font-black leading-relaxed text-slate-900">
                {currentCard.frontText}
              </h4>
              <p className="text-xs font-bold text-indigo-600">
                (Hãy tự nhẩm câu trả lời rồi bấm vào thẻ để kiểm tra đáp án)
              </p>
            </div>
          ) : (
            <div className="my-auto py-6 space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-500/20 border border-emerald-400/50 text-center">
                <div className="text-[11px] font-black uppercase text-emerald-300 mb-1">
                  ĐÁP ÁN CHUẨN XÁC:
                </div>
                <div className="text-lg sm:text-2xl font-black text-amber-300">
                  {currentCard.backAnswer}
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white/10 border border-white/15 flex items-start gap-2.5 text-xs sm:text-sm text-slate-200">
                <Lightbulb className="w-5 h-5 text-amber-300 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white">Giải thích & Mẹo nhớ nhanh:</strong>{' '}
                  {currentCard.backDetail}
                </div>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between text-xs font-bold opacity-75 pt-2 border-t border-current/10">
            <span>{currentLesson.title}</span>
            <span>{knownIds[currentCard.id] ? '✅ Đã thuộc' : '⏳ Đang học'}</span>
          </div>
        </div>

        {/* Bottom Action Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button
            onClick={() => {
              soundEngine.playClick();
              setIsFlipped(false);
              setCurrentIndex((prev) => (prev - 1 + activeDeck.length) % activeDeck.length);
            }}
            className="py-3 px-4 rounded-2xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Thẻ trước</span>
          </button>

          <button
            onClick={handleMarkNeedReview}
            className="py-3 px-4 rounded-2xl bg-amber-100 hover:bg-amber-200 border border-amber-300 text-amber-900 font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Cần ôn lại</span>
          </button>

          <button
            onClick={handleMarkKnown}
            className="py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-md transition cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Đã thuộc lòng!</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playClick();
              setIsFlipped(false);
              setCurrentIndex((prev) => (prev + 1) % activeDeck.length);
            }}
            className="py-3 px-4 rounded-2xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <span>Thẻ tiếp</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
