import { KhtnLesson, McqItem } from './lessonTypes';

const makeMcqs = (
  prefix: string,
  raw: Array<[string, [string, string, string, string], number, string]>
): McqItem[] =>
  raw.map(([question, options, correctIndex, explanation], idx) => ({
    id: `${prefix}-mcq-${idx + 1}`,
    question,
    options,
    correctIndex,
    explanation,
    level: idx < 12 ? 'Nhận biết' : idx < 22 ? 'Thông hiểu' : 'Vận dụng',
  }));

export const PHYSICS_LESSONS_PART_2: KhtnLesson[] = [
  // =========================================================================
  // BÀI 15: NĂNG LƯỢNG ÁNH SÁNG. TIA SÁNG, VÙNG TỐI (Tài liệu Chủ đề Ánh sáng)
  // =========================================================================
  {
    id: 'kntt-bai-15',
    lessonNumber: 15,
    title: 'Bài 15: Năng lượng ánh sáng. Tia sáng, vùng tối',
    chapterTitle: 'Chương V: Ánh sáng',
    subject: 'physics',
    pdfUrl: '/assets/aistudio/_C_p_nh_t_m_i__Ch______nh_s_ng_ac14e419.pdf',
    summary:
      'Ánh sáng là một dạng của năng lượng. Trong môi trường trong suốt và đồng tính, ánh sáng truyền đi theo đường thẳng. Đường truyền của ánh sáng được biểu diễn bằng một đường thẳng có mũi tên chỉ hướng gọi là tia sáng. Phía sau vật cản sáng được chiếu sáng có vùng tối (bóng tối) và vùng nửa tối (bóng nửa tối).',
    keyFormulas: [
      'Định luật truyền thẳng ánh sáng: Trong môi trường trong suốt và đồng tính, ánh sáng truyền theo đường thẳng',
      '3 loại chùm sáng: Chùm sáng song song (không giao nhau); Chùm sáng hội tụ (giao nhau); Chùm sáng phân kì (loe rộng ra)',
      'Nhật thực: Mặt Trời – Mặt Trăng – Trái Đất thẳng hàng (Mặt Trăng ở giữa)  |  Nguyệt thực: Mặt Trời – Trái Đất – Mặt Trăng thẳng hàng (Trái Đất ở giữa)',
    ],
    mcqs: makeMcqs('b15', [
      ['Vì sao mắt ta nhìn thấy được một vật?', ['Vì ta mở mắt hướng về phía vật.', 'Vì mắt ta phát ra các tia sáng chiếu lên vật.', 'Vì có ánh sáng từ vật đó truyền vào mắt ta.', 'Vì vật đó có kích thước lớn.'], 2, 'Ta nhìn thấy một vật khi có ánh sáng từ vật đó truyền vào mắt ta.'],
      ['Vật nào sau đây KHÔNG phải là nguồn sáng?', ['Mặt Trời.', 'Núi lửa đang phun trào.', 'Bóng đèn điện đang sáng.', 'Mặt Trăng.'], 3, 'Mặt Trăng không tự phát ra ánh sáng mà chỉ hắt lại ánh sáng từ Mặt Trời chiếu vào nó.'],
      ['Ta không nhìn thấy được một vật đặt trước mặt là vì:', ['vật đó không tự phát ra ánh sáng.', 'ánh sáng từ vật đó bị vật cản che khuất không truyền đến mắt ta được.', 'vật đó không phải là mặt gương.', 'vật đó ở quá gần.'], 1, 'Khi không có ánh sáng từ vật truyền tới mắt (do không được chiếu sáng hoặc bị che khuất) thì ta không thấy vật.'],
      ['Vật nào dưới đây KHÔNG phải là vật sáng?', ['Ngọn nến đang cháy.', 'Mảnh giấy trắng đặt dưới ánh nắng Mặt Trời.', 'Mảnh giấy đen đặt dưới ánh nắng Mặt Trời.', 'Mặt Trời.'], 2, 'Vật màu đen không tự phát sáng và cũng không hắt lại ánh sáng chiếu vào nó nên không phải là vật sáng.'],
      ['Trường hợp nào dưới đây ta không nhận biết được miếng bìa màu đen?', ['Dán miếng bìa đen lên tờ giấy xanh đặt dưới ánh đèn điện.', 'Dán miếng bìa đen lên tờ giấy trắng rồi đặt trong phòng tối hoàn toàn.', 'Đặt miếng bìa đen trước ngọn nến đang cháy.', 'Đặt miếng bìa đen ngoài trời nắng.'], 1, 'Trong phòng tối hoàn toàn, cả tờ giấy trắng cũng không hắt lại ánh sáng nên không thể phân biệt được miếng bìa đen.'],
      ['Ta nhìn thấy quyển sách màu đỏ dưới ánh đèn trắng là vì:', ['bản thân quyển sách là nguồn sáng đỏ.', 'có ánh sáng màu đỏ từ quyển sách hắt lại truyền đến mắt ta.', 'mắt ta phát ra tia sáng đỏ.', 'quyển sách tự phát nhiệt.'], 1, 'Quyển sách màu đỏ hắt lại ánh sáng đỏ truyền vào mắt ta.'],
      ['Ban ngày trời nắng, dùng một gương phẳng hứng ánh nắng Mặt Trời rồi chiếu qua cửa sổ vào phòng. Gương đó có phải là nguồn sáng không?', ['Là nguồn sáng vì có ánh sáng từ gương chiếu vào phòng.', 'Là nguồn sáng vì gương sáng chói.', 'Không phải nguồn sáng vì gương không tự phát ra ánh sáng (gương chỉ là vật được chiếu sáng).', 'Là nguồn sáng nhân tạo.'], 2, 'Gương không tự phát ra ánh sáng mà chỉ phản xạ ánh sáng Mặt Trời nên là vật được chiếu sáng (vật sáng), không phải nguồn sáng.'],
      ['Chiếu một chùm ánh sáng hẹp vào một tấm gỗ phẳng chắn sáng. Hiện tượng nào xảy ra?', ['Ánh sáng truyền xuyên qua tấm gỗ.', 'Ánh sáng đi vòng qua tấm gỗ theo đường cong.', 'Ánh sáng đi vòng theo đường gấp khúc.', 'Ánh sáng bị chặn lại, không truyền qua được tấm gỗ.'], 3, 'Gỗ là vật cản sáng (không trong suốt) nên ánh sáng không truyền qua được.'],
      ['Điền từ thích hợp vào chỗ trống: “Chùm sáng ……… gồm các tia sáng ……… trên đường truyền của chúng”.', ['phân kì; giao nhau.', 'hội tụ; loe rộng ra.', 'phân kì; loe rộng ra.', 'song song; giao nhau.'], 2, 'Chùm sáng phân kì gồm các tia sáng loe rộng ra trên đường truyền.'],
      ['Chọn phát biểu KHÔNG đúng về đường truyền của tia sáng:', ['Trong môi trường trong suốt nhưng không đồng tính, ánh sáng không truyền theo đường thẳng.', 'Trong môi trường trong suốt và đồng tính, ánh sáng truyền đi theo đường thẳng.', 'Trong môi trường đồng tính nhưng không trong suốt, ánh sáng không truyền qua được.', 'Trong mọi môi trường bất kì, ánh sáng luôn luôn truyền theo đường thẳng.'], 3, 'Ánh sáng chỉ truyền theo đường thẳng khi môi trường vừa trong suốt vừa đồng tính.'],
      ['Người ta quy ước biểu diễn đường truyền của ánh sáng bằng:', ['một đường cong bất kì.', 'một đường thẳng có mũi tên chỉ hướng truyền gọi là tia sáng.', 'một đường đứt nét không có mũi tên.', 'hai đường thẳng cắt nhau.'], 1, 'Tia sáng được biểu diễn bằng một đường thẳng có mũi tên chỉ hướng truyền của ánh sáng.'],
      ['Đứng trên Trái Đất, trường hợp nào dưới đây ta quan sát thấy hiện tượng nguyệt thực?', ['Ban đêm, khi Mặt Trăng không nhận được ánh sáng vì bị Trái Đất che khuất.', 'Ban ngày, khi Mặt Trăng che khuất Mặt Trời.', 'Khi Mặt Trời nằm giữa Trái Đất và Mặt Trăng.', 'Vào ngày mùng 1 đầu tháng âm lịch.'], 0, 'Nguyệt thực xảy ra vào đêm rằm khi Trái Đất nằm giữa Mặt Trời và Mặt Trăng, che khuất ánh sáng Mặt Trời chiếu tới Mặt Trăng.'],
      ['Tại sao trong phòng học, người ta lắp nhiều bóng đèn ống dài ở các vị trí khác nhau mà không dùng duy nhất một bóng đèn nhỏ công suất lớn?', ['Chỉ để trang trí cho lớp học đẹp hơn.', 'Để tránh tạo ra bóng tối và bóng nửa tối khi học sinh cúi đầu viết bài.', 'Để giảm điện năng tiêu thụ.', 'Vì bóng đèn nhỏ không sáng.'], 1, 'Lắp nhiều đèn ở các hướng khác nhau giúp ánh sáng chiếu tới vở từ nhiều phía, xóa bỏ bóng tối của bàn tay khi viết bài.'],
      ['Khi chiếu ánh sáng tới một vật cản sáng, yếu tố quyết định việc xuất hiện vùng bóng nửa tối phía sau vật cản là:', ['nguồn sáng có kích thước lớn (nguồn sáng rộng).', 'nguồn sáng rất nhỏ (nguồn sáng điểm).', 'vật cản sáng trong suốt.', 'màn chắn đặt sát nguồn sáng.'], 0, 'Nguồn sáng nhỏ chỉ tạo bóng tối; nguồn sáng lớn (rộng) tạo cả bóng tối và bóng nửa tối.'],
      ['Khi có hiện tượng nhật thực xảy ra, vị trí tương đối của ba thiên thể theo thứ tự trên cùng một đường thẳng là:', ['Trái Đất – Mặt Trời – Mặt Trăng.', 'Mặt Trời – Trái Đất – Mặt Trăng.', 'Trái Đất – Mặt Trăng – Mặt Trời (Mặt Trăng nằm ở giữa).', 'Không nằm trên cùng đường thẳng.'], 2, 'Nhật thực xảy ra vào ban ngày khi Mặt Trăng nằm giữa Mặt Trời và Trái Đất, che khuất ánh sáng Mặt Trời chiếu xuống một vùng trên Trái Đất.'],
      ['Bóng tối (vùng tối) phía sau vật cản sáng là:', ['vùng hoàn toàn không nhận được ánh sáng từ nguồn sáng truyền tới.', 'vùng chỉ nhận được một phần ánh sáng từ nguồn sáng truyền tới.', 'vùng nhận được đầy đủ ánh sáng từ nguồn sáng.', 'vùng nằm trước vật cản sáng.'], 0, 'Bóng tối là vùng phía sau vật cản hoàn toàn không nhận được ánh sáng từ nguồn sáng.'],
      ['Bóng nửa tối (vùng nửa tối) phía sau vật cản sáng là:', ['vùng hoàn toàn không nhận được ánh sáng từ nguồn sáng.', 'vùng chỉ nhận được ánh sáng từ một phần của nguồn sáng truyền tới.', 'vùng được chiếu sáng đầy đủ.', 'vùng nằm bên trong nguồn sáng.'], 1, 'Bóng nửa tối là vùng phía sau vật cản chỉ nhận được một phần ánh sáng từ nguồn sáng rộng.'],
      ['Vật sáng bao gồm những vật nào?', ['Chỉ những vật tự phát ra ánh sáng.', 'Chỉ những vật được chiếu sáng.', 'Bao gồm cả nguồn sáng và những vật hắt lại ánh sáng chiếu vào nó.', 'Bao gồm cả các vật màu đen trong bóng tối.'], 2, 'Vật sáng gồm nguồn sáng và các vật hắt lại ánh sáng chiếu vào nó.'],
      ['Hãy chỉ ra vật nào dưới đây KHÔNG phải là nguồn sáng?', ['Ngọn nến đang cháy.', 'Vỏ chai thủy tinh sáng chói dưới trời nắng.', 'Mặt Trời.', 'Đèn ống đang bật sáng.'], 1, 'Vỏ chai sáng chói là do phản xạ ánh nắng Mặt Trời, bản thân vỏ chai không tự phát ra ánh sáng.'],
      ['Chùm sáng do dây tóc bóng đèn pin (khi không có gương cầu phản xạ hoặc tháo chóa đèn) phát ra có tính chất nào?', ['Chùm sáng song song.', 'Chùm sáng phân kì (tỏa ra mọi hướng).', 'Chùm sáng hội tụ.', 'Chỉ gồm 1 tia sáng duy nhất.'], 1, 'Từ dây tóc đèn phát sáng, các tia sáng truyền tỏa ra mọi hướng tạo thành chùm sáng phân kì.'],
      ['Trong trường hợp nào dưới đây, ánh sáng truyền đi theo đường thẳng?', ['Trong môi trường trong suốt nhưng mật độ thay đổi liên tục.', 'Khi truyền từ không khí sang nước theo phương xiên góc.', 'Trong môi trường đồng tính nhưng chắn sáng.', 'Trong môi trường vừa trong suốt vừa đồng tính.'], 3, 'Theo định luật truyền thẳng ánh sáng: môi trường phải vừa trong suốt vừa đồng tính.'],
      ['Chùm sáng song song gồm các tia sáng:', ['giao nhau tại một điểm trên đường truyền.', 'không giao nhau trên đường truyền của chúng.', 'loe rộng ra khi càng xa nguồn.', 'đi theo đường tròn.'], 1, 'Chùm sáng song song gồm các tia sáng không giao nhau trên đường truyền.'],
      ['Khi cầm một kính lúp hứng dưới ánh nắng Mặt Trời để đốt cháy đầu que diêm, chùm tia sáng sau khi đi qua kính lúp tới đầu que diêm là:', ['chùm sáng song song.', 'chùm sáng phân kì.', 'chùm sáng hội tụ (tập trung năng lượng ánh sáng tại một điểm).', 'vùng bóng tối.'], 2, 'Kính lúp hội tụ chùm sáng Mặt Trời vào một điểm tại đầu que diêm làm nhiệt độ tăng cao gây cháy.'],
      ['Thí nghiệm dùng kính lúp tập trung ánh nắng Mặt Trời làm bốc cháy que diêm chứng tỏ điều gì?', ['Ánh sáng có mang năng lượng (quang năng chuyển hóa thành nhiệt năng).', 'Ánh sáng có khối lượng lớn.', 'Kính lúp là nguồn sáng.', 'Que diêm tự phát sáng.'], 0, 'Que diêm nóng lên và bốc cháy chứng tỏ ánh sáng mang năng lượng.'],
      ['Ban đêm trong phòng có một bóng đèn điện lớn (nguồn sáng rộng). Giơ bàn tay chắn giữa bóng đèn và bức tường trắng, trên tường sẽ xuất hiện:', ['chỉ một vùng bóng tối sắc nét.', 'vùng sáng hoàn toàn.', 'một vùng tối hình bàn tay ở giữa, xung quanh có viền mờ hơn (bóng nửa tối).', 'không có bóng trên tường.'], 2, 'Vì bóng đèn là nguồn sáng rộng nên tạo ra vùng bóng tối ở giữa và viền bóng nửa tối xung quanh.'],
      ['Tại một địa phương trên Trái Đất, người ta quan sát thấy hiện tượng nhật thực toàn phần khi địa phương đó:', ['nằm trong vùng bóng nửa tối của Mặt Trăng.', 'nằm trong vùng bóng tối của Mặt Trăng và bị Mặt Trăng che khuất hoàn toàn Mặt Trời.', 'nằm ở nửa Trái Đất đang là ban đêm.', 'nằm trong vùng bóng tối của Trái Đất.'], 1, 'Đứng ở vùng bóng tối của Mặt Trăng trên Trái Đất sẽ không nhìn thấy Mặt Trời (nhật thực toàn phần).'],
      ['Một cái cọc cắm thẳng đứng trên mặt đất cao h = 0,5 m. Khi chùm tia nắng Mặt Trời chiếu xiên hợp với mặt đất một góc 45° thì bóng của cái cọc trên mặt đất dài bao nhiêu?', ['0,25 m.', '0,50 m.', '1,00 m.', '0,75 m.'], 1, 'Tam giác tạo bởi cọc thẳng đứng (góc vuông 90°) và tia nắng hợp góc 45° với mặt đất là tam giác vuông cân ⇒ chiều dài bóng = chiều cao cọc = 0,5 m.'],
      ['Cùng một lúc dưới trời nắng, bóng của một cái cọc thẳng đứng cao 1 m có độ dài là 0,8 m, còn bóng của một cột điện gần đó dài 5 m. Chiều cao của cột điện là:', ['4,0 m.', '6,25 m.', '5,8 m.', '8,0 m.'], 1, 'Theo tỉ lệ đồng dạng: H / 1 = 5 / 0,8 = 6,25 ⇒ Chiều cao cột điện H = 6,25 m.'],
      ['Vì sao vào những ngày hè nắng gắt lúc gần trưa, nhìn mặt đường nhựa từ xa ta thấy có chỗ loang loáng như có vũng nước (ảo ảnh)?', ['Vì mặt đường nhựa chảy thành nước.', 'Vì lớp không khí sát mặt đường nhựa rất nóng nên không khí không còn đồng tính, làm tia sáng bị uốn cong.', 'Vì mắt người phát ra tia sáng.', 'Vì có mưa rơi trên đường.'], 1, 'Không khí gần mặt đường nóng hơn lớp trên nên môi trường không đồng tính, ánh sáng không truyền thẳng mà bị uốn cong tạo ảo ảnh.'],
      ['Vận tốc truyền ánh sáng trong không khí và chân không xấp xỉ 300 000 km/s. Biết khoảng cách từ Mặt Trời đến Trái Đất khoảng 150 000 000 km. Thời gian ánh sáng truyền từ Mặt Trời đến Trái Đất là:', ['5 s.', '50 s.', '500 s (khoảng 8 phút 20 giây).', '5000 s.'], 2, 't = s / v = 150 000 000 / 300 000 = 500 giây.'],
    ]),
    trueFalseList: [
      {
        id: 'b15-tf-1',
        stem: 'Xét khái niệm năng lượng ánh sáng, nguồn sáng và vật sáng:',
        statements: [
          { id: 'a', text: 'Ánh sáng là một dạng của năng lượng (ví dụ ánh sáng Mặt Trời giúp cây quang hợp, làm nóng vật và chạy pin mặt trời).', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Nguồn sáng là những vật tự nó phát ra ánh sáng (ví dụ: Mặt Trời, ngọn nến đang cháy, con đom đóm).', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Mặt Trăng và các hành tinh như Sao Hỏa, Sao Kim đều là các nguồn sáng tự nhiên.', isTrue: false, explanation: 'Sai, Mặt Trăng và các hành tinh không tự phát sáng mà chỉ hắt lại ánh sáng Mặt Trời nên là vật được chiếu sáng.' },
          { id: 'd', text: 'Vật sáng bao gồm nguồn sáng và những vật hắt lại ánh sáng chiếu vào nó.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b15-tf-2',
        stem: 'Xét sự truyền ánh sáng, tia sáng và các loại chùm sáng:',
        statements: [
          { id: 'a', text: 'Trong môi trường trong suốt và đồng tính (như không khí đồng nhất, nước tinh khiết, thủy tinh), ánh sáng truyền đi theo đường thẳng.', isTrue: true, explanation: 'Đúng nội dung định luật truyền thẳng ánh sáng.' },
          { id: 'b', text: 'Trong thực tế, ta có thể dễ dàng tách riêng và nhìn thấy một tia sáng đơn lẻ bằng mắt thường.', isTrue: false, explanation: 'Sai, tia sáng chỉ là đường quy ước hình học; trong thực tế ta chỉ nhìn thấy chùm sáng gồm rất nhiều tia sáng hợp thành.' },
          { id: 'c', text: 'Chùm sáng hội tụ gồm các tia sáng tiến lại gần nhau và cắt nhau tại một điểm trên đường truyền.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Mỗi tia sáng trong chùm sáng hội tụ sau khi đi qua điểm giao nhau sẽ tiếp tục truyền thẳng nên chùm sáng sau điểm hội tụ trở thành chùm sáng phân kì.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b15-tf-3',
        stem: 'Xét sự hình thành bóng tối và bóng nửa tối phía sau vật cản sáng:',
        statements: [
          { id: 'a', text: 'Khi chiếu sáng vật cản bằng một nguồn sáng rất nhỏ (nguồn sáng điểm), trên màn chắn phía sau vật cản chỉ xuất hiện bóng tối rõ nét.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Khi chiếu sáng vật cản bằng một nguồn sáng rộng (lớn), phía sau vật cản xuất hiện cả vùng bóng tối ở giữa và vùng bóng nửa tối bao quanh.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Bóng nửa tối là vùng hoàn toàn không nhận được bất kì tia sáng nào từ nguồn sáng.', isTrue: false, explanation: 'Sai, bóng nửa tối là vùng nhận được ánh sáng từ một phần của nguồn sáng rộng.' },
          { id: 'd', text: 'Trong phòng mổ bệnh viện, đèn mổ được thiết kế gồm rất nhiều bóng đèn nhỏ ghép trên một chao đèn lớn để triệt tiêu bóng tối của bàn tay bác sĩ.', isTrue: true, explanation: 'Đúng ứng dụng thực tế.' },
        ],
      },
      {
        id: 'b15-tf-4',
        stem: 'Xét hiện tượng Nhật thực và Nguyệt thực trong tự nhiên:',
        statements: [
          { id: 'a', text: 'Cả hiện tượng nhật thực và nguyệt thực đều được giải thích dựa trên định luật truyền thẳng của ánh sáng.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Nhật thực xảy ra vào ban ngày khi Mặt Trăng nằm giữa Mặt Trời và Trái Đất, làm bóng của Mặt Trăng đổ xuống Trái Đất.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Những người đứng ở vùng bóng nửa tối của Mặt Trăng trên Trái Đất sẽ quan sát thấy nhật thực toàn phần.', isTrue: false, explanation: 'Sai, đứng ở vùng bóng nửa tối chỉ quan sát thấy nhật thực một phần; phải đứng ở vùng bóng tối mới thấy nhật thực toàn phần.' },
          { id: 'd', text: 'Nguyệt thực xảy ra vào đêm rằm (trăng tròn) khi Trái Đất nằm giữa Mặt Trời và Mặt Trăng, làm Mặt Trăng đi vào vùng bóng tối của Trái Đất.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b15-tf-5',
        stem: 'Vào một ngày trời nắng, cùng một thời điểm người ta đo được bóng của một cái cọc thẳng đứng (cao 1 m) trên sân dài 0,8 m và bóng của một cột cờ bên cạnh dài 6,4 m:',
        statements: [
          { id: 'a', text: 'Bóng của cái cọc và cột cờ trên mặt sân chính là vùng tối do cọc và cột cờ chắn chùm tia nắng Mặt Trời.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Các tia nắng Mặt Trời chiếu xuống cùng một nơi tại cùng thời điểm được coi là chùm tia sáng song song.', isTrue: true, explanation: 'Đúng vì Mặt Trời ở rất xa Trái Đất.' },
          { id: 'c', text: 'Độ dài bóng của cột cờ gấp 8 lần độ dài bóng của cái cọc (6,4 / 0,8 = 8 lần).', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Chiều cao của cột cờ là 6,4 m.', isTrue: false, explanation: 'Sai, chiều cao của cột cờ phải gấp 8 lần chiều cao cái cọc: H = 8 × 1 m = 8,0 m.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b15-es-1',
        question: 'Câu 1 [Tài liệu Chủ đề Ánh sáng]:\n(a) Giải thích vì sao trong phòng có cửa gỗ đóng kín, ban đêm không bật đèn, ta không nhìn thấy mảnh giấy trắng đặt trên bàn?\n(b) Tại sao khi bật đèn trong phòng, mặc dù ta đứng quay lưng lại với bóng đèn (không nhìn trực tiếp bóng đèn) nhưng ta vẫn nhìn thấy rõ các đồ vật ở trước mặt?',
        hint: 'Vận dụng điều kiện nhìn thấy một vật: phải có ánh sáng từ vật đó truyền vào mắt.',
        sampleAnswer: '(a) Vì mảnh giấy trắng không phải là nguồn sáng mà chỉ là vật hắt lại ánh sáng. Trong phòng tối đóng kín không bật đèn, không có ánh sáng chiếu lên mảnh giấy ⇒ không có ánh sáng từ mảnh giấy truyền vào mắt ta nên ta không nhìn thấy mảnh giấy.\n(b) Khi bật đèn, ánh sáng từ bóng đèn truyền tới chiếu sáng các đồ vật ở trước mặt ta. Các đồ vật này hắt lại ánh sáng truyền vào mắt ta nên dù quay lưng với bóng đèn ta vẫn nhìn thấy các vật trước mặt.',
        rubricPoints: [
          'Giải thích đúng mảnh giấy trắng không có ánh sáng chiếu vào nên không có ánh sáng truyền tới mắt.',
          'Giải thích đúng các vật trước mặt hắt lại ánh sáng từ đèn vào mắt ta.',
        ],
      },
      {
        id: 'b15-es-2',
        question: 'Câu 2 [Tài liệu Chủ đề Ánh sáng]: Nếu ta thắp một nén hương để cho khói bay lên ở phía trước chiếc đèn pin đang bật sáng trong phòng tối, ta sẽ nhìn thấy rõ một vệt sáng thẳng từ đèn phát ra xuyên qua làn khói. Hãy giải thích vì sao? (Biết rằng khói gồm các hạt nhỏ li ti bay lơ lửng).',
        hint: 'Mỗi hạt khói nhỏ li ti khi được đèn chiếu sáng sẽ trở thành gì?',
        sampleAnswer: '- Khói gồm vô số các hạt bụi nhỏ li ti bay lơ lửng trong không khí.\n- Khi chùm sáng từ đèn pin truyền thẳng qua làn khói, các hạt khói nằm trên đường truyền của chùm sáng được chiếu sáng và hắt lại ánh sáng vào mắt ta (trở thành các vật sáng nhỏ li ti).\n- Các hạt khói sáng này nằm sát nhau dọc theo đường truyền thẳng của ánh sáng nên tạo thành một vệt sáng rõ nét mà mắt ta nhìn thấy được.',
        rubricPoints: [
          'Nêu được các hạt khói nhỏ li ti được chiếu sáng trở thành các vật sáng.',
          'Giải thích các hạt khói xếp nối tiếp nhau tạo thành vệt sáng thẳng truyền tới mắt.',
        ],
      },
      {
        id: 'b15-es-3',
        question: 'Câu 3 [Tài liệu Chủ đề Ánh sáng]: Làm thế nào để người thợ mộc hoặc người trồng cây có thể đóng được 3 cái cọc thẳng hàng trên mặt đất mà không cần dùng thước dây để gióng hàng? Giải thích cơ sở vật lí của cách làm đó.',
        hint: 'Ứng dụng định luật truyền thẳng của ánh sáng trong không khí.',
        sampleAnswer: '- Cách làm:\n+ Bước 1: Đóng cọc thứ nhất (A) và cọc thứ hai (B) thẳng đứng tại hai vị trí cần thiết.\n+ Bước 2: Đứng ở phía cọc A, nhắm một mắt lại, mắt kia ngắm nhìn về phía cọc A và cọc B rồi điều chỉnh vị trí cọc thứ ba (C) sao cho cọc A che khuất hoàn toàn cả cọc B và cọc C.\n- Cơ sở vật lí: Trong không khí (môi trường trong suốt và đồng tính), ánh sáng truyền đi theo đường thẳng. Khi cọc thứ nhất che khuất hoàn toàn hai cọc kia, ánh sáng từ cọc 2 và cọc 3 không truyền qua cọc 1 tới mắt được, chứng tỏ mắt và cả 3 cọc cùng nằm trên một đường thẳng.',
        rubricPoints: [
          'Trình bày đúng cách ngắm bằng một mắt sao cho cọc đầu che khuất hai cọc sau.',
          'Giải thích đúng dựa trên định luật truyền thẳng của ánh sáng.',
        ],
      },
      {
        id: 'b15-es-4',
        question: 'Câu 4 [Tài liệu Chủ đề Ánh sáng]: Vào một ngày trời nắng, cùng một lúc người ta quan sát thấy bóng của một cái cọc thẳng đứng và bóng của một cột điện trên mặt đất phẳng có độ dài lần lượt là 0,8 m và 5,0 m. Biết cái cọc cao 1,0 m. Hãy tính chiều cao của cột điện.',
        hint: 'Chùm tia nắng Mặt Trời là chùm sáng song song tạo thành hai tam giác vuông đồng dạng.',
        sampleAnswer: '- Gọi chiều cao của cột điện là H (m), chiều dài bóng cột điện là L = 5,0 m.\n- Chiều cao của cọc là h = 1,0 m, chiều dài bóng cọc là l = 0,8 m.\n- Vì cùng một thời điểm, các tia sáng Mặt Trời chiếu xuống hợp với mặt đất cùng một góc nên tỉ số giữa chiều cao vật và chiều dài bóng là không đổi:\nH / h = L / l ⇒ H / 1,0 = 5,0 / 0,8 = 6,25 ⇒ H = 6,25 m.\nVậy cột điện cao 6,25 m.',
        rubricPoints: [
          'Lập đúng tỉ lệ H / h = L / l = 5,0 / 0,8 = 6,25.',
          'Tính đúng chiều cao cột điện H = 6,25 m.',
        ],
      },
      {
        id: 'b15-es-5',
        question: 'Câu 5 [Tài liệu Chủ đề Ánh sáng]: Một cái cọc cắm thẳng đứng trên mặt đất cao AB = 0,5 m. Khi chùm tia sáng Mặt Trời chiếu xuống mặt đất hợp với mặt đất nằm ngang một góc 45° thì bóng BC của cái cọc trên mặt đất dài bao nhiêu mét? Giải thích.',
        hint: 'Xét tam giác vuông ABC vuông tại B có một góc nhọn bằng 45°.',
        sampleAnswer: '- Cọc AB cắm thẳng đứng trên mặt đất nằm ngang BC nên góc ABC = 90° (tam giác ABC vuông tại B).\n- Tia sáng Mặt Trời AC hợp với mặt đất BC một góc ACB = 45°.\n- Trong tam giác vuông ABC có góc C = 45° nên góc A cũng bằng 90° - 45° = 45° ⇒ Tam giác ABC là tam giác vuông cân tại B.\n- Do đó chiều dài bóng trên mặt đất bằng chiều cao của cọc: BC = AB = 0,5 m.',
        rubricPoints: [
          'Chứng minh được tam giác ABC vuông cân tại B.',
          'Kết luận đúng chiều dài bóng BC = 0,5 m.',
        ],
      },
      {
        id: 'b15-es-6',
        question: 'Câu 6 [Tài liệu Chủ đề Ánh sáng]: Khi cùng quan sát trên bầu trời đêm và thấy Mặt Trăng có hình lưỡi liềm, bạn A nói đó là hiện tượng nguyệt thực một phần, nhưng bạn B khẳng định đó không phải là nguyệt thực mà chỉ là trăng lưỡi liềm đầu tháng hoặc cuối tháng. Bạn B đã dựa vào căn cứ khoa học nào để khẳng định như vậy?',
        hint: 'Nguyệt thực chỉ có thể xảy ra vào ngày nào trong tháng âm lịch?',
        sampleAnswer: '- Bạn B đã căn cứ vào ngày âm lịch trong tháng và vị trí của Mặt Trăng:\n+ Hiện tượng nguyệt thực chỉ xảy ra khi Mặt Trời – Trái Đất – Mặt Trăng nằm thẳng hàng (Trái Đất ở giữa). Vị trí này chỉ xảy ra vào những đêm RẰM (giữa tháng âm lịch, khi Mặt Trăng đang tròn vành vạnh rồi bị bóng Trái Đất che khuất dần trong vài giờ).\n+ Còn vào các đêm đầu tháng hoặc cuối tháng âm lịch, Mặt Trăng có hình lưỡi liềm suốt cả đêm là do góc chiếu sáng tự nhiên của Mặt Trời lên Mặt Trăng khi nhìn từ Trái Đất, hoàn toàn không phải do Trái Đất che khuất.',
        rubricPoints: [
          'Nêu đúng nguyệt thực chỉ xảy ra vào đêm rằm (trăng tròn) và diễn ra trong vài giờ.',
          'Giải thích đúng trăng lưỡi liềm đầu/cuối tháng là pha tự nhiên của Mặt Trăng.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 16: SỰ PHẢN XẠ ÁNH SÁNG (Tài liệu Chủ đề Ánh sáng - Bài 13)
  // =========================================================================
  {
    id: 'kntt-bai-16',
    lessonNumber: 16,
    title: 'Bài 16: Sự phản xạ ánh sáng',
    chapterTitle: 'Chương V: Ánh sáng',
    subject: 'physics',
    pdfUrl: '/assets/aistudio/_C_p_nh_t_m_i__Ch______nh_s_ng_ac14e419.pdf',
    summary:
      'Khi ánh sáng truyền tới bề mặt nhẵn bóng (gương phẳng, mặt nước yên lặng) thì bị hắt trở lại theo hướng xác định gọi là phản xạ ánh sáng (phản xạ gương). Định luật phản xạ ánh sáng: Tia phản xạ nằm trong mặt phẳng tới và góc phản xạ luôn bằng góc tới (i′ = i).',
    keyFormulas: [
      'Định luật phản xạ ánh sáng:  Góc phản xạ bằng góc tới (i′ = i)',
      'Góc tới i = góc hợp bởi tia tới SI và pháp tuyến IN (IN vuông góc với mặt gương tại I)',
      'Nếu tia tới hợp với mặt gương góc α thì:  i = i′ = 90° - α  |  Góc hợp bởi tia tới và tia phản xạ:  góc SIR = i + i′ = 2·i',
    ],
    mcqs: makeMcqs('b16', [
      ['Theo định luật phản xạ ánh sáng, phát biểu nào sau đây là ĐÚNG?', ['Góc phản xạ luôn bằng góc tới (i′ = i).', 'Pháp tuyến tại điểm tới là đường phân giác của góc tạo bởi tia tới và tia phản xạ.', 'Tia phản xạ và tia tới nằm trong cùng một mặt phẳng tới và ở hai bên pháp tuyến.', 'Cả A, B, C đều đúng.'], 3, 'Cả 3 phát biểu đều mô tả chính xác định luật phản xạ ánh sáng.'],
      ['Mối quan hệ giữa góc tới (i) và góc phản xạ (i′) khi tia sáng gặp gương phẳng là:', ['Góc phản xạ lớn hơn góc tới.', 'Góc phản xạ nhỏ hơn góc tới.', 'Góc phản xạ bằng góc tới (i′ = i).', 'Góc phản xạ bằng một nửa góc tới.'], 2, 'Theo định luật phản xạ ánh sáng: i′ = i.'],
      ['Góc phản xạ (i′) là góc hợp bởi:', ['tia phản xạ và mặt gương.', 'tia phản xạ và đường pháp tuyến của gương tại điểm tới.', 'tia tới và pháp tuyến.', 'tia tới và tia phản xạ.'], 1, 'Góc phản xạ i′ là góc hợp bởi tia phản xạ IR và pháp tuyến IN tại điểm tới I.'],
      ['Góc tới (i) là góc hợp bởi:', ['tia phản xạ và mặt gương.', 'tia phản xạ và pháp tuyến.', 'tia tới và đường pháp tuyến của gương tại điểm tới.', 'tia tới và mặt gương.'], 2, 'Góc tới i là góc hợp bởi tia tới SI và pháp tuyến IN tại điểm tới I.'],
      ['Chiếu một tia sáng lên một gương phẳng, ta thu được một tia phản xạ tạo với tia tới một góc 40° (i + i′ = 40°). Giá trị của góc tới i là:', ['20°.', '80°.', '40°.', '50°.'], 0, 'Ta có i + i′ = 40° và i = i′ ⇒ i = 40° / 2 = 20°.'],
      ['Chiếu một tia sáng tới mặt gương phẳng với góc tới i = 45° thì góc hợp bởi tia phản xạ và mặt gương là:', ['45°.', '90°.', '30°.', '60°.'], 0, 'Góc phản xạ i′ = i = 45° ⇒ Góc hợp bởi tia phản xạ và mặt gương là 90° - 45° = 45°.'],
      ['Một tia sáng chiếu tới gương phẳng và hợp với mặt gương một góc 30°. Góc hợp bởi tia tới và tia phản xạ (i + i′) là:', ['30°.', '60°.', '90°.', '120°.'], 3, 'Góc tới i = 90° - 30° = 60° ⇒ Góc phản xạ i′ = 60° ⇒ Góc giữa tia tới và tia phản xạ = 60° + 60° = 120°.'],
      ['Trong các vật sau đây, bề mặt vật nào có thể coi là một gương phẳng (cho phản xạ gương)?', ['Mặt phẳng của tờ giấy trắng.', 'Mặt nước đang gợn sóng.', 'Mặt phẳng của một tấm kim loại được đánh nhẵn bóng.', 'Mặt đất sân trường.'], 2, 'Tấm kim loại phẳng nhẵn bóng phản xạ ánh sáng theo một hướng xác định giống gương phẳng.'],
      ['Hiện tượng phản xạ ánh sáng là:', ['hiện tượng tia sáng truyền xuyên qua gương.', 'hiện tượng tia sáng đi là là trên mặt nước.', 'hiện tượng khi chiếu một tia sáng vào gương bị gương hắt trở lại môi trường cũ.', 'hiện tượng tia sáng bị gãy khúc khi đi vào nước.'], 2, 'Phản xạ ánh sáng là hiện tượng ánh sáng bị hắt trở lại môi trường cũ khi gặp bề mặt nhẵn bóng.'],
      ['Đường pháp tuyến tại điểm tới I trên gương phẳng là:', ['đường thẳng trùng với mặt gương.', 'đường thẳng vuông góc với mặt phẳng gương tại điểm tới I.', 'đường thẳng tạo với mặt gương góc 45°.', 'đường phân giác của góc giữa tia tới và mặt gương.'], 1, 'Pháp tuyến của gương tại điểm tới I là đường thẳng vuông góc với mặt gương tại I.'],
      ['Mặt phẳng tới là mặt phẳng được tạo bởi:', ['tia tới và mặt gương.', 'tia tới và đường pháp tuyến của gương tại điểm tới I.', 'pháp tuyến và mặt gương.', 'hai cạnh của chiếc gương.'], 1, 'Mặt phẳng chứa tia tới SI và pháp tuyến IN tại điểm tới I gọi là mặt phẳng tới.'],
      ['Khi chiếu một tia sáng SI vuông góc với mặt gương phẳng thì góc tới i và góc phản xạ i′ có giá trị là:', ['i = 90°, i′ = 90°.', 'i = 0°, i′ = 0° (tia phản xạ truyền ngược lại chính đường tia tới).', 'i = 45°, i′ = 45°.', 'i = 0°, i′ = 90°.'], 1, 'Khi tia tới vuông góc với mặt gương thì tia tới trùng với pháp tuyến IN ⇒ góc tới i = 0° và góc phản xạ i′ = 0°.'],
      ['Vật nào sau đây KHÔNG thể dùng để soi ảnh của mình như một gương phẳng?', ['Tấm kim loại phẳng bóng.', 'Màn hình điện thoại phẳng bóng khi đang tắt.', 'Mặt hồ nước yên tĩnh, phẳng lặng.', 'Sàn nhà lát gạch nhám hoặc sàn gỗ sần sùi.'], 3, 'Sàn gỗ sần sùi gây phản xạ khuếch tán nên không tạo được ảnh rõ nét như gương phẳng.'],
      ['Khi chiếu một chùm tia tới song song vào một bề mặt nhám, gồ ghề (như tờ giấy, tấm vải len, mặt nước gợn sóng), các tia phản xạ sẽ:', ['vẫn song song với nhau.', 'bị phản xạ theo nhiều hướng khác nhau (gọi là phản xạ khuếch tán).', 'hội tụ tại một điểm duy nhất.', 'biến mất hoàn toàn.'], 1, 'Trên bề mặt không nhẵn bóng, các tia sáng song song bị hắt lại theo mọi hướng gọi là phản xạ khuếch tán.'],
      ['Vì sao при phản xạ khuếch tán trên tờ giấy trắng hay bức tường vôi, ta không nhìn thấy ảnh của mình trên đó?', ['Vì tờ giấy hấp thụ hết ánh sáng.', 'Vì các tia sáng song song chiếu tới bị phản xạ theo mọi hướng khác nhau, không tạo thành ảnh rõ nét.', 'Vì tờ giấy là nguồn sáng.', 'Vì ánh sáng truyền xuyên qua tường.'], 1, 'Phản xạ khuếch tán làm các tia phản xạ tán loạn theo nhiều hướng nên không tạo ra ảnh của vật.'],
      ['Vì sao khi mặt hồ nước phẳng lặng ta thấy bóng (ảnh) của hàng cây trên bờ rất rõ, nhưng khi có gió thổi làm mặt nước gợn sóng thì ảnh hàng cây bị nhòe đi?', ['Vì gió làm cây chuyển động.', 'Vì khi mặt nước phẳng lặng xảy ra phản xạ gương, còn khi gợn sóng xảy ra phản xạ khuếch tán.', 'Vì nước hồ bị đục khi có gió.', 'Vì ánh sáng không chiếu tới mặt hồ nữa.'], 1, 'Mặt nước phẳng lặng đóng vai trò như gương phẳng (phản xạ gương); mặt nước gợn sóng gây phản xạ khuếch tán.'],
      ['Chiếu một chùm sáng song song vào một gương phẳng. Chùm sáng phản xạ thu được là:', ['chùm sáng song song.', 'chùm sáng phân kì.', 'chùm sáng hội tụ.', 'không có chùm phản xạ.'], 0, 'Phản xạ trên gương phẳng bảo toàn tính song song của chùm sáng.'],
      ['Trong thí nghiệm đo góc tới và góc phản xạ bằng bảng chia độ, nếu lần lượt chiếu tia tới với các góc tới i₁ = 60°, i₂ = 45°, i₃ = 30° thì các góc phản xạ tương ứng là:', ['30°, 45°, 60°.', '60°, 45°, 30°.', '120°, 90°, 60°.', '30°, 30°, 30°.'], 1, 'Theo định luật phản xạ ánh sáng i′ = i nên các góc phản xạ lần lượt là 60°, 45°, 30°.'],
      ['Một tia sáng SI chiếu tới gương phẳng hợp với tia phản xạ IR một góc 120°. Giá trị của góc tới i là:', ['120°.', '60°.', '30°.', '45°.'], 1, 'Ta có i + i′ = 120° và i′ = i ⇒ 2i = 120° ⇒ i = 60°.'],
      ['Nếu tia tới hợp với mặt phẳng gương một góc α (với 0° < α < 90°) thì góc phản xạ i′ có giá trị là:', ['90° - α.', 'α.', '90° + α.', '180° - α.'], 0, 'Góc tới i = 90° - α ⇒ Góc phản xạ i′ = i = 90° - α.'],
      ['Chiếu tia sáng SI tới mặt gương phẳng sao cho góc hợp bởi tia tới và mặt gương là 25°. Góc tới i và góc phản xạ i′ bằng:', ['25°.', '65°.', '50°.', '130°.'], 1, 'i = i′ = 90° - 25° = 65°.'],
      ['Một tia sáng SI truyền theo phương hợp với mặt phẳng nằm ngang một góc 50° hướng xuống. Phải đặt gương phẳng hợp với mặt ngang một góc bao nhiêu để tia phản xạ có phương nằm ngang (cùng phía)?', ['25° (hoặc 65° tùy chiều phản xạ).', '50°.', '90°.', '10°.'], 0, 'Khi góc giữa SI và IR là 50° thì i = i′ = 25°, góc hợp bởi gương và phương ngang là 90° - 25° = 65° (hoặc 25° nếu phản xạ theo chiều ngược lại).'],
      ['Tia sáng Mặt Trời chiếu xiên hợp với mặt ngang một góc 36° đến gặp gương phẳng cho tia phản xạ có phương thẳng đứng hướng thẳng xuống đáy giếng. Góc giữa tia tới và tia phản xạ là:', ['126° (với i = i′ = 63°).', '36°.', '90°.', '54°.'], 0, 'Tia tới hợp phương ngang 36°, tia phản xạ thẳng đứng (hợp phương ngang 90°) ⇒ Góc SIR = 36° + 90° = 126° ⇒ i = i′ = 63°, mặt gương hợp phương thẳng đứng góc 90° - 63° = 27°.'],
      ['Ban đầu chiếu một tia sáng SI tới gương phẳng với góc tới i = 50°. Giữ nguyên tia tới, nếu xoay gương một góc 10° sao cho góc tới tăng lên thì góc phản xạ mới là:', ['40°.', '50°.', '60°.', '70°.'], 2, 'Khi xoay gương 10° thì pháp tuyến cũng quay 10° làm góc tới mới là i_mới = 50° + 10° = 60° ⇒ góc phản xạ mới i′_mới = 60°.'],
      ['Giả sử vận tốc ánh sáng truyền trong vũ trụ là 300 000 km/s, khoảng cách từ Mặt Trời đến Sao Hỏa khoảng 225 000 000 km. Thời gian ánh sáng truyền từ Mặt Trời đến Sao Hỏa là:', ['75 s.', '750 s (12 phút 30 giây).', '1500 s.', '500 s.'], 1, 't = s / v = 225 000 000 / 300 000 = 750 giây.'],
      ['Khi biết trước vị trí của một tia tới SI và tia phản xạ IR tại điểm tới I, ta xác định vị trí đặt gương phẳng bằng cách nào?', ['Đặt gương trùng với tia tới SI.', 'Đặt gương trùng với tia phản xạ IR.', 'Vẽ đường phân giác IN của góc SIR làm pháp tuyến, rồi đặt mặt gương vuông góc với IN tại I.', 'Đặt gương song song với phân giác IN.'], 2, 'Pháp tuyến IN là phân giác của góc SIR, mặt gương luôn vuông góc với pháp tuyến IN tại điểm tới I.'],
      ['Nếu chiếu một tia sáng SI trùng sát với mặt phẳng gương (góc hợp với mặt gương bằng 0°, góc tới i = 90°) thì:', ['tia sáng truyền thẳng tiếp tục dọc theo mặt gương.', 'tia sáng phản xạ vuông góc lên trên.', 'tia sáng bị gương hấp thụ hoàn toàn.', 'góc phản xạ bằng 0°.'], 0, 'Khi α = 0° (i = 90°), tia sáng đi sượt dọc theo mặt gương và truyền thẳng.'],
      ['Góc hợp bởi tia tới và mặt gương phẳng bằng một nửa góc tới (α = i / 2). Giá trị của góc tới i là:', ['30°.', '45°.', '60°.', '90°.'], 2, 'Ta có α + i = 90° và α = 0,5·i ⇒ 1,5·i = 90° ⇒ i = 60° (và α = 30°).'],
      ['Khi góc tới tăng thêm 15° thì góc hợp bởi tia tới và tia phản xạ sẽ:', ['tăng thêm 15°.', 'tăng thêm 30°.', 'giảm đi 15°.', 'không thay đổi.'], 1, 'Vì góc hợp bởi tia tới và tia phản xạ bằng 2·i nên khi i tăng 15° thì góc SIR tăng thêm 2 × 15° = 30°.'],
      ['Nhờ hiện tượng phản xạ khuếch tán của ánh sáng trên các đồ vật xung quanh mà:', ['ta chỉ nhìn thấy vật khi đặt mắt đúng một vị trí duy nhất.', 'ta có thể nhìn thấy các đồ vật trong phòng từ mọi hướng khác nhau.', 'mọi đồ vật đều biến thành gương soi.', 'trong phòng hoàn toàn tối đen.'], 1, 'Nhờ phản xạ khuếch tán, ánh sáng từ đồ vật hắt ra theo mọi hướng giúp mắt ta đặt ở vị trí nào trong phòng cũng nhìn thấy vật.'],
    ]),
    trueFalseList: [
      {
        id: 'b16-tf-1',
        stem: 'Xét nội dung của Định luật phản xạ ánh sáng:',
        statements: [
          { id: 'a', text: 'Tia phản xạ nằm trong mặt phẳng chứa tia tới và pháp tuyến của gương ở điểm tới.', isTrue: true, explanation: 'Đúng ý thứ nhất của định luật phản xạ ánh sáng.' },
          { id: 'b', text: 'Góc phản xạ luôn bằng góc tới (i′ = i).', isTrue: true, explanation: 'Đúng ý thứ hai của định luật phản xạ ánh sáng.' },
          { id: 'c', text: 'Góc tới i là góc hợp bởi tia tới và mặt phẳng gương.', isTrue: false, explanation: 'Sai, góc tới i là góc hợp bởi tia tới và đường pháp tuyến vuông góc với mặt gương.' },
          { id: 'd', text: 'Đường pháp tuyến tại điểm tới I là đường phân giác của góc hợp bởi tia tới và tia phản xạ.', isTrue: true, explanation: 'Đúng vì i = i′ và tia tới, tia phản xạ nằm ở hai bên pháp tuyến.' },
        ],
      },
      {
        id: 'b16-tf-2',
        stem: 'Xét sự khác biệt giữa phản xạ gương (phản xạ) và phản xạ khuếch tán:',
        statements: [
          { id: 'a', text: 'Khi chiếu chùm tia tới song song lên bề mặt nhẵn bóng (như mặt gương, mặt nước phẳng lặng), chùm tia phản xạ thu được cũng là chùm song song.', isTrue: true, explanation: 'Đúng tính chất của phản xạ gương.' },
          { id: 'b', text: 'Khi chiếu chùm tia tới song song lên bề mặt nhám, gồ ghề (như tờ giấy, mặt tường vôi), các tia sáng bị phản xạ theo nhiều hướng khác nhau.', isTrue: true, explanation: 'Đúng tính chất của phản xạ khuếch tán.' },
          { id: 'c', text: 'Trong hiện tượng phản xạ khuếch tán, từng tia sáng riêng lẻ khi chạm vào bề mặt gồ ghề không còn tuân theo định luật phản xạ ánh sáng nữa.', isTrue: false, explanation: 'Sai, mỗi tia sáng riêng lẻ vẫn tuân theo định luật phản xạ ánh sáng tại điểm tới cục bộ, nhưng do bề mặt gồ ghề nên các pháp tuyến không song song với nhau.' },
          { id: 'd', text: 'Phản xạ gương cho ta nhìn thấy ảnh rõ nét của vật, còn phản xạ khuếch tán không tạo ra hình ảnh của vật.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b16-tf-3',
        stem: 'Chiếu một tia sáng SI tới mặt gương phẳng tại điểm tới I sao cho tia tới hợp với mặt gương một góc α = 30°:',
        statements: [
          { id: 'a', text: 'Góc tới của tia sáng là i = 30°.', isTrue: false, explanation: 'Sai, góc tới i = 90° - α = 90° - 30° = 60°.' },
          { id: 'b', text: 'Góc phản xạ của tia sáng là i′ = 60°.', isTrue: true, explanation: 'Đúng vì i′ = i = 60°.' },
          { id: 'c', text: 'Tia phản xạ IR cũng hợp với mặt gương một góc bằng 30°.', isTrue: true, explanation: 'Đúng vì 90° - i′ = 90° - 60° = 30°.' },
          { id: 'd', text: 'Góc hợp bởi tia tới SI và tia phản xạ IR bằng 120°.', isTrue: true, explanation: 'Đúng vì góc SIR = i + i′ = 60° + 60° = 120°.' },
        ],
      },
      {
        id: 'b16-tf-4',
        stem: 'Xét các trường hợp đặc biệt khi chiếu tia sáng tới gương phẳng:',
        statements: [
          { id: 'a', text: 'Khi chiếu tia sáng vuông góc với mặt gương phẳng thì góc tới bằng 0° và góc phản xạ cũng bằng 0°.', isTrue: true, explanation: 'Đúng vì tia tới trùng với pháp tuyến.' },
          { id: 'b', text: 'Khi chiếu tia sáng vuông góc với mặt gương thì tia phản xạ truyền ngược chiều lại đúng trên đường truyền của tia tới.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Khi tia tới hợp với mặt gương một góc 45° thì tia phản xạ vuông góc với tia tới (góc SIR = 90°).', isTrue: true, explanation: 'Đúng vì i = 90° - 45° = 45° ⇒ i + i′ = 90°.' },
          { id: 'd', text: 'Nếu giữ nguyên gương phẳng và tăng góc tới thêm 10° thì góc phản xạ sẽ giảm đi 10°.', isTrue: false, explanation: 'Sai, vì i′ = i nên khi góc tới tăng thêm 10° thì góc phản xạ cũng tăng thêm 10°.' },
        ],
      },
      {
        id: 'b16-tf-5',
        stem: 'Một tia sáng Mặt Trời chiếu xiên từ trên xuống hợp với phương nằm ngang một góc 40° tới điểm I trên một gương phẳng để hắt ánh sáng theo phương thẳng đứng xuống đáy một giếng sâu:',
        statements: [
          { id: 'a', text: 'Tia phản xạ IR có phương thẳng đứng hướng xuống nên hợp với phương nằm ngang một góc 90°.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Góc hợp bởi tia tới SI và tia phản xạ IR là góc SIR = 40° + 90° = 130°.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Góc tới và góc phản xạ trong trường hợp này bằng nhau và bằng i = i′ = 65°.', isTrue: true, explanation: 'Đúng, i = i′ = 130° / 2 = 65°.' },
          { id: 'd', text: 'Mặt gương phẳng phải đặt nằm ngang để tia sáng truyền thẳng xuống giếng.', isTrue: false, explanation: 'Sai, mặt gương phải đặt nghiêng hợp với phương thẳng đứng một góc 90° - 65° = 25° (tức hợp với phương ngang góc 65°).' },
        ],
      },
    ],
    essays: [
      {
        id: 'b16-es-1',
        question: 'Câu 1 [Tài liệu Chủ đề Ánh sáng]:\n(a) Hãy phát biểu đầy đủ nội dung Định luật phản xạ ánh sáng.\n(b) Nêu định nghĩa: pháp tuyến của gương, mặt phẳng tới, góc tới và góc phản xạ.',
        hint: 'Phân biệt rõ góc tới (tia tới với pháp tuyến) và góc hợp bởi tia tới với mặt gương.',
        sampleAnswer: '(a) Định luật phản xạ ánh sáng:\n- Tia phản xạ nằm trong mặt phẳng chứa tia tới và pháp tuyến của gương ở điểm tới.\n- Góc phản xạ bằng góc tới (i′ = i).\n(b) Các khái niệm:\n- Pháp tuyến của gương (IN): Đường thẳng vuông góc với mặt phẳng gương tại điểm tới I.\n- Mặt phẳng tới: Mặt phẳng chứa tia tới SI và pháp tuyến IN tại điểm tới I.\n- Góc tới (i): Góc hợp bởi tia tới SI và pháp tuyến IN tại điểm tới.\n- Góc phản xạ (i′): Góc hợp bởi tia phản xạ IR và pháp tuyến IN tại điểm tới.',
        rubricPoints: [
          'Phát biểu đúng 2 ý của định luật phản xạ ánh sáng.',
          'Định nghĩa chính xác pháp tuyến, mặt phẳng tới, góc tới và góc phản xạ.',
        ],
      },
      {
        id: 'b16-es-2',
        question: 'Câu 2 [Tài liệu Chủ đề Ánh sáng]:\n(a) Tia sáng tới gương phẳng hợp với tia phản xạ một góc 120°. Tính giá trị góc tới và góc hợp bởi tia tới với mặt gương.\n(b) Một tia sáng khác chiếu tới gương phẳng và hợp với mặt gương một góc 30°. Hãy tính giá trị của góc tới và góc phản xạ.',
        hint: 'Áp dụng i + i′ = góc SIR, i = i′ và α + i = 90°.',
        sampleAnswer: '(a) Theo đề bài, góc hợp bởi tia tới và tia phản xạ là: i + i′ = 120°.\nTheo định luật phản xạ ánh sáng: i′ = i ⇒ 2 · i = 120° ⇒ i = i′ = 60°.\nGóc hợp bởi tia tới và mặt gương là: α = 90° - i = 90° - 60° = 30°.\n(b) Khi tia tới hợp với mặt gương góc 30°:\nVì pháp tuyến vuông góc với mặt gương (90°) nên góc tới là: i = 90° - 30° = 60°.\nTheo định luật phản xạ ánh sáng, góc phản xạ bằng góc tới: i′ = i = 60°.',
        rubricPoints: [
          'Tính đúng câu (a): i = 60° và góc với mặt gương α = 30°.',
          'Tính đúng câu (b): i = 60° và i′ = 60°.',
        ],
      },
      {
        id: 'b16-es-3',
        question: 'Câu 3 [Tài liệu Chủ đề Ánh sáng]: Hãy tính giá trị của góc tới và góc phản xạ trong hai trường hợp sau:\n(a) Khi tia sáng chiếu vuông góc với mặt gương phẳng.\n(b) Khi tia sáng chiếu là là trùng với mặt phẳng gương.',
        hint: 'Xác định góc giữa tia tới và pháp tuyến IN trong mỗi trường hợp.',
        sampleAnswer: '(a) Khi tia tới vuông góc với mặt gương phẳng:\nTia tới trùng với đường pháp tuyến IN của gương nên góc tới i = 0°.\nTheo định luật phản xạ ánh sáng: góc phản xạ i′ = i = 0° (tia phản xạ bật ngược trở lại theo đúng đường tia tới).\n(b) Khi tia tới trùng với mặt phẳng gương:\nGóc hợp bởi tia tới và mặt gương bằng 0°, suy ra góc giữa tia tới và pháp tuyến là i = 90° ⇒ i′ = 90° (tia sáng đi thẳng dọc theo mặt gương).',
        rubricPoints: [
          'Giải thích và tính đúng i = i′ = 0° khi tia tới vuông góc với gương.',
          'Giải thích và tính đúng i = i′ = 90° khi tia tới trùng mặt gương.',
        ],
      },
      {
        id: 'b16-es-4',
        question: 'Câu 4 [Tài liệu Chủ đề Ánh sáng]: Trình bày các bước hình học để xác định chính xác vị trí đặt một gương phẳng tại điểm tới I khi đã biết phương chiều của tia tới SI và tia phản xạ IR.',
        hint: 'Dùng tính chất pháp tuyến IN là đường phân giác của góc SIR và gương vuông góc với IN.',
        sampleAnswer: 'Các bước xác định vị trí đặt gương phẳng:\n- Bước 1: Xác định điểm tới I là giao điểm của tia tới SI và tia phản xạ IR.\n- Bước 2: Vẽ tia phân giác IN của góc hợp bởi tia tới và tia phản xạ (góc SIR). Đường thẳng chứa tia phân giác IN chính là đường pháp tuyến của gương tại điểm tới I.\n- Bước 3: Qua điểm tới I, kẻ đường thẳng GG′ vuông góc với pháp tuyến IN (mặt phản xạ hướng về phía chứa tia tới và tia phản xạ). Đường thẳng GG′ chính là vị trí đặt gương phẳng.',
        rubricPoints: [
          'Nêu đúng bước vẽ tia phân giác IN của góc SIR làm pháp tuyến.',
          'Nêu đúng bước kẻ mặt gương vuông góc với pháp tuyến IN tại I.',
        ],
      },
      {
        id: 'b16-es-5',
        question: 'Câu 5 [Tài liệu Chủ đề Ánh sáng]: Chiếu một tia sáng SI từ trên chếch xuống hợp với phương nằm ngang một góc 60°. Người ta đặt một gương phẳng tại I để thu được tia phản xạ IR có phương thẳng đứng hướng từ trên xuống dưới.\n(a) Tính góc hợp bởi tia tới SI và tia phản xạ IR.\n(b) Tính góc tới i, góc phản xạ i′ và góc hợp bởi mặt gương với phương nằm ngang.',
        hint: 'Vẽ đường nằm ngang qua I: tia SI nằm phía trên đường ngang góc 60°, tia IR thẳng đứng xuống dưới hợp đường ngang góc 90°.',
        sampleAnswer: '(a) Gọi IK là tia nằm ngang cùng phía với tia tới SI.\n- Tia tới SI hợp với phương ngang IK một góc KIS = 60°.\n- Tia phản xạ IR thẳng đứng hướng xuống nên vuông góc với IK: góc KIR = 90°.\n- Do đó góc hợp bởi tia tới SI và tia phản xạ IR là: góc SIR = góc KIS + góc KIR = 60° + 90° = 150°.\n(b) Theo định luật phản xạ ánh sáng (i = i′) và i + i′ = góc SIR:\ni = i′ = 150° / 2 = 75°.\nPháp tuyến IN hợp với tia tới SI góc 75° nên hợp với phương ngang IK góc 75° - 60° = 15° ⇒ Mặt gương (vuông góc với IN) hợp với phương ngang một góc 90° - 15° = 75°.',
        rubricPoints: [
          'Tính đúng góc hợp bởi tia tới và tia phản xạ góc SIR = 150°.',
          'Tính đúng góc tới i = góc phản xạ i′ = 75°.',
        ],
      },
      {
        id: 'b16-es-6',
        question: 'Câu 6 [Tài liệu Chủ đề Ánh sáng]: Phân biệt hiện tượng phản xạ gương và hiện tượng phản xạ khuếch tán. Lấy 2 ví dụ cho mỗi hiện tượng trong đời sống.',
        hint: 'So sánh bề mặt phản xạ, hướng của chùm tia phản xạ và khả năng tạo ảnh.',
        sampleAnswer: '- Phản xạ gương (phản xạ): Xảy ra khi ánh sáng chiếu tới bề mặt phẳng, nhẵn bóng. Chùm tia tới song song cho chùm tia phản xạ song song theo một hướng xác định và tạo ra ảnh rõ nét của vật. Ví dụ: Phản xạ trên gương soi phẳng, mặt hồ nước yên lặng.\n- Phản xạ khuếch tán: Xảy ra khi ánh sáng chiếu tới bề mặt nhám, gồ ghề, không nhẵn bóng. Chùm tia tới song song bị hắt lại theo mọi hướng khác nhau và không tạo ra hình ảnh của vật. Ví dụ: Phản xạ trên trang giấy trắng, bức tường sơn, mặt hồ đang gợn sóng.',
        rubricPoints: [
          'Nêu đúng đặc điểm và 2 ví dụ của phản xạ gương.',
          'Nêu đúng đặc điểm và 2 ví dụ của phản xạ khuếch tán.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 17: ẢNH CỦA VẬT QUA GƯƠNG PHẲNG (Tài liệu Chủ đề Ánh sáng - Bài 14)
  // =========================================================================
  {
    id: 'kntt-bai-17',
    lessonNumber: 17,
    title: 'Bài 17: Ảnh của vật qua gương phẳng',
    chapterTitle: 'Chương V: Ánh sáng',
    subject: 'physics',
    pdfUrl: '/assets/aistudio/_C_p_nh_t_m_i__Ch______nh_s_ng_ac14e419.pdf',
    summary:
      'Ảnh của một vật tạo bởi gương phẳng là ảnh ảo (không hứng được trên màn chắn), có độ lớn bằng vật và đối xứng với vật qua gương phẳng (khoảng cách từ một điểm của vật đến gương bằng khoảng cách từ ảnh của điểm đó đến gương).',
    keyFormulas: [
      '3 tính chất ảnh qua gương phẳng: (1) Ảnh ảo; (2) Độ lớn ảnh bằng độ lớn vật (A′B′ = AB); (3) Khoảng cách từ ảnh đến gương bằng khoảng cách từ vật đến gương (d′ = d)',
      'Khoảng cách giữa điểm sáng S và ảnh S′ của nó qua gương phẳng:  SS′ = SH + S′H = 2 · d',
      'Dựng ảnh: Lấy điểm S′ đối xứng với S qua mặt phẳng gương (SS′ ⊥ gương tại H và S′H = SH)',
    ],
    mcqs: makeMcqs('b17', [
      ['Nói về tính chất ảnh của một vật tạo bởi gương phẳng, phát biểu nào dưới đây là ĐÚNG?', ['Hứng được trên màn chắn và lớn bằng vật.', 'Không hứng được trên màn chắn và bé hơn vật.', 'Không hứng được trên màn chắn (là ảnh ảo) và lớn bằng vật.', 'Hứng được trên màn chắn và lớn hơn vật.'], 2, 'Ảnh của vật tạo bởi gương phẳng là ảnh ảo (không hứng được trên màn chắn) và có độ lớn bằng vật.'],
      ['Chọn phát biểu ĐÚNG về ảnh của một vật qua gương phẳng:', ['Ảnh thật, cùng chiều và nhỏ hơn vật.', 'Ảnh thật, cùng chiều, bằng vật và đối xứng với vật qua gương.', 'Ảnh ảo, cùng chiều, bằng vật và đối xứng với vật qua gương.', 'Ảnh ảo, ngược chiều và lớn hơn vật.'], 2, 'Ảnh qua gương phẳng luôn là ảnh ảo, lớn bằng vật và đối xứng với vật qua gương.'],
      ['Chọn câu SAI khi nói về tính chất ảnh của một vật qua gương phẳng:', ['Khoảng cách từ vật đến gương bằng khoảng cách từ vật đến ảnh (d = SS′).', 'Độ cao (kích thước) của vật bằng độ cao của ảnh.', 'Ảnh của vật không hứng được trên màn chắn.', 'Khoảng cách từ một điểm của vật đến gương bằng khoảng cách từ ảnh của điểm đó đến gương.'], 0, 'Khoảng cách từ vật đến gương (d) bằng khoảng cách từ ẢNH đến gương (d′), nên khoảng cách từ vật đến ảnh bằng 2d (câu A sai).'],
      ['Ảnh của vật tạo bởi gương phẳng được gọi là:', ['hình của một vật quan sát được trong gương.', 'bóng tối của vật ở phía sau gương.', 'hình ảnh hứng được trên tờ giấy đặt sau gương.', 'tia sáng phát ra từ gương.'], 0, 'Hình của một vật quan sát được trong gương gọi là ảnh của vật tạo bởi gương.'],
      ['Để kiểm chứng ảnh tạo bởi gương phẳng là ảnh ảo, người ta thực hiện cách nào sau đây?', ['Dùng máy ảnh chụp ảnh trong gương.', 'Đặt một màn chắn ở phía sau gương tại vị trí của ảnh xem có hứng được ảnh trên màn không.', 'Nhìn vào mặt trước của gương.', 'Dùng thước đo chiều cao của vật.'], 1, 'Khi đưa màn chắn ra phía sau gương không hứng được ảnh trên màn chắn ⇒ đó là ảnh ảo.'],
      ['Điểm sáng S đặt trước gương phẳng, cách gương phẳng một đoạn d = 5 cm và cho ảnh S′. Khoảng cách SS′ giữa điểm sáng S và ảnh S′ của nó lúc này là:', ['5 cm.', '10 cm.', '15 cm.', '2,5 cm.'], 1, 'Vì S và S′ đối xứng nhau qua gương nên SS′ = 2 · d = 2 × 5 = 10 cm.'],
      ['Một người cao 1,6 m đứng trước gương phẳng thẳng đứng, cách gương 1,5 m. Chiều cao của ảnh người đó trong gương và khoảng cách từ ảnh đến gương lần lượt là:', ['Cao 1,6 m; cách gương 1,5 m.', 'Cao 1,6 m; cách gương 3,0 m.', 'Cao 0,8 m; cách gương 1,5 m.', 'Cao 1,5 m; cách gương 1,6 m.'], 0, 'Ảnh lớn bằng vật (cao 1,6 m) và cách gương một khoảng bằng khoảng cách từ người đến gương (1,5 m).'],
      ['Một người đứng trước gương phẳng cách gương 1,5 m. Nếu người đó bước tiến lại gần gương thêm 0,5 m thì khoảng cách từ người đó đến ảnh của mình trong gương là:', ['1,0 m.', '2,0 m.', '3,0 m.', '2,5 m.'], 1, 'Sau khi tiến lại gần 0,5 m, người đó cách gương d = 1,5 - 0,5 = 1,0 m ⇒ Khoảng cách từ người đến ảnh là 2 · d = 2,0 m.'],
      ['Cho điểm sáng S đặt trước gương phẳng, biết khoảng cách từ S đến ảnh S′ của nó qua gương là 54 cm. Ảnh S′ nằm cách gương một khoảng bao nhiêu?', ['54 cm.', '27 cm.', '108 cm.', '18 cm.'], 1, 'Ta có SS′ = 2 · S′H = 54 cm ⇒ S′H = 54 / 2 = 27 cm.'],
      ['Khi nào mắt ta có thể nhìn thấy ảnh ảo S′ của một điểm sáng S đặt trước gương phẳng?', ['Khi mắt đặt ở phía sau mặt gương.', 'Khi S′ trở thành nguồn sáng thật.', 'Khi mắt đặt ở phía trước gương trong vùng đón nhận được các tia phản xạ của các tia tới xuất phát từ S.', 'Khi tắt hết đèn trong phòng.'], 2, 'Ta nhìn thấy ảnh ảo S′ vì mắt nhận được chùm tia phản xạ có đường kéo dài đi qua S′.'],
      ['Một vật sáng AB đặt trước gương phẳng sao cho AB hợp với mặt gương một góc 60°. Góc tạo bởi ảnh A′B′ của nó và mặt gương là:', ['30°.', '60°.', '90°.', '120°.'], 1, 'Do tính chất đối xứng của ảnh và vật qua gương phẳng nên góc tạo bởi ảnh A′B′ và mặt gương cũng bằng 60°.'],
      ['Một vật sáng hình mũi tên AB đặt song song với mặt gương phẳng và cách gương 20 cm. Ảnh A′B′ của vật qua gương có đặc điểm:', ['Song song, cùng chiều với AB và cách AB một khoảng 40 cm.', 'Vuông góc với AB và cách gương 20 cm.', 'Song song, ngược chiều với AB và cách gương 20 cm.', 'Nhỏ bằng một nửa AB.'], 0, 'Vật đặt song song với gương cho ảnh song song, cùng chiều, bằng vật và cách vật 20 + 20 = 40 cm.'],
      ['Một vật sáng hình mũi tên AB đặt vuông góc với mặt gương phẳng, đầu B hướng vào gương. Ảnh A′B′ của vật qua gương có đặc điểm:', ['Song song với mặt gương.', 'Vuông góc với mặt gương, có độ lớn bằng AB nhưng ngược chiều với AB (đầu B′ cũng hướng vào gương).', 'Vuông góc với mặt gương và cùng chiều với AB.', 'Lớn gấp đôi AB.'], 1, 'Do B gần gương hơn A nên ảnh B′ cũng gần gương hơn A′, tức là mũi tên ảnh A′B′ hướng ngược lại với AB.'],
      ['Khi vẽ ảnh S′ của điểm sáng S qua gương phẳng trên giấy, đường biểu diễn ảnh ảo và phần kéo dài của các tia phản xạ ở phía sau gương phải được vẽ bằng:', ['nét liền đậm.', 'nét đứt (vì phía sau gương không có tia sáng thật truyền tới).', 'nét đôi.', 'không được vẽ.'], 1, 'Ảnh ảo và phần kéo dài của tia phản xạ ở sau gương được quy ước vẽ bằng nét đứt.'],
      ['Nhận xét nào sau đây là SAI khi so sánh tác dụng của gương phẳng và một tấm kính cửa sổ trong suốt phẳng?', ['Nhìn vào gương phẳng ta không thấy được các vật ở phía sau lưng gương.', 'Nhìn vào tấm kính trong suốt ta thấy được cả vật ở phía sau tấm kính và ảnh mờ của vật ở trước tấm kính.', 'Cả gương phẳng và tấm kính phẳng đều có thể tạo được ảnh ảo của vật đặt trước chúng.', 'Nhìn qua tấm kính trong suốt ta hoàn toàn không thể thấy được các vật ở phía bên kia tấm kính.'], 3, 'Kính trong suốt cho ánh sáng truyền qua nên ta nhìn thấy rõ các vật ở phía bên kia tấm kính (câu D sai).'],
      ['Trong thí nghiệm kiểm tra độ lớn của ảnh bằng tấm kính phẳng (Hình 14 SGK), người ta đặt viên pin thứ nhất trước tấm kính và di chuyển viên pin thứ hai (giống hệt viên thứ nhất) ở phía sau tấm kính. Kết quả cho thấy:', ['Viên pin thứ hai trùng khít hoàn toàn với ảnh ảo của viên pin thứ nhất cả về vị trí và kích thước.', 'Ảnh của viên pin thứ nhất lớn gấp đôi viên pin thứ hai.', 'Viên pin thứ hai phải đặt sát mặt kính mới trùng với ảnh.', 'Không thể tìm được vị trí trùng khít.'], 0, 'Thí nghiệm chứng minh trực quan: độ lớn của ảnh bằng độ lớn của vật và khoảng cách từ ảnh đến gương bằng khoảng cách từ vật đến gương.'],
      ['Một gương phẳng đặt nghiêng một góc 45° so với phương nằm ngang (mặt phản xạ hướng xuống). Chiếu một chùm tia tới song song theo phương nằm ngang vào gương thì chùm tia phản xạ sẽ:', ['là chùm tia phân kì.', 'là chùm tia hội tụ.', 'là chùm tia song song có phương thẳng đứng hướng xuống dưới.', 'truyền ngược lại theo phương nằm ngang.'], 2, 'Góc tới i = 45° ⇒ góc phản xạ i′ = 45° ⇒ góc SIR = 90° nên chùm tia phản xạ song song hướng thẳng đứng xuống dưới.'],
      ['Một chiếc đồng hồ treo tường (loại mặt kim không ghi số) được nhìn qua một gương phẳng thẳng đứng. Trong gương ta thấy kim giờ chỉ vị trí số 10 và kim phút chỉ số 12. Hỏi thực tế lúc đó đồng hồ đang chỉ mấy giờ?', ['10 giờ 00.', '2 giờ 00 (hoặc 14 giờ chiều).', '8 giờ 00.', '4 giờ 00.'], 1, 'Do ảnh đối xứng trái – phải qua gương phẳng thẳng đứng nên vị trí số 10 đối xứng sang vị trí số 2 ⇒ Đồng hồ chỉ 2 giờ (hoặc 14h).'],
      ['Một chiếc đồng hồ kim (không số) đặt trước gương phẳng thẳng đứng. Thực tế đồng hồ đang chỉ 3 giờ 00. Nhìn ảnh của đồng hồ trong gương ta thấy kim chỉ mấy giờ?', ['3 giờ 00.', '9 giờ 00.', '6 giờ 00.', '12 giờ 15.'], 1, 'Vị trí số 3 và vị trí số 9 đối xứng nhau qua trục thẳng đứng (12h – 6h) ⇒ Trong gương thấy chỉ 9 giờ 00.'],
      ['Để vẽ tia phản xạ của một tia tới SI chiếu tới gương phẳng tại I một cách nhanh chóng và chính xác nhất bằng thước thẳng (mà không cần dùng thước đo độ), ta làm như sau:', ['Lấy điểm S′ đối xứng với S qua gương, rồi nối S′ với I và kéo dài ra phía trước gương được tia phản xạ IR.', 'Kẻ đại một đường bất kì từ I.', 'Nối S với mép gương.', 'Kẻ đường song song với mặt gương.'], 0, 'Vì mọi tia phản xạ đều có đường kéo dài đi qua ảnh ảo S′ nên chỉ cần lấy S′ đối xứng với S qua gương rồi nối S′I kéo dài là được tia phản xạ chính xác.'],
      ['Một điểm sáng S đặt trước gương phẳng cách gương 30 cm. Nếu dịch chuyển gương ra xa điểm sáng S thêm 10 cm (theo phương vuông góc với mặt gương) thì ảnh S′ sẽ cách S một khoảng là:', ['40 cm.', '60 cm.', '80 cm.', '70 cm.'], 2, 'Khoảng cách mới từ S đến gương là d′ = 30 + 10 = 40 cm ⇒ Khoảng cách từ S đến ảnh S′ là 2 × 40 = 80 cm.'],
      ['Một người đứng trước một gương phẳng. Nếu người đó tiến lại gần gương với tốc độ 1 m/s thì ảnh của người đó trong gương sẽ tiến lại gần người đó với tốc độ là:', ['0,5 m/s.', '1 m/s.', '2 m/s.', '0 m/s.'], 2, 'Trong 1 giây người tiến gần gương 1 m và ảnh cũng tiến gần gương 1 m từ phía đối diện ⇒ khoảng cách giữa người và ảnh giảm 2 m mỗi giây (tốc độ tương đối là 2 m/s).'],
      ['Khi người quan sát giữ nguyên vị trí đứng trước một gương phẳng nhỏ treo trên tường, nếu người đó bước lại gần gương hơn thì bề rộng vùng nhìn thấy của gương sẽ:', ['tăng lên (nhìn thấy được vùng không gian phía sau rộng hơn).', 'giảm đi.', 'không thay đổi.', 'bằng 0.'], 0, 'Khi mắt tiến lại gần gương, góc giới hạn bởi các tia phản xạ từ hai mép gương tới mắt mở rộng ra nên vùng nhìn thấy của gương rộng hơn.'],
      ['Một điểm sáng S đặt trước gương phẳng OM. Nếu giữ cố định điểm sáng S và quay gương một góc α = 20° quanh trục O thì đoạn nối OS′ (từ O đến ảnh S′) sẽ quay một góc bằng bao nhiêu?', ['10°.', '20°.', '40°.', '60°.'], 2, 'Khi gương phẳng quay một góc α thì tia phản xạ và ảnh S′ quay một góc 2α = 2 × 20° = 40°.'],
      ['Chiếu một tia sáng SI tới một gương phẳng cố định. Nếu giữ cố định gương và quay tia tới SI một góc α = 15° quanh điểm tới I thì tia phản xạ IR sẽ quay một góc bằng bao nhiêu?', ['15°.', '30°.', '7,5°.', '0°.'], 0, 'Vì pháp tuyến cố định và i′ = i nên khi tia tới quay góc α = 15° (góc tới thay đổi 15°) thì tia phản xạ cũng quay một góc đúng bằng α = 15° theo chiều ngược lại.'],
      ['Một con mèo đứng cách gương phẳng 1,2 m. Một con chuột đứng ở phía sau lưng con mèo và cách con mèo 0,8 m (cùng trên đường vuông góc với gương). Khoảng cách từ con chuột đến ảnh của con mèo trong gương là:', ['2,0 m.', '2,4 m.', '3,2 m.', '1,6 m.'], 2, 'Con mèo cách gương 1,2 m ⇒ ảnh con mèo ở sau gương 1,2 m. Con chuột ở trước gương cách gương 1,2 + 0,8 = 2,0 m ⇒ Khoảng cách từ chuột đến ảnh mèo = 2,0 + 1,2 = 3,2 m.'],
      ['Gương cầu lồi lắp làm gương chiếu hậu xe máy, ô tô khác với gương phẳng ở điểm nào?', ['Cho ảnh thật lớn hơn vật.', 'Cho ảnh ảo nhỏ hơn vật nhưng có vùng nhìn thấy rộng hơn gương phẳng có cùng kích thước.', 'Cho ảnh ảo lớn gấp đôi vật.', 'Không phản xạ ánh sáng.'], 1, 'Gương chiếu hậu dùng gương cầu lồi để mở rộng tối đa vùng quan sát phía sau cho người lái xe.'],
      ['Kính tiềm vọng trên tàu ngầm sử dụng hai gương phẳng đặt song song với nhau và nghiêng một góc bao nhiêu độ so với phương nằm ngang (hoặc thẳng đứng) để đổi hướng tia sáng đi qua ống thẳng đứng?', ['30°.', '45°.', '60°.', '90°.'], 1, 'Hai gương phẳng trong kính tiềm vọng đặt nghiêng góc 45° để bẻ vuông góc (90°) đường truyền của tia sáng hai lần.'],
      ['Chữ cái in hoa nào sau đây khi soi vào gương phẳng thẳng đứng cho ảnh trông giống hệt chữ ban đầu (có trục đối xứng dọc)?', ['Chữ P.', 'Chữ A (hoặc H, M, O, T, V, X, Y).', 'Chữ L.', 'Chữ R.'], 1, 'Các chữ A, H, I, M, O, T, U, V, W, X, Y có trục đối xứng dọc nên ảnh qua gương phẳng thẳng đứng không bị đảo ngược.'],
      ['Tại sao đầu xe cứu thương thường viết dòng chữ “AMBULANCE” bị ngược trái – phải?', ['Do nhà sản xuất in nhầm.', 'Để khi người lái xe phía trước nhìn qua gương chiếu hậu (gương phẳng), ảnh của dòng chữ sẽ đảo lại thành chữ xuôi dễ đọc ngay lập tức.', 'Để trang trí cho đẹp.', 'Để nhìn từ trên máy bay xuống.'], 1, 'Qua gương chiếu hậu, ảnh bị đối xứng trái – phải nên chữ in ngược trên đầu xe cứu thương sẽ hiện thành chữ xuôi “AMBULANCE” giúp tài xế xe trước nhận biết và nhường đường ngay.'],
    ]),
    trueFalseList: [
      {
        id: 'b17-tf-1',
        stem: 'Xét các đặc điểm của ảnh tạo bởi gương phẳng:',
        statements: [
          { id: 'a', text: 'Ảnh của một vật tạo bởi gương phẳng là ảnh ảo vì không hứng được trên màn chắn.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Độ lớn của ảnh tạo bởi gương phẳng luôn bằng độ lớn của vật, dù vật đặt gần gương hay đặt xa gương.', isTrue: true, explanation: 'Đúng, kích thước thật của ảnh qua gương phẳng luôn bằng vật.' },
          { id: 'c', text: 'Khi ta bước lùi ra xa gương phẳng thì kích thước của ảnh tạo bởi gương phẳng giảm dần.', isTrue: false, explanation: 'Sai, độ lớn của ảnh qua gương phẳng luôn bằng độ lớn của vật (cảm giác nhỏ đi chỉ là do góc nhìn của mắt khi ở xa).' },
          { id: 'd', text: 'Khoảng cách từ một điểm của vật đến gương phẳng bằng khoảng cách từ ảnh của điểm đó đến gương phẳng.', isTrue: true, explanation: 'Đúng tính chất đối xứng qua gương phẳng.' },
        ],
      },
      {
        id: 'b17-tf-2',
        stem: 'Xét hai cách dựng ảnh S′ của một điểm sáng S qua gương phẳng:',
        statements: [
          { id: 'a', text: 'Cách 1 (dựa vào định luật phản xạ ánh sáng): Từ S vẽ hai tia tới SI₁, SI₂ tới gương, vẽ hai tia phản xạ tương ứng; giao điểm đường kéo dài của hai tia phản xạ ở sau gương chính là ảnh ảo S′.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Cách 2 (dựa vào tính chất đối xứng của ảnh): Từ S kẻ đường thẳng vuông góc với mặt phẳng gương tại H, trên tia đối của tia HS lấy điểm S′ sao cho S′H = SH.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Hai cách dựng trên cho ra hai vị trí ảnh S′ khác nhau.', isTrue: false, explanation: 'Sai, cả hai cách dựng đều cho cùng một vị trí ảnh S′ duy nhất.' },
          { id: 'd', text: 'Khi dựng ảnh của một đoạn thẳng sáng AB qua gương phẳng, ta chỉ cần dựng ảnh A′ của A và B′ của B rồi nối A′B′ bằng nét đứt.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b17-tf-3',
        stem: 'Một điểm sáng S đặt trước một gương phẳng một khoảng d = 27 cm:',
        statements: [
          { id: 'a', text: 'Ảnh S′ của điểm sáng S nằm ở phía sau gương và cách mặt gương một khoảng d′ = 27 cm.', isTrue: true, explanation: 'Đúng vì d′ = d = 27 cm.' },
          { id: 'b', text: 'Khoảng cách từ điểm sáng S đến ảnh S′ của nó là SS′ = 54 cm.', isTrue: true, explanation: 'Đúng, SS′ = 27 + 27 = 54 cm.' },
          { id: 'c', text: 'Đường thẳng nối SS′ tạo với mặt phẳng gương một góc 45°.', isTrue: false, explanation: 'Sai, do S và S′ đối xứng qua gương nên đường thẳng SS′ luôn vuông góc (90°) với mặt gương.' },
          { id: 'd', text: 'Mọi tia sáng xuất phát từ S sau khi phản xạ trên gương phẳng đều có đường kéo dài đi qua điểm S′.', isTrue: true, explanation: 'Đúng bản chất tạo ảnh của gương phẳng.' },
        ],
      },
      {
        id: 'b17-tf-4',
        stem: 'Một bạn học sinh cao 1,5 m đứng thẳng trước một gương phẳng treo thẳng đứng trên tường và cách gương 2,0 m:',
        statements: [
          { id: 'a', text: 'Ảnh của bạn học sinh trong gương là ảnh ảo, cùng chiều (đầu ở trên, chân ở dưới) và cao 1,5 m.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Khoảng cách từ bạn học sinh đến ảnh của mình trong gương là 4,0 m.', isTrue: true, explanation: 'Đúng, 2,0 + 2,0 = 4,0 m.' },
          { id: 'c', text: 'Nếu bạn học sinh giơ tay phải lên thì ảnh trong gương sẽ giơ tay phía đối diện (trông như tay trái của ảnh).', isTrue: true, explanation: 'Đúng tính chất đối xứng qua mặt phẳng gương.' },
          { id: 'd', text: 'Nếu bạn học sinh tiến lại gần gương thêm 0,5 m thì khoảng cách giữa bạn và ảnh giảm đi 0,5 m.', isTrue: false, explanation: 'Sai, khi bạn tiến gần gương 0,5 m thì ảnh cũng tiến gần gương 0,5 m ⇒ khoảng cách giữa bạn và ảnh giảm đi 2 × 0,5 = 1,0 m (còn 3,0 m).' },
        ],
      },
      {
        id: 'b17-tf-5',
        stem: 'Xét vùng nhìn thấy của gương phẳng:',
        statements: [
          { id: 'a', text: 'Vùng nhìn thấy của gương phẳng là khoảng không gian ở trước gương mà mọi vật đặt trong đó ta đều nhìn thấy ảnh của chúng trong gương.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Cùng một vị trí đặt mắt, tấm gương phẳng càng lớn thì bề rộng vùng nhìn thấy của gương càng lớn.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Khi giữ nguyên vị trí người đứng và đẩy gương phẳng ra xa người hơn thì bề rộng vùng nhìn thấy của gương sẽ tăng lên.', isTrue: false, explanation: 'Sai, khi đẩy gương ra xa mắt hơn thì góc nhìn qua gương hẹp lại nên bề rộng vùng nhìn thấy giảm đi.' },
          { id: 'd', text: 'Để nhìn thấy ảnh ảo S′ của một điểm sáng S trong gương, mắt người quan sát phải đặt trong chùm tia phản xạ giới hạn bởi các tia phản xạ ở mép gương.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b17-es-1',
        question: 'Câu 1 [Tài liệu Chủ đề Ánh sáng]:\n(a) Trình bày đầy đủ các đặc điểm (tính chất) của ảnh một vật tạo bởi gương phẳng.\n(b) Khi vẽ ảnh của vật tạo bởi gương phẳng trên hình vẽ, ta cần lưu ý quy ước nét vẽ như thế nào?',
        hint: 'Nêu đủ 3 tính chất về loại ảnh, kích thước và khoảng cách đối xứng.',
        sampleAnswer: '(a) Đặc điểm ảnh của một vật tạo bởi gương phẳng:\n- Là ảnh ảo (không hứng được trên màn chắn).\n- Có kích thước (độ lớn) bằng vật.\n- Đối xứng với vật qua gương phẳng (khoảng cách từ một điểm của vật đến gương phẳng bằng khoảng cách từ ảnh của điểm đó đến gương, và đường nối vật – ảnh vuông góc với mặt gương).\n(b) Lưu ý khi vẽ hình:\n- Các tia sáng thật (tia tới, tia phản xạ trước gương) và vật thật vẽ bằng nét liền.\n- Ảnh ảo S′, A′B′ và phần kéo dài của các tia sáng ở phía sau gương phải vẽ bằng nét đứt.',
        rubricPoints: [
          'Nêu đúng 3 đặc điểm của ảnh tạo bởi gương phẳng.',
          'Nêu đúng quy ước nét liền (tia thật, vật thật) và nét đứt (ảnh ảo, tia kéo dài sau gương).',
        ],
      },
      {
        id: 'b17-es-2',
        question: 'Câu 2 [Tài liệu Chủ đề Ánh sáng]:\n(a) Một người cao 1,6 m đứng trước gương phẳng, cho ảnh cách gương 1,5 m. Hỏi người đó đứng cách gương bao nhiêu mét và cách ảnh của mình bao nhiêu mét?\n(b) Cho điểm sáng S đặt trước gương phẳng, biết S cách ảnh S′ của nó qua gương một khoảng 54 cm. Hỏi ảnh S′ nằm cách gương một khoảng bao nhiêu cm?',
        hint: 'Áp dụng tính chất đối xứng SH = S′H và SS′ = 2 · SH.',
        sampleAnswer: '(a) Vì ảnh và vật đối xứng nhau qua gương phẳng nên khoảng cách từ người đến gương bằng khoảng cách từ ảnh đến gương:\nd = d′ = 1,5 m.\nKhoảng cách từ người đó đến ảnh của mình trong gương là:\nL = d + d′ = 1,5 + 1,5 = 3,0 m.\n(b) Vì S và S′ đối xứng nhau qua gương phẳng nên SH = S′H.\nTheo đề bài: SS′ = SH + S′H = 2 · S′H = 54 cm\n⇒ S′H = 54 / 2 = 27 cm.\nVậy ảnh S′ nằm cách gương một khoảng là 27 cm.',
        rubricPoints: [
          'Tính đúng câu (a): người cách gương 1,5 m và cách ảnh 3,0 m.',
          'Tính đúng câu (b): ảnh S′ cách gương 27 cm.',
        ],
      },
      {
        id: 'b17-es-3',
        question: 'Câu 3 [Tài liệu Chủ đề Ánh sáng]: Cho điểm sáng S đặt trước một gương phẳng và hai điểm tới I, K trên mặt gương. Hãy trình bày cách vẽ hai tia phản xạ tại I và K một cách đơn giản, chính xác nhất dựa vào tính chất của ảnh qua gương phẳng.',
        hint: 'Dựng ảnh ảo S′ đối xứng với S qua gương trước, sau đó nối S′ với I và K.',
        sampleAnswer: 'Để vẽ các tia phản xạ tại I và K một cách đơn giản và chính xác nhất, ta căn cứ vào tính chất: mọi tia phản xạ đều có đường kéo dài đi qua ảnh ảo S′.\nCách vẽ:\n- Bước 1: Từ điểm sáng S kẻ đường thẳng vuông góc với mặt phẳng gương tại H, kéo dài ra sau gương và lấy điểm S′ sao cho S′H = SH (S′ là ảnh ảo của S).\n- Bước 2: Đặt thước thẳng đi qua S′ và điểm tới I: phần từ S′ đến I (sau gương) vẽ bằng nét đứt, phần kéo dài từ I ra phía trước gương vẽ bằng nét liền có mũi tên hướng ra xa gương ta được tia phản xạ IR.\n- Bước 3: Tương tự, nối S′ với K (sau gương nét đứt) và kéo dài ra trước gương (nét liền) ta được tia phản xạ thứ hai.',
        rubricPoints: [
          'Nêu đúng căn cứ: đường kéo dài của tia phản xạ đi qua ảnh ảo S′.',
          'Trình bày rõ 3 bước lấy điểm đối xứng S′ và nối S′I, S′K kéo dài.',
        ],
      },
      {
        id: 'b17-es-4',
        question: 'Câu 4 [Tài liệu Chủ đề Ánh sáng]: Cho một điểm sáng S đặt trước một gương phẳng. Chiếu một tia tới SI tới gương sao cho góc tạo bởi tia tới SI và mặt gương bằng 50°.\n(a) Hãy nêu cách vẽ ảnh S′ của S và tia phản xạ IR.\n(b) Tính góc tới i, góc phản xạ i′ và góc hợp bởi tia tới với tia phản xạ.',
        hint: 'Pháp tuyến IN vuông góc với mặt gương nên i = 90° - 50°.',
        sampleAnswer: '(a) Cách vẽ:\n- Kẻ SH vuông góc với mặt gương tại H, lấy S′ đối xứng với S qua gương (S′H = SH).\n- Nối S′ với điểm tới I (nét đứt ở sau gương) và kéo dài ra trước gương (nét liền) được tia phản xạ IR.\n(b) Tính góc:\n- Vì pháp tuyến IN vuông góc với mặt gương tại I nên: góc tới i = 90° - 50° = 40°.\n- Theo định luật phản xạ ánh sáng, góc phản xạ bằng góc tới: i′ = i = 40°.\n- Góc hợp bởi tia tới SI và tia phản xạ IR là: i + i′ = 40° + 40° = 80°.',
        rubricPoints: [
          'Trình bày đúng cách dựng ảnh S′ và tia phản xạ IR.',
          'Tính đúng i = 40°, i′ = 40° và góc SIR = 80°.',
        ],
      },
      {
        id: 'b17-es-5',
        question: 'Câu 5 [Tài liệu Chủ đề Ánh sáng]: Giải thích tại sao trên mặt nước hồ phẳng lặng ta nhìn thấy ảnh của ngọn tháp trên bờ có kích thước bằng ngọn tháp thật và lộn ngược xuống dưới đáy nước?',
        hint: 'Mặt nước phẳng lặng đóng vai trò như một gương phẳng nằm ngang.',
        sampleAnswer: '- Mặt nước hồ phẳng lặng đóng vai trò như một chiếc gương phẳng lớn đặt nằm ngang.\n- Ảnh của ngọn tháp tạo bởi mặt nước là ảnh ảo, có kích thước bằng ngọn tháp thật và đối xứng với ngọn tháp qua mặt phẳng nước.\n- Vì ngọn tháp thẳng đứng có chân tháp ở sát mặt nước còn đỉnh tháp ở xa mặt nước phía trên, nên theo tính chất đối xứng qua mặt gương nằm ngang: ảnh của chân tháp ở sát mặt nước còn ảnh của đỉnh tháp nằm sâu phía dưới mặt nước ⇒ Ta nhìn thấy ảnh ngọn tháp lộn ngược xuống dưới mặt nước.',
        rubricPoints: [
          'Nêu được mặt nước phẳng lặng đóng vai trò như một gương phẳng nằm ngang.',
          'Giải thích đúng do tính đối xứng qua mặt gương nằm ngang nên đỉnh tháp ở xa mặt nước hơn chân tháp, tạo ảnh lộn ngược.',
        ],
      },
      {
        id: 'b17-es-6',
        question: 'Câu 6 [Tài liệu Chủ đề Ánh sáng]: Một điểm sáng S đặt cố định trước một gương phẳng OM. Chứng minh rằng khi giữ cố định S và cho gương phẳng quay một góc α quanh điểm O (trên gương) thì đoạn thẳng nối O với ảnh S′ (tức OS′) sẽ quay một góc bằng 2α.',
        hint: 'Xét hai vị trí gương OM và OM′ hợp góc α; do tính đối xứng nên OS = OS′ = OS″.',
        sampleAnswer: '- Gọi S′ là ảnh của S qua gương ở vị trí ban đầu OM, và S″ là ảnh của S qua gương sau khi gương quay một góc α sang vị trí OM′.\n- Do tính đối xứng của ảnh và vật qua gương phẳng nên:\n+ Qua gương OM: OS′ = OS và góc SOM = góc M OS′ (gọi là β₁).\n+ Qua gương OM′: OS″ = OS và góc SOM′ = góc M′OS″ (gọi là β₂ = β₁ + α).\n- Ta có góc quay của ảnh là: góc S′OS″ = góc SOM′ + góc M′OS″ - 2·β₁ = 2·(β₁ + α) - 2·β₁ = 2α.\nVậy khi gương quay một góc α thì ảnh S′ (và tia phản xạ) quay một góc bằng 2α.',
        rubricPoints: [
          'Sử dụng đúng tính chất đối xứng OS = OS′ = OS″.',
          'Chứng minh được góc S′OS″ = 2α.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 18: NAM CHÂM (Tài liệu Chủ đề Từ - Bài 14)
  // =========================================================================
  {
    id: 'kntt-bai-18',
    lessonNumber: 18,
    title: 'Bài 18: Nam châm',
    chapterTitle: 'Chương VI: Từ',
    subject: 'physics',
    pdfUrl: '/assets/aistudio/_C_p_nh_t_m_i__Ch_____T__2d00c081.pdf',
    summary:
      'Nam châm là những vật có từ tính (có khả năng hút các vật liệu từ như sắt, thép, cobalt, nickel). Mỗi nam châm luôn có 2 cực phân biệt: khi để tự do, đầu luôn chỉ hướng Bắc địa lí gọi là cực Bắc (N - North, thường sơn đỏ), đầu chỉ hướng Nam gọi là cực Nam (S - South, thường sơn xanh). Hai cực cùng tên thì đẩy nhau, hai cực khác tên thì hút nhau.',
    keyFormulas: [
      'Vật liệu từ (bị nam châm hút): Sắt (Fe), Thép, Cobalt (Co), Nickel (Ni), Gadolinium...',
      'Vật liệu không có tính chất từ (không bị nam châm hút): Đồng (Cu), Nhôm (Al), Vàng, Bạc, Gỗ, Nhựa, Thủy tinh...',
      'Tương tác giữa hai nam châm: Cùng cực (N – N hoặc S – S) ⇒ Đẩy nhau  |  Khác cực (N – S) ⇒ Hút nhau',
    ],
    mcqs: makeMcqs('b18', [
      ['Nam châm là những vật có đặc tính nào sau đây?', ['Có từ tính (hút được các vật bằng sắt, thép).', 'Có điện tích âm.', 'Tự phát ra ánh sáng.', 'Hút được mọi kim loại kể cả đồng và nhôm.'], 0, 'Nam châm là những vật có từ tính, có thể hút được các vật bằng sắt, thép, cobalt, nickel.'],
      ['Nam châm có thể hút được những vật làm bằng chất nào sau đây, NGOẠI TRỪ:', ['Sắt (Iron).', 'Nhôm (Aluminium).', 'Thép.', 'Niken (Nickel).'], 1, 'Nhôm không phải là vật liệu từ nên không bị nam châm hút.'],
      ['Nam châm KHÔNG hút được vật liệu nào sau đây?', ['Đồng (Copper).', 'Sắt.', 'Coban (Cobalt).', 'Thép.'], 0, 'Đồng không có tính chất từ nên nam châm không hút được đồng.'],
      ['Để nam châm vĩnh cửu không bị mất từ tính, ta nên bảo quản nam châm như thế nào?', ['Để ở nơi có nhiệt độ rất cao (nung nóng trên lửa).', 'Tránh va đập mạnh và không để ở nơi có nhiệt độ cao.', 'Thường xuyên dùng búa đập mạnh vào nam châm.', 'Ngâm trong axit mạnh.'], 1, 'Nhiệt độ cao và va đập mạnh làm nam châm vĩnh cửu bị mất từ tính.'],
      ['Các vật dụng nào sau đây có sử dụng nam châm, NGOẠI TRỪ:', ['La bàn định hướng.', 'Loa điện.', 'Bóng đèn sợi đốt.', 'Bộ phận hít giữ cánh cửa tủ lạnh.'], 2, 'Bóng đèn sợi đốt hoạt động dựa trên tác dụng nhiệt của dòng điện, không sử dụng nam châm.'],
      ['Kí hiệu chữ “N” ghi trên một cực của thanh nam châm là viết tắt của từ tiếng Anh nào (có nghĩa là gì)?', ['Nam.', 'North (Cực Bắc).', 'Nothing.', 'Normal.'], 1, 'Chữ N viết tắt của từ North (hướng Bắc / cực Bắc); chữ S viết tắt của South (hướng Nam / cực Nam).'],
      ['Khi một thanh nam châm hoặc kim nam châm được treo hoặc đặt xoay tự do trên trục thẳng đứng (cách xa các vật từ tính khác), khi cân bằng nó luôn nằm dọc theo hướng nào?', ['Hướng Bắc – Nam.', 'Hướng Đông – Tây.', 'Hướng Đông Bắc – Tây Nam.', 'Hướng bất kì tùy lúc.'], 0, 'Do tác dụng của từ trường Trái Đất, nam châm để tự do luôn định hướng Bắc – Nam.'],
      ['Khi đưa cực Nam (S) của hai thanh nam châm lại gần nhau thì hiện tượng gì xảy ra?', ['Hai cực đẩy nhau.', 'Hai cực hút nhau.', 'Không có lực tương tác.', 'Lúc đầu hút sau đó đẩy.'], 0, 'Hai từ cực cùng tên (S và S) khi đưa lại gần nhau sẽ đẩy nhau.'],
      ['Vật liệu nào sau đây KHÔNG thể dùng để chế tạo nam châm?', ['Sắt và hợp chất của sắt.', 'Niken và hợp chất của niken.', 'Côban và hợp chất của côban.', 'Nhôm và hợp chất của nhôm.'], 3, 'Nhôm không phải là vật liệu từ nên không thể nhiễm từ để làm nam châm.'],
      ['Đặt hai đầu cực của hai thanh nam châm lại gần nhau thấy chúng đẩy nhau. Kết luận nào sau đây là ĐÚNG?', ['Hai cực gần nhau của hai nam châm là hai cực khác tên.', 'Hai cực gần nhau của hai nam châm là hai cực cùng tên (cùng là cực Bắc N hoặc cùng là cực Nam S).', 'Một trong hai thanh không phải là nam châm.', 'Cả hai thanh đều mất từ tính.'], 1, 'Hai cực nam châm đẩy nhau chứng tỏ đó là hai từ cực cùng tên.'],
      ['Nhận định nào sau đây là ĐÚNG về thanh nam châm?', ['Mọi nam châm luôn có hai cực phân biệt (cực Bắc N và cực Nam S).', 'Có thể chế tạo thanh nam châm chỉ có 1 cực Bắc duy nhất.', 'Nam châm hút được cả đồng, nhôm và nhựa.', 'Các cực cùng tên của nam châm thì hút nhau.'], 0, 'Mọi nam châm bao giờ cũng có hai từ cực phân biệt là cực Bắc và cực Nam.'],
      ['Trong các vật liệu: Sắt, Niken, Côban, Nhựa, Gỗ, Đồng. Số vật liệu từ (bị nam châm hút) là:', ['2.', '3 (Sắt, Niken, Côban).', '4.', '5.'], 1, 'Chỉ có Sắt, Niken và Côban là vật liệu từ.'],
      ['Khi đưa hai từ cực khác tên (cực Bắc N của nam châm này và cực Nam S của nam châm kia) lại gần nhau thì chúng sẽ:', ['đẩy nhau.', 'hút nhau.', 'không tương tác.', 'quay tròn.'], 1, 'Các từ cực khác tên thì hút nhau.'],
      ['Khi một thanh nam châm thẳng không may bị gãy làm hai nửa ở chính giữa, nhận định nào sau đây là ĐÚNG?', ['Mỗi nửa chỉ còn lại 1 từ cực duy nhất (một nửa chỉ có cực N, một nửa chỉ có cực S).', 'Cả hai nửa đều mất sạch từ tính.', 'Mỗi nửa đều trở thành một thanh nam châm mới hoàn chỉnh có đủ cả hai cực Bắc (N) và Nam (S) ở hai đầu.', 'Hai nửa biến thành đồng nguyên chất.'], 2, 'Không thể tách rời hai cực của nam châm: khi bị gãy, mỗi nửa lập tức là một nam châm mới có đủ 2 cực N và S.'],
      ['Thông thường trên các thanh nam châm trong phòng thí nghiệm, người ta sơn màu quy ước như thế nào?', ['Cực Bắc (N) sơn màu đỏ, cực Nam (S) sơn màu xanh (hoặc trắng).', 'Cả hai cực đều sơn màu đen.', 'Cực Bắc sơn màu vàng, cực Nam sơn màu tím.', 'Không bao giờ sơn màu.'], 0, 'Quy ước phổ biến: cực Bắc (N) sơn màu đỏ, cực Nam (S) sơn màu xanh lam (hoặc để trắng).'],
      ['Cách đây hơn hai nghìn năm, người Hy Lạp cổ đại đã phát hiện ra một loại quặng sắt tự nhiên có khả năng hút sắt và chỉ hướng, gọi là:', ['Đá vôi.', 'Đá nam châm (quặng Magnetite Fe₃O₄ / đá dẫn đường).', 'Đá thạch anh.', 'Kim cương.'], 1, 'Quặng sắt từ (Magnetite) trong tự nhiên có từ tính được gọi là đá nam châm hay đá dẫn đường.'],
      ['Có hai thanh kim loại A và B bề ngoài giống hệt nhau. Khi đưa bất kì đầu nào của thanh A lại gần bất kì đầu nào của thanh B hoặc đưa vào chính giữa thanh, chúng luôn hút nhau (không bao giờ đẩy nhau). Kết luận nào đúng?', ['Cả hai thanh A và B đều là nam châm.', 'Cả hai thanh đều là đồng.', 'Một trong hai thanh là nam châm, thanh còn lại là sắt (hoặc thép chưa nhiễm từ).', 'Cả hai thanh đều là nhôm.'], 2, 'Nếu cả hai đều là nam châm thì khi đảo đầu cùng cực phải đẩy nhau; vì luôn hút nhau ở mọi đầu nên 1 thanh là nam châm và 1 thanh là sắt/thép.'],
      ['Trên một thanh nam châm thẳng, bộ phận nào hút mạt sắt mạnh nhất?', ['Phần chính giữa của thanh nam châm.', 'Chỉ có duy nhất cực Bắc (N).', 'Chỉ có duy nhất cực Nam (S).', 'Ở cả hai đầu từ cực (cực Bắc N và cực Nam S) hút sắt mạnh nhất.'], 3, 'Từ tính của thanh nam châm tập trung mạnh nhất ở hai đầu từ cực, còn ở chính giữa thanh từ tính rất yếu.'],
      ['Trong bệnh viện, để lấy các mạt sắt nhỏ li ti vô tình bắn vào mắt bệnh nhân một cách nhanh chóng và an toàn, bác sĩ chuyên khoa mắt có thể sử dụng dụng cụ nào?', ['Dùng kìm sắt gắp.', 'Dùng nam châm y tế chuyên dụng đưa lại gần để hút mạt sắt ra.', 'Dùng thanh nhựa.', 'Dùng thanh nhôm.'], 1, 'Vì mạt sắt là vật liệu từ nên nam châm y tế có thể hút mạt sắt ra một cách chính xác, an toàn.'],
      ['Trong hình vẽ thanh nam châm hình chữ U (móng ngựa), chữ “S” ghi trên một đầu cực là viết tắt của từ nào và chỉ cực nào?', ['South – Cực Nam.', 'North – Cực Bắc.', 'Sun – Mặt Trời.', 'Steel – Thép.'], 0, 'Chữ S là viết tắt của South, chỉ cực Nam của nam châm.'],
      ['Một chiếc đinh ốc bằng sắt và một chiếc vỏ lon nước ngọt bằng nhôm để cạnh nhau. Khi đưa thanh nam châm lại gần thì:', ['nam châm hút cả hai vật.', 'nam châm chỉ hút đinh ốc bằng sắt, không hút vỏ lon bằng nhôm.', 'nam châm chỉ hút vỏ lon nhôm.', 'nam châm đẩy cả hai vật ra xa.'], 1, 'Sắt là vật liệu từ nên bị hút; nhôm không phải vật liệu từ nên không bị hút.'],
      ['Có hai thanh kim loại A và B bề ngoài giống hệt nhau, trong đó một thanh là nam châm và một thanh là sắt thường. Nếu KHÔNG dùng thêm bất kì vật nào khác, làm thế nào để biết chắc chắn thanh nào là nam châm?', ['Cân hai thanh xem thanh nào nặng hơn.', 'Đưa một đầu của thanh A chạm vào chính giữa của thanh B: nếu hút mạnh thì A là nam châm; nếu không hút (hoặc hút rất yếu) thì B là nam châm.', 'Đưa hai đầu của A và B lại gần nhau.', 'Nhìn màu sắc của hai thanh.'], 1, 'Phần chính giữa của thanh nam châm hầu như không có từ tính, còn hai đầu cực của nam châm hút rất mạnh.'],
      ['Một cách khác để nhận biết một thanh kim loại có phải là nam châm hay không là:', ['Dùng sợi chỉ mềm buộc vào chính giữa thanh rồi treo lên cho nằm ngang tự do: nếu khi cân bằng thanh luôn quay về hướng Bắc – Nam thì đó là nam châm.', 'Đun nóng thanh kim loại.', 'Thả thanh kim loại vào chậu nước.', 'Chiếu đèn pin vào thanh kim loại.'], 0, 'Nam châm treo tự do luôn định hướng Bắc – Nam theo từ trường Trái Đất.'],
      ['Khi chạm đầu tuốc-nơ-vít (làm bằng thép) vào cực của một thanh nam châm mạnh, sau khi lấy ra ta thấy đầu tuốc-nơ-vít hút được các đinh ốc nhỏ bằng sắt. Đó là vì:', ['đầu tuốc-nơ-vít có keo dính.', 'tuốc-nơ-vít bằng thép đã bị nhiễm từ và trở thành một nam châm.', 'đinh ốc tự bay lên.', 'tuốc-nơ-vít biến thành đồng.'], 1, 'Thép là vật liệu từ cứng, khi tiếp xúc với nam châm sẽ bị nhiễm từ và giữ được từ tính lâu dài.'],
      ['Để dọn sạch các đinh sắt rơi vãi trên mặt đường giao thông, xe vệ sinh môi trường thường gắn bộ phận gì ở phía dưới gầm xe?', ['Một tấm gỗ phẳng.', 'Một thanh nam châm lớn gắn sát mặt đường để hút hết đinh sắt.', 'Một chiếc gương phẳng.', 'Một chiếc chổi lông gà.'], 1, 'Thanh nam châm lớn giúp hút sạch các đinh sắt, mảnh thép sắc nhọn trên đường.'],
      ['Khi một thanh nam châm bị tróc hết lớp sơn đánh dấu tên cực (N, S), ta có thể xác định lại tên cực của nó bằng cách nào?', ['Đưa một đầu thanh nam châm đó lại gần cực Bắc (N) của một thanh nam châm chuẩn đã biết cực: nếu đẩy nhau thì đầu đó là cực Bắc (N), nếu hút nhau thì đầu đó là cực Nam (S).', 'Đưa lại gần một thanh sắt xem đầu nào hút sắt.', 'Đưa lại gần một thanh đồng.', 'Cân khối lượng hai đầu.'], 0, 'Dựa vào tương tác từ (cùng cực đẩy, khác cực hút) với một nam châm đã biết tên cực (hoặc treo tự do tìm hướng Bắc - Nam).'],
      ['Vì sao người ta khuyên không nên đặt nam châm mạnh sát cạnh màn hình tivi CRT cổ điển, ổ cứng từ tính hoặc thẻ từ ATM?', ['Vì nam châm làm trầy xước vỏ nhựa.', 'Vì từ tính mạnh của nam châm làm nhiễu loạn hoặc làm hỏng dữ liệu từ tính trong các thiết bị đó.', 'Vì nam châm làm nóng chảy nhựa.', 'Vì nam châm phát ra sóng âm.'], 1, 'Lực từ của nam châm có thể làm xóa dữ liệu trên dải từ của thẻ ATM, ổ cứng từ hoặc làm lệch tia điện tử.'],
      ['Ba thanh nam châm A–B, C–D, E–F được đặt gần nhau. Biết đầu A là cực Bắc (N); đầu B hút đầu C; đầu D đẩy đầu E. Tên từ cực của các đầu B, C, D, E, F lần lượt là:', ['B(S), C(N), D(S), E(S), F(N).', 'B(N), C(S), D(N), E(S), F(N).', 'B(S), C(S), D(N), E(N), F(S).', 'B(S), C(N), D(S), E(N), F(S).'], 0, 'A là N ⇒ B là S. B(S) hút C ⇒ C là N và D là S. D(S) đẩy E ⇒ E là S và F là N.'],
      ['Nhà máy phân loại rác thải tái chế muốn tách riêng các mảnh vụn sắt, thép ra khỏi hỗn hợp vụn nhôm, đồng và nhựa. Phương pháp đơn giản và hiệu quả nhất là:', ['Đổ toàn bộ vào nước.', 'Cho băng chuyền rác đi qua dưới một nam châm lớn để hút riêng sắt và thép ra.', 'Dùng quạt thổi.', 'Dùng kính lúp nhặt từng mảnh.'], 1, 'Nam châm chỉ hút sắt và thép, không hút nhôm, đồng và nhựa.'],
      ['Trong loa điện hoặc tai nghe, nam châm được sử dụng để:', ['tạo ra từ trường tương tác với cuộn dây có dòng điện làm màng loa dao động phát ra âm thanh.', 'tạo ra ánh sáng cho loa.', 'giữ cho thùng loa nặng hơn.', 'ngăn cản dòng điện đi vào loa.'], 0, 'Sự tương tác từ giữa nam châm và ống dây làm màng loa dao động theo tín hiệu âm thanh.'],
    ]),
    trueFalseList: [
      {
        id: 'b18-tf-1',
        stem: 'Xét tính chất từ của nam châm và sự phân loại vật liệu từ:',
        statements: [
          { id: 'a', text: 'Nam châm là những vật có từ tính, có khả năng hút được các vật bằng sắt, thép, cobalt và nickel.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Nam châm vĩnh cửu hút được tất cả các kim loại trong tự nhiên như vàng, bạc, đồng, nhôm.', isTrue: false, explanation: 'Sai, vàng, bạc, đồng, nhôm không phải là vật liệu từ nên không bị nam châm hút.' },
          { id: 'c', text: 'Trên một thanh nam châm thẳng, lực hút sắt mạnh nhất tập trung ở hai đầu từ cực (N và S).', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Nếu nung nóng nam châm ở nhiệt độ cao hoặc đập mạnh nhiều lần thì nam châm có thể bị mất từ tính.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b18-tf-2',
        stem: 'Xét sự định hướng và tương tác giữa hai thanh nam châm:',
        statements: [
          { id: 'a', text: 'Khi để một thanh nam châm xoay tự do ở trạng thái cân bằng, đầu luôn chỉ hướng Bắc địa lí gọi là cực Bắc (kí hiệu N), đầu chỉ hướng Nam gọi là cực Nam (kí hiệu S).', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Khi đưa hai cực cùng tên (N với N, hoặc S với S) của hai nam châm lại gần nhau thì chúng hút nhau.', isTrue: false, explanation: 'Sai, hai từ cực cùng tên thì đẩy nhau.' },
          { id: 'c', text: 'Khi đưa hai cực khác tên (N với S) của hai nam châm lại gần nhau thì chúng hút nhau.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Nếu cưa đôi một thanh nam châm thẳng ở chính giữa, ta thu được một nửa chỉ có cực Bắc (N) và một nửa chỉ có cực Nam (S).', isTrue: false, explanation: 'Sai, mỗi nửa sau khi cắt đều là một nam châm mới có đủ cả hai cực Bắc (N) và Nam (S).' },
        ],
      },
      {
        id: 'b18-tf-3',
        stem: 'Có hai thanh kim loại A và B hình dạng bên ngoài giống hệt nhau, trong đó có một thanh là nam châm vĩnh cửu và một thanh là sắt non không nhiễm từ:',
        statements: [
          { id: 'a', text: 'Nếu đưa một đầu của thanh A lại gần một đầu của thanh B thấy chúng hút nhau thì kết luận ngay A chắc chắn là nam châm.', isTrue: false, explanation: 'Sai, vì dù A là nam châm hay B là nam châm thì đầu của hai thanh vẫn hút nhau.' },
          { id: 'b', text: 'Nếu dùng sợi chỉ buộc vào chính giữa từng thanh và treo lên tự do (xa nhau), thanh nào luôn tự xoay định hướng Bắc – Nam thì thanh đó là nam châm.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Nếu đưa một đầu của thanh A chạm vào chính giữa của thanh B mà thấy hút mạnh thì thanh A chính là nam châm.', isTrue: true, explanation: 'Đúng, vì đầu thanh A có từ tính mạnh (là cực của nam châm), còn nếu A là sắt chạm vào giữa nam châm B (nơi từ tính rất yếu) thì hầu như không hút.' },
          { id: 'd', text: 'Dù đảo đầu nào của hai thanh A và B lại gần nhau thì chúng cũng chỉ hút nhau chứ không bao giờ đẩy nhau.', isTrue: true, explanation: 'Đúng vì một thanh là nam châm còn thanh kia là sắt (không có từ cực cố định).' },
        ],
      },
      {
        id: 'b18-tf-4',
        stem: 'Một thanh nam châm bị mờ hết chữ N, S và tróc hết sơn màu ở hai đầu A và B. Một học sinh đưa đầu A của thanh nam châm này lại gần cực Bắc (N) của một kim nam châm chuẩn thì thấy cực Bắc của kim nam châm bị đẩy ra xa:',
        statements: [
          { id: 'a', text: 'Đầu A của thanh nam châm là cực Bắc (N).', isTrue: true, explanation: 'Đúng vì cùng cực (N – N) mới đẩy nhau.' },
          { id: 'b', text: 'Đầu B còn lại của thanh nam châm là cực Nam (S).', isTrue: true, explanation: 'Đúng vì mỗi thanh nam châm có 2 cực N và S ở hai đầu.' },
          { id: 'c', text: 'Nếu đưa đầu B của thanh nam châm lại gần cực Bắc (N) của kim nam châm chuẩn thì chúng cũng đẩy nhau.', isTrue: false, explanation: 'Sai, đầu B là cực Nam (S) nên sẽ hút cực Bắc (N) của kim nam châm chuẩn.' },
          { id: 'd', text: 'Nếu treo thanh nam châm AB nằm ngang tự do bằng sợi chỉ không xoắn thì khi đứng yên đầu A sẽ hướng về phía Bắc địa lí.', isTrue: true, explanation: 'Đúng vì đầu A là cực Bắc (N).' },
        ],
      },
      {
        id: 'b18-tf-5',
        stem: 'Xét các ứng dụng thực tế của nam châm trong đời sống và kĩ thuật:',
        statements: [
          { id: 'a', text: 'Kim của la bàn chính là một kim nam châm nhỏ quay tự do trên trục nhọn.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Khi chạm đầu tuốc-nơ-vít bằng thép vào thanh nam châm, tuốc-nơ-vít bị nhiễm từ nên hút giữ được các đinh vít nhỏ bằng sắt giúp người thợ vặn ốc dễ dàng.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Đi-na-mô xe đạp sử dụng một núm quay làm quay nam châm vĩnh cửu bên cạnh cuộn dây để phát ra điện thắp sáng đèn xe.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Ta có thể dùng nam châm để hút các đồng xu làm bằng đồng nguyên chất hoặc nhôm rơi dưới khe hẹp.', isTrue: false, explanation: 'Sai, đồng và nhôm không phải vật liệu từ nên nam châm không hút được.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b18-es-1',
        question: 'Câu 1 [Tài liệu Chủ đề Từ]:\n(a) Nam châm là gì? Hãy kể tên 4 vật liệu từ (bị nam châm hút) và 4 vật liệu không có tính chất từ.\n(b) Kể tên 5 ứng dụng của nam châm trong đời sống và kĩ thuật.',
        hint: 'Phân biệt nhóm sắt từ (Fe, thép, Co, Ni) và nhóm phi từ (Cu, Al, nhựa, gỗ...).',
        sampleAnswer: '(a) Nam châm là những vật có từ tính, có khả năng hút được các vật bằng sắt, thép.\n- 4 vật liệu từ: Sắt (Iron), Thép, Côban (Cobalt), Niken (Nickel).\n- 4 vật liệu không phải vật liệu từ: Đồng, Nhôm, Nhựa, Gỗ (hoặc Thủy tinh).\n(b) 5 ứng dụng của nam châm trong đời sống: Chế tạo la bàn định hướng, loa điện, đi-na-mô phát điện xe đạp, nam châm hít giữ cửa tủ lạnh, đầu tuốc-nơ-vít từ tính giữ ốc vít (hoặc xe hút đinh trên đường).',
        rubricPoints: [
          'Nêu đúng khái niệm nam châm, 4 vật liệu từ và 4 vật liệu không từ tính.',
          'Kể đúng 5 ứng dụng thực tế của nam châm.',
        ],
      },
      {
        id: 'b18-es-2',
        question: 'Câu 2 [Tài liệu Chủ đề Từ]: Một thanh nam châm thẳng lâu ngày bị tróc hết lớp sơn màu và mất kí hiệu N, S ở hai đầu. Hãy trình bày 2 cách khác nhau để xác định lại đâu là cực Bắc (N) và đâu là cực Nam (S) của thanh nam châm đó.',
        hint: 'Cách 1: Dựa vào sự định hướng Bắc – Nam tự do; Cách 2: Dùng một nam châm chuẩn đã biết cực.',
        sampleAnswer: 'Hai cách xác định tên từ cực của thanh nam châm bị mất dấu:\n- Cách 1 (Dựa vào sự định hướng trong từ trường Trái Đất): Dùng một sợi chỉ mềm không xoắn buộc vào chính giữa thanh nam châm rồi treo lên cho thanh nằm ngang tự do (tránh xa các vật bằng sắt và nam châm khác). Khi thanh đứng yên cân bằng, đầu nào quay về hướng Bắc địa lí là cực Bắc (N), đầu quay về hướng Nam địa lí là cực Nam (S).\n- Cách 2 (Dùng một nam châm thử đã biết tên cực): Đưa cực Bắc (N) của nam châm đã biết cực lại gần một đầu của thanh nam châm cần thử: nếu hai đầu đẩy nhau thì đầu đó là cực Bắc (N); nếu hút nhau thì đầu đó là cực Nam (S).',
        rubricPoints: [
          'Trình bày đúng Cách 1: treo tự do bằng sợi chỉ để tìm hướng Bắc – Nam.',
          'Trình bày đúng Cách 2: đưa lại gần một nam châm đã biết cực (dựa vào hút/đẩy).',
        ],
      },
      {
        id: 'b18-es-3',
        question: 'Câu 3 [Tài liệu Chủ đề Từ]: Có hai thanh kim loại A và B bề ngoài giống hệt nhau, trong đó một thanh là nam châm và một thanh là sắt thường.\n(a) Nếu thấy hai thanh hút nhau thì có kết luận được thanh nào là nam châm không? Tại sao?\n(b) Trình bày cách nhận biết thanh nào là nam châm mà KHÔNG dùng thêm bất kì dụng cụ nào khác.',
        hint: 'Sử dụng đặc điểm: ở chính giữa thanh nam châm từ tính rất yếu (hầu như không hút sắt).',
        sampleAnswer: '(a) Nếu chỉ đưa hai đầu của hai thanh lại gần nhau và thấy hút nhau thì chưa thể kết luận thanh nào là nam châm, vì nam châm hút sắt và sắt cũng bị nam châm hút với lực như nhau.\n(b) Cách nhận biết không cần dụng cụ phụ: Cầm thanh A, đưa một đầu của thanh A chạm vuông góc vào phần CHÍNH GIỮA của thanh B (tạo hình chữ T):\n- Nếu thấy chúng hút nhau mạnh ⇒ Đầu thanh A có từ tính mạnh, vậy thanh A là nam châm (thanh B là sắt).\n- Nếu thấy chúng không hút nhau (hoặc hút rất yếu) ⇒ Chỗ chính giữa của thanh B là vùng trung hòa từ của nam châm, vậy thanh B là nam châm (thanh A là sắt).',
        rubricPoints: [
          'Giải thích đúng câu (a) vì tương tác giữa hai đầu đều là lực hút.',
          'Trình bày đúng phương pháp hình chữ T chạm vào chính giữa thanh kia ở câu (b).',
        ],
      },
      {
        id: 'b18-es-4',
        question: 'Câu 4 [Tài liệu Chủ đề Từ]:\n(a) Nêu cách bảo quản nam châm vĩnh cửu trong phòng thí nghiệm để phòng tránh mất từ tính.\n(b) Khi chạm đầu tuốc-nơ-vít bằng thép vào thanh nam châm thì sau đó đầu tuốc-nơ-vít hút được các ốc vít nhỏ bằng sắt. Hãy giải thích tại sao?',
        hint: '(a) Lưu ý nhiệt độ, va đập và cách xếp các cực; (b) Hiện tượng nhiễm từ của thép.',
        sampleAnswer: '(a) Cách bảo quản nam châm:\n- Không nung nóng nam châm, không để ở nơi có nhiệt độ cao.\n- Không làm rơi, không gõ đập mạnh vào nam châm.\n- Khi cất giữ hai thanh nam châm cạnh nhau, nên đặt hai cực khác tên (N và S) nằm sát nhau và đặt miếng sắt non nối hai đầu cực.\n(b) Giải thích hiện tượng ở tuốc-nơ-vít: Đầu tuốc-nơ-vít được làm bằng thép (là vật liệu từ cứng). Khi chạm vào thanh nam châm, đầu tuốc-nơ-vít bị nhiễm từ và giữ được từ tính trở thành một nam châm vĩnh cửu nhỏ nên hút được các ốc vít bằng sắt.',
        rubricPoints: [
          'Nêu đúng các nguyên tắc bảo quản nam châm ở câu (a).',
          'Giải thích đúng hiện tượng thép bị nhiễm từ trở thành nam châm ở câu (b).',
        ],
      },
      {
        id: 'b18-es-5',
        question: 'Câu 5 [Tài liệu Chủ đề Từ]: Một học sinh làm rơi một chiếc kim khâu bằng thép vào trong một lọ đựng đầy các hạt cườm bằng thủy tinh và hạt nhựa nhỏ. Hãy nêu cách nhanh nhất và an toàn nhất để lấy chiếc kim khâu ra mà không cần đổ các hạt ra ngoài hay thò tay vào lọ tìm (dễ bị kim đâm).',
        hint: 'So sánh tính chất từ của thép (kim khâu) với thủy tinh và nhựa.',
        sampleAnswer: '- Cách làm: Đưa một thanh nam châm vào miệng lọ hoặc áp thanh nam châm vào mặt ngoài thành lọ rồi di chuyển dọc theo thành lọ lên miệng lọ.\n- Giải thích: Chiếc kim khâu làm bằng thép (vật liệu từ) nên sẽ bị thanh nam châm hút tách ra khỏi các hạt thủy tinh và hạt nhựa (không phải vật liệu từ), giúp lấy chiếc kim ra nhanh chóng và an toàn tuyệt đối.',
        rubricPoints: [
          'Đề xuất đúng cách dùng nam châm hút kim khâu.',
          'Giải thích đúng kim khâu bằng thép là vật liệu từ còn thủy tinh/nhựa không bị hút.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 19 & 20: TỪ TRƯỜNG – CHẾ TẠO NAM CHÂM ĐIỆN (Tài liệu Chủ đề Từ - Bài 15)
  // =========================================================================
  {
    id: 'kntt-bai-19',
    lessonNumber: 19,
    title: 'Bài 19 & 20: Từ trường – Chế tạo nam châm điện đơn giản',
    chapterTitle: 'Chương VI: Từ',
    subject: 'physics',
    pdfUrl: '/assets/aistudio/_C_p_nh_t_m_i__Ch_____T__2d00c081.pdf',
    summary:
      'Không gian xung quanh nam châm và xung quanh dòng điện có từ trường (tác dụng lực từ lên kim nam châm đặt trong nó). Từ phổ là hình ảnh các đường mạt sắt xung quanh nam châm. Đường sức từ ở bên ngoài nam châm có chiều đi ra từ cực Bắc (N) và đi vào cực Nam (S). Nam châm điện gồm ống dây dẫn có dòng điện chạy qua và lõi sắt non bên trong.',
    keyFormulas: [
      'Chiều đường sức từ bên ngoài nam châm:  Đi ra từ cực Bắc (N) → Đi vào cực Nam (S)',
      'Độ mạnh yếu của từ trường:  Đường sức từ (mạt sắt) dày ⇒ Từ trường mạnh (ở gần 2 cực);  Đường sức từ thưa ⇒ Từ trường yếu',
      'Tăng lực từ của nam châm điện:  (1) Tăng số vòng dây của ống dây;  (2) Tăng cường độ dòng điện (tăng số pin)',
    ],
    mcqs: makeMcqs('b19', [
      ['Từ phổ là hình ảnh trực quan cụ thể về:', ['các đường sức điện.', 'các đường sức từ (từ trường).', 'cường độ dòng điện.', 'ánh sáng truyền thẳng.'], 1, 'Hình ảnh các đường mạt sắt tự sắp xếp xung quanh nam châm gọi là từ phổ, cho hình ảnh trực quan về từ trường và đường sức từ.'],
      ['Lực tác dụng của nam châm lên các vật liệu có từ tính và lên các nam châm khác được gọi là:', ['lực từ.', 'lực hấp dẫn.', 'lực ma sát.', 'lực đàn hồi.'], 0, 'Lực tác dụng của nam châm lên các vật từ tính hoặc nam châm khác gọi là lực từ.'],
      ['Độ dày, thưa của các đường sức từ trên cùng một hình vẽ cho ta biết điều gì về từ trường?', ['Chỗ đường sức từ càng dày thì từ trường càng yếu.', 'Chỗ đường sức từ càng dày thì từ trường càng mạnh, chỗ càng thưa thì từ trường càng yếu.', 'Mọi nơi trong từ trường đều mạnh như nhau.', 'Độ dày thưa chỉ để vẽ cho đẹp.'], 1, 'Nơi nào từ trường mạnh thì đường sức từ (và mạt sắt) sắp xếp dày; nơi nào từ trường yếu thì đường sức từ thưa.'],
      ['Chọn phát biểu ĐÚNG về cách thu nhận từ phổ:', ['Có thể thu được từ phổ bằng cách rắc mạt sắt lên tấm nhựa cứng đặt trong từ trường của nam châm rồi gõ nhẹ.', 'Có thể thu được từ phổ bằng cách rắc bột mì hoặc cát lên tấm bìa.', 'Nơi nào mạt sắt tập trung dày thì từ trường ở đó yếu.', 'Từ phổ chỉ xuất hiện trong chân không.'], 0, 'Mạt sắt trong từ trường bị nhiễm từ và sắp xếp thành các đường cong nối từ cực này sang cực kia khi gõ nhẹ tấm nhựa.'],
      ['Đường sức từ là những đường cong được vẽ theo quy ước sao cho ở bên ngoài thanh nam châm:', ['có chiều đi từ cực Nam (S) tới cực Bắc (N).', 'có chiều tùy ý.', 'có chiều đi ra từ cực Bắc (N) và đi vào cực Nam (S) của nam châm.', 'là những đường thẳng cắt nhau.'], 2, 'Quy ước chiều đường sức từ bên ngoài nam châm: đi ra từ cực Bắc (N) và đi vào cực Nam (S).'],
      ['Chiều của đường sức từ tại một điểm cho ta biết:', ['chiều chuyển động của thanh nam châm.', 'hướng của lực từ tác dụng lên cực Bắc (N) của kim nam châm thử đặt cân bằng tại điểm đó.', 'nhiệt độ của nam châm.', 'khối lượng của nam châm.'], 1, 'Tại mỗi điểm, cực Bắc của kim nam châm thử nằm cân bằng luôn chỉ theo chiều của đường sức từ tại điểm đó.'],
      ['Quan sát hình vẽ đường sức từ của một thanh nam châm thẳng có hai đầu A và B: thấy các mũi tên đường sức từ đi ra từ đầu B và đi vào đầu A. Tên các cực từ của nam châm là:', ['A là cực Bắc (N), B là cực Nam (S).', 'A là cực Nam (S), B là cực Bắc (N).', 'Cả A và B đều là cực Bắc.', 'Cả A và B đều là cực Nam.'], 1, 'Theo quy ước “ra Bắc vào Nam”, đường sức từ đi ra từ B và đi vào A nên B là cực Bắc (N) và A là cực Nam (S).'],
      ['Phát biểu nào sau đây là ĐÚNG khi đặt kim nam châm thử trong từ trường của một thanh nam châm?', ['Tại mỗi vị trí nhất định trong từ trường, kim nam châm thử có thể chỉ theo bất kì hướng nào.', 'Tại mọi vị trí khác nhau xung quanh thanh nam châm, các kim nam châm thử đều song song với nhau.', 'Tại mỗi vị trí nhất định trong từ trường (trừ các điểm rất xa), kim nam châm thử luôn chỉ một hướng xác định.', 'Kim nam châm thử quay tròn liên tục không bao giờ dừng lại.'], 2, 'Tại mỗi vị trí xác định trong từ trường, kim nam châm thử khi cân bằng luôn chỉ một hướng xác định (tiếp tuyến với đường sức từ).'],
      ['Xung quanh một thanh nam châm thẳng có 4 điểm: Điểm 1 ở ngay sát đầu cực Nam (S); Điểm 2 ở xa đầu cực S; Điểm 3 và Điểm 4 ở phía trên phần giữa thanh nam châm. Lực từ tác dụng lên kim nam châm đặt ở điểm nào là mạnh nhất?', ['Điểm 1 (ngay sát từ cực của nam châm).', 'Điểm 2.', 'Điểm 3.', 'Điểm 4.'], 0, 'Ở ngay sát hai đầu cực của nam châm, các đường sức từ dày nhất nên từ trường mạnh nhất.'],
      ['Trong khoảng không gian nằm giữa hai nhánh của một nam châm hình chữ U (móng ngựa), các đường sức từ có đặc điểm gì?', ['Là những đường cong cắt nhau.', 'Là những đường thẳng gần như song song và cách đều nhau (từ trường đều).', 'Không có đường sức từ nào.', 'Là những đường tròn đồng tâm.'], 1, 'Trong lòng nam châm chữ U, các đường sức từ là những đường thẳng song song cách đều nhau hướng từ cực N sang cực S.'],
      ['Không gian xung quanh nam châm và xung quanh dòng điện tồn tại:', ['từ trường.', 'trọng trường.', 'chân không.', 'ánh sáng.'], 0, 'Không gian xung quanh nam châm và xung quanh dòng điện có khả năng tác dụng lực từ lên kim nam châm đặt trong nó, gọi là từ trường.'],
      ['Dụng cụ chuẩn thường dùng để nhận biết sự tồn tại của từ trường tại một điểm trong không gian là:', ['nhiệt kế.', 'kim nam châm (nam châm thử).', 'thước đo độ.', 'gương phẳng.'], 1, 'Người ta dùng kim nam châm (nam châm thử) để nhận biết từ trường: nơi nào kim nam châm bị lệch khỏi hướng Bắc – Nam thì nơi đó có từ trường.'],
      ['Càng ra xa thanh nam châm thì các đường mạt sắt (và đường sức từ) càng:', ['dày hơn và từ trường mạnh hơn.', 'thưa dần và từ trường yếu dần.', 'chồng chéo lên nhau.', 'nóng lên.'], 1, 'Càng xa nam châm, từ trường càng yếu nên các đường mạt sắt càng thưa dần.'],
      ['Đường sức từ KHÔNG có tính chất nào sau đây?', ['Qua mỗi điểm trong từ trường chỉ vẽ được một đường sức từ.', 'Bên ngoài nam châm, đường sức từ có chiều đi ra từ cực Bắc và đi vào cực Nam.', 'Nơi từ trường mạnh thì đường sức từ dày, nơi từ trường yếu thì đường sức từ thưa.', 'Các đường sức từ của cùng một từ trường có thể cắt nhau tại nhiều điểm.'], 3, 'Tại mỗi điểm từ trường chỉ có một hướng xác định nên hai đường sức từ không bao giờ cắt nhau (câu D sai).'],
      ['Cấu tạo của một nam châm điện đơn giản bao gồm:', ['Một ống dây dẫn có dòng điện chạy qua và một lõi sắt non lồng bên trong ống dây.', 'Chỉ một thanh đồng nối với nguồn điện.', 'Một ống nhựa rỗng không có dây dẫn.', 'Một thanh nam châm vĩnh cửu không cần nguồn điện.'], 0, 'Nam châm điện gồm ống dây dẫn nối với nguồn điện và một lõi sắt non bên trong ống dây.'],
      ['Tại sao lõi của nam châm điện thường làm bằng sắt non mà KHÔNG làm bằng thép?', ['Vì sắt non đắt hơn thép.', 'Vì khi ngắt dòng điện, sắt non mất hết từ tính ngay lập tức; còn thép vẫn giữ từ tính lâu dài nên không điều khiển đóng/nhả vật được.', 'Vì thép không dẫn từ.', 'Vì sắt non nhẹ hơn nhựa.'], 1, 'Sắt non mất từ tính ngay khi ngắt dòng điện, giúp nam châm điện dễ dàng nhả các vật sắt sau khi di chuyển xong.'],
      ['Vật dụng nào sau đây KHÔNG phải là ứng dụng của nam châm điện?', ['Cần cẩu điện bốc dỡ sắt thép.', 'Chuông điện báo hiệu.', 'Máy chụp cộng hưởng từ (MRI) và tàu đệm từ.', 'Chiếc compa vẽ đường tròn bằng nhôm.'], 3, 'Compa học sinh chỉ là dụng cụ cơ học vẽ đường tròn, không có nam châm điện.'],
      ['Ưu điểm nổi bật của nam châm điện so với nam châm vĩnh cửu là gì?', ['Có thể tăng lực từ rất mạnh (bằng cách tăng dòng điện, tăng số vòng dây), có thể bật/tắt từ tính và đảo tên cực từ dễ dàng.', 'Hoạt động mãi mãi không cần nguồn điện.', 'Không bao giờ bị nóng.', 'Hút được cả nhựa và gỗ.'], 0, 'Nam châm điện điều khiển được lực từ, đóng/ngắt từ tính bằng công tắc và đổi cực bằng cách đổi chiều dòng điện.'],
      ['Trong thí nghiệm chế tạo nam châm điện đơn giản, khi NGẮT công tắc điện (không có dòng điện chạy qua ống dây) thì:', ['nam châm điện hút được nhiều ghim giấy hơn.', 'xung quanh ống dây và đinh sắt không còn từ trường nên các ghim giấy sắt rơi xuống.', 'chiều từ trường bị đảo ngược.', 'đinh sắt nóng chảy.'], 1, 'Từ trường của nam châm điện chỉ tồn tại khi có dòng điện chạy trong ống dây.'],
      ['Trong thí nghiệm nam châm điện, khi giữ nguyên ống dây nhưng tăng số pin của nguồn điện (tăng cường độ dòng điện chạy qua ống dây) và đóng công tắc thì:', ['lực từ không thay đổi.', 'nam châm điện hút được nhiều ghim giấy bằng sắt hơn do lực từ tăng lên.', 'nam châm điện hút được ít ghim giấy hơn.', 'nam châm điện ngừng hoạt động.'], 1, 'Khi tăng cường độ dòng điện (hoặc tăng số vòng dây), từ trường của nam châm điện mạnh lên nên hút được nhiều ghim sắt hơn.'],
      ['Nếu đổi chiều dòng điện chạy qua ống dây của nam châm điện (bằng cách đảo hai cực của pin nối với hai đầu ống dây) thì:', ['chiều từ trường không thay đổi.', 'hai từ cực (Bắc N và Nam S) của nam châm điện sẽ đổi chỗ cho nhau (chiều từ trường thay đổi).', 'nam châm điện mất hết từ tính.', 'lực từ tăng gấp đôi.'], 1, 'Khi đổi chiều dòng điện chạy trong ống dây thì chiều đường sức từ và tên hai cực từ của nam châm điện cũng đổi ngược lại.'],
      ['Kết luận nào sau đây là ĐÚNG về từ trường của nam châm điện?', ['Từ trường của nam châm điện chỉ tồn tại trong thời gian có dòng điện chạy trong ống dây; khi dòng điện thay đổi (độ lớn, chiều) thì từ trường cũng thay đổi.', 'Từ trường của nam châm điện tồn tại vĩnh viễn kể cả khi tháo pin.', 'Từ trường của nam châm điện không phụ thuộc vào số vòng dây.', 'Nam châm điện không có cực Bắc và cực Nam.'], 0, 'Từ trường nam châm điện phụ thuộc trực tiếp vào dòng điện chạy trong ống dây.'],
      ['Cần cẩu dùng nam châm điện ở các cảng biển, nhà máy thép hoạt động theo nguyên tắc nào để di chuyển sắt thép?', ['Đóng công tắc điện để nam châm điện hút sắt thép lên, di chuyển đến vị trí mới rồi ngắt công tắc điện để nam châm mất từ tính và nhả sắt thép xuống.', 'Dùng móc câu từng mảnh sắt.', 'Ngắt điện để hút sắt, đóng điện để nhả sắt.', 'Dùng nam châm vĩnh cửu rồi lấy búa gỡ sắt ra.'], 0, 'Nhờ khả năng đóng/ngắt từ tính tức thời bằng dòng điện, cần cẩu điện nâng hạ hàng tấn sắt thép rất nhanh chóng.'],
      ['Trong sơ đồ cấu tạo chuông điện, khi nhấn và giữ công tắc, búa gõ liên tục vào chuông phát ra tiếng reo là vì:', ['mạch điện tự động đóng – ngắt liên tục nhờ lõi sắt nam châm điện hút lá thép đàn hồi làm hở tiếp điểm, rồi lá thép lại bật về đóng tiếp điểm.', 'búa gõ tự quay tròn theo chiều kim đồng hồ.', 'chuông điện làm bằng nhôm bị đẩy ra.', 'pin phát ra âm thanh.'], 0, 'Khi mạch kín, nam châm điện hút thanh sắt làm búa gõ vào chuông đồng thời làm hở tiếp điểm ngắt điện; nam châm mất từ tính, lá thép đàn hồi kéo thanh sắt về đóng tiếp điểm lại, quá trình lặp lại liên tục.'],
      ['Có hai ống dây dẫn có lõi sắt non giống hệt nhau: Ống dây (1) quấn 100 vòng dây và nối với nguồn 1,5 V; Ống dây (2) quấn 250 vòng dây và nối với nguồn 3,0 V. So sánh lực từ của hai nam châm điện này:', ['Nam châm điện (1) mạnh hơn nam châm điện (2).', 'Nam châm điện (2) có lực từ mạnh hơn hẳn nam châm điện (1).', 'Hai nam châm điện mạnh bằng nhau.', 'Cả hai đều không có từ tính.'], 1, 'Ống dây (2) có cả số vòng dây nhiều hơn (250 > 100) và điện áp/dòng điện lớn hơn (3,0 V > 1,5 V) nên lực từ mạnh hơn hẳn.'],
      ['Làm thế nào để xác định đầu nào của chiếc đinh sắt trong nam châm điện là cực Bắc (N), đầu nào là cực Nam (S) khi đang đóng công tắc điện?', ['Đưa một kim nam châm thử lại gần một đầu đinh sắt: nếu đầu đó hút cực Nam (S) của kim nam châm thử thì đầu đinh sắt đó là cực Bắc (N).', 'Đếm số vòng dây đồng.', 'Đo chiều dài đinh sắt.', 'Nhìn màu sắc của dây đồng.'], 0, 'Dùng kim nam châm thử dựa vào quy tắc: cực khác tên hút nhau, cực cùng tên đẩy nhau.'],
      ['Một học sinh có một cục pin để lâu ngày và một đoạn dây dẫn đồng, không có bóng đèn nhưng có một kim nam châm thử. Học sinh đó có thể kiểm tra pin còn điện hay không bằng cách nào?', ['Đặt cục pin lên kim nam châm.', 'Nối hai đầu dây dẫn vào hai cực của pin (chạm nhanh) đồng thời đặt đoạn dây dẫn gần và song song với kim nam châm: nếu kim nam châm bị lệch khỏi hướng Bắc – Nam thì pin còn điện.', 'Dùng dây đồng buộc cục pin treo lên.', 'Không thể kiểm tra được.'], 1, 'Nếu pin còn điện, dòng điện chạy qua dây dẫn sẽ sinh ra từ trường làm kim nam châm đặt gần đó quay lệch khỏi hướng Bắc – Nam.'],
      ['Trong y học hiện đại, thiết bị chẩn đoán hình ảnh nào ứng dụng từ trường mạnh của nam châm điện siêu dẫn kết hợp sóng vô tuyến để chụp chi tiết các mô mềm và não bộ?', ['Nhiệt kế thủy ngân.', 'Máy chụp cộng hưởng từ (MRI).', 'Ống nghe nhịp tim.', 'Máy đo huyết áp cơ học.'], 1, 'MRI (Magnetic Resonance Imaging) là kĩ thuật chụp cộng hưởng từ sử dụng nam châm điện từ trường mạnh.'],
      ['Khi đặt hai thanh nam châm thẳng nằm dọc trên cùng một đường thẳng sao cho cực Bắc (N) của thanh thứ nhất đối diện gần với cực Bắc (N) của thanh thứ hai thì các đường sức từ ở khoảng giữa hai cực N – N sẽ:', ['đi thẳng từ cực N này sang cực N kia.', 'uốn cong tỏa ra hai bên (đẩy dạt ra xa nhau), ở chính giữa hai cực N – N các đường sức từ rất thưa.', 'xoắn lại thành hình lò xo.', 'biến mất hoàn toàn xung quanh hai nam châm.'], 1, 'Vì hai cực cùng tên (N – N) đẩy nhau nên các đường sức từ đi ra từ hai cực N đều uốn cong hướng ra hai bên.'],
      ['Khi đặt cực Bắc (N) của thanh nam châm thứ nhất đối diện gần với cực Nam (S) của thanh nam châm thứ hai thì các đường sức từ ở khoảng giữa hai cực N – S sẽ:', ['nối liền từ cực Bắc (N) của thanh thứ nhất sang cực Nam (S) của thanh thứ hai với mật độ rất dày.', 'tỏa dạt ra hai bên.', 'đi từ cực S sang cực N.', 'cắt nhau vuông góc.'], 0, 'Hai cực khác tên hút nhau, các đường sức từ đi ra từ cực N của thanh này và đi thẳng vào cực S của thanh kia.'],
    ]),
    trueFalseList: [
      {
        id: 'b19-tf-1',
        stem: 'Xét khái niệm từ trường, từ phổ và đường sức từ:',
        statements: [
          { id: 'a', text: 'Không gian xung quanh nam châm và xung quanh dòng điện có khả năng tác dụng lực từ lên kim nam châm đặt trong nó, ta nói trong không gian đó có từ trường.', isTrue: true, explanation: 'Đúng định nghĩa từ trường.' },
          { id: 'b', text: 'Bằng mắt thường, con người có thể nhìn thấy trực tiếp các đường sức từ trong không khí.', isTrue: false, explanation: 'Sai, mắt thường không nhìn thấy trực tiếp từ trường mà phải dùng mạt sắt (tạo từ phổ) hoặc dùng kim nam châm thử.' },
          { id: 'c', text: 'Bên ngoài thanh nam châm, các đường sức từ là những đường cong đi ra từ cực Bắc (N) và đi vào cực Nam (S).', isTrue: true, explanation: 'Đúng quy ước chiều đường sức từ.' },
          { id: 'd', text: 'Nơi nào từ trường mạnh thì các đường sức từ được vẽ dày, nơi nào từ trường yếu thì các đường sức từ được vẽ thưa.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b19-tf-2',
        stem: 'Xét hình ảnh đường sức từ trong lòng nam châm hình chữ U (móng ngựa) có hai nhánh thẳng song song A và B (biết đường sức từ đi từ nhánh A sang nhánh B):',
        statements: [
          { id: 'a', text: 'Nhánh A là cực Bắc (N) và nhánh B là cực Nam (S) của nam châm chữ U.', isTrue: true, explanation: 'Đúng vì đường sức từ đi ra từ cực Bắc (A) và đi vào cực Nam (B).' },
          { id: 'b', text: 'Trong khoảng không gian giữa hai nhánh A và B của nam châm chữ U, các đường sức từ là những đường thẳng gần như song song và cách đều nhau.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Nếu đặt một kim nam châm thử vào giữa hai nhánh A và B thì cực Bắc (N) của kim nam châm thử sẽ quay về phía nhánh A.', isTrue: false, explanation: 'Sai, cực Bắc (N) của kim nam châm thử luôn hướng theo chiều đường sức từ (bị cực Nam B hút) nên sẽ quay về phía nhánh B.' },
          { id: 'd', text: 'Ở rất xa bên ngoài nam châm chữ U, từ trường yếu hơn so với ở sát hai đầu cực A và B.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b19-tf-3',
        stem: 'Xét cấu tạo và hoạt động của nam châm điện đơn giản (gồm dây đồng quấn quanh ống nhựa có lõi đinh sắt non, nối với nguồn điện pin qua công tắc):',
        statements: [
          { id: 'a', text: 'Khi công tắc điện đang ngắt (mạch hở), chiếc đinh sắt non bên trong ống dây không hút được các ghim giấy bằng sắt.', isTrue: true, explanation: 'Đúng vì khi không có dòng điện thì nam châm điện không có từ trường.' },
          { id: 'b', text: 'Khi đóng công tắc điện, dòng điện chạy qua cuộn dây đồng sinh ra từ trường làm đinh sắt non nhiễm từ trở thành nam châm và hút được các ghim giấy.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Nếu rút bỏ lõi đinh sắt non ra ngoài và giữ nguyên dòng điện thì ống dây sẽ hút được nhiều ghim giấy hơn lúc có lõi sắt.', isTrue: false, explanation: 'Sai, lõi sắt non có tác dụng làm tăng mạnh từ trường của ống dây; nếu rút lõi sắt ra thì lực từ yếu đi rất nhiều.' },
          { id: 'd', text: 'Khi tăng số vòng dây quấn hoặc tăng số pin nối tiếp (tăng dòng điện), lực từ của nam châm điện sẽ tăng lên.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b19-tf-4',
        stem: 'So sánh đặc điểm giữa nam châm điện và nam châm vĩnh cửu:',
        statements: [
          { id: 'a', text: 'Nam châm vĩnh cửu luôn duy trì từ tính mà không cần cung cấp dòng điện, nhưng lực từ của nó khó thay đổi.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Nam châm điện có thể dễ dàng điều chỉnh độ mạnh yếu của lực từ bằng cách thay đổi cường độ dòng điện chạy vào ống dây.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Cực Bắc (N) và cực Nam (S) của nam châm điện là cố định vĩnh viễn, không thể thay đổi được.', isTrue: false, explanation: 'Sai, chỉ cần đổi chiều dòng điện chạy vào ống dây là hai cực N và S của nam châm điện sẽ đảo ngược cho nhau.' },
          { id: 'd', text: 'Cần cẩu bốc dỡ sắt vụn bắt buộc phải dùng nam châm điện để có thể ngắt điện nhả sắt vụn xuống nơi quy định.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b19-tf-5',
        stem: 'Xét nguyên lí hoạt động của chuông điện dùng nam châm điện:',
        statements: [
          { id: 'a', text: 'Bộ phận chính tạo ra lực hút búa gõ vào chuông là một nam châm điện có lõi sắt.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Khi nhấn giữ nút công tắc, dòng điện chạy qua cuộn dây làm nam châm điện hút miếng sắt gắn với búa gõ đập vào chuông phát ra âm thanh.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Ngay khi miếng sắt bị hút về phía nam châm điện, chỗ tiếp điểm bị hở ra làm mạch điện bị ngắt tạm thời.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Vì miếng sắt làm bằng thép cứng nên sau khi ngắt điện nó dính chặt mãi vào nam châm điện làm chuông chỉ kêu đúng 1 tiếng duy nhất.', isTrue: false, explanation: 'Sai, lõi và miếng hút làm bằng sắt non nên khi tiếp điểm hở mất điện, nó nhả ra ngay và lá thép đàn hồi kéo về đóng tiếp điểm lại, giúp chuông reo liên tục.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b19-es-1',
        question: 'Câu 1 [Tài liệu Chủ đề Từ]:\n(a) Nêu định nghĩa từ trường và cách nhận biết sự tồn tại của từ trường.\n(b) Từ phổ là gì? Nêu đặc điểm và quy ước chiều của các đường sức từ.',
        hint: 'Dùng kim nam châm thử để nhận biết từ trường; dùng mạt sắt để tạo từ phổ.',
        sampleAnswer: '(a) Từ trường:\n- Định nghĩa: Không gian xung quanh nam châm và xung quanh dòng điện có khả năng tác dụng lực từ lên kim nam châm đặt trong nó gọi là từ trường.\n- Cách nhận biết: Dùng kim nam châm (nam châm thử) đặt vào vị trí cần kiểm tra; nếu thấy kim nam châm bị lệch khỏi hướng Bắc – Nam bình thường thì tại đó có từ trường.\n(b) Từ phổ và đường sức từ:\n- Từ phổ là hình ảnh trực quan của các đường mạt sắt tự sắp xếp xung quanh nam châm.\n- Đặc điểm đường sức từ: Là những đường cong khép kín, bên ngoài nam châm có chiều đi ra từ cực Bắc (N) và đi vào cực Nam (S). Nơi nào từ trường mạnh thì đường sức từ dày, nơi nào từ trường yếu thì đường sức từ thưa.',
        rubricPoints: [
          'Nêu đúng định nghĩa từ trường và cách dùng kim nam châm thử.',
          'Nêu đúng khái niệm từ phổ và chiều đường sức từ (ra Bắc, vào Nam).',
        ],
      },
      {
        id: 'b19-es-2',
        question: 'Câu 2 [Tài liệu Chủ đề Từ]:\n(a) Nêu cấu tạo của một nam châm điện đơn giản.\n(b) Có những cách nào để làm tăng lực từ của một nam châm điện? Khi muốn đổi tên hai từ cực của nam châm điện ta làm thế nào?',
        hint: 'Cấu tạo gồm 3 phần: ống dây, lõi sắt non, nguồn điện.',
        sampleAnswer: '(a) Cấu tạo của một nam châm điện đơn giản gồm:\n- Một ống dây dẫn điện (dây đồng có vỏ cách điện quấn quanh ống nhựa).\n- Một lõi sắt non (ví dụ chiếc đinh sắt) lồng bên trong lòng ống dây.\n- Nguồn điện (pin hoặc ắc quy) và công tắc nối với hai đầu ống dây.\n(b) Điều chỉnh từ trường nam châm điện:\n- Để tăng lực từ của nam châm điện: Tăng cường độ dòng điện chạy qua các vòng dây (tăng số pin) hoặc tăng số vòng dây của ống dây.\n- Để đổi tên hai từ cực (N và S) của nam châm điện: Đổi chiều dòng điện chạy vào ống dây bằng cách đảo hai đầu dây nối với hai cực (+, -) của nguồn điện.',
        rubricPoints: [
          'Nêu đủ cấu tạo của nam châm điện (ống dây, lõi sắt non, nguồn điện).',
          'Nêu đúng 2 cách tăng lực từ và cách đảo cực của nam châm điện.',
        ],
      },
      {
        id: 'b19-es-3',
        question: 'Câu 3 [Tài liệu Chủ đề Từ]: Một nhóm học sinh chế tạo chiếc chuông điện gồm: nguồn điện, công tắc nhấn, cuộn dây có lõi sắt non (nam châm điện), lá thép đàn hồi gắn thanh sắt và búa gõ chuông, vít tiếp điểm. Hãy giải thích vì sao khi nhấn và giữ công tắc thì búa lại gõ vào chuông liên tục phát ra tiếng chuông reo cho đến khi nhả công tắc?',
        hint: 'Phân tích chu trình tự động: Đóng mạch → Hút thanh sắt gõ chuông → Hở tiếp điểm ngắt mạch → Lá thép đàn hồi kéo về đóng tiếp điểm.',
        sampleAnswer: 'Nguyên lí hoạt động của chuông điện:\n- Khi nhấn giữ công tắc, mạch điện kín ⇒ Dòng điện chạy qua cuộn dây làm lõi sắt trở thành nam châm điện.\n- Nam châm điện hút thanh sắt kéo theo búa gõ đập vào chuông phát ra tiếng kêu.\n- Đồng thời, khi thanh sắt bị hút về phía nam châm điện thì lá thép đàn hồi tách rời khỏi vít tiếp điểm làm mạch điện bị hở (ngắt dòng điện).\n- Khi mất dòng điện, lõi sắt non mất từ tính ngay lập tức, lá thép đàn hồi kéo thanh sắt trở về vị trí cũ và lại chạm vào tiếp điểm làm mạch điện kín trở lại.\n- Quá trình đóng – ngắt tự động lặp đi lặp lại rất nhanh làm búa gõ liên tục vào chuông cho đến khi nhả công tắc.',
        rubricPoints: [
          'Giải thích giai đoạn mạch kín: nam châm điện hút thanh sắt làm búa gõ vào chuông và làm hở tiếp điểm.',
          'Giải thích giai đoạn mạch hở: nam châm mất từ tính, lá thép đàn hồi kéo thanh sắt về đóng lại tiếp điểm tạo chu trình liên tục.',
        ],
      },
      {
        id: 'b19-es-4',
        question: 'Câu 4 [Tài liệu Chủ đề Từ]:\n(a) Nếu xem chiếc đinh sắt trong nam châm điện trở thành một thanh nam châm khi có dòng điện chạy qua cuộn dây, làm thế nào để xác định đâu là cực Bắc (N) và đâu là cực Nam (S) của chiếc đinh này?\n(b) Có một cục pin để lâu ngày và một đoạn dây dẫn. Nếu không có bóng đèn thử mà chỉ có một kim nam châm, làm thế nào để kiểm tra pin còn điện hay đã hết điện?',
        hint: 'Dùng kim nam châm thử trong cả hai câu.',
        sampleAnswer: '(a) Cách xác định cực của nam châm điện: Đóng công tắc cho dòng điện chạy qua cuộn dây, sau đó đưa một cực đã biết tên (ví dụ cực Bắc N) của một kim nam châm thử lại gần một đầu của chiếc đinh sắt: nếu cực Bắc của kim nam châm bị đẩy ra thì đầu đinh đó là cực Bắc (N); nếu bị hút vào thì đầu đinh đó là cực Nam (S).\n(b) Cách kiểm tra pin còn điện hay không: Đặt đoạn dây dẫn gần và song song với kim nam châm đang nằm cân bằng theo hướng Bắc – Nam, sau đó chạm nhanh hai đầu dây dẫn vào hai cực của cục pin. Nếu thấy kim nam châm quay lệch khỏi hướng Bắc – Nam thì chứng tỏ có dòng điện chạy qua dây dẫn (sinh ra từ trường) ⇒ pin còn điện; nếu kim đứng yên không lệch ⇒ pin đã hết điện.',
        rubricPoints: [
          'Nêu đúng cách dùng kim nam châm thử để xác định cực của đinh sắt ở câu (a).',
          'Nêu đúng cách nối dây dẫn qua pin đặt gần kim nam châm để kiểm tra từ trường dòng điện ở câu (b).',
        ],
      },
      {
        id: 'b19-es-5',
        question: 'Câu 5 [Tài liệu Chủ đề Từ]: Nêu ít nhất 4 ứng dụng quan trọng của nam châm điện trong công nghiệp, giao thông vận tải, đời sống và y học.',
        hint: 'Cần cẩu điện, tàu đệm từ, loa điện/rơ-le, máy chụp cộng hưởng từ MRI.',
        sampleAnswer: '4 ứng dụng tiêu biểu của nam châm điện:\n1. Trong công nghiệp: Cần cẩu điện dùng nam châm điện công suất lớn để nâng hạ, bốc dỡ hàng tấn sắt thép phế liệu hoặc thép tấm.\n2. Trong giao thông vận tải: Chế tạo tàu đệm từ cao tốc (Maglev) giúp tàu nâng lên khỏi đường ray giảm ma sát và đạt tốc độ hàng trăm km/h.\n3. Trong đời sống và kĩ thuật điện: Chế tạo chuông điện, rơ-le điện từ tự động ngắt mạch bảo vệ, loa điện, động cơ điện.\n4. Trong y học: Máy chụp cộng hưởng từ (MRI) dùng từ trường mạnh của nam châm điện hỗ trợ chẩn đoán chính xác các bệnh lí bên trong cơ thể mà không cần phẫu thuật.',
        rubricPoints: [
          'Nêu đúng ứng dụng trong công nghiệp (cần cẩu điện) và giao thông (tàu đệm từ).',
          'Nêu đúng ứng dụng trong kĩ thuật (chuông điện, rơ-le, động cơ) và y học (máy MRI).',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 21: TỪ TRƯỜNG TRÁI ĐẤT – SỬ DỤNG LA BÀN (Tài liệu Chủ đề Từ - Bài 16)
  // =========================================================================
  {
    id: 'kntt-bai-21',
    lessonNumber: 21,
    title: 'Bài 21: Từ trường Trái Đất – Sử dụng la bàn',
    chapterTitle: 'Chương VI: Từ',
    subject: 'physics',
    pdfUrl: '/assets/aistudio/_C_p_nh_t_m_i__Ch_____T__2d00c081.pdf',
    summary:
      'Trái Đất là một thanh nam châm khổng lồ vì có lõi cấu tạo chủ yếu bằng sắt và nickel chuyển động quay tạo nên từ trường Trái Đất. Cực Bắc địa từ và cực Bắc địa lí không trùng nhau (về mặt khoa học, gần cực Bắc địa lí là cực từ Nam của nam châm Trái Đất nên mới hút cực Bắc N của kim la bàn).',
    keyFormulas: [
      'Cấu tạo la bàn: (1) Kim nam châm quay tự do trên trục; (2) Mặt chia độ (360°, có 4 hướng chính N, S, E, W); (3) Vỏ kim loại (nhôm/đồng) kèm mặt kính',
      'Kí hiệu 8 hướng trên la bàn:  N (Bắc - 0°/360°), E (Đông - 90°), S (Nam - 180°), W (Tây - 270°), NE (Đông Bắc), SE (Đông Nam), SW (Tây Nam), NW (Tây Bắc)',
      'Nguyên tắc dùng la bàn: Đặt trên mặt phẳng ngang, cách xa các nam châm khác và các vật bằng sắt thép',
    ],
    mcqs: makeMcqs('b21', [
      ['Trục quay của Trái Đất là:', ['đường thẳng xuyên tâm nối giữa cực Nam địa lí và cực Bắc địa lí.', 'đường xích đạo bao quanh Trái Đất.', 'đường thẳng nằm ngang.', 'đường nối từ Trái Đất đến Mặt Trời.'], 0, 'Trái Đất quay quanh trục xuyên tâm nối giữa cực Bắc địa lí và cực Nam địa lí.'],
      ['Từ trường của Trái Đất mạnh nhất ở vùng nào?', ['Ở vùng gần đường xích đạo.', 'Ở vùng hai cực địa từ (gần hai cực Bắc và Nam của Trái Đất).', 'Mạnh bằng nhau ở mọi nơi trên Trái Đất.', 'Ở trên đỉnh núi cao.'], 1, 'Giống như một thanh nam châm khổng lồ, từ trường Trái Đất mạnh nhất ở vùng hai cực từ và yếu hơn ở vùng xích đạo.'],
      ['Vì sao có thể coi Trái Đất giống như một thanh nam châm khổng lồ?', ['Vì Trái Đất hút mọi vật về phía tâm (trọng lực).', 'Vì mỗi cực của kim nam châm để tự do trên Trái Đất luôn chịu tác dụng của lực từ và hướng về một cực xác định (Bắc – Nam).', 'Vì bề mặt Trái Đất toàn là nước biển.', 'Vì Trái Đất hình cầu.'], 1, 'Kim nam châm ở mọi nơi trên Trái Đất luôn định hướng Bắc – Nam chứng tỏ xung quanh Trái Đất có từ trường giống như một thanh nam châm khổng lồ.'],
      ['Hai nguyên tố kim loại chính cấu tạo nên phần lõi của Trái Đất (góp phần tạo ra từ trường Trái Đất khi lõi quay) là:', ['Nhôm và đồng.', 'Sắt (Iron) và Niken (Nickel).', 'Vàng và bạc.', 'Chì và kẽm.'], 1, 'Kết quả thăm dò địa vật lí cho thấy lõi Trái Đất cấu tạo chủ yếu từ Sắt và Niken (lõi trong rắn, lõi ngoài lỏng).'],
      ['Khi đặt một kim nam châm tự do trên mặt đất thì cực Bắc (N) của kim nam châm luôn hướng về phía nào?', ['Hướng về phía cực Bắc địa lí.', 'Hướng về phía cực Nam địa lí.', 'Hướng về phía Đông.', 'Hướng về phía Tây.'], 0, 'Cực Bắc (N) của mọi kim nam châm trên Trái Đất luôn hướng về phía cực Bắc địa lí.'],
      ['Theo quan điểm khoa học về tương tác từ (các cực khác tên hút nhau), vì cực Bắc (N) của kim la bàn luôn bị hút về phía cực Bắc địa lí nên thực chất ở gần cực Bắc địa lí là:', ['cực từ Nam (S) của “thanh nam châm Trái Đất”.', 'cực từ Bắc (N) của “thanh nam châm Trái Đất”.', 'không có từ cực nào.', 'vùng không có từ trường.'], 0, 'Về mặt vật lí, để hút cực Bắc (N) của kim la bàn thì từ cực của Trái Đất nằm ở Bắc bán cầu thực chất đóng vai trò là cực từ Nam (S), dù theo thói quen địa lí người ta vẫn gọi là cực Bắc địa từ.'],
      ['Chọn phát biểu ĐÚNG khi so sánh trục từ và trục quay địa lí của Trái Đất:', ['Trục từ và trục địa lí trùng khít hoàn toàn với nhau.', 'Trục từ và trục địa lí vuông góc với nhau.', 'Cực Bắc địa từ và cực Bắc địa lí không trùng nhau (trục từ lệch một góc khoảng 11° so với trục địa lí).', 'Các cực địa từ đứng yên vĩnh viễn không bao giờ dịch chuyển.'], 2, 'Cực Bắc địa từ và cực Bắc địa lí cách nhau hàng trăm km (trục từ nghiêng một góc nhỏ so với trục quay địa lí).'],
      ['Dụng cụ dùng để xác định phương hướng dựa vào từ trường Trái Đất có tên gọi là gì?', ['Nhiệt kế.', 'La bàn.', 'Đồng hồ bấm giây.', 'Lực kế.'], 1, 'La bàn là dụng cụ ứng dụng kim nam châm trong từ trường Trái Đất để xác định phương hướng.'],
      ['La bàn có cấu tạo gồm 3 bộ phận chính là:', ['Vỏ kèm mặt kính bảo vệ, kim nam châm quay tự do trên trục và mặt chia độ.', 'Cuộn dây điện, lõi sắt non và nguồn pin.', 'Gương phẳng, thước đo độ và đèn chiếu.', 'Kim bằng đồng, mặt số bằng sắt và vỏ bằng thép.'], 0, 'La bàn gồm: kim nam châm, mặt chia độ (360° và các hướng) và vỏ kim loại không từ tính (nhôm/đồng/nhựa) kèm mặt kính.'],
      ['Vì sao vỏ của la bàn phải được làm bằng nhôm, đồng hoặc nhựa mà KHÔNG được làm bằng sắt hay thép?', ['Vì sắt, thép là vật liệu từ sẽ hút kim nam châm làm kim không thể quay chỉ đúng hướng Bắc – Nam của Trái Đất.', 'Vì sắt, thép quá nhẹ.', 'Vì nhôm và nhựa có từ tính mạnh hơn sắt.', 'Vì sắt trong suốt.'], 0, 'Nếu vỏ la bàn làm bằng sắt/thép, nó sẽ tương tác từ với kim nam châm làm sai lệch hoàn toàn kết quả định hướng.'],
      ['Chọn ý SAI khi nói về mặt chia độ của la bàn:', ['Mặt chia độ được chia thành 360°.', 'Trên mặt chia độ có ghi các hướng chính: Bắc (N), Đông (E), Nam (S), Tây (W).', 'Mặt chia độ được gắn cố định với vỏ la bàn.', 'Mặt chia độ được hàn dính chặt với kim nam châm để cùng quay theo kim nam châm.'], 3, 'Mặt chia độ gắn với vỏ la bàn và quay độc lập với kim nam châm (để người dùng có thể xoay vỏ đưa vạch chữ N trùng với đầu kim đỏ).'],
      ['Khi sử dụng la bàn để xác định phương hướng, ta cần lưu ý điều gì quan trọng nhất?', ['Đặt la bàn ngay sát một thanh nam châm lớn.', 'Đặt la bàn thăng bằng trên mặt phẳng nằm ngang, cách xa các nam châm khác và các vật liệu có tính chất từ (sắt, thép, điện thoại).', 'Cầm la bàn lắc mạnh liên tục khi đọc số.', 'Đặt la bàn trên mặt nghiêng dốc đứng.'], 1, 'La bàn phải đặt trên mặt phẳng ngang để kim không bị kẹt và đặt xa các vật có từ tính để tránh bị nhiễu từ trường.'],
      ['Trên mặt la bàn, các kí hiệu chữ in hoa N, E, S, W lần lượt chỉ các hướng nào?', ['Bắc, Đông, Nam, Tây.', 'Nam, Đông, Bắc, Tây.', 'Bắc, Tây, Nam, Đông.', 'Đông, Tây, Nam, Bắc.'], 0, 'N = North (Bắc); E = East (Đông); S = South (Nam); W = West (Tây).'],
      ['Trên mặt la bàn, các kí hiệu NE, SE, SW, NW lần lượt tương ứng với các hướng nào?', ['Đông Bắc, Đông Nam, Tây Nam, Tây Bắc.', 'Tây Bắc, Tây Nam, Đông Nam, Đông Bắc.', 'Đông Nam, Đông Bắc, Tây Bắc, Tây Nam.', 'Bắc, Nam, Đông, Tây.'], 0, 'NE = North-East (Đông Bắc); SE = South-East (Đông Nam); SW = South-West (Tây Nam); NW = North-West (Tây Bắc).'],
      ['Trên vòng chia độ 360° của la bàn (với hướng Bắc N ứng với 0° hay 360°), hướng Đông (E), hướng Nam (S) và hướng Tây (W) lần lượt chỉ các góc nào?', ['90°, 180°, 270°.', '180°, 90°, 270°.', '45°, 90°, 180°.', '270°, 180°, 90°.'], 0, 'Theo chiều kim đồng hồ từ Bắc (0°): Đông (E) = 90°, Nam (S) = 180°, Tây (W) = 270°.'],
      ['Trên vòng chia độ của la bàn, hướng Đông Bắc (NE) ứng với góc bao nhiêu độ?', ['45°.', '90°.', '135°.', '225°.'], 0, 'Hướng Đông Bắc (NE) nằm chính giữa hướng Bắc (0°) và hướng Đông (90°) nên ứng với góc 45°.'],
      ['Sắp xếp các bước sử dụng la bàn để xác định hướng của một đối tượng A: (1) Đọc giá trị góc và hướng trên mặt chia độ gần nhất với hướng từ tâm la bàn tới điểm A; (2) Đặt la bàn nằm ngang cách xa các vật có tính chất từ; (3) Chờ kim nam châm ổn định rồi xoay vỏ la bàn sao cho vạch số 0 (chữ N) trùng với cực Bắc (đầu màu đỏ) của kim nam châm.', ['(1) → (2) → (3).', '(2) → (3) → (1).', '(3) → (2) → (1).', '(2) → (1) → (3).'], 1, 'Trình tự chuẩn: Đặt la bàn thăng bằng xa vật từ tính (2) → Xoay vỏ cho chữ N trùng đầu kim Bắc (3) → Đọc hướng tới điểm A (1).'],
      ['Một bạn học sinh viết bước 2 khi dùng la bàn là: “Khi kim nam châm ổn định, xoay la bàn sao cho vạch chữ E trùng với cực Bắc màu đỏ của kim nam châm”. Bước làm này đúng hay sai?', ['Đúng hoàn toàn.', 'Sai, vì phải xoay la bàn sao cho vạch số 0 ở chữ N (hướng Bắc) trùng với từ cực Bắc (màu đỏ) của kim nam châm.', 'Sai, vì phải xoay chữ S trùng với đầu kim đỏ.', 'Đúng nếu dùng vào buổi tối.'], 1, 'Đầu kim màu đỏ là cực Bắc (N) chỉ hướng Bắc nên phải xoay vạch chữ N (0°) trùng với đầu kim màu đỏ.'],
      ['Điều gì sẽ xảy ra nếu ta đặt la bàn trên một mặt bàn bị nghiêng nhiều khi đo?', ['Kim la bàn chỉ hướng chính xác hơn.', 'Kim nam châm dễ bị cọ xát, kẹt vào mặt kính hoặc mặt chia độ làm xác định hướng không chính xác.', 'Kim la bàn tự phát sáng.', 'Từ trường Trái Đất biến mất.'], 1, 'Khi đặt nghiêng, kim nam châm bị chạm vào mặt đáy hoặc mặt kính không quay tự do được.'],
      ['Buổi sáng sớm thức dậy, nếu không có la bàn nhưng em nhìn thấy Mặt Trời mọc ở ngay trước mặt mình (hướng Đông), thì phía sau lưng, bên tay trái và bên tay phải của em lần lượt là các hướng nào?', ['Sau lưng là Tây; bên trái là Bắc; bên phải là Nam.', 'Sau lưng là Bắc; bên trái là Tây; bên phải là Nam.', 'Sau lưng là Nam; bên trái là Đông; bên phải là Tây.', 'Sau lưng là Tây; bên trái là Nam; bên phải là Bắc.'], 0, 'Đứng nhìn về hướng Đông (trước mặt): sau lưng là hướng Tây, tay trái là hướng Bắc, tay phải là hướng Nam.'],
      ['Từ trường của Trái Đất có vai trò bảo vệ sự sống trên Trái Đất vô cùng quan trọng vì:', ['nó làm lệch hướng và ngăn chặn phần lớn các hạt mang điện năng lượng cao từ gió Mặt Trời và tia vũ trụ chiếu xuống Trái Đất.', 'nó làm cho Trái Đất không quay nữa.', 'nó tạo ra mưa rào.', 'nó hút Mặt Trăng rơi xuống Trái Đất.'], 0, 'Lá chắn từ quyển của Trái Đất bảo vệ bầu khí quyển và sinh vật khỏi bức xạ hạt mang điện nguy hiểm từ Mặt Trời (và tạo ra hiện tượng cực quang ở hai cực).'],
      ['Một số loài động vật di cư đường dài như chim én, chim bồ câu đưa thư, rùa biển có thể tìm đúng đường bay/bơi hàng nghìn km qua đại dương là nhờ:', ['chúng mang theo la bàn cơ học.', 'cơ thể chúng có các tế bào cảm nhận được từ trường của Trái Đất để định hướng.', 'chúng chỉ bay theo tàu thủy.', 'chúng nhìn biển báo giao thông.'], 1, 'Nhiều loài chim di cư, cá voi, rùa biển có khả năng cảm nhận từ trường Trái Đất (magnetoreception) để định hướng.'],
      ['Lõi của Trái Đất được chia thành hai phần có trạng thái vật lí như thế nào?', ['Lõi trong (nhân trong) ở trạng thái rắn và lõi ngoài (nhân ngoài) ở trạng thái lỏng nóng chảy.', 'Cả hai phần đều là chất khí.', 'Lõi trong lỏng và lõi ngoài rắn.', 'Lõi cấu tạo hoàn toàn bằng nước đá.'], 0, 'Lõi trong (Solid Inner Core) ở thể rắn do áp suất cực lớn; lõi ngoài (Liquid Outer Core) gồm sắt – niken nóng chảy ở thể lỏng.'],
      ['Sau khi đã đặt la bàn nằm ngang và xoay vỏ la bàn sao cho vạch chữ N (0°) trùng khít với đầu cực Bắc của kim nam châm, ta nhìn thấy cổng trường nằm theo hướng vạch 135° (SE) tính từ tâm la bàn. Vậy cổng trường nằm ở hướng nào so với vị trí ta đứng?', ['Hướng Đông Bắc.', 'Hướng Đông Nam (SE).', 'Hướng Tây Nam.', 'Hướng Tây Bắc.'], 1, 'Góc 135° ứng với kí hiệu SE là hướng Đông Nam.'],
      ['Tại khu vực mỏ sắt lớn như mỏ sắt Thạch Khê (Hà Tĩnh), khi sử dụng la bàn từ tính trên mặt đất ngay phía trên tầng quặng sắt thì:', ['la bàn chỉ hướng Bắc – Nam chính xác gấp đôi bình thường.', 'từ trường tại khu vực đó mạnh hơn bình thường và làm kim la bàn bị lệch (dị thường từ), không còn chỉ đúng hướng Bắc địa lí nữa.', 'kim la bàn biến thành nhựa.', 'la bàn ngừng chịu tác dụng của lực hấp dẫn.'], 1, 'Trữ lượng quặng sắt lớn dưới lòng đất làm biến dạng từ trường cục bộ (dị thường từ) khiến kim la bàn bị hút lệch.'],
      ['Khi đi dã ngoại trong rừng vào ban đêm quang mây ở Bắc bán cầu, nếu không có la bàn, người ta có thể nhìn chòm sao nào để xác định chính xác hướng Bắc?', ['Sao Bắc Cực (thuộc chòm sao Tiểu Hùng, tìm qua chòm sao Bắc Đẩu / Đại Hùng).', 'Mặt Trăng.', 'Sao Hỏa.', 'Mặt Trời.'], 0, 'Sao Bắc Cực nằm gần như thẳng trục Bắc của Trái Đất nên luôn chỉ hướng Bắc địa lí.'],
      ['Đường sức từ của từ trường Trái Đất ở không gian bên ngoài Trái Đất có chiều đi như thế nào?', ['Đi ra từ vùng cực từ ở Nam bán cầu (cực Nam địa lí) và đi vào vùng cực từ ở Bắc bán cầu (cực Bắc địa lí).', 'Đi theo đường xích đạo từ Đông sang Tây.', 'Đi từ trên tầng khí quyển thẳng đứng xuống xích đạo.', 'Không có chiều xác định.'], 0, 'Vì cực từ ở Nam bán cầu đóng vai trò là cực từ Bắc (N) và cực từ ở Bắc bán cầu đóng vai trò là cực từ Nam (S) nên đường sức từ đi từ Nam bán cầu lên Bắc bán cầu (nhờ đó mới đẩy cực N của kim la bàn hướng về phía Bắc địa lí).'],
      ['Nếu đặt 4 kim nam châm thử tại 4 địa điểm khác nhau trên Trái Đất (không gần quặng sắt), cực Bắc (N) của cả 4 kim nam châm đều:', ['chỉ về hướng Đông.', 'hướng dọc theo đường sức từ Trái Đất về phía cực Bắc địa lí.', 'chỉ thẳng đứng lên bầu trời.', 'chỉ về phía xích đạo.'], 1, 'Ở mọi nơi trên Trái Đất, cực Bắc của kim nam châm đều định hướng về phía cực Bắc địa lí.'],
      ['Bộ phận nào trên la bàn giúp khóa giữ kim nam châm không bị rung lắc làm mòn trục nhọn khi người dùng bỏ la bàn vào túi mang đi đường?', ['Mặt kính.', 'Chốt hãm (lẫy khóa kim nam châm).', 'Vạch chia độ.', 'Chữ N.'], 1, 'Chốt hãm dùng để khóa cố định kim khi không sử dụng; khi bắt đầu đo phải mở chốt hãm để kim quay tự do.'],
      ['Quan sát la bàn thấy đầu kim màu đỏ đã trùng với chữ N (0°), còn điểm B cần tìm đường đi nằm thẳng theo vạch chữ W (270°). Vậy để đi tới điểm B, ta phải đi theo hướng nào?', ['Hướng Đông.', 'Hướng Tây.', 'Hướng Nam.', 'Hướng Bắc.'], 1, 'Chữ W (West, 270°) chỉ hướng Tây.'],
    ]),
    trueFalseList: [
      {
        id: 'b21-tf-1',
        stem: 'Xét đặc điểm của từ trường Trái Đất:',
        statements: [
          { id: 'a', text: 'Do cấu tạo của lõi (chứa nhiều sắt và nickel) và chuyển động tự quay nên Trái Đất có từ trường giống như một thanh nam châm khổng lồ.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Từ trường Trái Đất mạnh nhất ở vùng hai cực từ và yếu hơn ở vùng xích đạo.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Cực Bắc địa từ và cực Bắc địa lí của Trái Đất nằm trùng khít tại một điểm duy nhất và cố định vĩnh viễn.', isTrue: false, explanation: 'Sai, cực địa từ và cực địa lí không trùng nhau (trục từ lệch so với trục quay địa lí) và vị trí cực từ có sự dịch chuyển chậm theo thời gian.' },
          { id: 'd', text: 'Nhờ có từ trường Trái Đất mà kim nam châm tự do ở mọi nơi trên Trái Đất luôn định hướng Bắc – Nam.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b21-tf-2',
        stem: 'Xét sự khác nhau giữa cách gọi tên từ cực của Trái Đất theo thói quen địa lí và theo bản chất khoa học vật lí:',
        statements: [
          { id: 'a', text: 'Mọi kim nam châm trên Trái Đất đều có cực Bắc (N) hướng về phía cực Bắc địa lí.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Theo quy luật tương tác từ (hai cực khác tên mới hút nhau), cực từ của Trái Đất nằm ở gần cực Bắc địa lí thực chất là cực từ Nam (S) của nam châm Trái Đất.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Cực từ của Trái Đất nằm ở gần cực Nam địa lí thực chất là cực từ Bắc (N) của nam châm Trái Đất.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Các đường sức từ bên ngoài Trái Đất có chiều đi ra từ vùng cực Bắc địa lí và đi vào vùng cực Nam địa lí.', isTrue: false, explanation: 'Sai, đường sức từ đi từ Nam bán cầu lên hướng về phía Bắc bán cầu nên cực Bắc (N) của kim la bàn mới chỉ về hướng Bắc địa lí.' },
        ],
      },
      {
        id: 'b21-tf-3',
        stem: 'Xét cấu tạo và ý nghĩa các kí hiệu trên mặt la bàn:',
        statements: [
          { id: 'a', text: 'Bộ phận quan trọng nhất của la bàn là một kim nam châm có thể quay tự do trên một trục nhọn thẳng đứng.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Mặt chia độ của la bàn được chia thành 360° và có thể xoay độc lập với kim nam châm.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Trên mặt la bàn, kí hiệu E chỉ hướng Tây và kí hiệu W chỉ hướng Đông.', isTrue: false, explanation: 'Sai, E (East) chỉ hướng Đông và W (West) chỉ hướng Tây.' },
          { id: 'd', text: 'Trên mặt la bàn, kí hiệu NE chỉ hướng Đông Bắc và kí hiệu SE chỉ hướng Đông Nam.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b21-tf-4',
        stem: 'Xét quy trình sử dụng la bàn để xác định phương hướng ngoài thực địa:',
        statements: [
          { id: 'a', text: 'Bước đầu tiên là đặt la bàn nằm ngang trên mặt phẳng và để cách xa các nam châm khác cũng như các vật bằng sắt, thép.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Mở chốt hãm để kim nam châm quay tự do cho đến khi kim nằm ổn định theo hướng Bắc – Nam.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Sau khi kim đứng yên, dùng tay bẻ kim nam châm sao cho kim chỉ vào hướng mình muốn đi.', isTrue: false, explanation: 'Sai, tuyệt đối không chạm vào kim mà phải xoay VỎ LA BÀN (mặt chia độ) sao cho vạch số 0 ở chữ N trùng với đầu cực Bắc của kim nam châm.' },
          { id: 'd', text: 'Khi vạch chữ N đã trùng với cực Bắc của kim nam châm, ta đọc hướng và số độ trên mặt chia độ nối từ tâm la bàn tới đối tượng cần xác định hướng.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b21-tf-5',
        stem: 'Xét các tình huống thực tế liên quan đến từ trường Trái Đất và việc xác định phương hướng:',
        statements: [
          { id: 'a', text: 'Khi đi trên tàu thủy vỏ thép hoặc đứng sát cột sắt lớn, số chỉ của la bàn từ tính có thể bị lệch do ảnh hưởng từ tính của khối sắt thép.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Tại các vùng có mỏ quặng sắt trữ lượng lớn nằm nông dưới mặt đất, từ trường tại đó có sự biến đổi (dị thường từ) so với các vùng bình thường.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Buổi chiều tối khi Mặt Trời đang lặn ở hướng Tây, nếu em đứng quay mặt về phía Mặt Trời lặn thì bên tay phải của em là hướng Bắc.', isTrue: true, explanation: 'Đúng: Trước mặt là Tây ⇒ sau lưng là Đông, tay phải là Bắc, tay trái là Nam.' },
          { id: 'd', text: 'La bàn chỉ hoạt động được vào ban ngày khi có ánh nắng Mặt Trời, ban đêm hoặc khi trời nhiều mây la bàn không hoạt động được.', isTrue: false, explanation: 'Sai, la bàn hoạt động dựa vào từ trường Trái Đất nên hoạt động được cả ngày lẫn đêm và trong mọi thời tiết.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b21-es-1',
        question: 'Câu 1 [Tài liệu Chủ đề Từ]:\n(a) Trình bày cấu tạo của một chiếc la bàn.\n(b) Nêu đầy đủ các bước sử dụng la bàn để xác định hướng địa lí của một điểm A ngoài thực địa.',
        hint: 'Nêu 3 bộ phận cấu tạo và 3 bước sử dụng chuẩn.',
        sampleAnswer: '(a) Cấu tạo của la bàn gồm 3 bộ phận chính:\n- Kim nam châm nhỏ quay tự do trên một trục nhọn thẳng đứng.\n- Mặt chia độ được chia thành 360° và ghi các hướng (N, S, E, W, NE, SE, SW, NW), gắn cố định với vỏ la bàn và quay độc lập với kim nam châm.\n- Vỏ kim loại (bằng nhôm, đồng hoặc nhựa) kèm mặt kính bảo vệ và chốt hãm.\n(b) Các bước sử dụng la bàn xác định hướng:\n- Bước 1: Đặt la bàn trên mặt phẳng nằm ngang, cách xa các nam châm và các vật liệu có tính chất từ (sắt, thép); mở chốt hãm.\n- Bước 2: Chờ khi kim nam châm nằm ổn định (hướng Bắc – Nam), xoay vỏ la bàn sao cho vạch số 0 ở chữ N trùng khít với từ cực Bắc (đầu sơn đỏ) của kim nam châm.\n- Bước 3: Đọc số chỉ của vạch chia độ và kí hiệu hướng gần nhất với hướng nhìn từ tâm la bàn tới điểm A.',
        rubricPoints: [
          'Nêu đúng 3 bộ phận cấu tạo của la bàn.',
          'Trình bày đúng và đủ 3 bước sử dụng la bàn.',
        ],
      },
      {
        id: 'b21-es-2',
        question: 'Câu 2 [Tài liệu Chủ đề Từ]:\n(a) Tại sao Trái Đất lại có từ trường và được ví như một thanh nam châm khổng lồ?\n(b) Giải thích sự khác nhau giữa tên gọi cực địa lí và bản chất cực từ của Trái Đất theo quan điểm khoa học.',
        hint: 'Dựa vào cấu tạo lõi Sắt – Niken và quy tắc các từ cực khác tên hút nhau.',
        sampleAnswer: '(a) Trái Đất có từ trường vì phần lõi của Trái Đất được cấu tạo chủ yếu bởi hai kim loại từ tính là Sắt và Niken (lõi trong rắn, lõi ngoài lỏng). Khi Trái Đất tự quay quanh trục, hai phần của lõi chuyển động với tốc độ khác nhau sinh ra dòng điện và từ trường bao quanh Trái Đất, khiến Trái Đất giống như một thanh nam châm khổng lồ.\n(b) Vì mọi kim nam châm đặt trên Trái Đất đều có cực Bắc (N) bị hút hướng về phía cực Bắc địa lí, mà theo quy luật tương tác từ thì hai cực khác tên mới hút nhau ⇒ Theo bản chất khoa học, từ cực của Trái Đất nằm gần cực Bắc địa lí thực chất là cực từ Nam (S), còn từ cực nằm gần cực Nam địa lí thực chất là cực từ Bắc (N).',
        rubricPoints: [
          'Giải thích đúng nguồn gốc từ trường Trái Đất từ lõi Sắt – Niken chuyển động quay.',
          'Giải thích đúng vì sao gần cực Bắc địa lí là cực từ Nam của nam châm Trái Đất.',
        ],
      },
      {
        id: 'b21-es-3',
        question: 'Câu 3 [Tài liệu Chủ đề Từ]:\n(a) Sáng sớm thức dậy, em thấy Mặt Trời mọc ở hướng Đông. Làm thế nào để xác định được các hướng Bắc, Nam và Tây?\n(b) Hãy nêu thêm 3 cách xác định phương hướng ngoài thực tế khi không có la bàn.',
        hint: 'Đứng dang hai tay hoặc nhìn thẳng về hướng Mặt Trời mọc.',
        sampleAnswer: '(a) Khi đứng nhìn thẳng về phía Mặt Trời mọc:\n- Trước mặt em là hướng Đông.\n- Đằng sau lưng em là hướng Tây.\n- Phía bên tay trái của em là hướng Bắc.\n- Phía bên tay phải của em là hướng Nam.\n(b) 3 cách khác để xác định phương hướng ngoài thực tế:\n1. Quan sát vị trí Mặt Trời lặn vào buổi chiều (hướng Tây) hoặc bóng cọc ngắn nhất vào lúc 12h trưa.\n2. Ban đêm quang mây, tìm sao Bắc Cực (luôn chỉ hướng Bắc) dựa vào chòm sao Đại Hùng (Bắc Đẩu) hoặc chòm sao Thiên Hậu (hình chữ W).\n3. Dùng một chiếc kim khâu bằng thép xát vào nam châm cho nhiễm từ rồi đặt lên miếng xốp nhỏ thả nổi trên bát nước tĩnh lặng (làm la bàn tự chế).',
        rubricPoints: [
          'Xác định đúng 4 hướng Đông, Tây, Bắc, Nam ở câu (a).',
          'Nêu đúng 3 phương pháp xác định phương hướng thực tế ở câu (b).',
        ],
      },
      {
        id: 'b21-es-4',
        question: 'Câu 4 [Tài liệu Chủ đề Từ]: Ở độ sâu khoảng 100 m tại mỏ Thạch Khê (Hà Tĩnh) có một trữ lượng quặng sắt rất lớn. Em có dự đoán gì về độ lớn và hướng của từ trường ở khu vực mặt đất ngay phía trên mỏ quặng này? Nếu dùng la bàn tại đây thì có hiện tượng gì xảy ra?',
        hint: 'Quặng sắt có tính chất từ và bị nhiễm từ trong từ trường Trái Đất.',
        sampleAnswer: '- Dự đoán về từ trường: Vì quặng sắt là vật liệu có tính chất từ, khi nằm trong từ trường của Trái Đất, khối quặng sắt khổng lồ này bị nhiễm từ mạnh và tạo ra từ trường phụ của riêng nó. Do đó, từ trường tổng hợp tại khu vực mặt đất phía trên mỏ sắt sẽ có độ lớn mạnh hơn bình thường và hướng bị biến dạng (gọi là hiện tượng dị thường từ).\n- Hiện tượng với la bàn: Khi sử dụng la bàn tại khu vực này, kim nam châm của la bàn sẽ bị khối quặng sắt hút lệch đi, không còn chỉ đúng hướng Bắc – Nam địa lí nữa (nhờ đặc điểm này các nhà địa chất cũng dùng máy đo từ trường để thăm dò và phát hiện các mỏ quặng sắt ngầm dưới lòng đất).',
        rubricPoints: [
          'Giải thích đúng khối quặng sắt bị nhiễm từ làm tăng độ lớn và làm biến dạng từ trường tại khu vực đó.',
          'Nêu đúng hiện tượng kim la bàn bị lệch không chỉ đúng hướng Bắc – Nam.',
        ],
      },
      {
        id: 'b21-es-5',
        question: 'Câu 5 [Tài liệu Chủ đề Từ]: Bằng cách nghiên cứu từ tính lưu lại trong các lớp đá cổ thu thập được trên các lục địa và dưới đáy đại dương, các nhà khoa học nhận thấy các từ cực của Trái Đất ở thời xa xưa khác vị trí so với các từ cực hiện nay. Điều này chứng tỏ điều gì về các từ cực của Trái Đất?',
        hint: 'Các từ cực địa từ có đứng yên cố định mãi mãi không?',
        sampleAnswer: '- Kết quả nghiên cứu cổ từ học trong các lớp đá cổ chứng tỏ rằng hai cực địa từ của Trái Đất KHÔNG cố định tại một vị trí vĩnh viễn mà có sự dịch chuyển chậm chạp theo thời gian địa chất (do sự biến đổi các dòng đối lưu của sắt – niken lỏng trong lõi ngoài của Trái Đất).\n- Thậm chí qua hàng trăm nghìn đến hàng triệu năm trong lịch sử Trái Đất, hai từ cực của Trái Đất còn có thể xảy ra hiện tượng đảo cực địa từ.',
        rubricPoints: [
          'Kết luận đúng các cực địa từ của Trái Đất không cố định mà di chuyển chậm theo thời gian.',
          'Liên hệ được nguyên nhân từ sự chuyển động của lớp lõi lỏng bên trong Trái Đất.',
        ],
      },
    ],
  },
];
