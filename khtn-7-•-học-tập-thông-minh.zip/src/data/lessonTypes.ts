import { SubSubject } from './khtn7Data';

export interface McqItem {
  id: string;
  question: string;
  options: [string, string, string, string];
  correctIndex: number;
  explanation: string;
  level?: 'Nhận biết' | 'Thông hiểu' | 'Vận dụng';
}

export interface TrueFalseStatement {
  id: string; // 'a' | 'b' | 'c' | 'd'
  text: string;
  isTrue: boolean;
  explanation: string;
}

export interface TrueFalseItem {
  id: string;
  stem: string;
  statements: [
    TrueFalseStatement,
    TrueFalseStatement,
    TrueFalseStatement,
    TrueFalseStatement
  ];
}

export interface EssayItem {
  id: string;
  question: string;
  hint?: string;
  sampleAnswer: string;
  rubricPoints: string[];
}

export interface KhtnLesson {
  id: string;
  lessonNumber: number;
  title: string;
  chapterTitle: string;
  subject: SubSubject;
  pdfUrl?: string;
  summary: string;
  keyFormulas: string[];
  mcqs: McqItem[]; // 30 for Physics/Chemistry, 15-20 for Biology
  trueFalseList: TrueFalseItem[]; // 5 items per lesson
  essays: EssayItem[]; // 5-10 for Physics/Chemistry, 3-6 for Biology
}

export interface EssaySubmission {
  textAnswer: string;
  attachedImages: string[]; // Base64 data URLs from camera capture, upload, or clipboard paste
  selfScore?: 'full' | 'partial' | 'retry';
  submittedAt?: string;
}
