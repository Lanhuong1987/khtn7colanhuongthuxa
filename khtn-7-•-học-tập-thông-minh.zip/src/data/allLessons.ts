import { KhtnLesson } from './lessonTypes';
import { CHEMISTRY_LESSONS } from './chemistryLessons';
import { PHYSICS_LESSONS_PART_1 } from './physicsLessonsPart1';
import { PHYSICS_LESSONS_PART_2 } from './physicsLessonsPart2';
import { BIOLOGY_LESSONS } from './biologyLessons';
import {
  B9_DO_TOC_DO,
  B11_AN_TOAN_GIAO_THONG,
  B19_TU_TRUONG,
  B20_NAM_CHAM_DIEN,
} from './additionalPhysicsLessons';
import { ADDITIONAL_BIOLOGY_LESSONS } from './additionalBiologyLessons';

// Filter out old merged lessons (kntt-bai-9 and kntt-bai-19) and replace with dedicated lessons
const physicsPart1Filtered = PHYSICS_LESSONS_PART_1.filter((l) => l.id !== 'kntt-bai-9');
const physicsPart2Filtered = PHYSICS_LESSONS_PART_2.filter((l) => l.id !== 'kntt-bai-19');

// Refine titles of Bài 29 and Bài 32 in BIOLOGY_LESSONS now that Bài 27, 28, 30, 34, 37 have their own dedicated entries
const biologyRefined = BIOLOGY_LESSONS.map((lesson) => {
  if (lesson.id === 'kntt-bai-29') {
    return {
      ...lesson,
      title: 'Bài 29: Trao đổi nước và các chất dinh dưỡng ở thực vật',
    };
  }
  if (lesson.id === 'kntt-bai-32') {
    return {
      ...lesson,
      title: 'Bài 32 & 33: Cảm ứng ở sinh vật và tập tính ở động vật',
      chapterTitle: 'Chương VIII: Cảm ứng ở sinh vật',
    };
  }
  return lesson;
});

export const ALL_KNTT_LESSONS: KhtnLesson[] = [
  ...CHEMISTRY_LESSONS,
  ...physicsPart1Filtered,
  B9_DO_TOC_DO,
  B11_AN_TOAN_GIAO_THONG,
  ...physicsPart2Filtered,
  B19_TU_TRUONG,
  B20_NAM_CHAM_DIEN,
  ...biologyRefined,
  ...ADDITIONAL_BIOLOGY_LESSONS,
].sort((a, b) => a.lessonNumber - b.lessonNumber);

export const KNTT_PDF_DOCUMENTS = [
  {
    id: 'pdf-chem-1',
    title: 'Chủ đề 1: Nguyên tử – Sơ lược bảng tuần hoàn các NTHH (KHTN 7 KNTT)',
    subject: 'chemistry' as const,
    lessons: 'Bài 2, Bài 3, Bài 4',
    url: '/assets/aistudio/2023_-_2024._7.1_Nguyen_tu_-_So_luoc_bang_tuan_hoan_cac_NTHH._TTB_-_in__1__5009ba6a.pdf',
  },
  {
    id: 'pdf-chem-2',
    title: 'Chủ đề 2: Phân tử – Liên kết hóa học (KHTN 7 KNTT)',
    subject: 'chemistry' as const,
    lessons: 'Bài 5, Bài 6, Bài 7',
    url: '/assets/aistudio/2023_-_2024._7.2_Phan_tu_-_Lien_ket_hoa_hoc._TTB_-_in_46aa4d03.pdf',
  },
  {
    id: 'pdf-phys-speed',
    title: 'Chủ đề 3: Tốc độ (Cập nhật mới – KHTN 7 KNTT)',
    subject: 'physics' as const,
    lessons: 'Bài 8, Bài 9, Bài 10, Bài 11',
    url: '/assets/aistudio/_C_p_nh_t_m_i__Ch_____T_c____e8df4bc0.pdf',
  },
  {
    id: 'pdf-phys-sound',
    title: 'Chủ đề 4: Âm thanh (KHTN 7 KNTT)',
    subject: 'physics' as const,
    lessons: 'Bài 12, Bài 13, Bài 14',
    url: '/assets/aistudio/Ch______m_Thanh_4881f43f.pdf',
  },
  {
    id: 'pdf-phys-light',
    title: 'Chủ đề 5: Ánh sáng (Cập nhật mới – KHTN 7 KNTT)',
    subject: 'physics' as const,
    lessons: 'Bài 15, Bài 16, Bài 17',
    url: '/assets/aistudio/_C_p_nh_t_m_i__Ch______nh_s_ng_ac14e419.pdf',
  },
  {
    id: 'pdf-phys-mag',
    title: 'Chủ đề 6: Từ (Cập nhật mới – KHTN 7 KNTT)',
    subject: 'physics' as const,
    lessons: 'Bài 18, Bài 19, Bài 20, Bài 21',
    url: '/assets/aistudio/_C_p_nh_t_m_i__Ch_____T__2d00c081.pdf',
  },
];

export const LESSON_BANK_STATS = {
  totalLessons: ALL_KNTT_LESSONS.length,
  totalMcq: ALL_KNTT_LESSONS.reduce((sum, l) => sum + l.mcqs.length, 0),
  totalTrueFalse: ALL_KNTT_LESSONS.reduce((sum, l) => sum + l.trueFalseList.length, 0),
  totalTrueFalseStatements: ALL_KNTT_LESSONS.reduce(
    (sum, l) => sum + l.trueFalseList.reduce((s, tf) => s + tf.statements.length, 0),
    0
  ),
  totalEssay: ALL_KNTT_LESSONS.reduce((sum, l) => sum + l.essays.length, 0),
};
