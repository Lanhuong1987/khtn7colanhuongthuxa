import { KhtnLesson, McqItem } from './lessonTypes';

const makeBioMcqs = (
  prefix: string,
  raw: Array<[string, [string, string, string, string], number, string]>
): McqItem[] =>
  raw.map(([question, options, correctIndex, explanation], idx) => ({
    id: `${prefix}-mcq-${idx + 1}`,
    question,
    options,
    correctIndex,
    explanation,
    level: idx < 7 ? 'Nhận biết' : idx < 13 ? 'Thông hiểu' : 'Vận dụng',
  }));

export const BIOLOGY_LESSONS: KhtnLesson[] = [
  // =========================================================================
  // BÀI 22: VAI TRÒ CỦA TRAO ĐỔI CHẤT VÀ CHUYỂN HÓA NĂNG LƯỢNG Ở SINH VẬT
  // =========================================================================
  {
    id: 'kntt-bai-22',
    lessonNumber: 22,
    title: 'Bài 22: Vai trò của trao đổi chất và chuyển hóa năng lượng',
    chapterTitle: 'Chương VII: Trao đổi chất và chuyển hóa năng lượng',
    subject: 'biology',
    summary:
      'Trao đổi chất và chuyển hóa năng lượng là đặc trưng cơ bản của sự sống, gồm quá trình cơ thể lấy các chất từ môi trường, biến đổi chúng thành chất sống của cơ thể và tạo năng lượng cung cấp cho các hoạt động sống, đồng thời thải các chất bã ra môi trường.',
    keyFormulas: [
      'Trao đổi chất với môi trường: Lấy vào (O₂, nước, chất dinh dưỡng, CO₂ ở cây) → Thải ra (CO₂, phân, nước tiểu, mồ hôi, O₂ ở cây)',
      'Chuyển hóa năng lượng trong tế bào: Quang năng → Hóa năng (trong Quang hợp)  |  Hóa năng (Glucose) → ATP + Nhiệt năng (trong Hô hấp tế bào)',
    ],
    mcqs: makeBioMcqs('b22', [
      ['Trao đổi chất ở sinh vật gồm hai quá trình gắn bó mật thiết là:', ['Trao đổi chất giữa cơ thể với môi trường và chuyển hóa các chất ở bên trong tế bào.', 'Chỉ lấy chất dinh dưỡng từ môi trường mà không thải chất bã.', 'Chỉ thải khí carbon dioxide ra môi trường.', 'Chỉ diễn ra khi sinh vật đang ngủ.'], 0, 'Trao đổi chất gồm sự trao đổi chất với môi trường ngoài và sự chuyển hóa vật chất – năng lượng trong tế bào.'],
      ['Nếu quá trình trao đổi chất và chuyển hóa năng lượng ở một cơ thể sinh vật ngừng lại hoàn toàn thì:', ['sinh vật sẽ lớn nhanh hơn.', 'sinh vật sẽ chết vì không còn năng lượng và vật chất duy trì sự sống.', 'sinh vật chuyển sang trạng thái ngủ đông vĩnh viễn.', 'sinh vật không bị ảnh hưởng gì.'], 1, 'Trao đổi chất là điều kiện tồn tại của sinh vật: ngừng trao đổi chất thì sinh vật sẽ chết.'],
      ['Ở người và động vật, cơ thể lấy những chất gì từ môi trường ngoài qua hệ tiêu hóa và hệ hô hấp?', ['Khí carbon dioxide (CO₂) và nước tiểu.', 'Thức ăn (chất dinh dưỡng), nước và khí oxygen (O₂).', 'Ánh sáng mặt trời và đất sét.', 'Khí nitrogen và mồ hôi.'], 1, 'Động vật và người lấy thức ăn, nước qua hệ tiêu hóa và lấy khí O₂ qua hệ hô hấp.'],
      ['Ở người, các sản phẩm thải như khí CO₂, nước tiểu và mồ hôi được bài tiết ra môi trường qua các cơ quan nào?', ['Phổi (thải CO₂), thận (thải nước tiểu) và da (thải mồ hôi).', 'Dạ dày và ruột non.', 'Tim và mạch máu.', 'Hệ xương và cơ.'], 0, 'Phổi, thận và da là các cơ quan bài tiết chính giúp thải CO₂, nước tiểu và mồ hôi.'],
      ['Trong quá trình quang hợp ở cây xanh, dạng năng lượng nào đã được chuyển hóa thành hóa năng tích lũy trong chất hữu cơ?', ['Nhiệt năng.', 'Quang năng (năng lượng ánh sáng mặt trời).', 'Cơ năng.', 'Điện năng.'], 1, 'Diệp lục ở lá hấp thụ quang năng để chuyển hóa thành hóa năng trong các liên kết của phân tử Glucose.'],
      ['Trong quá trình hô hấp tế bào ở người và động vật, hóa năng tích lũy trong chất hữu cơ được chuyển hóa chủ yếu thành:', ['năng lượng ATP (cung cấp cho hoạt động sống) và nhiệt năng (giữ ấm cơ thể).', 'quang năng phát sáng.', 'năng lượng hạt nhân.', 'tinh bột và cellulose.'], 0, 'Hô hấp tế bào phân giải chất hữu cơ tạo ra năng lượng hóa học ATP và nhiệt năng.'],
      ['Dấu hiệu nào sau đây KHÔNG phải là biểu hiện của quá trình trao đổi chất ở thực vật?', ['Rễ cây hút nước và muối khoáng từ đất.', 'Lá cây lấy khí CO₂ và nhả khí O₂ trong quá trình quang hợp.', 'Lá cây thoát hơi nước ra không khí.', 'Hòn đá nằm dưới gốc cây bị vỡ đôi do va đập.'], 3, 'Hòn đá là vật không sống, không thực hiện quá trình trao đổi chất.'],
      ['Vai trò của việc tổng hợp các chất mới (protein, lipid, carbohydrate, DNA) trong quá trình trao đổi chất là:', ['xây dựng tế bào mới, giúp cơ thể sinh trưởng, phát triển, phục hồi tổn thương và sinh sản.', 'làm cho cơ thể giảm khối lượng.', 'chỉ để thải ra ngoài môi trường.', 'ngăn cản tế bào lớn lên.'], 0, 'Chất hữu cơ tổng hợp được dùng làm nguyên liệu xây dựng mô, cơ quan giúp cơ thể lớn lên và sinh sản.'],
      ['Vì sao khi vận động mạnh (chạy bộ, đá bóng), nhịp thở của chúng ta tăng nhanh và cơ thể nóng lên, toát mồ hôi?', ['Vì cơ thể ngừng trao đổi chất.', 'Vì cơ bắp cần nhiều năng lượng ATP nên quá trình hô hấp tế bào tăng mạnh (cần nhiều O₂, thải nhiều CO₂ và tỏa nhiều nhiệt).', 'Vì phổi bị thu nhỏ lại.', 'Vì máu ngừng chảy.'], 1, 'Hoạt động mạnh đòi hỏi nhiều năng lượng, làm tăng tốc độ chuyển hóa vật chất và sinh nhiệt, cơ thể toát mồ hôi để điều hòa thân nhiệt.'],
      ['Nguồn năng lượng khởi đầu cung cấp cho hầu hết mọi sinh vật trên Trái Đất là:', ['Năng lượng gió.', 'Năng lượng ánh sáng Mặt Trời (được thực vật hấp thụ qua quang hợp).', 'Năng lượng thủy triều.', 'Năng lượng từ than đá.'], 1, 'Ánh sáng Mặt Trời được thực vật chuyển hóa thành chất hữu cơ nuôi sống thực vật và toàn bộ động vật trong chuỗi thức ăn.'],
      ['Ở động vật hằng nhiệt (như chim và thú, bao gồm con người), nhiệt lượng giải phóng ra từ quá trình chuyển hóa năng lượng giúp:', ['duy trì thân nhiệt ổn định (ở người khoảng 37°C).', 'làm cơ thể đóng băng.', 'biến cơ thể thành thực vật.', 'ngừng hô hấp.'], 0, 'Nhiệt năng sinh ra từ quá trình phân giải chất hữu cơ giúp duy trì thân nhiệt ổn định.'],
      ['Khi cơ thể người bị sốt cao, bác sĩ thường khuyên uống nhiều nước, ăn thức ăn dễ tiêu và lau mát cơ thể vì:', ['khi sốt cao, tốc độ chuyển hóa năng lượng và thoát hơi nước tăng mạnh làm cơ thể mất nước và tiêu hao nhiều năng lượng.', 'để làm tăng nhiệt độ cơ thể lên 42°C.', 'để ngừng quá trình bài tiết.', 'vì người sốt không cần năng lượng.'], 0, 'Khi sốt, chuyển hóa tăng cao gây mất nước và tiêu hao năng lượng nên cần bù nước, điện giải và dinh dưỡng dễ hấp thụ.'],
      ['Loại phân tử nào được coi là “đồng tiền năng lượng” trực tiếp cung cấp cho mọi hoạt động sống của tế bào?', ['Glucose.', 'ATP (Adenosine triphosphate).', 'Khí Carbon dioxide.', 'Muối khoáng.'], 1, 'ATP là hợp chất cao năng trực tiếp cung cấp năng lượng cho co cơ, dẫn truyền thần kinh, vận chuyển chất qua màng.'],
      ['Quá trình biến đổi các chất phức tạp (như tinh bột, protein trong thức ăn) thành các chất đơn giản và giải phóng năng lượng được gọi là:', ['quá trình tổng hợp (đồng hóa).', 'quá trình phân giải (dị hóa).', 'quá trình quang hợp.', 'quá trình thoát hơi nước.'], 1, 'Quá trình phân giải chất hữu cơ phức tạp thành chất đơn giản kèm theo giải phóng năng lượng gọi là dị hóa.'],
      ['Quá trình tế bào sử dụng nguyên liệu đơn giản và năng lượng để tạo ra các hợp chất phức tạp đặc trưng cho cơ thể gọi là:', ['quá trình tổng hợp (đồng hóa).', 'quá trình phân giải (dị hóa).', 'quá trình bài tiết.', 'quá trình tiêu hóa cơ học.'], 0, 'Tổng hợp chất mới và tích lũy năng lượng gọi là quá trình đồng hóa.'],
      ['Ở độ tuổi học sinh THCS (12 – 15 tuổi), cơ thể đang lớn rất nhanh. Lúc này mối tương quan giữa quá trình tổng hợp và quá trình phân giải trong cơ thể là:', ['Quá trình tổng hợp (tích lũy xây dựng cơ thể) mạnh hơn quá trình phân giải.', 'Quá trình phân giải mạnh gấp đôi quá trình tổng hợp.', 'Không có quá trình tổng hợp.', 'Không có quá trình phân giải.'], 0, 'Ở tuổi dậy thì đang lớn nhanh, quá trình tổng hợp vượt trội hơn phân giải để tạo thêm nhiều tế bào mới giúp tăng chiều cao và cân nặng.'],
    ]),
    trueFalseList: [
      {
        id: 'b22-tf-1',
        stem: 'Xét khái niệm và bản chất của trao đổi chất và chuyển hóa năng lượng:',
        statements: [
          { id: 'a', text: 'Trao đổi chất và chuyển hóa năng lượng luôn gắn liền với nhau, là đặc trưng cơ bản giúp phân biệt vật sống với vật không sống.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Quá trình trao đổi chất chỉ diễn ra ở động vật, còn thực vật đứng yên một chỗ nên không có trao đổi chất.', isTrue: false, explanation: 'Sai, mọi sinh vật sống (thực vật, động vật, nấm, vi khuẩn) đều thực hiện trao đổi chất liên tục.' },
          { id: 'c', text: 'Chuyển hóa năng lượng ở sinh vật là sự biến đổi năng lượng từ dạng này sang dạng khác (ví dụ từ quang năng thành hóa năng, từ hóa năng thành nhiệt năng).', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Nếu các chất thải độc hại (như CO₂, urê) không được cơ thể bài tiết ra môi trường ngoài thì cơ thể sẽ bị nhiễm độc và rối loạn chuyển hóa.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b22-tf-2',
        stem: 'Xét sự trao đổi chất giữa cơ thể người với môi trường bên ngoài:',
        statements: [
          { id: 'a', text: 'Hệ tiêu hóa giúp cơ thể lấy thức ăn, nước uống và thải phân ra ngoài.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Hệ hô hấp giúp cơ thể lấy khí carbon dioxide (CO₂) từ không khí và thải khí oxygen (O₂) ra môi trường.', isTrue: false, explanation: 'Sai, hệ hô hấp lấy khí O₂ từ không khí vào máu và thải khí CO₂ ra môi trường.' },
          { id: 'c', text: 'Hệ bài tiết (thận) và da giúp lọc máu và đào thải nước tiểu, mồ hôi chứa các chất dư thừa ra khỏi cơ thể.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Hệ tuần hoàn (tim và mạch máu) đóng vai trò vận chuyển chất dinh dưỡng và O₂ tới từng tế bào, đồng thời mang chất thải từ tế bào tới cơ quan bài tiết.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b22-tf-3',
        stem: 'Xét các vai trò của trao đổi chất và chuyển hóa năng lượng đối với cơ thể sinh vật:',
        statements: [
          { id: 'a', text: 'Cung cấp nguyên liệu để xây dựng tế bào và mô mới, giúp cơ thể sinh trưởng, phát triển và sinh sản.', isTrue: true, explanation: 'Đúng vai trò cung cấp vật chất.' },
          { id: 'b', text: 'Cung cấp năng lượng (ATP, nhiệt năng) cho mọi hoạt động sống như vận động, cảm ứng, giữ ấm cơ thể.', isTrue: true, explanation: 'Đúng vai trò cung cấp năng lượng.' },
          { id: 'c', text: 'Khi một người đang nằm ngủ yên vào ban đêm, mọi hoạt động trao đổi chất và chuyển hóa năng lượng trong cơ thể đều dừng lại hoàn toàn (bằng 0).', isTrue: false, explanation: 'Sai, khi ngủ tim vẫn đập, phổi vẫn thở, não và các tế bào vẫn duy trì chuyển hóa cơ bản.' },
          { id: 'd', text: 'Nhờ quá trình trao đổi chất mà vết thương trên da hay cành cây bị gãy có thể lành lại và tái tạo mô mới.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b22-tf-4',
        stem: 'So sánh sự trao đổi chất ở thực vật có diệp lục và động vật:',
        statements: [
          { id: 'a', text: 'Thực vật có khả năng tự tổng hợp chất hữu cơ từ các chất vô cơ (CO₂, H₂O) nhờ năng lượng ánh sáng mặt trời.', isTrue: true, explanation: 'Đúng (sinh vật tự dưỡng).' },
          { id: 'b', text: 'Động vật không có khả năng quang hợp nên phải lấy sẵn các chất hữu cơ từ thức ăn (thực vật hoặc động vật khác).', isTrue: true, explanation: 'Đúng (sinh vật dị dưỡng).' },
          { id: 'c', text: 'Thực vật chỉ thực hiện quang hợp vào ban ngày chứ hoàn toàn không thực hiện hô hấp tế bào.', isTrue: false, explanation: 'Sai, thực vật thực hiện hô hấp tế bào suốt ngày đêm để tạo năng lượng cho các hoạt động sống của cây.' },
          { id: 'd', text: 'Cả thực vật và động vật đều cần nước và các nguyên tố khoáng thiết yếu để duy trì trao đổi chất.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b22-tf-5',
        stem: 'Xét ảnh hưởng của hoạt động thể lực và môi trường đến tốc độ chuyển hóa năng lượng ở người:',
        statements: [
          { id: 'a', text: 'Khi lao động nặng hoặc chơi thể thao, nhu cầu năng lượng tăng cao nên nhịp tim và nhịp hô hấp đều tăng.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Vào mùa đông trời lạnh, cơ thể người tăng cường phân giải chất hữu cơ để sinh nhiệt giữ ấm nên ta thường cảm thấy nhanh đói hơn.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Uống đủ nước mỗi ngày giúp các phản ứng chuyển hóa vật chất và đào thải chất độc qua thận diễn ra thuận lợi.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Ăn càng nhiều đồ chiên rán nhiều dầu mỡ và nước ngọt có ga thì quá trình trao đổi chất càng khỏe mạnh, không gây béo phì.', isTrue: false, explanation: 'Sai, dư thừa năng lượng từ đường và chất béo xấu gây tích mỡ, béo phì và rối loạn chuyển hóa.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b22-es-1',
        question: 'Câu 1 [SGK KHTN 7 - KNTT]: Trao đổi chất và chuyển hóa năng lượng là gì? Nêu các vai trò cơ bản của trao đổi chất và chuyển hóa năng lượng đối với cơ thể sinh vật.',
        hint: 'Nêu khái niệm và 2 vai trò lớn: cung cấp nguyên liệu xây dựng cơ thể & cung cấp năng lượng cho hoạt động sống.',
        sampleAnswer: '- Khái niệm: Trao đổi chất và chuyển hóa năng lượng là quá trình cơ thể sinh vật lấy các chất từ môi trường, biến đổi chúng thành các chất cần thiết cho cơ thể và tạo năng lượng cung cấp cho các hoạt động sống, đồng thời trả lại cho môi trường các chất thải.\n- Vai trò đối với cơ thể sinh vật:\n1. Cung cấp nguyên liệu cấu tạo nên tế bào và cơ thể, giúp sinh vật sinh trưởng, phát triển, phục hồi tổn thương và sinh sản.\n2. Cung cấp năng lượng (ATP, nhiệt năng) cho mọi hoạt động sống của tế bào và cơ thể (vận động, cảm ứng, hấp thụ chất, điều hòa thân nhiệt).',
        rubricPoints: [
          'Nêu đúng khái niệm trao đổi chất và chuyển hóa năng lượng.',
          'Nêu đúng 2 vai trò chính: cung cấp nguyên liệu xây dựng cơ thể và cung cấp năng lượng.',
        ],
      },
      {
        id: 'b22-es-2',
        question: 'Câu 2 [SGK KHTN 7 - KNTT]: Hãy liệt kê các chất mà cơ thể người lấy vào từ môi trường và các chất thải ra môi trường trong quá trình trao đổi chất. Nêu sự biến đổi các dạng năng lượng trong cơ thể người khi ăn cơm rồi đạp xe đến trường.',
        hint: 'Thức ăn chứa dạng năng lượng gì? Khi đạp xe chuyển thành dạng năng lượng gì?',
        sampleAnswer: '- Các chất cơ thể người lấy vào: Thức ăn (chứa carbohydrate, protein, lipid, vitamin, muối khoáng), nước uống và khí oxygen (O₂).\n- Các chất cơ thể thải ra môi trường: Khí carbon dioxide (CO₂), phân, nước tiểu và mồ hôi.\n- Sự chuyển hóa năng lượng khi ăn cơm và đạp xe: Hóa năng tích lũy trong thức ăn (cơm) được cơ thể phân giải chuyển hóa thành năng lượng hóa học trong phân tử ATP, sau đó chuyển hóa thành cơ năng (giúp cơ chân co duỗi đạp xe) và nhiệt năng (làm ấm cơ thể).',
        rubricPoints: [
          'Liệt kê đúng các chất lấy vào (thức ăn, nước, O₂) và thải ra (CO₂, phân, nước tiểu, mồ hôi).',
          'Mô tả đúng sự chuyển hóa: Hóa năng (thức ăn) → Năng lượng ATP → Cơ năng + Nhiệt năng.',
        ],
      },
      {
        id: 'b22-es-3',
        question: 'Câu 3 [SBT KHTN 7 - KNTT]: Giải thích vì sao khi chúng ta chạy bộ hoặc lao động chân tay nặng nhọc thì nhịp thở tăng nhanh, tim đập nhanh hơn, cơ thể nóng lên và toát nhiều mồ hôi?',
        hint: 'Liên hệ nhu cầu năng lượng của hệ cơ với quá trình hô hấp tế bào và điều hòa thân nhiệt.',
        sampleAnswer: '- Khi chạy bộ hoặc lao động nặng, hệ cơ hoạt động mạnh nên cần một lượng lớn năng lượng ATP.\n- Để tạo ra nhiều ATP, quá trình hô hấp tế bào phải diễn ra mạnh mẽ, đòi hỏi nhiều khí O₂ và chất dinh dưỡng, đồng thời thải ra nhiều khí CO₂ ⇒ Do đó nhịp thở và nhịp tim phải tăng nhanh để cung cấp kịp thời O₂ và đào thải nhanh CO₂.\n- Quá trình phân giải chất hữu cơ tăng mạnh cũng giải phóng ra nhiều nhiệt lượng làm cơ thể nóng lên ⇒ Cơ thể phản ứng bằng cách toát mồ hôi qua da để tỏa bớt nhiệt, giữ thân nhiệt ổn định ở mức 37°C.',
        rubricPoints: [
          'Giải thích đúng cơ bắp cần nhiều năng lượng nên hô hấp tế bào tăng mạnh (cần nhiều O₂, thải nhiều CO₂) làm tăng nhịp tim, nhịp thở.',
          'Giải thích đúng quá trình chuyển hóa sinh nhiều nhiệt nên cơ thể toát mồ hôi để làm mát.',
        ],
      },
      {
        id: 'b22-es-4',
        question: 'Câu 4 [SBT KHTN 7 - KNTT]: Vì sao vào mùa đông trời lạnh, chúng ta thường có cảm giác nhanh đói và cần ăn nhiều thức ăn giàu năng lượng hơn so với mùa hè?',
        hint: 'Vào mùa đông cơ thể mất nhiều nhiệt ra môi trường lạnh.',
        sampleAnswer: '- Con người là sinh vật hằng nhiệt (thân nhiệt luôn duy trì ổn định quanh mức 37°C).\n- Vào mùa đông, nhiệt độ môi trường bên ngoài xuống thấp nên cơ thể bị mất nhiệt ra môi trường nhiều hơn so với mùa hè.\n- Để bù đắp lượng nhiệt bị mất và giữ ấm cho cơ thể, quá trình phân giải các chất hữu cơ (hô hấp tế bào) trong cơ thể phải tăng cường mạnh hơn để sinh nhiệt. Vì tiêu hao nhiều chất hữu cơ dự trữ nên chúng ta cảm thấy nhanh đói và cần ăn nhiều hơn.',
        rubricPoints: [
          'Nêu được mùa đông cơ thể tỏa nhiều nhiệt ra môi trường lạnh.',
          'Giải thích cơ thể phải tăng cường phân giải chất dinh dưỡng để sinh nhiệt giữ ấm nên nhanh đói.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 23: QUANG HỢP Ở THỰC VẬT
  // =========================================================================
  {
    id: 'kntt-bai-23',
    lessonNumber: 23,
    title: 'Bài 23: Quang hợp ở thực vật',
    chapterTitle: 'Chương VII: Trao đổi chất và chuyển hóa năng lượng',
    subject: 'biology',
    summary:
      'Quang hợp là quá trình lá cây sử dụng nước và khí carbon dioxide nhờ năng lượng ánh sáng đã được diệp lục hấp thụ để tổng hợp chất hữu cơ (glucose/tinh bột) và giải phóng khí oxygen. Bào quan thực hiện quang hợp là lục lạp.',
    keyFormulas: [
      'Phương trình chữ:  Nước + Carbon dioxide  --(Ánh sáng, Diệp lục)-->  Glucose (Chất hữu cơ) + Oxygen',
      'Phương trình hóa học:  6 CO₂ + 6 H₂O  --(Ánh sáng, Diệp lục)-->  C₆H₁₂O₆ + 6 O₂↑',
      'Bào quan quang hợp: Lục lạp (chứa sắc tố diệp lục)  |  Cấu tạo lá thích nghi: Phiến lá dẹt, rộng; nhiều lục lạp; có hệ gân lá và nhiều khí khổng',
    ],
    mcqs: makeBioMcqs('b23', [
      ['Cơ quan chính thực hiện quá trình quang hợp ở thực vật là:', ['Rễ cây.', 'Thân cây.', 'Lá cây.', 'Hoa và quả.'], 2, 'Lá cây là cơ quan chính thực hiện quang hợp vì có phiến lá rộng và chứa nhiều lục lạp.'],
      ['Bào quan trong tế bào thịt lá thực hiện chức năng quang hợp là:', ['Ti thể.', 'Lục lạp (chứa chất diệp lục).', 'Nhân tế bào.', 'Không bào.'], 1, 'Lục lạp chứa sắc tố diệp lục có khả năng hấp thụ năng lượng ánh sáng để quang hợp.'],
      ['Nguyên liệu trực tiếp của quá trình quang hợp ở cây xanh là:', ['Khí oxygen (O₂) và nước.', 'Khí carbon dioxide (CO₂) và nước (H₂O).', 'Glucose và khí oxygen.', 'Tinh bột và muối khoáng.'], 1, 'Nguyên liệu của quang hợp là khí CO₂ (lấy từ không khí qua khí khổng) và H₂O (hút từ rễ lên).'],
      ['Sản phẩm tạo ra từ quá trình quang hợp ở thực vật là:', ['Chất hữu cơ (Glucose / Tinh bột) và khí oxygen (O₂).', 'Khí carbon dioxide và nước.', 'Năng lượng ATP và khí CO₂.', 'Chỉ có hơi nước.'], 0, 'Sản phẩm của quang hợp là chất hữu cơ (glucose, sau đó chuyển thành tinh bột) và khí oxygen.'],
      ['Trong quá trình quang hợp, năng lượng đã được chuyển hóa như thế nào?', ['Từ hóa năng thành quang năng.', 'Từ quang năng (năng lượng ánh sáng) thành hóa năng (trong các liên kết của hợp chất hữu cơ).', 'Từ nhiệt năng thành cơ năng.', 'Từ hóa năng thành nhiệt năng.'], 1, 'Quang hợp chuyển hóa quang năng thành hóa năng tích lũy trong phân tử hữu cơ.'],
      ['Bộ phận nào trên lớp biểu bì của lá cây giúp khí CO₂ khuếch tán từ ngoài không khí vào bên trong lá và khí O₂ đi ra ngoài?', ['Gân lá.', 'Cuống lá.', 'Khí khổng (lỗ khí).', 'Lớp cutin.'], 2, 'Khí khổng đóng mở giúp trao đổi khí (CO₂ vào, O₂ ra) và thoát hơi nước.'],
      ['Hệ thống gân lá đóng vai trò gì đối với quá trình quang hợp của lá cây?', ['Chỉ làm cho lá cứng cáp.', 'Vận chuyển nước và muối khoáng (theo mạch gỗ) đến từng tế bào thịt lá để làm nguyên liệu quang hợp, và vận chuyển chất hữu cơ (theo mạch rây) đi khỏi lá.', 'Hấp thụ trực tiếp ánh sáng.', 'Đóng mở khí khổng.'], 1, 'Gân lá chứa các bó mạch gỗ (dẫn nước vào lá) và mạch rây (dẫn sản phẩm quang hợp từ lá đi nuôi cây).'],
      ['Đặc điểm hình thái nào của phiến lá giúp lá thu nhận được nhiều tia sáng mặt trời nhất?', ['Phiến lá thường có bản dẹt, diện tích bề mặt lớn và xếp xen kẽ nhau trên cành.', 'Phiến lá cuộn tròn lại.', 'Phiến lá mọc ngầm dưới đất.', 'Phiến lá không có màu xanh.'], 0, 'Phiến lá bản dẹt, rộng và xếp so le giúp tránh che khuất nhau, tối ưu hóa diện tích nhận ánh sáng.'],
      ['Ở các loài cây như xương rồng sống ở sa mạc khô hạn, lá biến đổi thành gai để giảm mất nước. Vậy bộ phận nào của cây xương rồng thực hiện chức năng quang hợp?', ['Các chiếc gai khô.', 'Thân cây màu xanh có chứa nhiều diệp lục.', 'Rễ cây sâu dưới đất.', 'Cây xương rồng không quang hợp.'], 1, 'Thân cây xương rồng mọng nước và có màu xanh (chứa lục lạp) đảm nhận chức năng quang hợp thay cho lá.'],
      ['Những cây có lá màu đỏ hoặc màu tím (như cây tía tô, cây huyết dụ, rau dền đỏ) có thực hiện quang hợp được không?', ['Không, vì chúng hoàn toàn không có diệp lục.', 'Có, vì trong lá vẫn có chứa chất diệp lục nhưng bị sắc tố màu đỏ/tím (anthocyanin, carotenoid) che khuất màu xanh.', 'Chỉ quang hợp vào ban đêm.', 'Chúng sống kí sinh vào đất.'], 1, 'Trong lá cây tía tô, rau dền đỏ vẫn có đầy đủ lục lạp và diệp lục để quang hợp bình thường.'],
      ['Yếu tố ngoại cảnh nào sau đây ảnh hưởng trực tiếp đến cường độ quang hợp của cây xanh?', ['Ánh sáng, nồng độ khí CO₂, nước và nhiệt độ.', 'Chỉ có tiếng ồn trong không khí.', 'Từ trường của nam châm.', 'Áp suất khí hiếm Argon.'], 0, '4 yếu tố ngoại cảnh chính ảnh hưởng đến quang hợp là: Ánh sáng, CO₂, nước và nhiệt độ.'],
      ['Khi nồng độ khí CO₂ trong không khí giảm xuống quá thấp (dưới 0,008% - 0,01%) thì quá trình quang hợp của cây sẽ:', ['tăng lên gấp đôi.', 'bị ngừng trệ và cây không thể quang hợp được nữa.', 'chuyển sang tạo ra khí nitrogen.', 'không bị ảnh hưởng.'], 1, 'CO₂ là nguyên liệu trực tiếp của quang hợp; khi nồng độ CO₂ quá thấp dưới ngưỡng bù thì quang hợp ngừng lại.'],
      ['Nhiệt độ môi trường thuận lợi nhất cho quá trình quang hợp của đa số cây trồng vùng nhiệt đới nằm trong khoảng:', ['0°C – 5°C.', '25°C – 35°C.', '50°C – 60°C.', 'Trên 70°C.'], 1, 'Đa số thực vật nhiệt đới quang hợp hiệu quả nhất ở khoảng nhiệt độ 25°C – 35°C.'],
      ['Trong thí nghiệm phát hiện tinh bột tạo thành qua quang hợp (Bài 24 KNTT), người ta dùng dung dịch thuốc thử nào nhỏ lên lá cây đã tẩy sắc tố để nhận biết tinh bột?', ['Dung dịch nước vôi trong.', 'Dung dịch Iodine (cồn i-ốt) — làm phần lá có tinh bột chuyển sang màu xanh tím.', 'Nước cất.', 'Dầu ăn.'], 1, 'Dung dịch Iodine tác dụng với hồ tinh bột tạo ra màu xanh tím đặc trưng.'],
      ['Trong thí nghiệm chứng minh quang hợp giải phóng khí oxygen ở rong đuôi chó đặt trong cốc nước ngoài nắng, người ta thử chất khí thu được trong ống nghiệm bằng cách nào?', ['Đưa que đóm còn tàn đỏ vào miệng ống nghiệm thấy que đóm bùng cháy trở lại.', 'Đưa tờ giấy quỳ tím vào.', 'Đổ giấm ăn vào.', 'Ngửi mùi của chất khí.'], 0, 'Khí oxygen (O₂) duy trì sự cháy nên làm que đóm còn tàn đỏ bùng cháy thành ngọn lửa.'],
      ['Vì sao khi trồng lúa, ngô hoặc cây ăn quả, người nông dân phải trồng với mật độ vừa phải (không trồng quá dày sát nhau)?', ['Để tiết kiệm hạt giống.', 'Để các cây không che khuất ánh sáng của nhau, thông thoáng khí CO₂ và đủ nước, khoáng giúp cây quang hợp tốt nhất.', 'Để sâu bệnh dễ phát triển.', 'Để giảm cường độ quang hợp của cây.'], 1, 'Trồng mật độ hợp lí giúp tán lá nhận đủ ánh sáng và khí CO₂ để quang hợp đạt năng suất cao.'],
      ['Việc trồng và bảo vệ nhiều cây xanh ở các đô thị và khu công nghiệp có ý nghĩa gì đối với môi trường và biến đổi khí hậu?', ['Cây xanh quang hợp hấp thụ khí CO₂ (khí nhà kính) và giải phóng khí O₂, giúp điều hòa không khí và giảm hiệu ứng nhà kính.', 'Làm không khí nóng hơn.', 'Làm tăng lượng khí CO₂ trong thành phố.', 'Chỉ để lấy củi đốt.'], 0, 'Quang hợp của rừng và cây xanh giữ cân bằng tỉ lệ O₂ / CO₂ trong khí quyển và giảm hiệu ứng nhà kính.'],
      ['Vào những ngày nắng gắt trên 40°C và khô hạn, cường độ quang hợp của cây trồng giảm mạnh vì:', ['khí khổng đóng lại để hạn chế mất nước làm khí CO₂ không thể khuếch tán vào lá.', 'lục lạp biến thành ti thể.', 'khí O₂ trong không khí biến mất.', 'rễ cây ngừng hô hấp.'], 0, 'Khi thiếu nước và nắng gắt, khí khổng đóng lại dẫn đến thiếu nguyên liệu CO₂ cho quang hợp.'],
    ]),
    trueFalseList: [
      {
        id: 'b23-tf-1',
        stem: 'Xét khái niệm, nguyên liệu và sản phẩm của quá trình quang hợp ở thực vật:',
        statements: [
          { id: 'a', text: 'Quang hợp là quá trình tổng hợp chất hữu cơ (glucose) từ các chất vô cơ (CO₂ và H₂O) nhờ năng lượng ánh sáng được diệp lục hấp thụ.', isTrue: true, explanation: 'Đúng định nghĩa quang hợp.' },
          { id: 'b', text: 'Phương trình tổng quát của quang hợp là: Nước + Carbon dioxide → Glucose + Oxygen (điều kiện: Ánh sáng, Diệp lục).', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Quá trình quang hợp diễn ra ở mọi tế bào của cây kể cả các tế bào rễ nằm sâu dưới lòng đất tối.', isTrue: false, explanation: 'Sai, quang hợp chỉ diễn ra ở các tế bào chứa lục lạp (diệp lục) và khi có ánh sáng.' },
          { id: 'd', text: 'Khí oxygen giải phóng ra từ quá trình quang hợp của thực vật có nguồn gốc từ sự phân li các phân tử nước (H₂O).', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b23-tf-2',
        stem: 'Xét mối quan hệ giữa cấu tạo của lá cây và chức năng quang hợp:',
        statements: [
          { id: 'a', text: 'Phiến lá thường có dạng bản dẹt và rộng giúp thu nhận được nhiều tia sáng mặt trời nhất.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Lớp tế bào thịt lá chứa rất nhiều lục lạp là nơi trực tiếp diễn ra quá trình quang hợp.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Lớp biểu bì của lá có nhiều khí khổng giúp khí O₂ đi vào làm nguyên liệu quang hợp và thải khí CO₂ ra ngoài.', isTrue: false, explanation: 'Sai, trong quang hợp khí khổng lấy khí CO₂ vào làm nguyên liệu và thải khí O₂ ra ngoài.' },
          { id: 'd', text: 'Hệ thống gân lá chứa mạch gỗ (dẫn nước và muối khoáng đến lá) và mạch rây (dẫn chất hữu cơ từ lá đi nuôi các bộ phận khác của cây).', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b23-tf-3',
        stem: 'Xét ảnh hưởng của các yếu tố môi trường đến quang hợp:',
        statements: [
          { id: 'a', text: 'Các loài cây ưa sáng (như lúa, ngô, bạch đàn, phi lao) cần cường độ ánh sáng mạnh để quang hợp đạt hiệu quả cao.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Các loài cây ưa bóng (như cây lá lốt, cây vạn niên thanh, cây phong lan) có thể quang hợp tốt ở nơi có ánh sáng yếu hoặc bóng râm.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Khi tăng nồng độ khí CO₂ và nhiệt độ môi trường càng cao đến vô hạn (80°C – 100°C) thì cường độ quang hợp của cây càng tăng mạnh.', isTrue: false, explanation: 'Sai, chỉ tăng đến giới hạn tối ưu (khoảng 0,4% CO₂ và 25-35°C); nếu nhiệt độ quá cao trên 45-50°C sẽ làm hỏng enzyme và ngừng quang hợp.' },
          { id: 'd', text: 'Khi cây bị thiếu nước (hạn hán), tế bào khí khổng mất nước và đóng lại làm quang hợp bị đình trệ.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b23-tf-4',
        stem: 'Trong thí nghiệm chứng minh tinh bột được tạo thành trong quang hợp (dùng băng giấy đen bịt kín một phần lá cây khoai lang rồi để ngoài nắng 6 giờ, sau đó đun cách thủy trong cồn và nhỏ dung dịch Iodine):',
        statements: [
          { id: 'a', text: 'Việc để chậu cây trong bóng tối 2 ngày trước khi làm thí nghiệm nhằm mục đích làm tiêu hao hết lượng tinh bột có sẵn trong lá.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Việc đun sôi lá trong cồn 90° cách thủy nhằm mục đích hòa tan và tẩy hết sắc tố diệp lục màu xanh để dễ quan sát màu của phản ứng với Iodine.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Sau khi nhỏ dung dịch Iodine, phần lá bị bịt kín bằng băng giấy đen chuyển sang màu xanh tím đậm, còn phần lá không bịt thì không đổi màu.', isTrue: false, explanation: 'Sai, phần lá KHÔNG bị bịt giấy đen nhận được ánh sáng nên quang hợp tạo ra tinh bột và chuyển màu xanh tím; còn phần bị bịt giấy đen không nhận được ánh sáng nên không tạo được tinh bột.' },
          { id: 'd', text: 'Thí nghiệm này chứng minh ánh sáng là điều kiện bắt buộc để lá cây quang hợp tổng hợp nên tinh bột.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b23-tf-5',
        stem: 'Xét vai trò của quang hợp đối với tự nhiên và đời sống con người:',
        statements: [
          { id: 'a', text: 'Cung cấp nguồn chất hữu cơ làm thức ăn cho mọi sinh vật dị dưỡng và làm nguyên liệu cho công nghiệp, dược phẩm.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Hấp thụ khí CO₂ và giải phóng khí O₂ giúp duy trì cân bằng hàm lượng khí O₂ (≈ 21%) và CO₂ (≈ 0,03% - 0,04%) trong khí quyển.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Để bầu không khí trong phòng ngủ ban đêm có nhiều khí oxygen, ta nên đặt thật nhiều chậu cây xanh um tùm trong phòng ngủ đóng kín cửa.', isTrue: false, explanation: 'Sai, vào ban đêm không có ánh sáng nên cây ngừng quang hợp và chỉ thực hiện hô hấp (hút O₂ và thải CO₂), dễ gây thiếu dưỡng khí trong phòng kín.' },
          { id: 'd', text: 'Trong nông nghiệp hiện đại, người ta có thể dùng đèn LED chiếu sáng nhân tạo và bổ sung CO₂ trong nhà kính để tăng năng suất rau quả.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b23-es-1',
        question: 'Câu 1 [SGK KHTN 7 - KNTT]:\n(a) Quang hợp là gì? Viết phương trình quang hợp dạng chữ.\n(b) Cho biết nguyên liệu, sản phẩm, nơi diễn ra và sự chuyển hóa năng lượng trong quá trình quang hợp.',
        hint: 'Chú ý phân biệt nguyên liệu (vô cơ) và sản phẩm (hữu cơ + O₂) cùng điều kiện ánh sáng, diệp lục.',
        sampleAnswer: '(a) Khái niệm: Quang hợp là quá trình lá cây sử dụng nước và khí carbon dioxide nhờ năng lượng ánh sáng đã được diệp lục hấp thụ để tổng hợp chất hữu cơ và giải phóng khí oxygen.\n- Phương trình dạng chữ:\nNước + Carbon dioxide  --(Ánh sáng, Diệp lục)-->  Glucose (Chất hữu cơ) + Oxygen\n(b) Chi tiết:\n- Nguyên liệu: Nước (H₂O) và khí Carbon dioxide (CO₂).\n- Sản phẩm: Chất hữu cơ (Glucose / Tinh bột) và khí Oxygen (O₂).\n- Nơi diễn ra: Bào quan lục lạp (trong tế bào thịt lá).\n- Chuyển hóa năng lượng: Chuyển hóa quang năng (ánh sáng) thành hóa năng (tích lũy trong chất hữu cơ).',
        rubricPoints: [
          'Nêu đúng khái niệm và viết đúng phương trình chữ của quang hợp.',
          'Nêu đúng nguyên liệu, sản phẩm, bào quan lục lạp và sự chuyển hóa quang năng → hóa năng.',
        ],
      },
      {
        id: 'b23-es-2',
        question: 'Câu 2 [SGK KHTN 7 - KNTT]: Hãy phân tích các đặc điểm cấu tạo của lá cây (phiến lá, lục lạp, hệ gân lá, khí khổng) thích nghi với chức năng quang hợp.',
        hint: 'Mỗi bộ phận của lá đảm nhận một nhiệm vụ cụ thể trong việc thu sáng, dẫn nguyên liệu và trao đổi khí.',
        sampleAnswer: 'Các đặc điểm cấu tạo của lá cây thích nghi với chức năng quang hợp:\n1. Phiến lá: Có dạng bản dẹt, mỏng và diện tích bề mặt lớn; các lá xếp xen kẽ nhau giúp thu nhận được tối đa ánh sáng mặt trời.\n2. Tế bào thịt lá chứa nhiều lục lạp: Lục lạp chứa sắc tố diệp lục giúp hấp thụ và chuyển hóa năng lượng ánh sáng.\n3. Hệ thống gân lá phát triển: Phân nhánh đến tận từng tế bào thịt lá, chứa mạch gỗ (dẫn nước và muối khoáng từ rễ lên làm nguyên liệu) và mạch rây (vận chuyển chất hữu cơ tổng hợp được đi nuôi cây).\n4. Lớp biểu bì có nhiều khí khổng: Khí khổng đóng mở giúp khí CO₂ từ không khí khuếch tán vào trong lá và khí O₂ thoát ra ngoài môi trường.',
        rubricPoints: [
          'Phân tích đúng vai trò của phiến lá dẹt rộng và lớp tế bào chứa nhiều lục lạp.',
          'Phân tích đúng vai trò của hệ thống gân lá và khí khổng.',
        ],
      },
      {
        id: 'b23-es-3',
        question: 'Câu 3 [SBT KHTN 7 - KNTT]:\n(a) Ở cây xương rồng lá đã biến thành gai, vậy cây xương rồng có quang hợp được không? Bộ phận nào thực hiện chức năng đó?\n(b) Các loài cây có lá màu đỏ, tím như cây huyết dụ, cây tía tô, rau dền đỏ có quang hợp được không? Vì sao?',
        hint: '(a) Quan sát màu sắc thân cây xương rồng; (b) Trong lá đỏ có chất diệp lục không?',
        sampleAnswer: '(a) Cây xương rồng vẫn quang hợp bình thường. Do sống ở nơi khô hạn nắng nóng, lá xương rồng biến thành gai để hạn chế sự thoát hơi nước; thay vào đó, THÂN CÂY xương rồng mọng nước và có màu xanh chứa nhiều lục lạp đảm nhận chức năng quang hợp thay cho lá.\n(b) Các cây có lá màu đỏ, tím (tía tô, huyết dụ, rau dền đỏ) vẫn quang hợp bình thường. Vì trong tế bào lá của chúng vẫn có đầy đủ lục lạp và chất diệp lục màu xanh, nhưng do hàm lượng sắc tố phụ (như anthocyanin màu đỏ tím) nhiều hơn nên đã che khuất màu xanh của diệp lục.',
        rubricPoints: [
          'Giải thích đúng thân xanh của xương rồng thực hiện quang hợp thay cho lá biến thành gai.',
          'Giải thích đúng lá màu đỏ/tím vẫn chứa diệp lục nhưng bị sắc tố đỏ/tím át màu.',
        ],
      },
      {
        id: 'b23-es-4',
        question: 'Câu 4 [SGK KHTN 7 - KNTT]: Giải thích cơ sở khoa học của các biện pháp kĩ thuật nông nghiệp sau:\n(a) Tại sao khi trồng cây nông nghiệp (lúa, ngô, cây ăn quả) cần trồng đúng thời vụ và đảm bảo mật độ vừa phải?\n(b) Tại sao vào những ngày hè nắng nóng cần tưới đủ nước cho cây trồng?',
        hint: 'Liên hệ đến 4 yếu tố ngoại cảnh ảnh hưởng đến quang hợp: ánh sáng, nhiệt độ, CO₂, nước.',
        sampleAnswer: '(a) Trồng đúng thời vụ và đúng mật độ:\n- Trồng đúng thời vụ giúp cây sinh trưởng trong điều kiện nhiệt độ và chế độ chiếu sáng thích hợp nhất cho quang hợp.\n- Trồng với mật độ vừa phải giúp các tán lá không che khuất ánh sáng của nhau, đồng thời không khí lưu thông tốt cung cấp đủ CO₂ giúp quang hợp đạt hiệu suất cao nhất.\n(b) Tưới đủ nước ngày nắng nóng:\n- Nước vừa là nguyên liệu trực tiếp của quang hợp, vừa giúp làm mát lá và duy trì độ trương nước để khí khổng mở cho CO₂ đi vào lá.',
        rubricPoints: [
          'Giải thích đúng ý nghĩa của trồng đúng thời vụ (nhiệt độ, ánh sáng) và đúng mật độ (không che sáng, thoáng khí CO₂).',
          'Giải thích đúng vai trò của nước đối với nguyên liệu quang hợp và độ mở khí khổng.',
        ],
      },
      {
        id: 'b23-es-5',
        question: 'Câu 5 [SBT KHTN 7 - KNTT]: Nêu các bước tiến hành và giải thích kết quả thí nghiệm chứng minh tinh bột được tạo thành trong quang hợp (sử dụng chậu cây khoai lang, băng giấy đen, cồn 90° và dung dịch Iodine).',
        hint: 'Tại sao phải để cây trong tối 2 ngày? Tại sao đun lá trong cồn? Màu sắc khi nhỏ Iodine?',
        sampleAnswer: '- Các bước chính:\n+ Bước 1: Đặt chậu khoai lang trong bóng tối 2 ngày (để lá sử dụng hết tinh bột cũ).\n+ Bước 2: Dùng băng giấy đen bịt kín một phần ở cả hai mặt của chiếc lá rồi đem chậu cây để ngoài nắng từ 4 – 6 giờ.\n+ Bước 3: Ngắt lá, gỡ băng giấy đen, đun lá trong nước sôi rồi đun cách thủy trong cồn 90° để tẩy sạch chất diệp lục màu xanh.\n+ Bước 4: Rửa sạch lá trong nước ấm rồi nhỏ dung dịch Iodine lên phiến lá.\n- Kết quả và giải thích:\n+ Phần lá không bịt băng giấy đen chuyển sang màu xanh tím đặc trưng (do nhận được ánh sáng nên quang hợp tạo ra tinh bột, tinh bột tác dụng với Iodine cho màu xanh tím).\n+ Phần lá bị bịt băng giấy đen không chuyển màu xanh tím (vì không nhận được ánh sáng nên không tổng hợp được tinh bột).',
        rubricPoints: [
          'Trình bày đúng mục đích các bước làm tối, bịt giấy đen, tẩy diệp lục bằng cồn.',
          'Giải thích đúng sự khác biệt màu sắc giữa phần lá được chiếu sáng (xanh tím) và phần bị bịt kín.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 25: HÔ HẤP TẾ BÀO
  // =========================================================================
  {
    id: 'kntt-bai-25',
    lessonNumber: 25,
    title: 'Bài 25: Hô hấp tế bào',
    chapterTitle: 'Chương VII: Trao đổi chất và chuyển hóa năng lượng',
    subject: 'biology',
    summary:
      'Hô hấp tế bào là quá trình tế bào phân giải chất hữu cơ (glucose) khi có khí oxygen thành khí carbon dioxide, nước và giải phóng năng lượng (ATP và nhiệt) cung cấp cho các hoạt động sống. Bào quan thực hiện hô hấp tế bào là ti thể.',
    keyFormulas: [
      'Phương trình chữ:  Glucose + Oxygen  --->  Carbon dioxide + Nước + Năng lượng (ATP + Nhiệt)',
      'Phương trình hóa học:  C₆H₁₂O₆ + 6 O₂  --->  6 CO₂ + 6 H₂O + Năng lượng (ATP + Nhiệt)',
      'Bào quan thực hiện: Ti thể (Mitochondria)  |  Mối quan hệ: Sản phẩm của Quang hợp là nguyên liệu của Hô hấp tế bào và ngược lại',
    ],
    mcqs: makeBioMcqs('b25', [
      ['Hô hấp tế bào là quá trình:', ['tổng hợp chất hữu cơ từ khí CO₂ và nước nhờ ánh sáng.', 'phân giải chất hữu cơ (glucose) tạo thành nước, khí CO₂ và giải phóng năng lượng ATP cung cấp cho các hoạt động sống.', 'chỉ trao đổi khí ở mũi.', 'thoát hơi nước qua bề mặt lá.'], 1, 'Hô hấp tế bào là quá trình phân giải chất hữu cơ có sự tham gia của O₂ tạo thành CO₂, H₂O và năng lượng ATP.'],
      ['Bào quan đóng vai trò là “nhà máy năng lượng” thực hiện quá trình hô hấp tế bào ở sinh vật nhân thực là:', ['Lục lạp.', 'Ti thể.', 'Không bào.', 'Thành tế bào.'], 1, 'Ti thể là bào quan thực hiện quá trình hô hấp tế bào.'],
      ['Nguyên liệu tham gia vào quá trình hô hấp tế bào là:', ['Chất hữu cơ (Glucose) và khí Oxygen (O₂).', 'Khí Carbon dioxide (CO₂) và Nước (H₂O).', 'Muối khoáng và ánh sáng.', 'Năng lượng ATP và khí CO₂.'], 0, 'Nguyên liệu của hô hấp tế bào là Glucose (C₆H₁₂O₆) và khí Oxygen (O₂).'],
      ['Sản phẩm của quá trình hô hấp tế bào bao gồm:', ['Glucose và khí Oxygen.', 'Khí Carbon dioxide (CO₂), Nước (H₂O) và Năng lượng (ATP + nhiệt).', 'Tinh bột và diệp lục.', 'Chỉ có khí Oxygen.'], 1, 'Sản phẩm của hô hấp tế bào là CO₂, H₂O và năng lượng (tích lũy trong ATP + nhiệt năng).'],
      ['Quá trình hô hấp tế bào diễn ra ở những nhóm sinh vật nào?', ['Chỉ diễn ra ở động vật và con người.', 'Chỉ diễn ra ở thực vật vào ban đêm.', 'Diễn ra ở mọi cơ thể sinh vật sống (cả thực vật, động vật, nấm, con người) suốt ngày đêm.', 'Chỉ diễn ra ở hạt đang khô.'], 2, 'Mọi tế bào sống đều phải thực hiện hô hấp tế bào liên tục để tạo năng lượng duy trì sự sống.'],
      ['Trong quá trình hô hấp tế bào, năng lượng đã được chuyển hóa như thế nào?', ['Từ quang năng thành hóa năng.', 'Từ hóa năng tích lũy trong chất hữu cơ (Glucose) thành năng lượng dễ sử dụng trong phân tử ATP và nhiệt năng.', 'Từ nhiệt năng thành quang năng.', 'Từ cơ năng thành quang năng.'], 1, 'Hóa năng trong liên kết của Glucose được giải phóng thành năng lượng ATP và nhiệt năng.'],
      ['Nhận xét nào sau đây là ĐÚNG về mối quan hệ giữa Quang hợp và Hô hấp tế bào?', ['Là hai quá trình hoàn toàn độc lập, không liên quan gì đến nhau.', 'Là hai quá trình trái ngược nhau nhưng phụ thuộc chặt chẽ lẫn nhau: sản phẩm của quang hợp (chất hữu cơ, O₂) là nguyên liệu của hô hấp tế bào và ngược lại.', 'Cả hai quá trình đều tạo ra khí Oxygen.', 'Cả hai quá trình đều diễn ra ở lục lạp.'], 1, 'Sản phẩm của quá trình này chính là nguyên liệu của quá trình kia.'],
      ['Trong thí nghiệm chứng minh hô hấp ở hạt đậu đang nảy mầm (Bài 26 KNTT), vì sao khi dẫn khí trong bình chứa hạt đang nảy mầm vào ống nghiệm đựng nước vôi trong thì nước vôi trong bị vẩn đục?', ['Vì hạt đang nảy mầm thải ra nhiều khí Oxygen.', 'Vì hạt đang nảy mầm hô hấp mạnh thải ra nhiều khí Carbon dioxide (CO₂) làm đục nước vôi trong.', 'Vì hạt đậu tiết ra tinh bột.', 'Vì hạt đậu quang hợp trong bình tối.'], 1, 'Khí CO₂ do hạt nảy mầm thải ra phản ứng với nước vôi trong Ca(OH)₂ tạo kết tủa trắng CaCO₃ làm vẩn đục.'],
      ['Trong thí nghiệm đặt nhiệt kế vào bình giữ nhiệt chứa hạt đậu đang nảy mầm, ta thấy số chỉ của nhiệt kế tăng lên cao hơn bình đối chứng (chứa hạt khô đã luộc chín). Điều này chứng minh:', ['hạt đang nảy mầm hô hấp tế bào có tỏa ra nhiệt năng.', 'hạt đậu tự hấp thụ ánh sáng.', 'nhiệt kế bị hỏng.', 'hạt đã luộc chín hô hấp mạnh hơn.'], 0, 'Một phần năng lượng giải phóng từ hô hấp tế bào của hạt nảy mầm thoát ra dưới dạng nhiệt làm ấm bình.'],
      ['Vì sao khi bảo quản các loại hạt ngũ cốc (thóc, ngô, đậu) trong kho, người ta phải phơi hoặc sấy khô hạt đến độ ẩm thấp (khoảng 11% – 13%)?', ['Để hạt nặng hơn.', 'Để giảm hàm lượng nước trong hạt, từ đó ức chế cường độ hô hấp tế bào xuống mức tối thiểu, giúp hạt không bị hao hụt chất dinh dưỡng và không nảy mầm hay ẩm mốc.', 'Để tăng cường độ hô hấp của hạt lên tối đa.', 'Để hạt quang hợp tốt hơn.'], 1, 'Nước là môi trường cho các phản ứng hô hấp: giảm độ ẩm làm giảm hô hấp tối đa giúp bảo quản hạt lâu dài.'],
      ['Vì sao rau tươi và trái cây thường được bảo quản trong ngăn mát tủ lạnh (nhiệt độ thấp khoảng 2°C – 8°C) mà không được phơi khô như hạt thóc?', ['Vì rau tươi và trái cây chứa nhiều nước, nếu phơi khô sẽ mất độ tươi ngon; bảo quản ở nhiệt độ thấp giúp làm chậm hô hấp tế bào và hạn chế vi sinh vật gây hỏng.', 'Vì trong tủ lạnh có nhiều ánh sáng mặt trời.', 'Để làm cho nước trong rau quả đóng đá hoàn toàn.', 'Để tăng tốc độ hô hấp của rau quả.'], 0, 'Nhiệt độ thấp trong ngăn mát giúp ức chế enzyme hô hấp mà vẫn giữ được độ ẩm tươi ngon của rau quả.'],
      ['Khi đất trồng cây bị ngập úng nước lâu ngày, cây trồng trên cạn thường bị héo rũ và chết là vì:', ['cây bị thừa ánh sáng.', 'nước lấp đầy các khe đất làm rễ cây bị thiếu khí Oxygen (O₂), không thể thực hiện hô hấp tế bào để lấy năng lượng hút nước và khoáng.', 'cây bị thiếu nước.', 'lá cây ngừng thoát hơi nước.'], 1, 'Rễ cây cần O₂ trong các khe đất để hô hấp; ngập úng làm rễ thiếu O₂ dẫn đến thối rễ và chết cây.'],
      ['Trong trồng trọt, biện pháp kĩ thuật nào giúp cung cấp đầy đủ khí Oxygen cho hệ rễ cây hô hấp tốt?', ['Nén chặt mặt đất quanh gốc cây.', 'Thường xuyên xới đất, làm cỏ, vun gốc và thoát nước kịp thời sau khi mưa lớn.', 'Ngâm gốc cây trong nước ngập quanh năm.', 'Phủ kín mặt đất bằng nhựa đặc.'], 1, 'Xới đất tơi xốp giúp không khí giàu O₂ dễ dàng len lỏi vào các khe đất cung cấp cho rễ hô hấp.'],
      ['Tại sao không nên để nhiều hoa tươi hoặc cây cảnh lớn trong phòng ngủ đóng kín cửa vào ban đêm?', ['Vì ban đêm hoa và cây ngừng quang hợp nhưng vẫn hô hấp tế bào (lấy khí O₂ và thải khí CO₂) làm giảm O₂ trong phòng kín, dễ gây ngạt thở.', 'Vì ban đêm cây thải ra quá nhiều khí Oxygen.', 'Vì cây làm phòng ngủ lạnh đi.', 'Vì cây hút hết hơi nước trong phòng.'], 0, 'Trong phòng kín ban đêm, cây xanh cạnh tranh khí O₂ với con người và thải ra CO₂.'],
      ['Khi bảo quản nông sản trong kho hiện đại theo phương pháp điều chỉnh khí quyển (CA), người ta thường điều chỉnh nồng độ khí như thế nào để giảm hô hấp của nông sản?', ['Tăng thật cao nồng độ O₂ và giảm hết CO₂.', 'Giảm nồng độ O₂ xuống mức thấp hợp lí và tăng nồng độ CO₂ lên mức thích hợp để ức chế hô hấp.', 'Bơm khí Chlorine vào kho.', 'Hút chân không tuyệt đối làm nổ tế bào.'], 1, 'Nồng độ CO₂ cao hơn bình thường và O₂ thấp hợp lí giúp ức chế mạnh quá trình hô hấp của nông sản.'],
      ['Vì sao trước khi gieo hạt (lúa, ngô, đậu), người nông dân thường ngâm hạt vào nước ấm một thời gian?', ['Để hạt trương nước và có nhiệt độ ấm thích hợp, kích thích quá trình hô hấp tế bào diễn ra mạnh mẽ cung cấp năng lượng cho hạt nảy mầm.', 'Để ngăn cản hạt hô hấp.', 'Để làm chết phôi bên trong hạt.', 'Để hạt nhẹ hơn nổi lên mặt nước.'], 0, 'Độ ẩm cao và nhiệt độ ấm kích hoạt enzyme hô hấp phân giải chất dự trữ tạo năng lượng ATP cho phôi nảy mầm.'],
    ]),
    trueFalseList: [
      {
        id: 'b25-tf-1',
        stem: 'Xét bản chất, nguyên liệu và sản phẩm của quá trình hô hấp tế bào:',
        statements: [
          { id: 'a', text: 'Hô hấp tế bào là quá trình phân giải chất hữu cơ (chủ yếu là glucose) khi có oxygen thành khí carbon dioxide, nước và giải phóng năng lượng ATP.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Bào quan thực hiện quá trình hô hấp tế bào ở cả tế bào thực vật và tế bào động vật là ti thể.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Quá trình hô hấp tế bào chỉ diễn ra ở động vật, còn thực vật chỉ có quá trình quang hợp.', isTrue: false, explanation: 'Sai, mọi tế bào sống của thực vật (rễ, thân, lá, hoa, quả, hạt) đều thực hiện hô hấp tế bào suốt ngày đêm.' },
          { id: 'd', text: 'Một phần năng lượng giải phóng trong hô hấp tế bào thoát ra dưới dạng nhiệt năng giúp duy trì nhiệt độ cơ thể.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b25-tf-2',
        stem: 'So sánh hai quá trình Quang hợp và Hô hấp tế bào ở thực vật:',
        statements: [
          { id: 'a', text: 'Quang hợp diễn ra ở lục lạp khi có ánh sáng, còn hô hấp tế bào diễn ra ở ti thể suốt cả ngày và đêm.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Quang hợp là quá trình tổng hợp chất hữu cơ và tích lũy năng lượng; còn hô hấp tế bào là quá trình phân giải chất hữu cơ và giải phóng năng lượng.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Sản phẩm của quang hợp (Glucose và O₂) chính là nguyên liệu của quá trình hô hấp tế bào.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Vào ban ngày có ánh nắng, cây xanh chỉ thực hiện quang hợp mà ngừng hoàn toàn quá trình hô hấp tế bào.', isTrue: false, explanation: 'Sai, vào ban ngày cây vẫn hô hấp tế bào bình thường, chỉ là cường độ quang hợp mạnh hơn nhiều so với cường độ hô hấp.' },
        ],
      },
      {
        id: 'b25-tf-3',
        stem: 'Xét ảnh hưởng của các yếu tố môi trường đến hô hấp tế bào và ứng dụng bảo quản nông sản:',
        statements: [
          { id: 'a', text: 'Nếu cường độ hô hấp tế bào diễn ra quá mạnh trong thời gian bảo quản sẽ làm nông sản nhanh bị hao hụt chất dinh dưỡng, giảm chất lượng và dễ hỏng.', isTrue: true, explanation: 'Đúng, vì hô hấp phân giải chất hữu cơ dự trữ và sinh nhiệt, sinh nước.' },
          { id: 'b', text: 'Nguyên tắc chung khi bảo quản lương thực, thực phẩm là khống chế cho cường độ hô hấp tế bào giảm xuống mức tối thiểu (nhưng không làm chết tế bào hạt giống).', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Phơi khô hạt thóc, hạt ngô trước khi cất vào kho là biện pháp dùng nhiệt độ lạnh để bảo quản.', isTrue: false, explanation: 'Sai, phơi khô hạt là biện pháp giảm hàm lượng nước (độ ẩm) trong hạt để ức chế hô hấp.' },
          { id: 'd', text: 'Bảo quản rau quả tươi trong ngăn mát tủ lạnh là ứng dụng ảnh hưởng của nhiệt độ thấp làm chậm quá trình hô hấp tế bào.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b25-tf-4',
        stem: 'Trong thí nghiệm tìm hiểu về hô hấp ở hạt đậu xanh đang nảy mầm (đặt trong bình kín ở chỗ tối):',
        statements: [
          { id: 'a', text: 'Phải dùng hạt đang nảy mầm vì lúc này quá trình hô hấp tế bào diễn ra rất mạnh để lấy năng lượng tạo cây mầm.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Khi đưa cây nến đang cháy vào bình chứa hạt đậu đang nảy mầm (đã đậy kín sau vài giờ), ngọn nến bị tắt ngay vì hạt nảy mầm đã tiêu thụ hết khí O₂ và thải ra nhiều khí CO₂.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Ở bình đối chứng chứa hạt đậu đã luộc chín để nguội, cây nến đưa vào cũng bị tắt ngay lập tức.', isTrue: false, explanation: 'Sai, hạt đã luộc chín thì tế bào đã chết, không còn hô hấp nên trong bình vẫn còn nguyên khí O₂ giúp nến cháy bình thường.' },
          { id: 'd', text: 'Nhiệt độ trong bình chứa hạt đang nảy mầm cao hơn nhiệt độ phòng chứng tỏ hô hấp tế bào tỏa nhiệt.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b25-tf-5',
        stem: 'Xét mối liên hệ giữa hô hấp tế bào và chăm sóc cây trồng, sức khỏe con người:',
        statements: [
          { id: 'a', text: 'Xới đất tơi xốp, vun gốc và làm cỏ giúp rễ cây nhận được nhiều khí Oxygen trong các khe đất để hô hấp tốt hơn.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Khi ruộng rau hoặc vườn cây ăn quả bị ngập nước sau mưa bão, cần khơi thông rãnh thoát nước ngay để tránh rễ cây bị ngạt khí O₂.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Ban đêm nên đóng kín mít cửa phòng ngủ và đặt nhiều chậu cây lớn, hoa tươi quanh giường để ngủ ngon hơn.', isTrue: false, explanation: 'Sai, ban đêm cây hô hấp lấy O₂ và thải CO₂, để nhiều cây trong phòng ngủ kín dễ gây thiếu O₂.' },
          { id: 'd', text: 'Tập thể dục thể thao đều đặn ở nơi thoáng khí giúp tăng cường khả năng cung cấp O₂ cho hô hấp tế bào ở cơ thể người.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b25-es-1',
        question: 'Câu 1 [SGK KHTN 7 - KNTT]:\n(a) Hô hấp tế bào là gì? Viết phương trình hô hấp tế bào dạng chữ.\n(b) Hãy lập bảng hoặc nêu rõ sự khác nhau giữa Quang hợp và Hô hấp tế bào về: Nơi diễn ra (bào quan), Điều kiện ánh sáng, Nguyên liệu, Sản phẩm và Sự chuyển hóa năng lượng.',
        hint: 'Đối chiếu từng tiêu chí giữa Lục lạp (Quang hợp) và Ti thể (Hô hấp tế bào).',
        sampleAnswer: '(a) Hô hấp tế bào là quá trình tế bào phân giải chất hữu cơ tạo thành nước, khí carbon dioxide và giải phóng năng lượng cung cấp cho các hoạt động sống.\n- Phương trình chữ:\nGlucose + Oxygen  --->  Carbon dioxide + Nước + Năng lượng (ATP + Nhiệt)\n(b) So sánh Quang hợp và Hô hấp tế bào:\n1. Bào quan thực hiện: Quang hợp ở Lục lạp | Hô hấp tế bào ở Ti thể.\n2. Điều kiện ánh sáng: Quang hợp cần có ánh sáng | Hô hấp tế bào diễn ra suốt ngày đêm (không cần ánh sáng).\n3. Nguyên liệu: Quang hợp lấy CO₂ và H₂O | Hô hấp tế bào lấy Glucose và O₂.\n4. Sản phẩm: Quang hợp tạo Glucose và O₂ | Hô hấp tế bào tạo CO₂, H₂O và ATP.\n5. Chuyển hóa năng lượng: Quang hợp tích lũy năng lượng (Quang năng → Hóa năng) | Hô hấp giải phóng năng lượng (Hóa năng → ATP + Nhiệt).',
        rubricPoints: [
          'Nêu đúng khái niệm và phương trình chữ của hô hấp tế bào.',
          'So sánh chính xác cả 5 tiêu chí giữa Quang hợp và Hô hấp tế bào.',
        ],
      },
      {
        id: 'b25-es-2',
        question: 'Câu 2 [SGK KHTN 7 - KNTT]: Giải thích cơ sở khoa học của các việc làm sau trong nông nghiệp:\n(a) Tại sao trước khi đưa hạt thóc, hạt ngô, hạt đậu vào kho bảo quản, người nông dân phải phơi khô hạt?\n(b) Tại sao khi trồng cây trên đất cạn, người ta phải thường xuyên xới đất, làm cỏ, vun gốc và chống ngập úng?',
        hint: '(a) Mối liên hệ giữa hàm lượng nước và cường độ hô hấp ở hạt bảo quản; (b) Nhu cầu khí O₂ cho hô hấp của rễ cây.',
        sampleAnswer: '(a) Phơi khô hạt trước khi bảo quản:\n- Nước là môi trường và nguyên liệu cần thiết cho các phản ứng hô hấp tế bào.\n- Khi phơi khô hạt đến độ ẩm an toàn (11% - 13%), hàm lượng nước trong hạt giảm thấp khiến cường độ hô hấp tế bào bị ức chế xuống mức tối thiểu. Nhờ đó hạt không bị tiêu hao chất hữu cơ dự trữ, không sinh nhiệt ẩm mốc và không nảy mầm sớm trong kho.\n(b) Xới đất, vun gốc và chống ngập úng:\n- Tế bào rễ cây rất cần khí Oxygen (O₂) để thực hiện hô hấp tế bào tạo năng lượng ATP phục vụ quá trình hút nước và muối khoáng.\n- Xới đất tơi xốp và thoát nước chống ngập úng giúp không khí giàu O₂ đi vào các khe đất cung cấp đầy đủ cho rễ cây hô hấp.',
        rubricPoints: [
          'Giải thích đúng phơi khô làm giảm độ ẩm để ức chế hô hấp bảo quản hạt.',
          'Giải thích đúng xới đất và thoát nước giúp cung cấp O₂ cho hệ rễ hô hấp.',
        ],
      },
      {
        id: 'b25-es-3',
        question: 'Câu 3 [SBT KHTN 7 - KNTT]: Vì sao không nên để nhiều chậu cây xanh hoặc cắm nhiều hoa tươi trong phòng ngủ đóng kín cửa vào ban đêm?',
        hint: 'Ban đêm không có ánh sáng thì cây xanh thực hiện quá trình nào?',
        sampleAnswer: '- Vào ban đêm không có ánh sáng mặt trời nên cây xanh và hoa tươi ngừng hoàn toàn quá trình quang hợp, nhưng vẫn thực hiện quá trình hô hấp tế bào bình thường.\n- Khi hô hấp, cây xanh và hoa tươi hấp thụ khí Oxygen (O₂) trong phòng và thải ra khí Carbon dioxide (CO₂).\n- Nếu phòng ngủ đóng kín cửa và để nhiều cây/hoa, lượng khí O₂ trong phòng sẽ bị tiêu hao nhanh chóng trong khi nồng độ khí CO₂ tăng cao, gây thiếu dưỡng khí khiến người ngủ trong phòng cảm thấy mệt mỏi, đau đầu, thậm chí ngạt thở.',
        rubricPoints: [
          'Nêu rõ ban đêm cây ngừng quang hợp nhưng vẫn hô hấp tế bào.',
          'Giải thích cây hút O₂ và thải CO₂ trong phòng kín gây thiếu dưỡng khí cho con người.',
        ],
      },
      {
        id: 'b25-es-4',
        question: 'Câu 4 [SGK KHTN 7 - KNTT]: Tại sao đối với rau tươi, hoa quả tươi, người ta không dùng phương pháp phơi khô mà lại bảo quản trong ngăn mát tủ lạnh và đựng trong túi nilon có đục một vài lỗ nhỏ?',
        hint: 'Tác dụng của nhiệt độ thấp và việc duy trì độ ẩm vừa phải.',
        sampleAnswer: '- Rau tươi và hoa quả tươi có hàm lượng nước rất cao, nếu đem phơi khô sẽ làm tế bào mất nước, héo quắt và mất giá trị dinh dưỡng tươi sống.\n- Bảo quản trong ngăn mát tủ lạnh (nhiệt độ thấp khoảng 2°C – 8°C) giúp làm giảm hoạt tính của enzyme, từ đó làm chậm quá trình hô hấp tế bào và ức chế vi sinh vật gây thối hỏng.\n- Đựng trong túi có đục lỗ nhỏ giúp hạn chế sự bay hơi nước (giữ rau quả tươi giòn) nhưng vẫn thoát bớt hơi nước ngưng tụ do hô hấp sinh ra để tránh bị úng thối.',
        rubricPoints: [
          'Giải thích đúng vai trò của nhiệt độ thấp làm giảm cường độ hô hấp mà vẫn giữ độ tươi.',
          'Giải thích đúng vai trò của túi bảo quản có lỗ thông hơi.',
        ],
      },
      {
        id: 'b25-es-5',
        question: 'Câu 5 [SBT KHTN 7 - KNTT]: Trong thí nghiệm chứng minh hô hấp ở hạt nảy mầm, người ta cho 100 g hạt đậu xanh đang nảy mầm vào Bình A và 100 g hạt đậu xanh đã luộc chín vào Bình B, đậy kín cả hai bình và để trong bóng tối 3 giờ. Sau đó mở nút và đưa nến đang cháy vào từng bình. Hãy dự đoán hiện tượng xảy ra ở hai bình và giải thích.',
        hint: 'So sánh sự sống và hoạt động hô hấp của hạt nảy mầm (Bình A) với hạt đã luộc chín (Bình B).',
        sampleAnswer: '- Hiện tượng:\n+ Ở Bình A (chứa hạt đang nảy mầm): Khi đưa nến đang cháy vào thì ngọn nến bị tắt ngay lập tức.\n+ Ở Bình B (chứa hạt đã luộc chín): Khi đưa nến đang cháy vào thì ngọn nến vẫn tiếp tục cháy bình thường.\n- Giải thích:\n+ Ở Bình A, hạt đậu đang nảy mầm có các tế bào sống thực hiện hô hấp tế bào rất mạnh, đã lấy hết khí O₂ trong bình kín và thải ra nhiều khí CO₂ ⇒ Không còn O₂ duy trì sự cháy nên nến tắt.\n+ Ở Bình B, hạt đậu đã luộc chín nên các tế bào đã chết, không thực hiện hô hấp tế bào ⇒ Lượng khí O₂ trong bình vẫn còn nguyên nên nến vẫn cháy.',
        rubricPoints: [
          'Dự đoán đúng hiện tượng: Bình A nến tắt, Bình B nến vẫn cháy.',
          'Giải thích đúng Bình A hạt nảy mầm hô hấp tiêu thụ hết O₂ và thải CO₂; Bình B hạt đã chết không hô hấp.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 27, 28, 29: TRAO ĐỔI KHÍ – TRAO ĐỔI NƯỚC VÀ DINH DƯỠNG Ở THỰC VẬT
  // =========================================================================
  {
    id: 'kntt-bai-29',
    lessonNumber: 29,
    title: 'Bài 27, 28 & 29: Trao đổi khí, nước và chất dinh dưỡng ở thực vật',
    chapterTitle: 'Chương VII: Trao đổi chất và chuyển hóa năng lượng',
    subject: 'biology',
    summary:
      'Trao đổi khí ở thực vật diễn ra chủ yếu qua khí khổng ở lá. Thực vật hấp thụ nước và muối khoáng hòa tan từ đất qua tế bào lông hút ở rễ, vận chuyển lên thân và lá theo mạch gỗ (Xylem), đồng thời vận chuyển chất hữu cơ từ lá đến các cơ quan theo mạch rây (Phloem). Động lực chính kéo dòng mạch gỗ đi lên là sự thoát hơi nước ở lá.',
    keyFormulas: [
      'Cơ chế đóng mở khí khổng: Tế bào khí khổng trương nước (no nước) ⇒ Khí khổng MỞ  |  Tế bào khí khổng mất nước ⇒ Khí khổng ĐÓNG',
      'Mạch gỗ (Xylem): Vận chuyển Nước & Muối khoáng từ Rễ ↑ Thân ↑ Lá (tế bào chết hóa gỗ)',
      'Mạch rây (Phloem): Vận chuyển Chất hữu cơ từ Lá ↓ Thân, Rễ, Củ, Quả (tế bào sống)',
      'Vai trò thoát hơi nước ở lá: (1) Tạo lực hút đầu trên kéo nước & khoáng lên lá; (2) Làm mát lá; (3) Khí khổng mở giúp CO₂ đi vào lá để quang hợp',
    ],
    mcqs: makeBioMcqs('b29', [
      ['Ở thực vật trên cạn, sự trao đổi khí với môi trường xung quanh được thực hiện chủ yếu qua bộ phận nào ở biểu bì lá?', ['Gân lá.', 'Khí khổng (lỗ khí).', 'Cuống lá.', 'Lông hút.'], 1, 'Khí khổng ở lớp biểu bì lá (thường tập trung nhiều ở mặt dưới lá) thực hiện trao đổi khí và thoát hơi nước.'],
      ['Mỗi khí khổng được cấu tạo bởi mấy tế bào hình hạt đậu nằm áp sát vào nhau?', ['1 tế bào.', '2 tế bào hình hạt đậu (có thành trong dày và thành ngoài mỏng).', '4 tế bào.', '6 tế bào.'], 1, 'Mỗi khí khổng gồm 2 tế bào hình hạt đậu có thành trong dày và thành ngoài mỏng tạo nên khe khí khổng ở giữa.'],
      ['Khi hai tế bào hình hạt đậu của khí khổng hấp thụ nhiều nước (trương nước) thì hiện tượng gì xảy ra?', ['Thành mỏng phía ngoài căng ra làm thành dày phía trong cong theo ⇒ lỗ khí khổng MỞ rộng.', 'Lỗ khí khổng đóng kín lại.', 'Tế bào khí khổng bị vỡ.', 'Lá cây rụng ngay lập tức.'], 0, 'Khi no nước (trương nước), thành ngoài mỏng dãn mạnh kéo thành trong cong theo làm khí khổng mở.'],
      ['Trong quá trình quang hợp ban ngày ở lá cây, các chất khí khuếch tán qua khí khổng theo chiều nào?', ['Khí CO₂ khuếch tán từ ngoài vào trong lá; khí O₂ và hơi nước khuếch tán từ trong lá ra ngoài.', 'Khí O₂ đi từ ngoài vào và khí CO₂ đi ra.', 'Chỉ có khí Nitrogen đi vào lá.', 'Không có chất khí nào đi qua khí khổng.'], 0, 'Trong quang hợp, CO₂ đi từ ngoài vào lá làm nguyên liệu, còn O₂ và hơi nước thoát ra ngoài qua khí khổng.'],
      ['Ở người và thú, quá trình trao đổi khí giữa cơ thể với môi trường diễn ra ở cơ quan nào?', ['Dạ dày.', 'Phổi (tại các phế nang).', 'Thận.', 'Mang cá.'], 1, 'Ở người, thú, chim, bò sát, cơ quan trao đổi khí là phổi; ở cá, tôm, cua là mang; ở giun đất là qua da ẩm.'],
      ['Thực vật trên cạn hấp thụ nước và các ion muối khoáng hòa tan từ đất chủ yếu qua bộ phận nào của rễ?', ['Chóp rễ.', 'Các tế bào lông hút ở miền hút của rễ.', 'Vỏ thân cây.', 'Ngọn lá.'], 1, 'Tế bào lông hút ở rễ có thành mỏng, không thấm cutin và có không bào lớn giúp hấp thụ nước và muối khoáng từ đất.'],
      ['Con đường vận chuyển nước và muối khoáng từ tế bào lông hút vào mạch gỗ của rễ rồi đi lên thân và lá được gọi là:', ['dòng mạch rây (Phloem).', 'dòng mạch gỗ (Xylem).', 'quá trình quang hợp.', 'quá trình hô hấp.'], 1, 'Mạch gỗ (Xylem) dẫn nước và muối khoáng hòa tan một chiều từ rễ lên thân và lá.'],
      ['Con đường vận chuyển các chất hữu cơ (do lá tổng hợp từ quá trình quang hợp) đến nuôi thân, rễ, hoa, quả, củ dự trữ được gọi là:', ['dòng mạch gỗ (Xylem).', 'dòng mạch rây (Phloem).', 'sự thoát hơi nước.', 'sự hút nước của lông hút.'], 1, 'Mạch rây (Phloem) vận chuyển chất hữu cơ từ lá đến các cơ quan cần sử dụng hoặc tích lũy dự trữ.'],
      ['Trong một thí nghiệm, người ta cắm một cành hoa cúc trắng vào cốc nước có pha màu thực phẩm đỏ. Sau vài giờ, cánh hoa cúc chuyển sang màu đỏ là nhờ hoạt động của:', ['dòng mạch gỗ vận chuyển nước pha màu đỏ từ cốc lên cánh hoa.', 'dòng mạch rây vận chuyển từ hoa xuống gốc.', 'quá trình quang hợp tạo ra màu đỏ.', 'không khí xung quanh nhuộm đỏ hoa.'], 0, 'Nước màu được hút và vận chuyển theo mạch gỗ đi lên làm các mạch ở cánh hoa và phiến lá nhuộm màu đỏ.'],
      ['Phần lớn lượng nước do rễ cây hút vào từ đất (khoảng 98%) được cây sử dụng vào việc gì?', ['Giữ lại toàn bộ trong rễ.', 'Thoát ra ngoài không khí dưới dạng hơi nước qua khí khổng ở lá (chỉ khoảng 2% giữ lại để quang hợp và tạo mô).', 'Biến thành muối khoáng.', 'Chảy ngược ra đất.'], 1, 'Khoảng 98% lượng nước rễ hút vào bị thoát ra ngoài qua lá dưới dạng hơi nước.'],
      ['Tuy làm mất tới 98% lượng nước hút vào, nhưng quá trình thoát hơi nước ở lá lại có ý nghĩa sống còn đối với cây vì:', ['tạo lực hút đầu trên giúp kéo dòng nước và muối khoáng từ rễ lên lá, làm mát lá dưới nắng gắt và giúp khí khổng mở cho CO₂ đi vào.', 'làm cho cây nhẹ hơn để gió thổi bay.', 'giúp cây không cần quang hợp nữa.', 'làm cho đất trồng khô nhanh hơn.'], 0, 'Thoát hơi nước vừa tạo động lực kéo dòng mạch gỗ, vừa hạ nhiệt độ lá và mở khí khổng cho CO₂ vào quang hợp.'],
      ['Nếu khoanh vỏ một cành cây (bóc bỏ một vòng vỏ chứa mạch rây nhưng giữ nguyên phần gỗ bên trong), sau một thời gian khoảng 1 tháng ta quan sát thấy:', ['Cành cây phía trên vết cắt bị héo khô ngay lập tức.', 'Cành cây vẫn xanh tươi, nhưng mép vỏ phía trên vết cắt phình to ra do chất hữu cơ từ lá vận chuyển xuống theo mạch rây bị ứ đọng lại.', 'Mép vỏ phía dưới vết cắt phình to ra.', 'Cành cây biến thành rễ.'], 1, 'Mạch gỗ bên trong vẫn còn nên nước vẫn lên nuôi lá xanh tươi; mạch rây ở vỏ bị đứt nên chất hữu cơ từ lá đi xuống bị ứ lại ở mép trên (ứng dụng để chiết cành).'],
      ['Vì sao khi đánh (bứng) cây đi trồng ở nơi khác, người ta thường phải tỉa bớt cành lá và chọn ngày râm mát hoặc chiều mát để trồng?', ['Cho cây gọn gàng dễ vận chuyển.', 'Để giảm bớt sự thoát hơi nước qua lá trong lúc bộ rễ mới bị đứt lông hút chưa kịp phục hồi khả năng hút nước, giúp cây không bị héo chết.', 'Để cây không thực hiện hô hấp nữa.', 'Để tăng sự thoát hơi nước.'], 1, 'Khi mới bứng cây, bộ rễ bị tổn thương chưa hút được nước; tỉa bớt lá giúp giảm thoát hơi nước để cân bằng nước trong cây.'],
      ['Ba nguyên tố khoáng đa lượng quan trọng nhất thường có trong các loại phân bón hóa học tổng hợp NPK giúp cây trồng sinh trưởng và đạt năng suất cao là:', ['Sodium (Na), Chlorine (Cl), Iron (Fe).', 'Nitrogen (N - Đạm), Phosphorus (P - Lân) và Potassium (K - Kali).', 'Helium (He), Neon (Ne), Argon (Ar).', 'Gold (Au), Silver (Ag), Copper (Cu).'], 1, 'Phân NPK cung cấp 3 nguyên tố dinh dưỡng thiết yếu: Đạm (N), Lân (P) và Kali (K).'],
      ['Khi bón phân hóa học cho cây trồng, nếu bón quá nhiều phân đặc sát gốc và không tưới nước thì cây sẽ bị “xót rễ” và héo chết vì:', ['nồng độ chất tan trong đất quá cao làm rễ cây không hút được nước mà còn bị mất nước ngược ra ngoài đất.', 'phân bón làm rễ cây lạnh cóng.', 'cây ăn no quá không cần nước nữa.', 'lá cây ngừng nhận ánh sáng.'], 0, 'Bón phân quá đặc làm nồng độ dịch đất cao hơn dịch tế bào lông hút, khiến rễ không hút được nước và bị héo.'],
      ['Trong cơ thể người, nước chiếm khoảng bao nhiêu phần trăm khối lượng cơ thể và có vai trò gì?', ['Chiếm khoảng 10%; chỉ để làm đẹp da.', 'Chiếm khoảng 60% – 70% khối lượng cơ thể; là thành phần cấu tạo tế bào, dung môi hòa tan và vận chuyển các chất, điều hòa thân nhiệt.', 'Chiếm 99% khối lượng cơ thể.', 'Không có vai trò gì quan trọng.'], 1, 'Nước chiếm 60% - 70% khối lượng cơ thể người; mất từ 10% - 20% lượng nước có thể nguy hiểm đến tính mạng.'],
      ['Bệnh bướu cổ và suy giảm trí tuệ ở trẻ em thường do chế độ ăn hàng ngày bị thiếu nguyên tố khoáng vi lượng nào?', ['Calcium (Ca).', 'Iodine (I - I-ốt).', 'Magnesium (Mg).', 'Sulfur (S).'], 1, 'Thiếu Iodine làm tuyến giáp không tổng hợp đủ hormone thyroxine gây bệnh bướu cổ.'],
      ['Trẻ em bị bệnh còi xương, chậm lớn và người lớn tuổi bị loãng xương là do cơ thể thiếu nguyên tố khoáng nào và vitamin nào hỗ trợ hấp thụ nó?', ['Thiếu nguyên tố Calcium (Ca) và Vitamin D.', 'Thiếu nguyên tố Sodium (Na) và Vitamin C.', 'Thiếu nguyên tố Chlorine (Cl) và Vitamin B1.', 'Thiếu nguyên tố Iron (Fe) và Vitamin A.'], 0, 'Vitamin D giúp cơ thể chuyển hóa và hấp thụ Calcium để tạo hệ xương và răng vững chắc.'],
    ]),
    trueFalseList: [
      {
        id: 'b29-tf-1',
        stem: 'Xét cấu tạo và cơ chế đóng mở của khí khổng ở biểu bì lá thực vật:',
        statements: [
          { id: 'a', text: 'Mỗi khí khổng gồm 2 tế bào hình hạt đậu có thành trong dày và thành ngoài mỏng nằm áp sát nhau tạo thành khe lỗ khí.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Khi tế bào hình hạt đậu trương nước (no nước), thành mỏng căng ra làm thành dày cong theo khiến lỗ khí khổng mở rộng.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Khi cây bị thiếu nước (mất nước), tế bào hình hạt đậu xẹp xuống làm lỗ khí khổng mở to hết cỡ.', isTrue: false, explanation: 'Sai, khi mất nước thành mỏng hết căng làm thành dày duỗi thẳng, lỗ khí khổng khép (đóng) lại để hạn chế mất nước.' },
          { id: 'd', text: 'Khí khổng thực hiện đồng thời hai nhiệm vụ: trao đổi khí (CO₂, O₂) và thoát hơi nước.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b29-tf-2',
        stem: 'So sánh đặc điểm và chức năng của mạch gỗ (Xylem) và mạch rây (Phloem) ở thực vật:',
        statements: [
          { id: 'a', text: 'Mạch gỗ được cấu tạo bởi các tế bào chết đã hóa gỗ, vận chuyển nước và muối khoáng hòa tan từ rễ lên thân và lá.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Mạch rây được cấu tạo bởi các tế bào sống, vận chuyển các chất hữu cơ tổng hợp được ở lá đến các cơ quan cần sử dụng hoặc dự trữ (rễ, củ, quả, hạt).', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Động lực chính giúp kéo dòng nước và muối khoáng đi ngược chiều trọng lực từ rễ lên tới ngọn các cây cổ thụ cao hàng chục mét là sự thoát hơi nước ở lá.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Nếu bóc bỏ một khoanh vỏ quanh cành cây thì mạch gỗ bị cắt đứt hoàn toàn còn mạch rây vẫn nguyên vẹn.', isTrue: false, explanation: 'Sai, mạch rây nằm ở lớp vỏ nên khi bóc khoanh vỏ thì mạch rây bị cắt đứt, còn mạch gỗ nằm sâu bên trong phần gỗ vẫn nguyên vẹn.' },
        ],
      },
      {
        id: 'b29-tf-3',
        stem: 'Xét sự trao đổi khí ở động vật (côn trùng, cá, lưỡng cư, chim, thú và người):',
        statements: [
          { id: 'a', text: 'Ở mọi loài động vật, quá trình trao đổi khí với môi trường đều là lấy khí Oxygen (O₂) vào cơ thể và thải khí Carbon dioxide (CO₂) ra môi trường.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Các loài sống dưới nước như cá, tôm, cua, trai sông trao đổi khí qua mang.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Giun đất trao đổi khí qua hệ thống ống khí phân nhánh, còn châu chấu trao đổi khí qua da ẩm.', isTrue: false, explanation: 'Sai, ngược lại: giun đất trao đổi khí qua bề mặt da ẩm ướt, còn côn trùng (châu chấu, cào cào) trao đổi khí qua hệ thống ống khí.' },
          { id: 'd', text: 'Ở người, thú, chim và bò sát, cơ quan trao đổi khí chuyên hóa là phổi.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b29-tf-4',
        stem: 'Xét các ứng dụng thực tế về trao đổi nước và dinh dưỡng khoáng trong trồng trọt:',
        statements: [
          { id: 'a', text: 'Khi bứng cây đi trồng nơi khác cần giữ bầu đất quanh rễ để hạn chế làm đứt các tế bào lông hút của rễ.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Tỉa bớt lá khi mới trồng cây giúp giảm sự thoát hơi nước qua lá, tránh cho cây bị mất nước và héo chết khi rễ chưa kịp hồi phục.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Bón phân cho cây càng nhiều và càng đặc sát gốc vào lúc trưa nắng gắt thì cây càng hấp thụ nhanh và xanh tốt.', isTrue: false, explanation: 'Sai, bón phân quá nhiều lúc nắng gắt làm nồng độ dịch đất quá cao gây xót rễ, làm cây mất nước và chết héo.' },
          { id: 'd', text: 'Nên tưới nước cho cây vào buổi sáng sớm hoặc chiều mát theo nguyên tắc: đủ số lượng, đúng thời điểm và đúng phương pháp.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b29-tf-5',
        stem: 'Xét vai trò của nước và các chất dinh dưỡng đối với cơ thể người:',
        statements: [
          { id: 'a', text: 'Chất đường bột (Carbohydrate có trong cơm, bánh mì, khoai) là nguồn cung cấp năng lượng chủ yếu cho các hoạt động của cơ thể.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Chất đạm (Protein có trong thịt, cá, trứng, sữa, đậu) là nguyên liệu chính xây dựng tế bào, cơ bắp và tạo kháng thể bảo vệ cơ thể.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Vitamin và muối khoáng không cung cấp năng lượng trực tiếp nên cơ thể người hoàn toàn không cần đến chúng.', isTrue: false, explanation: 'Sai, dù không sinh năng lượng nhưng vitamin và muối khoáng (Ca, Fe, I, Zn...) rất cần thiết cho enzyme và cấu trúc cơ thể; thiếu chúng sẽ gây nhiều bệnh nguy hiểm (thiếu máu, còi xương, bướu cổ, quáng gà).' },
          { id: 'd', text: 'Để phòng tránh ngộ độc thực phẩm và bảo vệ hệ tiêu hóa, chúng ta cần thực hiện ăn chín, uống sôi và đảm bảo vệ sinh an toàn thực phẩm.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b29-es-1',
        question: 'Câu 1 [SGK KHTN 7 - KNTT]:\n(a) Nêu cấu tạo và cơ chế đóng – mở của khí khổng ở lá cây.\n(b) Quá trình thoát hơi nước ở lá có vai trò gì đối với đời sống của thực vật?',
        hint: 'Liên hệ độ trương nước của 2 tế bào hình hạt đậu và 3 vai trò của thoát hơi nước.',
        sampleAnswer: '(a) Cấu tạo và cơ chế đóng – mở khí khổng:\n- Cấu tạo: Mỗi khí khổng gồm 2 tế bào hình hạt đậu nằm áp sát vào nhau, có thành trong dày và thành ngoài mỏng tạo nên lỗ khí ở giữa.\n- Cơ chế: Khi tế bào hình hạt đậu trương nước (no nước), thành ngoài mỏng căng mạnh làm thành trong dày cong theo ⇒ khí khổng mở. Khi tế bào mất nước, thành mỏng hết căng và thành dày duỗi thẳng ⇒ khí khổng đóng lại (không đóng hoàn toàn).\n(b) Ba vai trò quan trọng của sự thoát hơi nước ở lá:\n1. Tạo lực hút đầu trên giúp kéo dòng nước và muối khoáng hòa tan từ rễ theo mạch gỗ lên thân và lá.\n2. Khi khí khổng mở để thoát hơi nước thì đồng thời tạo điều kiện cho khí CO₂ khuếch tán vào lá cung cấp nguyên liệu cho quang hợp.\n3. Giúp hạ nhiệt độ, làm mát bề mặt lá dưới ánh nắng mặt trời gay gắt, bảo vệ lá không bị đốt nóng.',
        rubricPoints: [
          'Nêu đúng cấu tạo 2 tế bào hình hạt đậu và cơ chế đóng mở khi trương nước / mất nước.',
          'Nêu đủ 3 vai trò của sự thoát hơi nước đối với cây.',
        ],
      },
      {
        id: 'b29-es-2',
        question: 'Câu 2 [SGK KHTN 7 - KNTT]: Phân biệt sự vận chuyển các chất trong dòng mạch gỗ (Xylem) và dòng mạch rây (Phloem) ở thực vật về: Cấu tạo tế bào mạch, Chất được vận chuyển và Chiều vận chuyển chính.',
        hint: 'Mạch gỗ dẫn nước và khoáng từ rễ lên lá; mạch rây dẫn chất hữu cơ từ lá xuống.',
        sampleAnswer: 'Phân biệt dòng mạch gỗ và dòng mạch rây:\n1. Mạch gỗ (Xylem):\n- Cấu tạo: Gồm các tế bào chết đã hóa gỗ, nối thông với nhau thành ống dẫn vững chắc.\n- Chất vận chuyển: Nước và các muối khoáng hòa tan (rễ hút từ đất).\n- Chiều vận chuyển: Đi từ rễ lên thân, cành và lá.\n2. Mạch rây (Phloem):\n- Cấu tạo: Gồm các tế bào sống (ống rây và tế bào kèm).\n- Chất vận chuyển: Các chất hữu cơ (chủ yếu là đường sucrose) được tổng hợp từ quá trình quang hợp ở lá.\n- Chiều vận chuyển: Đi từ lá xuống thân, rễ và đến các cơ quan dự trữ (củ, quả, hạt) hoặc chồi non đang sinh trưởng.',
        rubricPoints: [
          'Trình bày đúng cấu tạo, chất vận chuyển và chiều đi lên của mạch gỗ.',
          'Trình bày đúng cấu tạo, chất vận chuyển và chiều đi từ lá đến các cơ quan của mạch rây.',
        ],
      },
      {
        id: 'b29-es-3',
        question: 'Câu 3 [SBT KHTN 7 - KNTT]: Giải thích cơ sở khoa học của các hiện tượng và kĩ thuật sau:\n(a) Khi nhân giống cây ăn quả bằng phương pháp chiết cành, người ta bóc bỏ một khoanh vỏ của cành cây rồi bó bầu đất ẩm vào vị trí đó. Sau một thời gian, rễ mới sẽ mọc ra từ mép vỏ phía trên hay phía dưới vết cắt? Vì sao?\n(b) Vì sao khi đánh cây đi trồng ở nơi mới, người ta phải giữ bầu đất quanh rễ và tỉa bớt cành lá?',
        hint: '(a) Lớp vỏ chứa mạch rây bị cắt đứt làm chất hữu cơ ứ đọng ở đâu? (b) Bảo vệ lông hút và giảm thoát hơi nước.',
        sampleAnswer: '(a) Rễ mới sẽ mọc ra từ MÉP VỎ PHÍA TRÊN vết cắt.\nGiải thích: Khi bóc bỏ khoanh vỏ, mạch rây nằm ở lớp vỏ bị cắt đứt (trong khi mạch gỗ bên trong vẫn dẫn nước và khoáng lên lá bình thường). Các chất hữu cơ và hormone do lá tổng hợp vận chuyển xuống theo mạch rây bị ứ đọng lại ở mép vỏ phía trên vết cắt làm mép trên phình to và kích thích hình thành rễ mới tại đó.\n(b) Khi bứng cây đi trồng:\n- Giữ bầu đất quanh rễ để bảo vệ các tế bào lông hút mỏng manh không bị đứt gãy.\n- Tỉa bớt cành lá để giảm diện tích thoát hơi nước qua lá, giúp cây không bị mất nước quá mức và héo chết trong những ngày đầu khi bộ rễ chưa hồi phục khả năng hút nước.',
        rubricPoints: [
          'Giải thích đúng rễ mọc ở mép vỏ phía trên do chất hữu cơ từ lá đi xuống theo mạch rây bị ứ đọng.',
          'Giải thích đúng mục đích giữ bầu đất (bảo vệ lông hút) và tỉa bớt lá (giảm thoát hơi nước).',
        ],
      },
      {
        id: 'b29-es-4',
        question: 'Câu 4 [SGK KHTN 7 - KNTT]: Kể tên các cơ quan trao đổi khí ở các đại diện động vật sau: Giun đất, Châu chấu, Cá chép, Chim bồ câu, Con người. Nêu đặc điểm chung của bề mặt trao đổi khí giúp sự khuếch tán khí O₂ và CO₂ diễn ra hiệu quả.',
        hint: 'Có 4 kiểu cơ quan trao đổi khí chính ở động vật: qua da, hệ thống ống khí, mang và phổi.',
        sampleAnswer: '- Cơ quan trao đổi khí của các loài:\n+ Giun đất: Trao đổi khí qua bề mặt da (da mỏng và luôn ẩm ướt).\n+ Châu chấu (côn trùng): Trao đổi khí qua hệ thống ống khí (thông ra ngoài qua các lỗ thở ở bụng).\n+ Cá chép: Trao đổi khí qua mang (có các cung mang chứa nhiều mao mạch máu).\n+ Chim bồ câu và Con người: Trao đổi khí qua phổi.\n- Đặc điểm chung của bề mặt trao đổi khí: Diện tích bề mặt lớn, mỏng, luôn ẩm ướt và có mạng lưới mao mạch máu dày đặc (trừ côn trùng ống khí tới thẳng tế bào) giúp khí O₂ và CO₂ khuếch tán nhanh chóng.',
        rubricPoints: [
          'Nêu đúng cơ quan trao đổi khí của Giun đất (da), Châu chấu (ống khí), Cá (mang), Chim và Người (phổi).',
          'Nêu đúng các đặc điểm của bề mặt trao đổi khí (mỏng, ẩm ướt, diện tích lớn, nhiều mao mạch).',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 32, 34, 37: CẢM ỨNG – SINH TRƯỞNG, PHÁT TRIỂN VÀ SINH SẢN Ở SINH VẬT
  // =========================================================================
  {
    id: 'kntt-bai-32',
    lessonNumber: 32,
    title: 'Bài 32, 34 & 37: Cảm ứng, Sinh trưởng, Phát triển và Sinh sản',
    chapterTitle: 'Chương VIII, IX, X: Cảm ứng – Sinh trưởng – Sinh sản',
    subject: 'biology',
    summary:
      'Cảm ứng là khả năng cơ thể sinh vật tiếp nhận và phản ứng thích hợp với các kích thích từ môi trường để tồn tại và phát triển. Sinh trưởng là sự tăng lên về kích thước và khối lượng cơ thể do tăng số lượng và kích thước tế bào; Phát triển bao gồm sinh trưởng, phân hóa tế bào và phát sinh hình thái. Sinh sản gồm sinh sản vô tính và sinh sản hữu tính.',
    keyFormulas: [
      'Cảm ứng ở thực vật: Hướng sáng, hướng nước, hướng trọng lực, hướng tiếp xúc (diễn ra chậm, liên quan đến sinh trưởng tế bào)',
      'Tập tính ở động vật: Tập tính bẩm sinh (di truyền, đặc trưng cho loài)  |  Tập tính học được (hình thành trong đời sống qua học tập, rèn luyện)',
      'Sinh sản vô tính (không có sự kết hợp giao tử đực – cái; con giống hệt mẹ)  |  Sinh sản hữu tính (có thụ tinh giữa giao tử đực và giao tử cái tạo hợp tử)',
    ],
    mcqs: makeBioMcqs('b32', [
      ['Cảm ứng ở sinh vật là:', ['khả năng cơ thể sinh vật tiếp nhận và phản ứng thích hợp với các kích thích từ môi trường, đảm bảo cho sinh vật tồn tại và phát triển.', 'quá trình cây hút nước từ đất.', 'quá trình tăng chiều cao của cây.', 'hiện tượng vật rơi tự do.'], 0, 'Cảm ứng là phản ứng của sinh vật đối với các kích thích từ môi trường trong và ngoài cơ thể.'],
      ['Khi đặt một chậu cây nhỏ trên bệ cửa sổ nơi chỉ có ánh sáng chiếu vào từ một phía, sau vài ngày ngọn cây uốn cong vươn về phía có ánh sáng. Hiện tượng này gọi là:', ['tính hướng nước.', 'tính hướng sáng của ngọn cây.', 'tính hướng trọng lực.', 'tập tính học được.'], 1, 'Ngọn cây luôn hướng về phía có ánh sáng để thu nhận ánh sáng cho quang hợp (tính hướng sáng dương).'],
      ['Rễ cây luôn mọc hướng về phía nguồn nước và nguồn phân bón trong đất. Hiện tượng này thể hiện:', ['tính hướng sáng.', 'tính hướng nước và hướng hóa của rễ cây.', 'tính hướng tiếp xúc.', 'sự thoát hơi nước.'], 1, 'Rễ cây có tính hướng nước dương và hướng hóa dương giúp tìm kiếm nguồn nước và khoáng nuôi cây.'],
      ['Khi trồng các loài cây thân leo như mướp, bầu, bí, đậu Hà Lan, người nông dân thường làm giàn cọc tre là ứng dụng hình thức cảm ứng nào của cây?', ['Tính hướng tiếp xúc (tua cuốn quấn quanh giá thể khi chạm vào cọc giàn).', 'Tính hướng nước.', 'Tính hướng trọng lực.', 'Phản xạ có điều kiện.'], 0, 'Tua cuốn của cây bầu, bí, mướp có tính hướng tiếp xúc giúp cây bám vào giàn vươn lên cao đón nắng.'],
      ['Tập tính ở động vật được chia thành hai nhóm chính là:', ['Tập tính bẩm sinh và tập tính học được.', 'Tập tính hướng sáng và hướng nước.', 'Tập tính quang hợp và hô hấp.', 'Tập tính vô tính và hữu tính.'], 0, 'Tập tính động vật gồm tập tính bẩm sinh (sinh ra đã biết làm) và tập tính học được (học trong đời sống).'],
      ['Hiện tượng nào sau đây là tập tính BẨM SINH ở động vật?', ['Con nhện vừa nở ra đã biết chăng tơ đúng kiểu của loài và gà con mới nở biết mổ thóc.', 'Con khỉ biết đi xe đạp trong rạp xiếc.', 'Con vẹt biết nói tiếng người.', 'Học sinh dừng lại khi gặp đèn đỏ giao thông.'], 0, 'Nhện chăng tơ, tò vò xây tổ, gà con mổ thóc là tập tính bẩm sinh di truyền từ bố mẹ, đặc trưng cho loài.'],
      ['Hiện tượng nào sau đây là tập tính HỌC ĐƯỢC (thói quen) trong đời sống?', ['Chim công múa khoe lông vào mùa sinh sản.', 'Ếch đực kêu vào mùa hè sau cơn mưa.', 'Người tham gia giao thông dừng xe khi thấy tín hiệu đèn đỏ và thói quen tập thể dục mỗi sáng.', 'Ve sầu kêu vào mùa hè.'], 2, 'Dừng xe khi đèn đỏ, đọc sách, tập thể dục là các thói quen/tập tính học được qua quá trình giáo dục và rèn luyện.'],
      ['Sinh trưởng ở sinh vật là:', ['quá trình tăng lên về kích thước và khối lượng của cơ thể do sự tăng lên về số lượng và kích thước của tế bào.', 'quá trình cơ thể già đi và chết.', 'chỉ là quá trình ra hoa kết quả.', 'quá trình di chuyển từ nơi này sang nơi khác.'], 0, 'Sinh trưởng là sự tăng kích thước (chiều cao, chiều dài) và khối lượng cơ thể nhờ sự phân chia và lớn lên của tế bào.'],
      ['Ở thực vật có mạch, mô phân sinh đỉnh nằm ở đâu và có chức năng gì?', ['Nằm ở đầu ngọn thân, chồi nách và chóp rễ; giúp thân và rễ cây dài ra.', 'Nằm ở mặt lá; giúp lá rụng.', 'Làm cho thân cây to bề ngang.', 'Chỉ có ở hạt khô.'], 0, 'Mô phân sinh đỉnh giúp thân và rễ dài ra (tăng chiều cao cây và chiều dài rễ).'],
      ['Ở các cây Hai lá mầm thân gỗ (như cây xoài, cây nhãn, cây lim), bộ phận nào giúp thân và rễ cây lớn lên về chiều ngang (tăng đường kính thân hàng năm tạo các vòng gỗ)?', ['Mô phân sinh đỉnh.', 'Mô phân sinh bên (tầng sinh vỏ và tầng sinh mạch).', 'Khí khổng.', 'Lông hút.'], 1, 'Mô phân sinh bên phân chia tế bào giúp thân và rễ cây thân gỗ to ra theo chiều ngang.'],
      ['Quá trình phát triển của con bướm (hoặc con muỗi, con ếch) trải qua các giai đoạn mà con non (sâu bướm, lăng quăng, nòng nọc) có hình thái, cấu tạo rất khác với con trưởng thành được gọi là:', ['phát triển không qua biến thái.', 'phát triển qua biến thái.', 'sinh sản vô tính.', 'cảm ứng hướng sáng.'], 1, 'Sâu bướm thành bướm, nòng nọc thành ếch, lăng quăng thành muỗi là phát triển qua biến thái hoàn toàn.'],
      ['Để tiêu diệt muỗi truyền bệnh sốt xuất huyết hiệu quả nhất, chúng ta nên tác động vào giai đoạn nào trong vòng đời phát triển của muỗi?', ['Chỉ đuổi muỗi khi muỗi đã bay đi đốt người.', 'Diệt lăng quăng (bọ gậy) và trứng muỗi bằng cách đậy kín chum vại chứa nước, úp các dụng cụ đọng nước và thả cá ăn bọ gậy.', 'Tắt đèn ban đêm.', 'Trồng thêm nhiều cỏ dại ẩm thấp.'], 1, 'Trứng và ấu trùng muỗi (bọ gậy/lăng quăng) bắt buộc phải sống trong nước đọng nên loại bỏ nơi nước đọng và thả cá diệt bọ gậy là hiệu quả nhất.'],
      ['Sinh sản vô tính là hình thức sinh sản:', ['có sự kết hợp giữa giao tử đực và giao tử cái.', 'không có sự kết hợp giữa giao tử đực và giao tử cái; cơ thể con được hình thành từ một phần cơ thể mẹ và có đặc điểm giống hệt mẹ.', 'chỉ xảy ra ở chim và thú.', 'tạo ra hạt thông qua quá trình thụ phấn.'], 1, 'Sinh sản vô tính chỉ từ 1 cá thể mẹ, không có sự thụ tinh, con sinh ra giữ nguyên đặc tính di truyền của mẹ.'],
      ['Phương pháp nhân giống nào sau đây ở thực vật thuộc hình thức sinh sản SINH DƯỠNG (sinh sản vô tính)?', ['Gieo hạt ngô, hạt lúa.', 'Giâm cành (sắn, mía, rau muống), chiết cành (cam, bưởi, nhãn), ghép mắt và nuôi cấy mô tế bào.', 'Thụ phấn cho hoa bí ngô.', 'Ong mật hút mật hoa.'], 1, 'Giâm cành, chiết cành, ghép cành, nuôi cấy mô đều tạo cây con từ cơ quan sinh dưỡng (rễ, thân, lá) không qua thụ tinh.'],
      ['Trong cấu tạo của một bông hoa lưỡng tính ở thực vật có hoa, bộ phận sinh sản đực và bộ phận sinh sản cái lần lượt là:', ['Đài hoa và tràng hoa (cánh hoa).', 'Nhị hoa (có bao phấn chứa hạt phấn mang giao tử đực) và Nhụy hoa (có bầu nhụy chứa noãn mang giao tử cái).', 'Cuống hoa và đế hoa.', 'Lá đài và cuống lá.'], 1, 'Nhị là cơ quan sinh sản đực; Nhụy là cơ quan sinh sản cái của hoa.'],
      ['Sau quá trình thụ phấn và thụ tinh ở thực vật có hoa, Hợp tử và Noãn đã thụ tinh và Bầu nhụy sẽ lần lượt phát triển thành những bộ phận nào?', ['Hợp tử phát triển thành phôi; Noãn phát triển thành hạt; Bầu nhụy phát triển thành quả chứa hạt.', 'Tất cả đều rụng đi.', 'Cánh hoa biến thành quả.', 'Nhị hoa biến thành hạt.'], 0, 'Hợp tử → Phôi; Noãn → Hạt; Bầu nhụy → Quả bảo vệ hạt.'],
    ]),
    trueFalseList: [
      {
        id: 'b32-tf-1',
        stem: 'Xét đặc điểm cảm ứng ở thực vật và động vật:',
        statements: [
          { id: 'a', text: 'Cảm ứng ở thực vật thường diễn ra chậm và biểu hiện thông qua sự vận động sinh trưởng của các cơ quan (ngọn hướng sáng, rễ hướng nước và hướng trọng lực).', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Cảm ứng ở động vật có hệ thần kinh diễn ra rất nhanh và chính xác thông qua cung phản xạ.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Khi chạm tay vào lá cây trinh nữ (cây xấu hổ), lá cây cụp lại ngay lập tức là do cây trinh nữ có hệ thần kinh giống động vật.', isTrue: false, explanation: 'Sai, thực vật hoàn toàn không có hệ thần kinh; lá cây trinh nữ cụp lại là do sự thay đổi sức trương nước ở thể gối tại cuống lá.' },
          { id: 'd', text: 'Trong trồng trọt, người ta ứng dụng tính hướng nước và hướng hóa của rễ cây để bón phân, tưới nước theo rãnh quanh tán cây giúp bộ rễ lan rộng bám sâu vào đất.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b32-tf-2',
        stem: 'Phân biệt tập tính bẩm sinh và tập tính học được ở động vật và con người:',
        statements: [
          { id: 'a', text: 'Tập tính bẩm sinh là loại tập tính sinh ra đã có, được di truyền từ bố mẹ và đặc trưng cho từng loài (ví dụ: nhện giăng tơ, chim di cư, tò vò đào hang).', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Tập tính học được là loại tập tính được hình thành trong quá trình sống của cá thể thông qua học tập, rút kinh nghiệm (ví dụ: gà chạy tới khi nghe tiếng gõ mõ cho ăn, học sinh tự giác học bài).', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Tập tính học được là cố định vĩnh viễn và được di truyền nguyên vẹn cho thế hệ con cháu.', isTrue: false, explanation: 'Sai, tập tính học được không di truyền và có thể bị mai một nếu không được củng cố thường xuyên.' },
          { id: 'd', text: 'Để hình thành một thói quen tốt (như dậy sớm, đọc sách, tập thể dục), chúng ta cần lặp đi lặp lại hành động đó kiên trì hàng ngày.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b32-tf-3',
        stem: 'Xét quá trình sinh trưởng và phát triển ở thực vật và động vật:',
        statements: [
          { id: 'a', text: 'Sinh trưởng và phát triển là hai quá trình liên quan mật thiết: sinh trưởng là cơ sở cho phát triển, và phát triển thúc đẩy sinh trưởng.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Khi bấm ngọn (tỉa đỉnh sinh trưởng) của cây mồng tơi, cây đậu, cây cà phê sẽ kích thích các chồi bên (cành bên) phát triển mạnh hơn giúp tăng năng suất.', isTrue: true, explanation: 'Đúng ứng dụng bấm ngọn để phát triển chồi nách.' },
          { id: 'c', text: 'Vòng đời của con gà và con mèo thuộc kiểu phát triển qua biến thái hoàn toàn.', isTrue: false, explanation: 'Sai, gà con và mèo con mới nở/sinh ra đã có cấu tạo hình thái tương tự con trưởng thành nên thuộc kiểu phát triển KHÔNG qua biến thái.' },
          { id: 'd', text: 'Vòng đời của bướm (Trứng → Sâu bướm → Nhộng → Bướm) thuộc kiểu phát triển qua biến thái hoàn toàn.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b32-tf-4',
        stem: 'Xét các hình thức sinh sản vô tính ở sinh vật và ứng dụng trong thực tiễn:',
        statements: [
          { id: 'a', text: 'Trong sinh sản vô tính, cá thể con được tạo thành từ một phần cơ thể mẹ (không có sự kết hợp giao tử đực – cái) nên giữ nguyên được các đặc tính quý của cây mẹ.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Cây thuốc bỏng (sống đời) mọc cây con từ mép lá, cây khoai lang mọc từ đoạn dây thân, cây gừng mọc từ thân rễ đều là sinh sản sinh dưỡng.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Ở động vật như thủy tức có hình thức sinh sản vô tính bằng cách mọc chồi; thằn lằn đứt đuôi mọc lại đuôi mới là hình thức tái sinh bộ phận.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Phương pháp chiết cành ở cây ăn quả (cam, bưởi, nhãn) làm cho cây con lâu ra hoa kết quả hơn so với trồng bằng hạt.', isTrue: false, explanation: 'Sai, chiết cành giúp cây con giữ nguyên phẩm chất ngon của cây mẹ và ra hoa kết quả SỚM hơn nhiều so với trồng từ hạt.' },
        ],
      },
      {
        id: 'b32-tf-5',
        stem: 'Xét quá trình sinh sản hữu tính ở thực vật có hoa và ở động vật:',
        statements: [
          { id: 'a', text: 'Sinh sản hữu tính luôn có sự kết hợp giữa giao tử đực (tinh trùng) và giao tử cái (trứng) qua quá trình thụ tinh tạo thành hợp tử.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Sinh sản hữu tính tạo ra đời con đa dạng về đặc điểm di truyền, giúp loài thích nghi tốt hơn khi điều kiện môi trường sống thay đổi.', isTrue: true, explanation: 'Đúng ưu thế của sinh sản hữu tính.' },
          { id: 'c', text: 'Những bông hoa thụ phấn nhờ côn trùng (ong, bướm) thường có màu sắc sặc sỡ, có hương thơm và mật ngọt, hạt phấn to và có gai hoặc chất dính.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Sau khi thụ tinh ở hoa, cánh hoa sẽ phình to ra biến thành hạt, còn nhị hoa biến thành quả.', isTrue: false, explanation: 'Sai, sau khi thụ tinh cánh hoa và nhị hoa thường héo rụng; noãn đã thụ tinh phát triển thành hạt và bầu nhụy phát triển thành quả.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b32-es-1',
        question: 'Câu 1 [SGK KHTN 7 - KNTT]:\n(a) Cảm ứng ở sinh vật là gì? Hãy nêu 3 ví dụ về cảm ứng ở thực vật và cho biết ý nghĩa của chúng đối với đời sống của cây.\n(b) Phân biệt tập tính bẩm sinh và tập tính học được ở động vật (cho 2 ví dụ mỗi loại).',
        hint: 'Nêu tính hướng sáng, hướng nước, hướng tiếp xúc ở cây; so sánh tính di truyền của 2 loại tập tính.',
        sampleAnswer: '(a) Cảm ứng là khả năng cơ thể sinh vật tiếp nhận và phản ứng thích hợp với các kích thích từ môi trường để tồn tại và phát triển.\n- 3 ví dụ ở thực vật:\n1. Tính hướng sáng dương của ngọn cây: giúp lá cây vươn tới nơi có nhiều ánh sáng để quang hợp.\n2. Tính hướng nước và hướng hóa dương của rễ cây: giúp rễ tìm tới nguồn nước và phân bón trong đất để hấp thụ.\n3. Tính hướng tiếp xúc của tua cuốn (bầu, bí, mướp): giúp cây bám vào giá thể leo lên cao đón nắng.\n(b) Phân biệt tập tính ở động vật:\n- Tập tính bẩm sinh: Sinh ra đã có, được di truyền từ bố mẹ, đặc trưng cho loài (VD: nhện chăng tơ, tò vò đào tổ, gà con mới nở biết mổ hạt).\n- Tập tính học được: Hình thành trong quá trình sống của cá thể qua học tập và rèn luyện, không di truyền (VD: cá nổi lên khi nghe tiếng vỗ tay cho ăn, chó nghiệp vụ tìm đồ vật, con người chấp hành luật giao thông).',
        rubricPoints: [
          'Nêu đúng khái niệm cảm ứng và 3 ví dụ kèm ý nghĩa ở thực vật.',
          'Phân biệt rõ tập tính bẩm sinh và tập tính học được kèm ví dụ minh họa.',
        ],
      },
      {
        id: 'b32-es-2',
        question: 'Câu 2 [SGK KHTN 7 - KNTT]:\n(a) Sinh trưởng và phát triển ở sinh vật là gì? Giữa sinh trưởng và phát triển có mối quan hệ với nhau như thế nào?\n(b) Giải thích vì sao khi trồng các loại cây lấy quả, lấy lá (như bầu, bí, mồng tơi, cà phê) người ta thường ngắt ngọn (bấm ngọn), còn khi trồng các cây lấy gỗ (như bạch đàn, thông, keo) người ta lại tỉa bỏ các cành bên và giữ ngọn chính?',
        hint: 'Liên hệ vai trò của mô phân sinh đỉnh ở ngọn chính và sự phát triển của các chồi nách.',
        sampleAnswer: '(a) Khái niệm và mối quan hệ:\n- Sinh trưởng là sự tăng lên về kích thước và khối lượng của cơ thể do sự tăng số lượng và kích thước tế bào.\n- Phát triển bao gồm sinh trưởng, sự phân hóa tế bào và phát sinh hình thái các cơ quan, cơ thể.\n- Mối quan hệ: Sinh trưởng và phát triển gắn bó mật thiết với nhau; sinh trưởng tạo tiền đề vật chất cho phát triển (ví dụ cây phải sinh trưởng đủ lá, đủ lớn mới phát triển ra hoa), ngược lại phát triển thúc đẩy giai đoạn sinh trưởng tiếp theo.\n(b) Ứng dụng bấm ngọn và tỉa cành:\n- Với cây lấy lá, lấy quả (bầu, bí, mồng tơi, cà phê): Bấm ngọn (loại bỏ đỉnh sinh trưởng ngọn) để xóa bỏ ưu thế đỉnh, kích thích các chồi nách (cành bên) đâm ra nhiều nhánh mới, cho nhiều lá và nhiều hoa quả hơn.\n- Với cây lấy gỗ (bạch đàn, thông, lim): Giữ ngọn chính và tỉa bớt cành bên ở dưới thấp để cây tập trung chất dinh dưỡng phát triển thân chính vươn thẳng, cao và ít mắt gỗ.',
        rubricPoints: [
          'Nêu đúng khái niệm và mối quan hệ giữa sinh trưởng và phát triển.',
          'Giải thích đúng mục đích bấm ngọn (tăng cành bên/quả) và tỉa cành ở cây lấy gỗ (thân chính cao, thẳng).',
        ],
      },
      {
        id: 'b32-es-3',
        question: 'Câu 3 [SBT KHTN 7 - KNTT]: Vẽ sơ đồ (hoặc viết sơ đồ mũi tên) mô tả các giai đoạn trong vòng đời phát triển của con bướm (sâu hại rau) và con muỗi. Từ đặc điểm vòng đời của chúng, hãy đề xuất các biện pháp tiêu diệt sâu hại mùa màng và tiêu diệt muỗi truyền bệnh sốt xuất huyết hiệu quả, thân thiện với môi trường.',
        hint: 'Vòng đời gồm 4 giai đoạn: Trứng → Ấu trùng (Sâu bướm / Bọ gậy) → Nhộng → Trưởng thành.',
        sampleAnswer: '- Sơ đồ vòng đời phát triển qua biến thái hoàn toàn:\n+ Ở bướm: Trứng → Sâu bướm (Ấu trùng ăn lá) → Nhộng → Bướm trưởng thành.\n+ Ở muỗi: Trứng (trong nước) → Bọ gậy / Lăng quăng (trong nước) → Cung quăng (Nhộng) → Muỗi trưởng thành.\n- Biện pháp phòng trừ hiệu quả:\n1. Đối với sâu bướm hại cây trồng: Giai đoạn phá hoại mùa màng mạnh nhất là giai đoạn sâu non (sâu bướm), trong khi bướm trưởng thành đẻ trứng. Ta có thể dùng bẫy đèn bắt bướm trưởng thành, nuôi thả thiên địch (ong mắt đỏ, chim ăn sâu) hoặc bắt sâu, vệ sinh đồng ruộng để cắt đứt vòng đời của chúng.\n2. Đối với muỗi sốt xuất huyết: Vì trứng, bọ gậy và cung quăng bắt buộc phải sống trong nước đọng nên biện pháp hiệu quả nhất là đậy kín các dụng cụ chứa nước, lật úp các vật phế thải đọng nước, khơi thông cống rãnh và thả cá vào bể nước để ăn bọ gậy.',
        rubricPoints: [
          'Viết đúng sơ đồ 4 giai đoạn vòng đời của bướm và muỗi.',
          'Đề xuất đúng biện pháp sinh học diệt sâu hại và diệt bọ gậy/lăng quăng phòng sốt xuất huyết.',
        ],
      },
      {
        id: 'b32-es-4',
        question: 'Câu 4 [SGK KHTN 7 - KNTT]:\n(a) Phân biệt sinh sản vô tính và sinh sản hữu tính ở sinh vật.\n(b) Trong trồng trọt, phương pháp nhân giống vô tính (như chiết cành, ghép cành, nuôi cấy mô) có những ưu điểm gì nổi bật so với trồng bằng hạt?',
        hint: 'So sánh sự tham gia của giao tử đực – cái, đặc điểm di truyền của đời con và thời gian cho thu hoạch.',
        sampleAnswer: '(a) Phân biệt sinh sản vô tính và sinh sản hữu tính:\n- Sinh sản vô tính: Không có sự kết hợp giữa giao tử đực và giao tử cái; cơ thể con hình thành từ một phần cơ thể mẹ nên có đặc điểm di truyền giống hệt mẹ.\n- Sinh sản hữu tính: Có sự kết hợp giữa giao tử đực và giao tử cái thông qua thụ tinh tạo thành hợp tử; cơ thể con phát triển từ hợp tử mang đặc điểm di truyền của cả bố và mẹ nên đa dạng và thích nghi tốt với môi trường thay đổi.\n(b) Ưu điểm của nhân giống vô tính (chiết cành, ghép cành, nuôi cấy mô) trong trồng trọt:\n1. Giữ nguyên được các đặc tính quý (quả ngọt, hoa đẹp, năng suất cao) của cây mẹ mà không bị phân tính (thoái hóa) như trồng từ hạt.\n2. Rút ngắn thời gian sinh trưởng, giúp cây nhanh ra hoa kết quả và sớm cho thu hoạch hơn trồng bằng hạt.\n3. Nhân nhanh được số lượng lớn cây giống sạch bệnh trong thời gian ngắn (đặc biệt là nuôi cấy mô).',
        rubricPoints: [
          'Phân biệt đúng sinh sản vô tính và sinh sản hữu tính.',
          'Nêu đúng 3 ưu điểm của nhân giống vô tính trong nông nghiệp.',
        ],
      },
    ],
  },
];
