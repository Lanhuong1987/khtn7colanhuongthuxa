import { SubSubject } from './khtn7Data';
import { GK1_EXAM_PAPERS } from './examsGk1';
import { HK1_EXAM_PAPERS } from './examsHk1';
import { GK2_EXAM_PAPERS } from './examsGk2';
import { HK2_EXAM_PAPERS } from './examsHk2';

export type CognitiveLevel = 'Nhận biết' | 'Thông hiểu' | 'Vận dụng' | 'Vận dụng cao';
export type ExamPeriodCode = 'gk1' | 'hk1' | 'gk2' | 'hk2';

export interface StandardExamMcq {
  id: string;
  subject: SubSubject;
  lessonRef: string; // e.g. 'Lí – Bài 8', 'Hóa – Bài 2', 'Sinh – Bài 21'
  level: CognitiveLevel;
  question: string;
  options: [string, string, string, string];
  correctIndex: number;
  explanation: string;
}

export interface StandardExamEssay {
  id: string;
  subject: SubSubject;
  lessonRef: string;
  level: CognitiveLevel; // Lí, Hóa: Vận dụng / Vận dụng cao; Sinh: Thông hiểu / Vận dụng
  points: number; // e.g., 0.5 điểm
  question: string;
  sampleAnswer: string;
  rubricCriteria: string[];
}

export interface KnttExamPaper {
  id: string;
  code: ExamPeriodCode | string;
  paperNumber?: number; // 1, 2, 3, 4
  title: string;
  shortTitle: string;
  durationMinutes: number;
  scopeSummary: {
    physics: string;
    chemistry: string;
    biology: string;
  };
  matrixSummary: string;
  mcqs: StandardExamMcq[]; // 21 câu TN (Biết ~30%, Hiểu ~30%, Vận dụng ~20%, Vận dụng cao ~20%)
  essays: StandardExamEssay[]; // 6 câu TL (Lí, Hóa: Vận dụng & Vận dụng cao; Sinh: Hiểu & Vận dụng)
  isCustomTeacherExam?: boolean;
  rawHtmlPreview?: string;
  createdAt?: string;
}

export interface ExamPeriodGroup {
  code: ExamPeriodCode;
  name: string;
  shortName: string;
  scopeSummary: {
    physics: string;
    chemistry: string;
    biology: string;
  };
  papers: KnttExamPaper[];
}

// Deterministically distribute the correct answer across A, B, C, D so options are balanced
function distributePaperOptions(paper: KnttExamPaper, paperIdx: number): KnttExamPaper {
  const rotatedMcqs: StandardExamMcq[] = paper.mcqs.map((q, qIdx) => {
    const targetPos = (qIdx * 3 + paperIdx + (paper.paperNumber || 1)) % 4;
    if (q.correctIndex === targetPos) return q;

    const opts = [...q.options] as [string, string, string, string];
    const correctText = opts[q.correctIndex];
    const otherTexts = opts.filter((_, i) => i !== q.correctIndex);

    const nextOptions: string[] = [];
    let otherCursor = 0;
    for (let pos = 0; pos < 4; pos++) {
      if (pos === targetPos) {
        nextOptions.push(correctText);
      } else {
        nextOptions.push(otherTexts[otherCursor++]);
      }
    }

    return {
      ...q,
      options: nextOptions as [string, string, string, string],
      correctIndex: targetPos,
    };
  });

  return {
    ...paper,
    mcqs: rotatedMcqs,
  };
}

const gk1Normalized = GK1_EXAM_PAPERS.map((p, i) => distributePaperOptions(p, i));
const hk1Normalized = HK1_EXAM_PAPERS.map((p, i) => distributePaperOptions(p, i + 1));
const gk2Normalized = GK2_EXAM_PAPERS.map((p, i) => distributePaperOptions(p, i + 2));
const hk2Normalized = HK2_EXAM_PAPERS.map((p, i) => distributePaperOptions(p, i + 3));

export const KNTT_EXAM_PERIOD_GROUPS: ExamPeriodGroup[] = [
  {
    code: 'gk1',
    name: 'Đề Kiểm Tra Giữa Học Kì I (GK1)',
    shortName: 'Đề Giữa Kì 1 (GK1)',
    scopeSummary: {
      physics: 'Lí: Bài 8 – 11',
      chemistry: 'Hóa: Bài 1 – 2',
      biology: 'Sinh: Bài 21 – 27',
    },
    papers: gk1Normalized,
  },
  {
    code: 'hk1',
    name: 'Đề Kiểm Tra Cuối Học Kì I (HK1)',
    shortName: 'Đề Học Kì 1 (HK1)',
    scopeSummary: {
      physics: 'Lí: Bài 8 – 14',
      chemistry: 'Hóa: Bài 1 – 4',
      biology: 'Sinh: Bài 21 – 32',
    },
    papers: hk1Normalized,
  },
  {
    code: 'gk2',
    name: 'Đề Kiểm Tra Giữa Học Kì II (GK2)',
    shortName: 'Đề Giữa Kì 2 (GK2)',
    scopeSummary: {
      physics: 'Lí: Bài 15 – 17',
      chemistry: 'Hóa: Bài 5 – 6',
      biology: 'Sinh: Bài 33 – 37',
    },
    papers: gk2Normalized,
  },
  {
    code: 'hk2',
    name: 'Đề Kiểm Tra Cuối Học Kì II (HK2)',
    shortName: 'Đề Học Kì 2 (HK2)',
    scopeSummary: {
      physics: 'Lí: Bài 15 – 20',
      chemistry: 'Hóa: Bài 6 – 7',
      biology: 'Sinh: Bài 33 – 42',
    },
    papers: hk2Normalized,
  },
];

export const KNTT_STANDARD_EXAMS: KnttExamPaper[] = [
  ...gk1Normalized,
  ...hk1Normalized,
  ...gk2Normalized,
  ...hk2Normalized,
];
