export interface StudentAssessmentScores {
  tx1: number | null; // Hệ số 1
  tx2: number | null; // Hệ số 1
  tx3: number | null; // Hệ số 1
  tx4: number | null; // Hệ số 1
  tx5: number | null; // Hệ số 1
  dggk: number | null; // Đánh giá giữa kì - Hệ số 2
  dgck: number | null; // Đánh giá cuối kì - Hệ số 3
}

export interface CommendationRecord {
  id: string;
  reason: string;
  points: number;
  weekNumber: number;
  createdAt: string;
}

export interface TeacherCommentRecord {
  id: string;
  weekNumber: number;
  content: string;
  trendTag: 'Tiến bộ vượt bậc' | 'Duy trì tốt' | 'Cần cố gắng thêm' | 'Cần phụ đạo sát';
  createdAt: string;
}

export interface StudentProfile {
  id: string;
  code: string;
  fullName: string;
  className: string;
  avatarColor: string;
  absorptionLevel?: 'Xuất sắc' | 'Khá' | 'Trung bình' | 'Cần hỗ trợ';
  baselineWeeksCompleted: number[];
  baselineMcqDone: number;
  baselineMcqCorrect: number;
  baselineTfDone: number;
  baselineEssayDone: number;
  baselineExamScore: number | null;
  baselineGameScore: number;
  scores?: StudentAssessmentScores;
  commendationPoints?: number;
  commendationHistory?: CommendationRecord[];
  strengths?: string;
  privateNote?: string;
  teacherComments?: TeacherCommentRecord[];
}

export interface WeeklyAssignment {
  weekNumber: number;
  semesterLabel?: string; // e.g., 'HK1' | 'HK2'
  title: string;
  subjectLabel: string;
  lessonIds: string[];
  dueDate: string;
  targetMcq: number;
  targetTf: number;
  targetEssay: number;
}

export const DEFAULT_STUDENTS: StudentProfile[] = [
  {
    id: 'hs-01',
    code: 'KHTN7_HS01',
    fullName: 'VÕ THỊ THANH HÀ',
    className: 'Lớp 7A1',
    avatarColor: 'bg-emerald-600',
    absorptionLevel: 'Xuất sắc',
    baselineWeeksCompleted: [1, 2, 3, 4, 5, 6],
    baselineMcqDone: 180,
    baselineMcqCorrect: 168,
    baselineTfDone: 30,
    baselineEssayDone: 32,
    baselineExamScore: 9.2,
    baselineGameScore: 680,
    scores: {
      tx1: 8.5,
      tx2: 9.0,
      tx3: 9.25,
      tx4: 9.5,
      tx5: null,
      dggk: 9.0,
      dgck: null,
    },
    commendationPoints: 30,
    commendationHistory: [
      {
        id: 'cm-1',
        reason: 'Hoàn thành xuất sắc BTVN Tuần 1–5 và nộp đủ ảnh bài Tự luận',
        points: 20,
        weekNumber: 5,
        createdAt: '15/10/2026',
      },
      {
        id: 'cm-2',
        reason: 'Đạt giải Nhất Rung Chuông Vàng Bài 2: Nguyên tử',
        points: 10,
        weekNumber: 6,
        createdAt: '22/10/2026',
      },
    ],
    strengths: 'Nắm rất chắc Hóa học (Nguyên tử, Bảng tuần hoàn) và công thức tính Tốc độ v = s/t.',
    privateNote: 'Học sinh tích cực, chữ viết trình bày bài tự luận rõ ràng, có thể giao thêm bài nâng cao.',
    teacherComments: [
      {
        id: 'tc-1',
        weekNumber: 6,
        content: 'Thanh Hà hoàn thành 100% bài tập về nhà đúng hạn, điểm kiểm tra thường xuyên tăng đều qua từng tuần. Tuyên dương tinh thần tự giác!',
        trendTag: 'Tiến bộ vượt bậc',
        createdAt: '25/10/2026',
      },
    ],
  },
  {
    id: 'hs-02',
    code: 'KHTN7_HS02',
    fullName: 'LÊ PHAN BẢO CHÂU',
    className: 'Lớp 7A1',
    avatarColor: 'bg-blue-600',
    absorptionLevel: 'Xuất sắc',
    baselineWeeksCompleted: [1, 2, 3, 4, 5, 6],
    baselineMcqDone: 175,
    baselineMcqCorrect: 162,
    baselineTfDone: 28,
    baselineEssayDone: 29,
    baselineExamScore: 9.5,
    baselineGameScore: 720,
    scores: {
      tx1: 9.0,
      tx2: 8.75,
      tx3: 9.5,
      tx4: 9.25,
      tx5: null,
      dggk: 9.25,
      dgck: null,
    },
    commendationPoints: 25,
    strengths: 'Tư duy Vật lí (Đồ thị quãng đường - thời gian, Sóng âm) rất nhạy bén.',
    privateNote: 'Học tập nghiêm túc, luôn chủ động hoàn thành bài tập đúng hạn.',
    teacherComments: [
      {
        id: 'tc-2',
        weekNumber: 6,
        content: 'Bảo Châu làm bài rất chắc chắn, đạt điểm cao ở cả phần Trắc nghiệm và Tự luận.',
        trendTag: 'Duy trì tốt',
        createdAt: '25/10/2026',
      },
    ],
  },
  {
    id: 'hs-03',
    code: 'KHTN7_HS03',
    fullName: 'PHẠM ĐOÀN NINA',
    className: 'Lớp 7A1',
    avatarColor: 'bg-amber-600',
    absorptionLevel: 'Khá',
    baselineWeeksCompleted: [1, 2, 3, 4, 5],
    baselineMcqDone: 145,
    baselineMcqCorrect: 125,
    baselineTfDone: 24,
    baselineEssayDone: 22,
    baselineExamScore: 8.5,
    baselineGameScore: 540,
    scores: {
      tx1: 8.0,
      tx2: 8.25,
      tx3: 8.5,
      tx4: null,
      tx5: null,
      dggk: 8.5,
      dgck: null,
    },
    commendationPoints: 15,
    strengths: 'Yêu thích phân môn Sinh học (Quang hợp, Hô hấp tế bào) và Hóa học.',
    privateNote: 'Chăm chỉ luyện tập trên hệ thống mỗi tuần.',
    teacherComments: [],
  },
  {
    id: 'hs-04',
    code: 'KHTN7_HS04',
    fullName: 'NGUYỄN ĐỖ ÁNH TIÊN',
    className: 'Lớp 7A1',
    avatarColor: 'bg-indigo-600',
    absorptionLevel: 'Xuất sắc',
    baselineWeeksCompleted: [1, 2, 3, 4, 5, 6],
    baselineMcqDone: 168,
    baselineMcqCorrect: 154,
    baselineTfDone: 28,
    baselineEssayDone: 26,
    baselineExamScore: 9.0,
    baselineGameScore: 630,
    scores: {
      tx1: 8.5,
      tx2: 8.75,
      tx3: 9.0,
      tx4: 9.0,
      tx5: null,
      dggk: 8.75,
      dgck: null,
    },
    commendationPoints: 20,
    strengths: 'Nắm vững kiến thức cả 3 phân môn Vật lí, Hóa học, Sinh học.',
    privateNote: 'Trình bày bài tự luận sạch đẹp, khoa học.',
    teacherComments: [],
  },
  {
    id: 'hs-05',
    code: 'KHTN7_HS05',
    fullName: 'VÕ ĐỨC ĐAM',
    className: 'Lớp 7A1',
    avatarColor: 'bg-teal-600',
    absorptionLevel: 'Khá',
    baselineWeeksCompleted: [1, 2, 3, 4, 5],
    baselineMcqDone: 138,
    baselineMcqCorrect: 118,
    baselineTfDone: 22,
    baselineEssayDone: 20,
    baselineExamScore: 8.2,
    baselineGameScore: 510,
    scores: {
      tx1: 7.75,
      tx2: 8.0,
      tx3: 8.25,
      tx4: null,
      tx5: null,
      dggk: 8.0,
      dgck: null,
    },
    commendationPoints: 15,
    strengths: 'Tích cực tham gia trả lời câu hỏi và làm bài tập vận dụng.',
    privateNote: 'Đang tiến bộ đều qua từng tuần học.',
    teacherComments: [],
  },
  {
    id: 'hs-06',
    code: 'KHTN7_HS06',
    fullName: 'NGUYỄN BẢO KHANG',
    className: 'Lớp 7A1',
    avatarColor: 'bg-rose-600',
    absorptionLevel: 'Khá',
    baselineWeeksCompleted: [1, 2, 3, 4, 5],
    baselineMcqDone: 142,
    baselineMcqCorrect: 122,
    baselineTfDone: 23,
    baselineEssayDone: 21,
    baselineExamScore: 8.4,
    baselineGameScore: 560,
    scores: {
      tx1: 7.5,
      tx2: 8.25,
      tx3: 8.5,
      tx4: null,
      tx5: null,
      dggk: 8.25,
      dgck: null,
    },
    commendationPoints: 15,
    strengths: 'Nhạy bén với các bài toán tính tốc độ và đồ thị quãng đường - thời gian.',
    privateNote: 'Có tinh thần tự giác ôn luyện.',
    teacherComments: [],
  },
  {
    id: 'hs-07',
    code: 'KHTN7_HS07',
    fullName: 'NGUYỄN THỊ GIA NHI',
    className: 'Lớp 7A1',
    avatarColor: 'bg-cyan-600',
    absorptionLevel: 'Xuất sắc',
    baselineWeeksCompleted: [1, 2, 3, 4, 5, 6],
    baselineMcqDone: 172,
    baselineMcqCorrect: 158,
    baselineTfDone: 28,
    baselineEssayDone: 28,
    baselineExamScore: 9.1,
    baselineGameScore: 650,
    scores: {
      tx1: 8.5,
      tx2: 9.0,
      tx3: 9.25,
      tx4: null,
      tx5: null,
      dggk: 9.0,
      dgck: null,
    },
    commendationPoints: 25,
    strengths: 'Ghi chép bài tự luận sạch đẹp, cẩn thận, nắm chắc lý thuyết.',
    privateNote: 'Đang duy trì phong độ học tập rất tốt.',
    teacherComments: [],
  },
  {
    id: 'hs-08',
    code: 'KHTN7_HS08',
    fullName: 'PHẠM THÀNH TIẾN',
    className: 'Lớp 7A1',
    avatarColor: 'bg-purple-600',
    absorptionLevel: 'Khá',
    baselineWeeksCompleted: [1, 2, 3, 4],
    baselineMcqDone: 120,
    baselineMcqCorrect: 98,
    baselineTfDone: 19,
    baselineEssayDone: 16,
    baselineExamScore: 7.8,
    baselineGameScore: 460,
    scores: {
      tx1: 7.25,
      tx2: 7.75,
      tx3: 8.0,
      tx4: null,
      tx5: null,
      dggk: 7.75,
      dgck: null,
    },
    commendationPoints: 15,
    strengths: 'Có cố gắng khắc phục các câu sai trong tuần.',
    privateNote: 'Cần rèn thêm bài tập vận dụng cao phần Hóa học và Vật lí.',
    teacherComments: [],
  },
  {
    id: 'hs-09',
    code: 'KHTN7_HS09',
    fullName: 'TRƯƠNG THỊ QUỲNH NHƯ',
    className: 'Lớp 7A1',
    avatarColor: 'bg-emerald-700',
    absorptionLevel: 'Xuất sắc',
    baselineWeeksCompleted: [1, 2, 3, 4, 5, 6],
    baselineMcqDone: 170,
    baselineMcqCorrect: 155,
    baselineTfDone: 28,
    baselineEssayDone: 27,
    baselineExamScore: 9.0,
    baselineGameScore: 610,
    scores: {
      tx1: 8.5,
      tx2: 8.75,
      tx3: 9.0,
      tx4: 9.25,
      tx5: null,
      dggk: 8.75,
      dgck: null,
    },
    commendationPoints: 25,
    strengths: 'Trình bày bài tập tự luận Hóa học và Sinh học rất mạch lạc.',
    privateNote: 'Học tập ổn định, tích cực.',
    teacherComments: [],
  },
  {
    id: 'hs-10',
    code: 'KHTN7_HS10',
    fullName: 'KIỀU TRƯƠNG THẢO NHƯ',
    className: 'Lớp 7A1',
    avatarColor: 'bg-amber-700',
    absorptionLevel: 'Khá',
    baselineWeeksCompleted: [1, 2, 3, 4, 5],
    baselineMcqDone: 140,
    baselineMcqCorrect: 120,
    baselineTfDone: 22,
    baselineEssayDone: 20,
    baselineExamScore: 8.3,
    baselineGameScore: 520,
    scores: {
      tx1: 7.75,
      tx2: 8.25,
      tx3: 8.5,
      tx4: null,
      tx5: null,
      dggk: 8.25,
      dgck: null,
    },
    commendationPoints: 15,
    strengths: 'Chăm chỉ hoàn thành đầy đủ bài tập trắc nghiệm và tự luận.',
    privateNote: 'Tiến bộ đều qua các tuần học.',
    teacherComments: [],
  },
  {
    id: 'hs-11',
    code: 'KHTN7_HS11',
    fullName: 'BÙI NHÂN NHÂN',
    className: 'Lớp 7A1',
    avatarColor: 'bg-blue-700',
    absorptionLevel: 'Khá',
    baselineWeeksCompleted: [1, 2, 3, 4, 5],
    baselineMcqDone: 135,
    baselineMcqCorrect: 115,
    baselineTfDone: 22,
    baselineEssayDone: 20,
    baselineExamScore: 8.4,
    baselineGameScore: 490,
    scores: {
      tx1: 7.5,
      tx2: 8.0,
      tx3: 8.5,
      tx4: null,
      tx5: null,
      dggk: 8.0,
      dgck: null,
    },
    commendationPoints: 15,
    strengths: 'Chăm chỉ làm bài luyện tập và chơi game ôn bài.',
    privateNote: 'Tiến bộ rõ rệt ở chương Âm thanh và Ánh sáng.',
    teacherComments: [],
  },
  {
    id: 'hs-12',
    code: 'KHTN7_HS12',
    fullName: 'NGUYỄN NỮ MỘC MIÊN',
    className: 'Lớp 7A1',
    avatarColor: 'bg-teal-700',
    absorptionLevel: 'Xuất sắc',
    baselineWeeksCompleted: [1, 2, 3, 4, 5, 6],
    baselineMcqDone: 165,
    baselineMcqCorrect: 150,
    baselineTfDone: 27,
    baselineEssayDone: 25,
    baselineExamScore: 8.9,
    baselineGameScore: 590,
    scores: {
      tx1: 8.5,
      tx2: 8.75,
      tx3: 9.0,
      tx4: null,
      tx5: null,
      dggk: 8.75,
      dgck: null,
    },
    commendationPoints: 20,
    strengths: 'Nắm vững kiến thức Sinh học và Hóa học 7.',
    privateNote: 'Luôn hoàn thành bài tập về nhà đúng thời hạn.',
    teacherComments: [],
  },
  {
    id: 'hs-13',
    code: 'KHTN7_HS13',
    fullName: 'PHẠM ANH TRÍ',
    className: 'Lớp 7A1',
    avatarColor: 'bg-indigo-700',
    absorptionLevel: 'Khá',
    baselineWeeksCompleted: [1, 2, 3, 4, 5],
    baselineMcqDone: 132,
    baselineMcqCorrect: 112,
    baselineTfDone: 21,
    baselineEssayDone: 18,
    baselineExamScore: 8.1,
    baselineGameScore: 500,
    scores: {
      tx1: 7.5,
      tx2: 8.0,
      tx3: 8.25,
      tx4: null,
      tx5: null,
      dggk: 8.0,
      dgck: null,
    },
    commendationPoints: 15,
    strengths: 'Tư duy thực hành và thí nghiệm mô phỏng tốt.',
    privateNote: 'Học tập tích cực.',
    teacherComments: [],
  },
  {
    id: 'hs-14',
    code: 'KHTN7_HS14',
    fullName: 'NGUYỄN LÊ THÙY DƯƠNG',
    className: 'Lớp 7A1',
    avatarColor: 'bg-pink-600',
    absorptionLevel: 'Xuất sắc',
    baselineWeeksCompleted: [1, 2, 3, 4, 5, 6],
    baselineMcqDone: 174,
    baselineMcqCorrect: 160,
    baselineTfDone: 28,
    baselineEssayDone: 27,
    baselineExamScore: 9.2,
    baselineGameScore: 640,
    scores: {
      tx1: 8.75,
      tx2: 9.0,
      tx3: 9.25,
      tx4: null,
      tx5: null,
      dggk: 9.0,
      dgck: null,
    },
    commendationPoints: 25,
    strengths: 'Chăm chỉ, nắm chắc lý thuyết và vận dụng tốt vào bài tập.',
    privateNote: 'Tuyên dương tinh thần tự học cao.',
    teacherComments: [],
  },
  {
    id: 'hs-15',
    code: 'KHTN7_HS15',
    fullName: 'LÝ TIẾN THIÊN',
    className: 'Lớp 7A1',
    avatarColor: 'bg-cyan-700',
    absorptionLevel: 'Khá',
    baselineWeeksCompleted: [1, 2, 3, 4, 5],
    baselineMcqDone: 128,
    baselineMcqCorrect: 108,
    baselineTfDone: 20,
    baselineEssayDone: 18,
    baselineExamScore: 8.0,
    baselineGameScore: 480,
    scores: {
      tx1: 7.5,
      tx2: 7.75,
      tx3: 8.25,
      tx4: null,
      tx5: null,
      dggk: 8.0,
      dgck: null,
    },
    commendationPoints: 15,
    strengths: 'Yêu thích các chủ đề Vật lí và thí nghiệm trực quan.',
    privateNote: 'Đang có xu hướng tăng điểm tích cực.',
    teacherComments: [],
  },
  {
    id: 'hs-16',
    code: 'KHTN7_HS16',
    fullName: 'MAI ĐĂNG KHOA',
    className: 'Lớp 7A1',
    avatarColor: 'bg-emerald-600',
    absorptionLevel: 'Xuất sắc',
    baselineWeeksCompleted: [1, 2, 3, 4, 5, 6],
    baselineMcqDone: 166,
    baselineMcqCorrect: 152,
    baselineTfDone: 27,
    baselineEssayDone: 25,
    baselineExamScore: 8.8,
    baselineGameScore: 620,
    scores: {
      tx1: 8.25,
      tx2: 8.75,
      tx3: 9.0,
      tx4: null,
      tx5: null,
      dggk: 8.75,
      dgck: null,
    },
    commendationPoints: 20,
    strengths: 'Tư duy logic tốt, giải nhanh các bài tập tính toán.',
    privateNote: 'Học sinh tích cực trong giờ học.',
    teacherComments: [],
  },
  {
    id: 'hs-17',
    code: 'KHTN7_HS17',
    fullName: 'BÙI ANH KIỆT',
    className: 'Lớp 7A1',
    avatarColor: 'bg-blue-600',
    absorptionLevel: 'Khá',
    baselineWeeksCompleted: [1, 2, 3, 4, 5],
    baselineMcqDone: 130,
    baselineMcqCorrect: 110,
    baselineTfDone: 21,
    baselineEssayDone: 19,
    baselineExamScore: 8.1,
    baselineGameScore: 510,
    scores: {
      tx1: 7.5,
      tx2: 8.0,
      tx3: 8.25,
      tx4: null,
      tx5: null,
      dggk: 8.0,
      dgck: null,
    },
    commendationPoints: 15,
    strengths: 'Nắm vững kiến thức cơ bản, tích cực ôn tập.',
    privateNote: 'Cần duy trì thói quen làm bài tập hàng tuần.',
    teacherComments: [],
  },
  {
    id: 'hs-18',
    code: 'KHTN7_HS18',
    fullName: 'THIÊN KIM',
    className: 'Lớp 7A1',
    avatarColor: 'bg-amber-600',
    absorptionLevel: 'Khá',
    baselineWeeksCompleted: [1, 2, 3, 4, 5],
    baselineMcqDone: 140,
    baselineMcqCorrect: 122,
    baselineTfDone: 23,
    baselineEssayDone: 21,
    baselineExamScore: 8.5,
    baselineGameScore: 540,
    scores: {
      tx1: 8.0,
      tx2: 8.25,
      tx3: 8.5,
      tx4: null,
      tx5: null,
      dggk: 8.5,
      dgck: null,
    },
    commendationPoints: 20,
    strengths: 'Chăm chỉ hoàn thành bài tập về nhà và ghi nhớ lý thuyết tốt.',
    privateNote: 'Học tập đều các phân môn.',
    teacherComments: [],
  },
  {
    id: 'hs-19',
    code: 'KHTN7_HS19',
    fullName: 'PHƯƠNG LINH',
    className: 'Lớp 7A1',
    avatarColor: 'bg-teal-600',
    absorptionLevel: 'Xuất sắc',
    baselineWeeksCompleted: [1, 2, 3, 4, 5, 6],
    baselineMcqDone: 176,
    baselineMcqCorrect: 164,
    baselineTfDone: 29,
    baselineEssayDone: 28,
    baselineExamScore: 9.4,
    baselineGameScore: 690,
    scores: {
      tx1: 8.75,
      tx2: 9.25,
      tx3: 9.5,
      tx4: 9.5,
      tx5: null,
      dggk: 9.25,
      dgck: null,
    },
    commendationPoints: 30,
    strengths: 'Giỏi toàn diện cả 3 phân môn Hóa – Lí – Sinh.',
    privateNote: 'Luôn hoàn thành BTVN sớm và đạt điểm cao.',
    teacherComments: [],
  },
];

// Unicode NFC + whitespace normalization for Vietnamese student names (strips invisible Zalo/Word chars)
export function normalizeStudentNameNFC(str: string): string {
  return (str || '')
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .replace(/\u00A0/g, ' ')
    .normalize('NFC')
    .trim()
    .replace(/\s+/g, ' ')
    .toLowerCase();
}

// Strip Vietnamese accents for resilient lookup when parents/students type without diacritics
export function removeVietnameseDiacritics(str: string): string {
  return normalizeStudentNameNFC(str)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'd')
    .trim();
}

// Resilient student matcher for Student Portal & Parent Portal
export function findStudentByNameOrCode(
  roster: StudentProfile[],
  rawInput: string
): StudentProfile | undefined {
  const queryNFC = normalizeStudentNameNFC(rawInput);
  if (!queryNFC) return undefined;

  // 1. Exact NFC fullName or code match
  const exactMatch = roster.find(
    (s) =>
      normalizeStudentNameNFC(s.fullName) === queryNFC ||
      normalizeStudentNameNFC(s.code) === queryNFC
  );
  if (exactMatch) return exactMatch;

  // 2. Exact diacritic-free fullName match (e.g., "VO THI THANH HA" -> "VÕ THỊ THANH HÀ")
  const queryNoAccent = removeVietnameseDiacritics(rawInput);
  const noAccentMatch = roster.find(
    (s) => removeVietnameseDiacritics(s.fullName) === queryNoAccent
  );
  if (noAccentMatch) return noAccentMatch;

  // 3. Match by trailing given name if parent/student enters at least 2 words (e.g., "THANH HÀ", "BẢO CHÂU", "THIÊN KIM", "PHƯƠNG LINH")
  const queryWords = queryNFC.split(' ').filter(Boolean);
  if (queryWords.length >= 2) {
    const suffixMatches = roster.filter((s) => {
      const fullNFC = normalizeStudentNameNFC(s.fullName);
      const fullNoAccent = removeVietnameseDiacritics(s.fullName);
      return (
        fullNFC.endsWith(' ' + queryNFC) ||
        fullNFC === queryNFC ||
        fullNoAccent.endsWith(' ' + queryNoAccent)
      );
    });
    if (suffixMatches.length === 1) {
      return suffixMatches[0];
    }
  }

  return undefined;
}

// Privacy-safe partial suggestion helper for mobile/Zalo WebViews where <datalist> is hidden
export function suggestStudentsByPartialName(
  roster: StudentProfile[],
  rawInput: string,
  limit = 5
): StudentProfile[] {
  const queryNFC = normalizeStudentNameNFC(rawInput);
  const queryNoAccent = removeVietnameseDiacritics(rawInput);
  if (queryNoAccent.length < 3) return [];

  return roster
    .filter((s) => {
      const fullNFC = normalizeStudentNameNFC(s.fullName);
      const fullNoAccent = removeVietnameseDiacritics(s.fullName);
      return (
        fullNFC.includes(queryNFC) ||
        fullNoAccent.includes(queryNoAccent) ||
        normalizeStudentNameNFC(s.code) === queryNFC
      );
    })
    .slice(0, limit);
}


export const WEEKLY_ASSIGNMENTS: WeeklyAssignment[] = [
  // ==================== HỌC KÌ I (TUẦN 1 – TUẦN 18) ====================
  {
    weekNumber: 1,
    semesterLabel: 'HK1',
    title: 'Tuần 1: Bài 2 – Nguyên tử (Khối lượng & Cấu tạo nguyên tử)',
    subjectLabel: 'Hóa học 7 (Chương I)',
    lessonIds: ['kntt-bai-2'],
    dueDate: 'Thứ Sáu Tuần 1',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 6,
  },
  {
    weekNumber: 2,
    semesterLabel: 'HK1',
    title: 'Tuần 2: Bài 3 – Nguyên tố hóa học & Kí hiệu hóa học',
    subjectLabel: 'Hóa học 7 (Chương I)',
    lessonIds: ['kntt-bai-3'],
    dueDate: 'Thứ Sáu Tuần 2',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 6,
  },
  {
    weekNumber: 3,
    semesterLabel: 'HK1',
    title: 'Tuần 3: Bài 4 – Sơ lược về bảng tuần hoàn các nguyên tố hóa học (Phần 1)',
    subjectLabel: 'Hóa học 7 (Chương I)',
    lessonIds: ['kntt-bai-4'],
    dueDate: 'Thứ Sáu Tuần 3',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 6,
  },
  {
    weekNumber: 4,
    semesterLabel: 'HK1',
    title: 'Tuần 4: Bài 4 – Bảng tuần hoàn (Phần 2) & Ôn tập Chương I',
    subjectLabel: 'Hóa học 7 (Chương I)',
    lessonIds: ['kntt-bai-3', 'kntt-bai-4'],
    dueDate: 'Thứ Sáu Tuần 4',
    targetMcq: 60,
    targetTf: 10,
    targetEssay: 12,
  },
  {
    weekNumber: 5,
    semesterLabel: 'HK1',
    title: 'Tuần 5: Bài 5 – Phân tử, Đơn chất, Hợp chất',
    subjectLabel: 'Hóa học 7 (Chương II)',
    lessonIds: ['kntt-bai-5'],
    dueDate: 'Thứ Sáu Tuần 5',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 6,
  },
  {
    weekNumber: 6,
    semesterLabel: 'HK1',
    title: 'Tuần 6: Bài 6 – Giới thiệu về liên kết hóa học (Ion & Cộng hóa trị)',
    subjectLabel: 'Hóa học 7 (Chương II)',
    lessonIds: ['kntt-bai-6'],
    dueDate: 'Thứ Sáu Tuần 6',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 6,
  },
  {
    weekNumber: 7,
    semesterLabel: 'HK1',
    title: 'Tuần 7: Bài 7 – Hóa trị và Công thức hóa học',
    subjectLabel: 'Hóa học 7 (Chương II)',
    lessonIds: ['kntt-bai-7'],
    dueDate: 'Thứ Sáu Tuần 7',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 7,
  },
  {
    weekNumber: 8,
    semesterLabel: 'HK1',
    title: 'Tuần 8: Ôn tập Giữa Học kì I (Tổng hợp Chương I & Chương II)',
    subjectLabel: 'Hóa học 7 (Ôn tập Giữa kì I)',
    lessonIds: ['kntt-bai-2', 'kntt-bai-5', 'kntt-bai-7'],
    dueDate: 'Thứ Sáu Tuần 8',
    targetMcq: 90,
    targetTf: 15,
    targetEssay: 18,
  },
  {
    weekNumber: 9,
    semesterLabel: 'HK1',
    title: 'Tuần 9: Bài 8 – Tốc độ chuyển động',
    subjectLabel: 'Vật lí 7 (Chương III)',
    lessonIds: ['kntt-bai-8'],
    dueDate: 'Thứ Sáu Tuần 9',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 7,
  },
  {
    weekNumber: 10,
    semesterLabel: 'HK1',
    title: 'Tuần 10: Bài 9 – Đo tốc độ (Đồng hồ bấm giây & Cổng quang điện)',
    subjectLabel: 'Vật lí 7 (Chương III)',
    lessonIds: ['kntt-bai-9'],
    dueDate: 'Thứ Sáu Tuần 10',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 6,
  },
  {
    weekNumber: 11,
    semesterLabel: 'HK1',
    title: 'Tuần 11: Bài 10 – Đồ thị quãng đường – thời gian',
    subjectLabel: 'Vật lí 7 (Chương III)',
    lessonIds: ['kntt-bai-10'],
    dueDate: 'Thứ Sáu Tuần 11',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 6,
  },
  {
    weekNumber: 12,
    semesterLabel: 'HK1',
    title: 'Tuần 12: Bài 11 – Thảo luận về ảnh hưởng của tốc độ trong an toàn giao thông',
    subjectLabel: 'Vật lí 7 (Chương III)',
    lessonIds: ['kntt-bai-11'],
    dueDate: 'Thứ Sáu Tuần 12',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 5,
  },
  {
    weekNumber: 13,
    semesterLabel: 'HK1',
    title: 'Tuần 13: Bài 12 – Sóng âm (Nguồn âm & Môi trường truyền âm)',
    subjectLabel: 'Vật lí 7 (Chương IV)',
    lessonIds: ['kntt-bai-12'],
    dueDate: 'Thứ Sáu Tuần 13',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 6,
  },
  {
    weekNumber: 14,
    semesterLabel: 'HK1',
    title: 'Tuần 14: Bài 13 – Độ to và độ cao của âm (Tần số Hz & Biên độ)',
    subjectLabel: 'Vật lí 7 (Chương IV)',
    lessonIds: ['kntt-bai-13'],
    dueDate: 'Thứ Sáu Tuần 14',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 5,
  },
  {
    weekNumber: 15,
    semesterLabel: 'HK1',
    title: 'Tuần 15: Bài 14 – Phản xạ âm, Tiếng vang & Chống ô nhiễm tiếng ồn',
    subjectLabel: 'Vật lí 7 (Chương IV)',
    lessonIds: ['kntt-bai-14'],
    dueDate: 'Thứ Sáu Tuần 15',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 5,
  },
  {
    weekNumber: 16,
    semesterLabel: 'HK1',
    title: 'Tuần 16: Bài 15 – Năng lượng ánh sáng, Tia sáng và vùng tối',
    subjectLabel: 'Vật lí 7 (Chương V)',
    lessonIds: ['kntt-bai-15'],
    dueDate: 'Thứ Sáu Tuần 16',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 6,
  },
  {
    weekNumber: 17,
    semesterLabel: 'HK1',
    title: 'Tuần 17: Bài 16 – Sự phản xạ ánh sáng (Định luật phản xạ ánh sáng)',
    subjectLabel: 'Vật lí 7 (Chương V)',
    lessonIds: ['kntt-bai-16'],
    dueDate: 'Thứ Sáu Tuần 17',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 6,
  },
  {
    weekNumber: 18,
    semesterLabel: 'HK1',
    title: 'Tuần 18: Ôn tập & Kiểm tra Cuối Học kì I (Hóa học & Vật lí)',
    subjectLabel: 'Tổng hợp Cuối Học kì I',
    lessonIds: ['kntt-bai-7', 'kntt-bai-8', 'kntt-bai-13', 'kntt-bai-16'],
    dueDate: 'Thứ Sáu Tuần 18',
    targetMcq: 120,
    targetTf: 20,
    targetEssay: 24,
  },

  // ==================== HỌC KÌ II (TUẦN 19 – TUẦN 35) ====================
  {
    weekNumber: 19,
    semesterLabel: 'HK2',
    title: 'Tuần 19: Bài 17 – Ảnh của vật tạo bởi gương phẳng',
    subjectLabel: 'Vật lí 7 (Chương V)',
    lessonIds: ['kntt-bai-17'],
    dueDate: 'Thứ Sáu Tuần 19',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 6,
  },
  {
    weekNumber: 20,
    semesterLabel: 'HK2',
    title: 'Tuần 20: Bài 18 – Nam châm (Từ cực & Tương tác giữa hai nam châm)',
    subjectLabel: 'Vật lí 7 (Chương VI)',
    lessonIds: ['kntt-bai-18'],
    dueDate: 'Thứ Sáu Tuần 20',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 5,
  },
  {
    weekNumber: 21,
    semesterLabel: 'HK2',
    title: 'Tuần 21: Bài 19 – Từ trường (Từ phổ & Đường sức từ)',
    subjectLabel: 'Vật lí 7 (Chương VI)',
    lessonIds: ['kntt-bai-19'],
    dueDate: 'Thứ Sáu Tuần 21',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 5,
  },
  {
    weekNumber: 22,
    semesterLabel: 'HK2',
    title: 'Tuần 22: Bài 20 – Từ trường Trái Đất và Sử dụng la bàn',
    subjectLabel: 'Vật lí 7 (Chương VI)',
    lessonIds: ['kntt-bai-20'],
    dueDate: 'Thứ Sáu Tuần 22',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 5,
  },
  {
    weekNumber: 23,
    semesterLabel: 'HK2',
    title: 'Tuần 23: Bài 21 – Nam châm điện và Ứng dụng trong đời sống',
    subjectLabel: 'Vật lí 7 (Chương VI)',
    lessonIds: ['kntt-bai-21'],
    dueDate: 'Thứ Sáu Tuần 23',
    targetMcq: 30,
    targetTf: 5,
    targetEssay: 5,
  },
  {
    weekNumber: 24,
    semesterLabel: 'HK2',
    title: 'Tuần 24: Bài 22 – Vai trò của trao đổi chất và chuyển hóa năng lượng ở sinh vật',
    subjectLabel: 'Sinh học 7 (Chương VII)',
    lessonIds: ['kntt-bai-22'],
    dueDate: 'Thứ Sáu Tuần 24',
    targetMcq: 16,
    targetTf: 5,
    targetEssay: 4,
  },
  {
    weekNumber: 25,
    semesterLabel: 'HK2',
    title: 'Tuần 25: Bài 23 – Quang hợp ở thực vật & Các yếu tố ảnh hưởng',
    subjectLabel: 'Sinh học 7 (Chương VII)',
    lessonIds: ['kntt-bai-23'],
    dueDate: 'Thứ Sáu Tuần 25',
    targetMcq: 18,
    targetTf: 5,
    targetEssay: 5,
  },
  {
    weekNumber: 26,
    semesterLabel: 'HK2',
    title: 'Tuần 26: Bài 25 – Hô hấp tế bào & Ôn tập Giữa Học kì II',
    subjectLabel: 'Sinh học 7 (Chương VII)',
    lessonIds: ['kntt-bai-25'],
    dueDate: 'Thứ Sáu Tuần 26',
    targetMcq: 18,
    targetTf: 5,
    targetEssay: 5,
  },
  {
    weekNumber: 27,
    semesterLabel: 'HK2',
    title: 'Tuần 27: Bài 27 – Trao đổi khí ở sinh vật (Khí khổng & Hệ hô hấp)',
    subjectLabel: 'Sinh học 7 (Chương VII)',
    lessonIds: ['kntt-bai-27'],
    dueDate: 'Thứ Sáu Tuần 27',
    targetMcq: 16,
    targetTf: 5,
    targetEssay: 4,
  },
  {
    weekNumber: 28,
    semesterLabel: 'HK2',
    title: 'Tuần 28: Bài 28 – Vai trò của nước và các chất dinh dưỡng đối với sinh vật',
    subjectLabel: 'Sinh học 7 (Chương VII)',
    lessonIds: ['kntt-bai-28'],
    dueDate: 'Thứ Sáu Tuần 28',
    targetMcq: 18,
    targetTf: 5,
    targetEssay: 4,
  },
  {
    weekNumber: 29,
    semesterLabel: 'HK2',
    title: 'Tuần 29: Bài 29 – Trao đổi nước và các chất dinh dưỡng ở thực vật (Mạch gỗ & Mạch rây)',
    subjectLabel: 'Sinh học 7 (Chương VII)',
    lessonIds: ['kntt-bai-29'],
    dueDate: 'Thứ Sáu Tuần 29',
    targetMcq: 18,
    targetTf: 5,
    targetEssay: 4,
  },
  {
    weekNumber: 30,
    semesterLabel: 'HK2',
    title: 'Tuần 30: Bài 30 – Trao đổi nước và các chất dinh dưỡng ở động vật',
    subjectLabel: 'Sinh học 7 (Chương VII)',
    lessonIds: ['kntt-bai-30'],
    dueDate: 'Thứ Sáu Tuần 30',
    targetMcq: 18,
    targetTf: 5,
    targetEssay: 5,
  },
  {
    weekNumber: 31,
    semesterLabel: 'HK2',
    title: 'Tuần 31: Bài 32 & 33 – Cảm ứng ở sinh vật và Tập tính ở động vật',
    subjectLabel: 'Sinh học 7 (Chương VIII)',
    lessonIds: ['kntt-bai-32'],
    dueDate: 'Thứ Sáu Tuần 31',
    targetMcq: 18,
    targetTf: 5,
    targetEssay: 4,
  },
  {
    weekNumber: 32,
    semesterLabel: 'HK2',
    title: 'Tuần 32: Bài 34 & 35 – Sinh trưởng và phát triển ở sinh vật',
    subjectLabel: 'Sinh học 7 (Chương IX)',
    lessonIds: ['kntt-bai-34'],
    dueDate: 'Thứ Sáu Tuần 32',
    targetMcq: 18,
    targetTf: 5,
    targetEssay: 4,
  },
  {
    weekNumber: 33,
    semesterLabel: 'HK2',
    title: 'Tuần 33: Bài 37 & 38 – Sinh sản ở sinh vật (Vô tính & Hữu tính)',
    subjectLabel: 'Sinh học 7 (Chương X)',
    lessonIds: ['kntt-bai-37'],
    dueDate: 'Thứ Sáu Tuần 33',
    targetMcq: 16,
    targetTf: 5,
    targetEssay: 4,
  },
  {
    weekNumber: 34,
    semesterLabel: 'HK2',
    title: 'Tuần 34: Ôn tập tổng hợp Học kì II (Từ trường & Toàn bộ Sinh học 7)',
    subjectLabel: 'Ôn tập Cuối Học kì II',
    lessonIds: ['kntt-bai-19', 'kntt-bai-23', 'kntt-bai-29', 'kntt-bai-30'],
    dueDate: 'Thứ Sáu Tuần 34',
    targetMcq: 84,
    targetTf: 20,
    targetEssay: 18,
  },
  {
    weekNumber: 35,
    semesterLabel: 'HK2',
    title: 'Tuần 35: Kiểm tra Đánh giá Cuối năm KHTN 7 – Sách Kết nối tri thức',
    subjectLabel: 'Tổng kết Năm học KHTN 7',
    lessonIds: ['kntt-bai-7', 'kntt-bai-8', 'kntt-bai-23', 'kntt-bai-37'],
    dueDate: 'Thứ Sáu Tuần 35',
    targetMcq: 94,
    targetTf: 20,
    targetEssay: 21,
  },
];

const WEEKLY_ASSIGNMENTS_KEY = 'khtn7_weekly_assignments_v3';

export function loadWeeklyAssignments(): WeeklyAssignment[] {
  try {
    const raw = localStorage.getItem(WEEKLY_ASSIGNMENTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {
    // ignore
  }
  return WEEKLY_ASSIGNMENTS;
}

export function saveWeeklyAssignments(assignments: WeeklyAssignment[]): void {
  try {
    localStorage.setItem(WEEKLY_ASSIGNMENTS_KEY, JSON.stringify(assignments));
  } catch {
    // ignore
  }
}

export function getDefaultScoresForStudent(student: StudentProfile): StudentAssessmentScores {
  if (student.scores) return student.scores;
  const base = student.baselineExamScore ?? 7.5;
  return {
    tx1: Number(Math.max(3.5, Math.min(10, base - 0.5)).toFixed(2)),
    tx2: Number(Math.max(3.5, Math.min(10, base)).toFixed(2)),
    tx3: Number(Math.max(3.5, Math.min(10, base + 0.25)).toFixed(2)),
    tx4: null,
    tx5: null,
    dggk: student.baselineExamScore ? Number(student.baselineExamScore.toFixed(2)) : null,
    dgck: null,
  };
}

export interface StudentGradeMetrics {
  scores: StudentAssessmentScores;
  average: number;
  highest: number;
  lowest: number;
  filledCount: number;
  totalColumns: number;
  rankLabel: 'Giỏi' | 'Khá' | 'Đạt' | 'Yếu';
  trend: 'up' | 'down' | 'stable';
  trendLabel: '↑ Tiến bộ' | '↓ Giảm sút' | '→ Ổn định';
  needsWarning: boolean;
  chartPoints: { key: string; label: string; coeff: number; value: number | null }[];
}

export function calculateStudentGradeMetrics(student: StudentProfile): StudentGradeMetrics {
  const sc = getDefaultScoresForStudent(student);
  const chartPoints = [
    { key: 'tx1', label: 'TX1', coeff: 1, value: sc.tx1 },
    { key: 'tx2', label: 'TX2', coeff: 1, value: sc.tx2 },
    { key: 'tx3', label: 'TX3', coeff: 1, value: sc.tx3 },
    { key: 'tx4', label: 'TX4', coeff: 1, value: sc.tx4 },
    { key: 'tx5', label: 'TX5', coeff: 1, value: sc.tx5 },
    { key: 'dggk', label: 'ĐGGK', coeff: 2, value: sc.dggk },
    { key: 'dgck', label: 'ĐGCK', coeff: 3, value: sc.dgck },
  ];

  const validItems = chartPoints.filter((p) => p.value !== null) as {
    key: string;
    label: string;
    coeff: number;
    value: number;
  }[];

  let weightedSum = 0;
  let totalWeight = 0;
  let highest = 0;
  let lowest = 10;

  for (const item of validItems) {
    weightedSum += item.value * item.coeff;
    totalWeight += item.coeff;
    if (item.value > highest) highest = item.value;
    if (item.value < lowest) lowest = item.value;
  }

  const average = totalWeight > 0 ? Number((weightedSum / totalWeight).toFixed(2)) : 0;
  if (validItems.length === 0) {
    lowest = 0;
  }

  let rankLabel: 'Giỏi' | 'Khá' | 'Đạt' | 'Yếu' = 'Đạt';
  if (average >= 8.0) rankLabel = 'Giỏi';
  else if (average >= 6.5) rankLabel = 'Khá';
  else if (average >= 5.0) rankLabel = 'Đạt';
  else rankLabel = 'Yếu';

  let trend: 'up' | 'down' | 'stable' = 'stable';
  if (validItems.length >= 2) {
    const first = validItems[0].value;
    const last = validItems[validItems.length - 1].value;
    if (last - first >= 0.35) trend = 'up';
    else if (first - last >= 0.35) trend = 'down';
  }

  const trendLabel =
    trend === 'up' ? '↑ Tiến bộ' : trend === 'down' ? '↓ Giảm sút' : '→ Ổn định';

  const needsWarning = average < 5.0 || (validItems.length > 0 && lowest <= 4.0);

  return {
    scores: sc,
    average,
    highest,
    lowest,
    filledCount: validItems.length,
    totalColumns: 7,
    rankLabel,
    trend,
    trendLabel,
    needsWarning,
    chartPoints,
  };
}

// ==================== SAVED WORD EXAMS & DOCUMENTS STORE ====================
export interface ParsedWordMcq {
  id: string;
  question: string;
  options: [string, string, string, string];
  correctIndex: number;
}

export interface SavedWordExamDoc {
  id: string;
  title: string;
  fileName: string;
  docType: 'exam' | 'worksheet' | 'material';
  subjectLabel: 'Liên môn KHTN 7' | 'Hóa học 7' | 'Vật lí 7' | 'Sinh học 7';
  weekNumber: number;
  createdAt: string;
  htmlPreview: string;
  rawText: string;
  fileDataUrl?: string;
  parsedMcqs?: ParsedWordMcq[];
}

const SAVED_WORD_DOCS_KEY = 'khtn7_saved_word_docs_v2';

export const DEFAULT_SAVED_WORD_DOCS: SavedWordExamDoc[] = [
  {
    id: 'word-doc-default-1',
    title: 'Đề Kiểm Tra Giữa Học Kì I – KHTN 7 KNTT (Có ma trận & đáp án)',
    fileName: 'De_Kiem_Tra_Giua_HK1_KHTN7_KNTT.docx',
    docType: 'exam',
    subjectLabel: 'Liên môn KHTN 7',
    weekNumber: 8,
    createdAt: '25/10/2026 08:30',
    htmlPreview: `
      <h3>ĐỀ KIỂM TRA ĐÁNH GIÁ GIỮA HỌC KÌ I — MÔN KHOA HỌC TỰ NHIÊN 7 (SÁCH KNTT)</h3>
      <p><strong>Thời gian làm bài:</strong> 60 phút · <strong>Cấu trúc:</strong> Trắc nghiệm 4 lựa chọn + Đúng/Sai + Tự luận</p>
      <hr/>
      <p><strong>Câu 1:</strong> Hạt nhân nguyên tử được cấu tạo bởi những loại hạt nào?</p>
      <p>A. Proton và electron &nbsp;&nbsp; B. Proton và neutron &nbsp;&nbsp; C. Neutron và electron &nbsp;&nbsp; D. Chỉ có proton</p>
      <p><strong>Câu 2:</strong> Đơn vị đo tốc độ hợp pháp trong hệ đo lường chính thức của nước ta là:</p>
      <p>A. m/s và km/h &nbsp;&nbsp; B. km và giờ &nbsp;&nbsp; C. m/phút &nbsp;&nbsp; D. cm/giây</p>
      <p><strong>Câu 3 (Tự luận):</strong> Một ô tô đi quãng đường 90 km trong 1,5 giờ. Tính tốc độ của ô tô theo đơn vị km/h và m/s.</p>
    `,
    rawText:
      'ĐỀ KIỂM TRA ĐÁNH GIÁ GIỮA HỌC KÌ I — MÔN KHOA HỌC TỰ NHIÊN 7 (SÁCH KNTT)\nCâu 1: Hạt nhân nguyên tử được cấu tạo bởi những loại hạt nào?\nA. Proton và electron\nB. Proton và neutron\nC. Neutron và electron\nD. Chỉ có proton',
    parsedMcqs: [
      {
        id: 'w-mcq-1',
        question: 'Hạt nhân nguyên tử được cấu tạo bởi những loại hạt nào?',
        options: [
          'Proton và electron',
          'Proton và neutron',
          'Neutron và electron',
          'Chỉ có proton',
        ],
        correctIndex: 1,
      },
      {
        id: 'w-mcq-2',
        question: 'Đơn vị đo tốc độ hợp pháp trong hệ đo lường chính thức của nước ta là:',
        options: ['m/s và km/h', 'km và giờ', 'm/phút', 'cm/giây'],
        correctIndex: 0,
      },
    ],
  },
];

export function loadSavedWordDocs(): SavedWordExamDoc[] {
  try {
    const raw = localStorage.getItem(SAVED_WORD_DOCS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {
    // ignore
  }
  return DEFAULT_SAVED_WORD_DOCS;
}

export function saveWordDocsToStorage(docs: SavedWordExamDoc[]): void {
  try {
    localStorage.setItem(SAVED_WORD_DOCS_KEY, JSON.stringify(docs));
  } catch {
    // ignore
  }
}

