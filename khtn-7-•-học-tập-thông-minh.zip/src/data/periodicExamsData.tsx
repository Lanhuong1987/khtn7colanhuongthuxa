import { QuizQuestion, SubSubject } from './khtn7Data';

export interface ExamPaperDefinition {
  id: string;
  code: 'gk1' | 'hk1' | 'gk2' | 'hk2' | string;
  title: string;
  shortLabel: string;
  durationMinutes: number;
  isCustomTeacherExam?: boolean;
  createdAt?: string;
  rawHtmlPreview?: string;
  scopeSummary: {
    physics: string;
    chemistry: string;
    biology: string;
  };
  questions: QuizQuestion[];
}

export const DEFAULT_PERIODIC_EXAMS: ExamPaperDefinition[] = [
  // ============================================================================
  // 1. ĐỀ KIỂM TRA GIỮA HỌC KÌ 1
  // Phạm vi: Vật lí Bài 8–11 | Hóa học Bài 1–2 | Sinh học Bài 21–27 (KHTN 7 KNTT)
  // ============================================================================
  {
    id: 'exam-gk1-kntt',
    code: 'gk1',
    title: 'Đề Kiểm Tra Giữa Học Kì 1 – KHTN 7 (Kết nối tri thức)',
    shortLabel: 'Đề Giữa Kì 1',
    durationMinutes: 45,
    scopeSummary: {
      physics: 'Vật lí: Bài 8 – Bài 11 (Tốc độ chuyển động, Đo tốc độ, Đồ thị s–t, An toàn giao thông)',
      chemistry: 'Hóa học: Bài 1 – Bài 2 (Phương pháp & kĩ năng học KHTN, Nguyên tử)',
      biology: 'Sinh học: Bài 21 – Bài 27 (Khái quát trao đổi chất, Quang hợp, Hô hấp tế bào, Trao đổi khí)',
    },
    questions: [
      // --- HÓA HỌC: BÀI 1 - BÀI 2 (6 CÂU) ---
      {
        id: 'gk1-chem-1',
        subject: 'chemistry',
        topic: 'Bài 1: Phương pháp và kĩ năng học tập môn KHTN',
        level: 'Nhận biết',
        question:
          'Bước đầu tiên trong phương pháp tìm hiểu tự nhiên của môn Khoa học tự nhiên 7 là gì?',
        options: [
          'Hình thành giả thuyết khoa học',
          'Quan sát và đặt câu hỏi nghiên cứu',
          'Lập kế hoạch kiểm tra giả thuyết',
          'Viết báo cáo và thuyết trình kết quả',
        ],
        correctIndex: 1,
        explanation:
          'Quy trình tìm hiểu tự nhiên bắt đầu bằng Bước 1: Quan sát hiện tượng tự nhiên và đặt câu hỏi nghiên cứu.',
        formulaHint: 'Bài 1 KNTT: Quan sát & đặt câu hỏi → Giả thuyết → Lập kế hoạch → Thực hiện → Kết luận',
      },
      {
        id: 'gk1-chem-2',
        subject: 'chemistry',
        topic: 'Bài 1: Phương pháp và kĩ năng học tập môn KHTN',
        level: 'Thông hiểu',
        question:
          'Dụng cụ dùng để đo khối lượng hoặc thể tích chất lỏng với độ chính xác cao và tự động hiện số liệu trong phòng thí nghiệm hiện đại được gọi là:',
        options: [
          'Ống nghiệm thủy tinh và phễu lọc',
          'Dao động kí điện tử',
          'Cảm biến (sensor) kết nối bộ thu thập dữ liệu',
          'Đèn cồn và kiềng đun',
        ],
        correctIndex: 2,
        explanation:
          'Trong Bài 1 SGK KHTN 7 KNTT, cảm biến (nhiệt độ, pH, quang học, cổng quang điện...) giúp đo tự động và chính xác các đại lượng.',
        formulaHint: 'Bài 1 KNTT: Kĩ năng đo và sử dụng thiết bị cảm biến',
      },
      {
        id: 'gk1-chem-3',
        subject: 'chemistry',
        topic: 'Bài 2: Nguyên tử',
        level: 'Nhận biết',
        question:
          'Theo mô hình nguyên tử Rutherford – Bohr (Bài 2), hạt nhân nguyên tử được cấu tạo bởi những loại hạt nào?',
        options: [
          'Proton (p) và electron (e)',
          'Proton (p) và neutron (n)',
          'Neutron (n) và electron (e)',
          'Chỉ gồm các hạt electron (e)',
        ],
        correctIndex: 1,
        explanation:
          'Hạt nhân nguyên tử nằm ở tâm, mang điện tích dương, gồm các hạt proton (mang điện +1) và neutron (không mang điện).',
        formulaHint: 'Bài 2 KNTT: Hạt nhân = Proton (+1) + Neutron (0)',
      },
      {
        id: 'gk1-chem-4',
        subject: 'chemistry',
        topic: 'Bài 2: Nguyên tử',
        level: 'Thông hiểu',
        question:
          'Vì sao nguyên tử luôn trung hòa về điện ở trạng thái bình thường?',
        options: [
          'Vì trong nguyên tử số hạt proton bằng số hạt neutron',
          'Vì trong nguyên tử số hạt proton mang điện dương bằng số hạt electron mang điện âm',
          'Vì hạt neutron nằm ở vỏ nguyên tử che chắn điện tích',
          'Vì khối lượng của electron rất nhỏ so với proton',
        ],
        correctIndex: 1,
        explanation:
          'Mỗi proton mang điện tích +1, mỗi electron mang điện tích -1. Trong nguyên tử, số p = số e nên tổng điện tích bằng 0.',
        formulaHint: 'Bài 2 KNTT: Số proton (p) = Số electron (e)',
      },
      {
        id: 'gk1-chem-5',
        subject: 'chemistry',
        topic: 'Bài 2: Nguyên tử',
        level: 'Vận dụng',
        question:
          'Nguyên tử Aluminium (nhôm) có điện tích hạt nhân là +13 và số hạt neutron trong hạt nhân là 14. Khối lượng nguyên tử Aluminium tính theo đơn vị amu là bao nhiêu?',
        options: ['13 amu', '14 amu', '26 amu', '27 amu'],
        correctIndex: 3,
        explanation:
          'Khối lượng nguyên tử (amu) xấp xỉ bằng tổng số hạt proton và số hạt neutron: A = p + n = 13 + 14 = 27 amu.',
        formulaHint: 'Bài 2 KNTT: Khối lượng nguyên tử ≈ p + n (amu)',
      },
      {
        id: 'gk1-chem-6',
        subject: 'chemistry',
        topic: 'Bài 2: Nguyên tử',
        level: 'Vận dụng',
        question:
          'Một nguyên tử Oxygen có 8 proton trong hạt nhân. Hỏi các electron của nguyên tử Oxygen được phân bố vào mấy lớp electron và lớp ngoài cùng có bao nhiêu electron?',
        options: [
          '1 lớp electron, có 8 electron lớp ngoài cùng',
          '2 lớp electron, lớp ngoài cùng có 6 electron',
          '2 lớp electron, lớp ngoài cùng có 4 electron',
          '3 lớp electron, lớp ngoài cùng có 2 electron',
        ],
        correctIndex: 1,
        explanation:
          'Nguyên tử có 8e: lớp thứ nhất (trong cùng) chứa tối đa 2e, còn lại 6e xếp vào lớp thứ hai (lớp ngoài cùng).',
        formulaHint: 'Bài 2 KNTT: Lớp 1 tối đa 2e; Lớp 2 tối đa 8e',
      },

      // --- VẬT LÍ: BÀI 8 - BÀI 11 (7 CÂU) ---
      {
        id: 'gk1-phys-1',
        subject: 'physics',
        topic: 'Bài 8: Tốc độ chuyển động',
        level: 'Nhận biết',
        question:
          'Công thức tính tốc độ chuyển động của một vật (Bài 8) là gì?',
        options: ['v = s · t', 'v = s / t', 'v = t / s', 's = v / t'],
        correctIndex: 1,
        explanation:
          'Tốc độ chuyển động bằng thương số giữa quãng đường đi được (s) và thời gian đi hết quãng đường đó (t): v = s / t.',
        formulaHint: 'Bài 8 KNTT: v = s / t',
      },
      {
        id: 'gk1-phys-2',
        subject: 'physics',
        topic: 'Bài 8: Tốc độ chuyển động',
        level: 'Thông hiểu',
        question:
          'Một vận động viên chạy cự li 100 m hết 10 s. Tốc độ của vận động viên này khi đổi ra đơn vị km/h là bao nhiêu?',
        options: ['10 km/h', '28 km/h', '36 km/h', '3,6 km/h'],
        correctIndex: 2,
        explanation:
          'Ta có v = s / t = 100 / 10 = 10 m/s. Đổi sang km/h: 10 · 3,6 = 36 km/h.',
        formulaHint: 'Bài 8 KNTT: 1 m/s = 3,6 km/h',
      },
      {
        id: 'gk1-phys-3',
        subject: 'physics',
        topic: 'Bài 9: Đo tốc độ',
        level: 'Nhận biết',
        question:
          'Trong phòng thí nghiệm KHTN 7 (Bài 9), để đo thời gian chuyển động của một vật nhỏ đi từ cổng quang điện A đến cổng quang điện B, ta kết nối hai cổng quang điện với thiết bị nào?',
        options: [
          'Đồng hồ bấm giây cơ học',
          'Đồng hồ đo thời gian hiện số',
          'Nhiệt kế điện tử',
          'Lực kế lò xo',
        ],
        correctIndex: 1,
        explanation:
          'Hai cổng quang điện kết nối với đồng hồ đo thời gian hiện số (chế độ A ↔ B) để đo chính xác thời gian vật đi từ A đến B.',
        formulaHint: 'Bài 9 KNTT: Cổng quang điện + Đồng hồ đo thời gian hiện số',
      },
      {
        id: 'gk1-phys-4',
        subject: 'physics',
        topic: 'Bài 9: Đo tốc độ',
        level: 'Nhận biết',
        question:
          'Thiết bị của cảnh sát giao thông sử dụng để kiểm tra tốc độ của các phương tiện đang lưu thông trên đường được gọi là:',
        options: [
          'Tốc kế gắn trên xe máy',
          'Thiết bị bắn tốc độ (súng bắn tốc độ)',
          'Cổng quang điện thí nghiệm',
          'Thước cuộn đo quãng đường',
        ],
        correctIndex: 1,
        explanation:
          'Cảnh sát giao thông dùng thiết bị bắn tốc độ phát sóng điện từ/laser tới xe để tính tốc độ tức thời của phương tiện.',
        formulaHint: 'Bài 9 KNTT: Thiết bị bắn tốc độ trong giao thông',
      },
      {
        id: 'gk1-phys-5',
        subject: 'physics',
        topic: 'Bài 10: Đồ thị quãng đường – thời gian',
        level: 'Thông hiểu',
        question:
          'Trên đồ thị quãng đường – thời gian (s – t) của một vật chuyển động (Bài 10), nếu đường biểu diễn là một đoạn thẳng nằm ngang song song với trục thời gian Ot thì vật đang ở trạng thái nào?',
        options: [
          'Vật đang chuyển động thẳng với tốc độ không đổi',
          'Vật đang tăng tốc rất nhanh',
          'Vật đang đứng yên (quãng đường không thay đổi theo thời gian)',
          'Vật đang quay trở lại vị trí xuất phát',
        ],
        correctIndex: 2,
        explanation:
          'Đường biểu diễn song song với trục Ot chứng tỏ thời gian t tăng nhưng quãng đường s không đổi → vật đang đứng yên (v = 0).',
        formulaHint: 'Bài 10 KNTT: Đoạn thẳng song song trục Ot → vật đứng yên',
      },
      {
        id: 'gk1-phys-6',
        subject: 'physics',
        topic: 'Bài 10: Đồ thị quãng đường – thời gian',
        level: 'Vận dụng',
        question:
          'Dựa vào đồ thị quãng đường – thời gian của một người đi xe đạp, biết sau 2 giờ kể từ lúc xuất phát người đó đi được quãng đường 30 km với tốc độ không đổi. Sau 3 giờ người đó đi được quãng đường bao nhiêu?',
        options: ['40 km', '45 km', '50 km', '60 km'],
        correctIndex: 1,
        explanation:
          'Tốc độ của người đi xe đạp là v = 30 / 2 = 15 km/h. Sau 3 giờ, quãng đường đi được là s = v · t = 15 · 3 = 45 km.',
        formulaHint: 'Bài 10 KNTT: v = s₁ / t₁ ⇒ s₂ = v · t₂',
      },
      {
        id: 'gk1-phys-7',
        subject: 'physics',
        topic: 'Bài 11: Thảo luận về ảnh hưởng của tốc độ trong an toàn giao thông',
        level: 'Vận dụng',
        question:
          'Theo quy tắc "3 giây" trên đường cao tốc (Bài 11), nếu một ô tô đang chạy với tốc độ 25 m/s (tương đương 90 km/h) thì khoảng cách an toàn tối thiểu với xe chạy ngay phía trước là bao nhiêu?',
        options: ['50 m', '65 m', '75 m', '90 m'],
        correctIndex: 2,
        explanation:
          'Theo quy tắc 3 giây: Khoảng cách an toàn tối thiểu s = v (m/s) × 3 (s) = 25 × 3 = 75 m.',
        formulaHint: 'Bài 11 KNTT: Khoảng cách an toàn tối thiểu d = v (m/s) × 3 (s)',
      },

      // --- SINH HỌC: BÀI 21 - BÀI 27 (7 CÂU) ---
      {
        id: 'gk1-bio-1',
        subject: 'biology',
        topic: 'Bài 21: Khái quát về trao đổi chất và chuyển hóa năng lượng',
        level: 'Nhận biết',
        question:
          'Quá trình cơ thể sinh vật lấy các chất từ môi trường, biến đổi chúng thành các chất cần thiết cho cơ thể và tạo năng lượng, đồng thời thải các chất bã ra môi trường được gọi là gì?',
        options: [
          'Quá trình sinh trưởng và phát triển',
          'Quá trình trao đổi chất và chuyển hóa năng lượng',
          'Quá trình cảm ứng ở sinh vật',
          'Quá trình sinh sản vô tính',
        ],
        correctIndex: 1,
        explanation:
          'Theo Bài 21 SGK KHTN 7 KNTT, trao đổi chất và chuyển hóa năng lượng luôn gắn liền với nhau, là điều kiện tồn tại của sinh vật.',
        formulaHint: 'Bài 21 KNTT: Khái niệm trao đổi chất và chuyển hóa năng lượng',
      },
      {
        id: 'gk1-bio-2',
        subject: 'biology',
        topic: 'Bài 22: Quang hợp ở thực vật',
        level: 'Nhận biết',
        question:
          'Trong quá trình quang hợp ở cây xanh (Bài 22), nguyên liệu đầu vào cây lấy từ môi trường để tổng hợp chất hữu cơ (Glucose) là:',
        options: [
          'Khí Oxygen và chất hữu cơ',
          'Nước (H₂O) và khí Carbon dioxide (CO₂)',
          'Khí Nitrogen và muối khoáng',
          'Khí Oxygen và hơi nước',
        ],
        correctIndex: 1,
        explanation:
          'Phương trình quang hợp: Nước + Carbon dioxide → (Ánh sáng, Diệp lục) → Glucose + Oxygen.',
        formulaHint: 'Bài 22 KNTT: H₂O + CO₂ → Glucose + O₂ (nhờ ánh sáng, diệp lục)',
      },
      {
        id: 'gk1-bio-3',
        subject: 'biology',
        topic: 'Bài 23: Một số yếu tố ảnh hưởng đến quang hợp',
        level: 'Thông hiểu',
        question:
          'Những yếu tố chủ yếu của môi trường ngoài ảnh hưởng trực tiếp đến cường độ quang hợp ở thực vật (Bài 23) bao gồm:',
        options: [
          'Ánh sáng, nước, hàm lượng khí carbon dioxide (CO₂) và nhiệt độ',
          'Độ pH của đất, tiếng ồn và gió',
          'Hàm lượng khí nitrogen và áp suất khí quyển',
          'Chỉ phụ thuộc vào lượng phân bón hóa học',
        ],
        correctIndex: 0,
        explanation:
          'Các yếu tố chính ảnh hưởng tới quang hợp là: ánh sáng, nước, nồng độ khí CO₂ và nhiệt độ môi trường.',
        formulaHint: 'Bài 23 KNTT: Ánh sáng + Nước + CO₂ + Nhiệt độ',
      },
      {
        id: 'gk1-bio-4',
        subject: 'biology',
        topic: 'Bài 24: Thực hành chứng minh quang hợp ở cây xanh',
        level: 'Thông hiểu',
        question:
          'Trong thí nghiệm chứng minh tinh bột được tạo thành trong quang hợp (Bài 24), thuốc thử nào được nhỏ lên lá cây đã tẩy sắc tố để nhận biết sự có mặt của tinh bột ở phần lá không bị bịt băng đen?',
        options: [
          'Dung dịch nước vôi trong',
          'Dung dịch Iodine (cồn iốt)',
          'Dung dịch Xanh methylene',
          'Cồn 90 độ đun sôi',
        ],
        correctIndex: 1,
        explanation:
          'Dung dịch Iodine tác dụng với tinh bột tạo ra màu xanh tím đặc trưng ở phần lá nhận được ánh sáng.',
        formulaHint: 'Bài 24 KNTT: Tinh bột + Dung dịch Iodine → Màu xanh tím',
      },
      {
        id: 'gk1-bio-5',
        subject: 'biology',
        topic: 'Bài 25: Hô hấp tế bào',
        level: 'Nhận biết',
        question:
          'Bào quan nào trong tế bào nhân thực là nơi diễn ra quá trình hô hấp tế bào để phân giải chất hữu cơ giải phóng năng lượng ATP (Bài 25)?',
        options: ['Lục lạp', 'Ti thể', 'Không bào', 'Thành tế bào'],
        correctIndex: 1,
        explanation:
          'Ti thể là "nhà máy năng lượng" của tế bào, nơi diễn ra hô hấp tế bào: Glucose + O₂ → CO₂ + H₂O + Năng lượng (ATP + Nhiệt).',
        formulaHint: 'Bài 25 KNTT: Hô hấp tế bào diễn ra tại Ti thể',
      },
      {
        id: 'gk1-bio-6',
        subject: 'biology',
        topic: 'Bài 26: Thực hành về hô hấp tế bào ở thực vật',
        level: 'Vận dụng',
        question:
          'Trong thí nghiệm về hô hấp ở hạt đang nảy mầm (Bài 26), vì sao khi dẫn khí từ bình chứa hạt nảy mầm sang ống nghiệm đựng nước vôi trong thì nước vôi trong bị vẩn đục?',
        options: [
          'Vì hạt nảy mầm thải ra nhiều khí Oxygen',
          'Vì hạt nảy mầm hô hấp mạnh thải ra khí Carbon dioxide (CO₂) làm đục nước vôi trong',
          'Vì hạt nảy mầm hút hết hơi nước trong bình',
          'Vì hạt nảy mầm thực hiện quang hợp trong bóng tối',
        ],
        correctIndex: 1,
        explanation:
          'Hạt đang nảy mầm hô hấp mạnh, hấp thụ O₂ và thải ra CO₂. Khí CO₂ phản ứng với dung dịch Ca(OH)₂ tạo kết tủa CaCO₃ làm đục nước vôi trong.',
        formulaHint: 'Bài 26 KNTT: Hạt nảy mầm hô hấp thải khí CO₂',
      },
      {
        id: 'gk1-bio-7',
        subject: 'biology',
        topic: 'Bài 27: Trao đổi khí ở sinh vật',
        level: 'Thông hiểu',
        question:
          'Ở thực vật trên cạn, quá trình trao đổi khí (lấy vào CO₂, O₂ và thoát hơi nước) giữa lá cây với môi trường diễn ra chủ yếu qua bộ phận nào (Bài 27)?',
        options: [
          'Lớp biểu bì rễ cây',
          'Khí khổng (chủ yếu ở mặt dưới của lá)',
          'Mạch gỗ trong thân cây',
          'Đỉnh sinh trưởng của chồi ngọn',
        ],
        correctIndex: 1,
        explanation:
          'Ở thực vật, sự trao đổi khí với môi trường xung quanh thực hiện chủ yếu qua các lỗ khí khổng trên bề mặt lá.',
        formulaHint: 'Bài 27 KNTT: Thực vật trao đổi khí qua Khí khổng',
      },
    ],
  },

  // ============================================================================
  // 2. ĐỀ KIỂM TRA CUỐI HỌC KÌ 1
  // Phạm vi: Vật lí Bài 8–14 | Hóa học Bài 1–4 | Sinh học Bài 21–32 (KHTN 7 KNTT)
  // ============================================================================
  {
    id: 'exam-hk1-kntt',
    code: 'hk1',
    title: 'Đề Kiểm Tra Cuối Học Kì 1 – KHTN 7 (Kết nối tri thức)',
    shortLabel: 'Đề Học Kì 1',
    durationMinutes: 60,
    scopeSummary: {
      physics: 'Vật lí: Bài 8 – Bài 14 (Chủ đề Tốc độ Bài 8–11 & Chủ đề Âm thanh Bài 12–14)',
      chemistry: 'Hóa học: Bài 1 – Bài 4 (Mở đầu KHTN, Nguyên tử, Nguyên tố hóa học, Bảng tuần hoàn)',
      biology: 'Sinh học: Bài 21 – Bài 32 (Trao đổi chất, Quang hợp, Hô hấp, Dinh dưỡng TV & ĐV, Cảm ứng ở sinh vật)',
    },
    questions: [
      // --- HÓA HỌC: BÀI 1 - BÀI 4 (8 CÂU) ---
      {
        id: 'hk1-chem-1',
        subject: 'chemistry',
        topic: 'Bài 1: Phương pháp và kĩ năng học tập môn KHTN',
        level: 'Nhận biết',
        question:
          'Kĩ năng nào sau đây giúp dự đoán điều gì sẽ xảy ra dựa trên các quy luật, số liệu hoặc quan sát đã có trước đó (Bài 1)?',
        options: [
          'Kĩ năng phân loại',
          'Kĩ năng dự báo',
          'Kĩ năng liên kết',
          'Kĩ năng đo đạc',
        ],
        correctIndex: 1,
        explanation:
          'Kĩ năng dự báo là kĩ năng đề xuất điều sẽ xảy ra dựa trên các quan sát, tri thức và quy luật đã biết.',
        formulaHint: 'Bài 1 KNTT: Kĩ năng quan sát, phân loại, liên kết, đo, dự báo',
      },
      {
        id: 'hk1-chem-2',
        subject: 'chemistry',
        topic: 'Bài 2: Nguyên tử',
        level: 'Nhận biết',
        question:
          'Trong nguyên tử, loại hạt nào có khối lượng rất nhỏ (chỉ khoảng 0,00055 amu), chuyển động rất nhanh xung quanh hạt nhân?',
        options: ['Proton', 'Neutron', 'Electron', 'Hạt nhân'],
        correctIndex: 2,
        explanation:
          'Hạt electron có khối lượng khoảng 0,00055 amu (rất nhỏ so với proton và neutron đều xấp xỉ 1 amu).',
        formulaHint: 'Bài 2 KNTT: m_p ≈ 1 amu; m_n ≈ 1 amu; m_e ≈ 0,00055 amu',
      },
      {
        id: 'hk1-chem-3',
        subject: 'chemistry',
        topic: 'Bài 3: Nguyên tố hóa học',
        level: 'Nhận biết',
        question:
          'Tập hợp những nguyên tử cùng loại, có cùng số hạt proton trong hạt nhân được gọi là gì (Bài 3)?',
        options: [
          'Phân tử hóa học',
          'Nguyên tố hóa học',
          'Hợp chất hóa học',
          'Hỗn hợp đồng nhất',
        ],
        correctIndex: 1,
        explanation:
          'Nguyên tố hóa học là tập hợp những nguyên tử cùng loại có cùng số proton trong hạt nhân.',
        formulaHint: 'Bài 3 KNTT: Cùng số proton ⇒ Cùng một nguyên tố hóa học',
      },
      {
        id: 'hk1-chem-4',
        subject: 'chemistry',
        topic: 'Bài 3: Nguyên tố hóa học',
        level: 'Nhận biết',
        question:
          'Kí hiệu hóa học viết đúng quy tắc IUPAC của nguyên tố Calcium và nguyên tố Copper (đồng) lần lượt là:',
        options: ['CA và CU', 'Ca và Cu', 'C và Co', 'Cl và Cr'],
        correctIndex: 1,
        explanation:
          'Kí hiệu hóa học gồm 1 hoặc 2 chữ cái: chữ cái đầu viết in hoa, chữ cái thứ hai (nếu có) viết thường: Calcium là Ca, Copper là Cu.',
        formulaHint: 'Bài 3 KNTT: Calcium (Ca), Copper (Cu), Sodium (Na), Iron (Fe)',
      },
      {
        id: 'hk1-chem-5',
        subject: 'chemistry',
        topic: 'Bài 4: Sơ lược về bảng tuần hoàn các nguyên tố hóa học',
        level: 'Thông hiểu',
        question:
          'Các nguyên tố hóa học trong bảng tuần hoàn (Bài 4) được sắp xếp theo chiều tăng dần của đại lượng nào?',
        options: [
          'Số hạt neutron trong hạt nhân',
          'Điện tích hạt nhân nguyên tử (số hiệu nguyên tử Z)',
          'Số lớp electron của nguyên tử',
          'Độ âm điện và bán kính nguyên tử',
        ],
        correctIndex: 1,
        explanation:
          'Nguyên tắc sắp xếp bảng tuần hoàn: Các nguyên tố được xếp theo chiều tăng dần của điện tích hạt nhân nguyên tử.',
        formulaHint: 'Bài 4 KNTT: Sắp xếp theo chiều tăng dần điện tích hạt nhân',
      },
      {
        id: 'hk1-chem-6',
        subject: 'chemistry',
        topic: 'Bài 4: Sơ lược về bảng tuần hoàn các nguyên tố hóa học',
        level: 'Thông hiểu',
        question:
          'Một nguyên tố nằm ở chu kì 3, nhóm IA trong bảng tuần hoàn thì nguyên tử của nguyên tố đó có bao nhiêu lớp electron và bao nhiêu electron ở lớp ngoài cùng?',
        options: [
          '1 lớp electron và 3 electron lớp ngoài cùng',
          '3 lớp electron và 1 electron lớp ngoài cùng',
          '3 lớp electron và 3 electron lớp ngoài cùng',
          '2 lớp electron và 1 electron lớp ngoài cùng',
        ],
        correctIndex: 1,
        explanation:
          'Số thứ tự chu kì = số lớp electron (3 lớp); Số thứ tự nhóm A = số electron lớp ngoài cùng (1e). Đó là nguyên tố Sodium (Na, Z = 11).',
        formulaHint: 'Bài 4 KNTT: Số chu kì = Số lớp e; Số nhóm A = Số e lớp ngoài cùng',
      },
      {
        id: 'hk1-chem-7',
        subject: 'chemistry',
        topic: 'Bài 4: Sơ lược về bảng tuần hoàn các nguyên tố hóa học',
        level: 'Thông hiểu',
        question:
          'Các nguyên tố khí hiếm (như Helium, Neon, Argon) nằm ở nhóm nào trong bảng tuần hoàn các nguyên tố hóa học?',
        options: ['Nhóm IA', 'Nhóm IIA', 'Nhóm VIIA', 'Nhóm VIIIA'],
        correctIndex: 3,
        explanation:
          'Các nguyên tố khí hiếm nằm ở cột cuối cùng bên phải bảng tuần hoàn – Nhóm VIIIA.',
        formulaHint: 'Bài 4 KNTT: Nhóm VIIIA là nhóm nguyên tố khí hiếm',
      },
      {
        id: 'hk1-chem-8',
        subject: 'chemistry',
        topic: 'Bài 4: Sơ lược về bảng tuần hoàn các nguyên tố hóa học',
        level: 'Vận dụng',
        question:
          'Nguyên tử của nguyên tố X có 12 proton (2e ở lớp thứ nhất, 8e ở lớp thứ hai, 2e ở lớp thứ ba). X thuộc loại nguyên tố nào và nằm ở vị trí nào trong bảng tuần hoàn?',
        options: [
          'Nguyên tố phi kim, chu kì 2, nhóm IIIA',
          'Nguyên tố kim loại (Magnesium), chu kì 3, nhóm IIA',
          'Nguyên tố khí hiếm, chu kì 3, nhóm VIIIA',
          'Nguyên tố kim loại, chu kì 2, nhóm IIA',
        ],
        correctIndex: 1,
        explanation:
          'Z = 12 (Magnesium – Mg) có 3 lớp electron → Chu kì 3; có 2e lớp ngoài cùng → Nhóm IIA, là nguyên tố kim loại.',
        formulaHint: 'Bài 4 KNTT: Mg (Z=12) → Chu kì 3, Nhóm IIA (Kim loại)',
      },

      // --- VẬT LÍ: BÀI 8 - BÀI 14 (8 CÂU) ---
      {
        id: 'hk1-phys-1',
        subject: 'physics',
        topic: 'Bài 8: Tốc độ chuyển động',
        level: 'Vận dụng',
        question:
          'Một người đi xe đạp đi trên đoạn đường đầu dài 3 km hết 0,25 giờ, đoạn đường tiếp theo dài 6 km hết 0,5 giờ. Tốc độ trung bình của người đó trên cả hai đoạn đường là:',
        options: ['10 km/h', '12 km/h', '15 km/h', '18 km/h'],
        correctIndex: 1,
        explanation:
          'Tốc độ trung bình v = (s₁ + s₂) / (t₁ + t₂) = (3 + 6) / (0,25 + 0,5) = 9 / 0,75 = 12 km/h.',
        formulaHint: 'Bài 8 KNTT: v_tb = (s₁ + s₂) / (t₁ + t₂)',
      },
      {
        id: 'hk1-phys-2',
        subject: 'physics',
        topic: 'Bài 9 & 10: Đo tốc độ & Đồ thị quãng đường – thời gian',
        level: 'Thông hiểu',
        question:
          'Trên cùng một hệ trục tọa độ quãng đường – thời gian (s – t), đường biểu diễn của vật A dốc hơn (tạo góc lớn hơn với trục Ot) so với đường biểu diễn của vật B. Nhận xét nào sau đây là đúng?',
        options: [
          'Tốc độ của vật A lớn hơn tốc độ của vật B',
          'Tốc độ của vật A nhỏ hơn tốc độ của vật B',
          'Hai vật A và B có cùng tốc độ',
          'Vật A đang đứng yên còn vật B đang chuyển động',
        ],
        correctIndex: 0,
        explanation:
          'Trên đồ thị s – t, đường biểu diễn càng dốc thì trong cùng một khoảng thời gian vật đi được quãng đường lớn hơn, nghĩa là tốc độ lớn hơn.',
        formulaHint: 'Bài 10 KNTT: Độ dốc đồ thị s–t càng lớn ⇒ tốc độ v càng lớn',
      },
      {
        id: 'hk1-phys-3',
        subject: 'physics',
        topic: 'Bài 11: Ảnh hưởng của tốc độ trong an toàn giao thông',
        level: 'Nhận biết',
        question:
          'Khi trời mưa to làm mặt đường trơn trượt hoặc có sương mù dày đặc (Bài 11), người lái xe cần điều chỉnh tốc độ và khoảng cách an toàn như thế nào?',
        options: [
          'Tăng tốc độ để nhanh qua đoạn đường mưa',
          'Giảm tốc độ và tăng khoảng cách an toàn với xe phía trước',
          'Giữ nguyên tốc độ tối đa và bám sát đuôi xe trước',
          'Chỉ cần bật đèn pha và giữ nguyên tốc độ',
        ],
        correctIndex: 1,
        explanation:
          'Khi đường trơn hoặc tầm nhìn hạn chế, quãng đường phanh tăng lên nên phải giảm tốc độ và tăng khoảng cách an toàn.',
        formulaHint: 'Bài 11 KNTT: Đường trơn / mưa → Giảm tốc độ, tăng khoảng cách an toàn',
      },
      {
        id: 'hk1-phys-4',
        subject: 'physics',
        topic: 'Bài 12: Sóng âm',
        level: 'Nhận biết',
        question:
          'Sóng âm truyền được trong những môi trường nào và KHÔNG truyền được trong môi trường nào (Bài 12)?',
        options: [
          'Truyền được trong chất rắn, lỏng, khí; không truyền được trong chân không',
          'Chỉ truyền được trong chất khí, không truyền được trong chất rắn và chất lỏng',
          'Truyền được trong cả chất rắn, lỏng, khí và chân không',
          'Truyền nhanh nhất trong chân không và chậm nhất trong chất rắn',
        ],
        correctIndex: 0,
        explanation:
          'Sóng âm là sự lan truyền dao động của nguồn âm nên truyền được trong chất rắn, lỏng, khí (v_rắn > v_lỏng > v_khí) và không truyền được trong chân không.',
        formulaHint: 'Bài 12 KNTT: Sóng âm không truyền được trong chân không (v_rắn > v_lỏng > v_khí)',
      },
      {
        id: 'hk1-phys-5',
        subject: 'physics',
        topic: 'Bài 13: Độ to và độ cao của âm',
        level: 'Nhận biết',
        question:
          'Độ cao của âm phụ thuộc vào yếu tố nào của nguồn âm và tần số có đơn vị đo là gì (Bài 13)?',
        options: [
          'Phụ thuộc vào biên độ dao động; đơn vị là đề-xi-ben (dB)',
          'Phụ thuộc vào tần số dao động; đơn vị là Héc (Hz)',
          'Phụ thuộc vào tốc độ truyền âm; đơn vị là m/s',
          'Phụ thuộc vào thời gian phát âm; đơn vị là giây (s)',
        ],
        correctIndex: 1,
        explanation:
          'Số dao động trong 1 giây gọi là tần số (đơn vị Hz). Tần số càng lớn thì âm phát ra càng cao (càng bổng).',
        formulaHint: 'Bài 13 KNTT: Tần số f (Hz) quyết định độ cao; Biên độ quyết định độ to',
      },
      {
        id: 'hk1-phys-6',
        subject: 'physics',
        topic: 'Bài 13: Độ to và độ cao của âm',
        level: 'Vận dụng',
        question:
          'Trong 10 giây, cánh của một con ong mật thực hiện được 3 300 dao động, còn cánh của một con muỗi thực hiện được 6 000 dao động. Hỏi tần số dao động của cánh ong và cánh muỗi lần lượt là bao nhiêu và con nào phát ra âm cao hơn?',
        options: [
          'Ong: 330 Hz; Muỗi: 600 Hz → Âm do cánh muỗi phát ra cao hơn',
          'Ong: 33 Hz; Muỗi: 60 Hz → Âm do cánh ong phát ra cao hơn',
          'Ong: 330 Hz; Muỗi: 600 Hz → Âm do cánh ong phát ra cao hơn',
          'Ong: 3 300 Hz; Muỗi: 6 000 Hz → Hai âm có độ cao bằng nhau',
        ],
        correctIndex: 0,
        explanation:
          'f_ong = 3300 / 10 = 330 Hz; f_muỗi = 6000 / 10 = 600 Hz. Vì f_muỗi > f_ong nên âm do cánh muỗi phát ra cao (bổng) hơn.',
        formulaHint: 'Bài 13 KNTT: f = N / t (Hz)',
      },
      {
        id: 'hk1-phys-7',
        subject: 'physics',
        topic: 'Bài 14: Phản xạ âm, chống ô nhiễm tiếng ồn',
        level: 'Thông hiểu',
        question:
          'Những vật liệu nào sau đây phản xạ âm KÉM (hấp thụ âm tốt) thường được dùng để ốp tường trong phòng thu âm, rạp chiếu phim (Bài 14)?',
        options: [
          'Tấm kính phẳng, gạch men bóng, tường bê tông nhẵn',
          'Xốp, nhung, dạ, cao su xốp, rèm vải dày có bề mặt gồ ghề',
          'Tấm thép phẳng, mặt đá hoa cương',
          'Mặt gương phẳng lớn và tấm nhôm',
        ],
        correctIndex: 1,
        explanation:
          'Các vật mềm, xốp, có bề mặt gồ ghề (nhung, dạ, xốp, rèm vải...) hấp thụ âm tốt và phản xạ âm kém, giúp giảm tiếng vang.',
        formulaHint: 'Bài 14 KNTT: Vật mềm, xốp, gồ ghề → phản xạ âm kém (cách âm/tiêu âm)',
      },
      {
        id: 'hk1-phys-8',
        subject: 'physics',
        topic: 'Bài 14: Phản xạ âm, chống ô nhiễm tiếng ồn',
        level: 'Vận dụng',
        question:
          'Một tàu khảo sát phát sóng siêu âm xuống đáy biển và thu được âm phản xạ sau 1,2 giây. Biết tốc độ truyền siêu âm trong nước biển là 1 500 m/s. Độ sâu của đáy biển tại nơi đó là:',
        options: ['1 800 m', '900 m', '750 m', '1 250 m'],
        correctIndex: 1,
        explanation:
          'Sóng siêu âm đi từ tàu xuống đáy biển rồi phản xạ ngược lại tàu (quãng đường 2h), nên độ sâu h = (v · t) / 2 = (1500 · 1,2) / 2 = 900 m.',
        formulaHint: 'Bài 14 KNTT: Độ sâu đáy biển h = (v · t) / 2',
      },

      // --- SINH HỌC: BÀI 21 - BÀI 32 (8 CÂU) ---
      {
        id: 'hk1-bio-1',
        subject: 'biology',
        topic: 'Bài 22 & 25: Quang hợp và Hô hấp tế bào',
        level: 'Thông hiểu',
        question:
          'Mối quan hệ giữa quá trình quang hợp và quá trình hô hấp tế bào ở thực vật là gì?',
        options: [
          'Hai quá trình hoàn toàn độc lập, không liên quan đến nhau',
          'Hai quá trình trái ngược nhau nhưng phụ thuộc lẫn nhau: sản phẩm của quang hợp (Glucose, O₂) là nguyên liệu của hô hấp và ngược lại',
          'Hai quá trình đều chỉ diễn ra vào ban ngày khi có ánh sáng mặt trời',
          'Cả hai quá trình đều tổng hợp chất hữu cơ và giải phóng khí Oxygen',
        ],
        correctIndex: 1,
        explanation:
          'Quang hợp tổng hợp chất hữu cơ và giải phóng O₂ (nguyên liệu cho hô hấp); hô hấp phân giải chất hữu cơ giải phóng CO₂ và H₂O (nguyên liệu cho quang hợp).',
        formulaHint: 'Bài 22 & 25 KNTT: Quang hợp ⇄ Hô hấp tế bào',
      },
      {
        id: 'hk1-bio-2',
        subject: 'biology',
        topic: 'Bài 27: Trao đổi khí ở sinh vật',
        level: 'Nhận biết',
        question:
          'Ở động vật, cơ quan trao đổi khí của cá chép, châu chấu và người lần lượt là (Bài 27):',
        options: [
          'Phổi – Hệ thống ống khí – Mang',
          'Mang – Hệ thống ống khí – Phổi',
          'Qua bề mặt da – Mang – Phổi',
          'Mang – Phổi – Hệ thống ống khí',
        ],
        correctIndex: 1,
        explanation:
          'Cá trao đổi khí qua mang; côn trùng (châu chấu) trao đổi khí qua hệ thống ống khí; thú, chim, bò sát và người trao đổi khí qua phổi.',
        formulaHint: 'Bài 27 KNTT: Cá (Mang) · Côn trùng (Ống khí) · Người/Thú (Phổi)',
      },
      {
        id: 'hk1-bio-3',
        subject: 'biology',
        topic: 'Bài 28: Vai trò của nước và chất dinh dưỡng đối với sinh vật',
        level: 'Nhận biết',
        question:
          'Vì sao phân tử nước (H₂O) được gọi là phân tử phân cực và đóng vai trò là dung môi hòa tan nhiều chất trong cơ thể sống (Bài 28)?',
        options: [
          'Vì nguyên tử Oxygen có khả năng hút cặp electron dùng chung mạnh hơn Hydrogen nên vùng gần O tích điện âm nhẹ, vùng gần H tích điện dương nhẹ',
          'Vì phân tử nước gồm 2 nguyên tử Oxygen và 1 nguyên tử Hydrogen',
          'Vì nước không hòa tan được muối khoáng và đường',
          'Vì nước là một chất hữu cơ cung cấp năng lượng trực tiếp cho tế bào',
        ],
        correctIndex: 0,
        explanation:
          'Do sự chênh lệch khả năng hút electron giữa O và H nên phân tử nước có tính phân cực, dễ dàng hòa tan các chất phân cực (muối khoáng, đường, vitamin tan trong nước).',
        formulaHint: 'Bài 28 KNTT: Tính phân cực của phân tử nước H₂O',
      },
      {
        id: 'hk1-bio-4',
        subject: 'biology',
        topic: 'Bài 29: Trao đổi nước và các chất dinh dưỡng ở thực vật',
        level: 'Thông hiểu',
        question:
          'Trong thân cây xanh (Bài 29), mạch gỗ (xylem) và mạch rây (phloem) đảm nhận chức năng vận chuyển như thế nào?',
        options: [
          'Mạch gỗ vận chuyển nước và muối khoáng từ rễ lên lá; mạch rây vận chuyển chất hữu cơ từ lá xuống các cơ quan dự trữ/nuôi cây',
          'Mạch gỗ vận chuyển chất hữu cơ từ lá xuống rễ; mạch rây vận chuyển nước từ rễ lên lá',
          'Cả mạch gỗ và mạch rây đều chỉ vận chuyển nước từ lá xuống rễ',
          'Mạch gỗ chỉ hoạt động vào ban đêm, mạch rây chỉ hoạt động vào ban ngày',
        ],
        correctIndex: 0,
        explanation:
          'Dòng đi lên (mạch gỗ) vận chuyển nước & muối khoáng từ lông hút của rễ lên lá; dòng đi xuống (mạch rây) vận chuyển chất hữu cơ tổng hợp từ lá đến các bộ phận.',
        formulaHint: 'Bài 29 KNTT: Mạch gỗ (Nước + khoáng ↑) · Mạch rây (Chất hữu cơ ↓)',
      },
      {
        id: 'hk1-bio-5',
        subject: 'biology',
        topic: 'Bài 29: Trao đổi nước và các chất dinh dưỡng ở thực vật',
        level: 'Thông hiểu',
        question:
          'Quá trình thoát hơi nước qua lá ở thực vật có ý nghĩa sinh học quan trọng nào sau đây?',
        options: [
          'Làm cây bị héo và mất toàn bộ chất hữu cơ',
          'Tạo động lực đầu trên giúp vận chuyển nước và muối khoáng từ rễ lên lá, đồng thời giúp hạ nhiệt độ bề mặt lá và mở khí khổng cho CO₂ đi vào quang hợp',
          'Ngăn cản hoàn toàn sự hút nước của rễ cây',
          'Chỉ có tác dụng làm tăng độ ẩm không khí mà không có lợi cho cây',
        ],
        correctIndex: 1,
        explanation:
          'Thoát hơi nước qua khí khổng tạo lực hút đầu trên kéo dòng mạch gỗ đi lên, làm mát lá và giúp khí khổng mở để lấy CO₂ cho quang hợp.',
        formulaHint: 'Bài 29 KNTT: 3 vai trò của thoát hơi nước ở lá',
      },
      {
        id: 'hk1-bio-6',
        subject: 'biology',
        topic: 'Bài 30: Trao đổi nước và các chất dinh dưỡng ở động vật',
        level: 'Nhận biết',
        question:
          'Ở người, con đường thu nhận và tiêu hóa thức ăn trong ống tiêu hóa lần lượt đi qua các cơ quan theo thứ tự nào (Bài 30)?',
        options: [
          'Khoang miệng → Thực quản → Dạ dày → Ruột non → Ruột già → Trực tràng → Hậu môn',
          'Khoang miệng → Khí quản → Phổi → Dạ dày → Ruột non → Hậu môn',
          'Khoang miệng → Dạ dày → Thực quản → Ruột già → Ruột non → Hậu môn',
          'Khoang miệng → Thực quản → Gan → Thận → Bàng quang',
        ],
        correctIndex: 0,
        explanation:
          'Ống tiêu hóa ở người gồm: Khoang miệng → Hầu → Thực quản → Dạ dày → Ruột non (hấp thụ chính) → Ruột già → Trực tràng → Hậu môn.',
        formulaHint: 'Bài 30 KNTT: Sơ đồ ống tiêu hóa và hệ tuần hoàn ở người',
      },
      {
        id: 'hk1-bio-7',
        subject: 'biology',
        topic: 'Bài 31: Thực hành chứng minh thân vận chuyển nước và lá thoát hơi nước',
        level: 'Thông hiểu',
        question:
          'Khi cắm cành hoa huệ trắng vào cốc nước pha màu thực phẩm đỏ (Bài 31), sau vài giờ ta thấy cánh hoa chuyển sang màu đỏ và khi cắt ngang thân thấy các chấm đỏ ở vùng nào?',
        options: [
          'Ở vùng mạch gỗ của thân cây',
          'Ở lớp vỏ ngoài cùng của thân',
          'Ở lớp biểu bì cánh hoa',
          'Ở phần ruột xốp chính giữa thân',
        ],
        correctIndex: 0,
        explanation:
          'Nước pha màu được vận chuyển từ dưới lên hoa thông qua hệ thống mạch gỗ trong thân cây.',
        formulaHint: 'Bài 31 KNTT: Thí nghiệm chứng minh mạch gỗ vận chuyển nước',
      },
      {
        id: 'hk1-bio-8',
        subject: 'biology',
        topic: 'Bài 32: Cảm ứng ở sinh vật',
        level: 'Nhận biết',
        question:
          'Khả năng cơ thể sinh vật tiếp nhận và phản ứng thích hợp với các kích thích từ môi trường bên trong và bên ngoài cơ thể để tồn tại và phát triển được gọi là gì (Bài 32)?',
        options: [
          'Trao đổi chất',
          'Cảm ứng ở sinh vật',
          'Sinh sản vô tính',
          'Hô hấp tế bào',
        ],
        correctIndex: 1,
        explanation:
          'Cảm ứng là phản ứng của sinh vật đối với các kích thích của môi trường (ví dụ: ngọn cây hướng về phía ánh sáng, tay rụt lại khi chạm vật nóng).',
        formulaHint: 'Bài 32 KNTT: Khái niệm và vai trò của Cảm ứng ở sinh vật',
      },
    ],
  },

  // ============================================================================
  // 3. ĐỀ KIỂM TRA GIỮA HỌC KÌ 2
  // Phạm vi: Vật lí Bài 15–17 | Hóa học Bài 5–6 | Sinh học Bài 33–37 (KHTN 7 KNTT)
  // ============================================================================
  {
    id: 'exam-gk2-kntt',
    code: 'gk2',
    title: 'Đề Kiểm Tra Giữa Học Kì 2 – KHTN 7 (Kết nối tri thức)',
    shortLabel: 'Đề Giữa Kì 2',
    durationMinutes: 45,
    scopeSummary: {
      physics: 'Vật lí: Bài 15 – Bài 17 (Năng lượng ánh sáng, Sự phản xạ ánh sáng, Ảnh của vật tạo bởi gương phẳng)',
      chemistry: 'Hóa học: Bài 5 – Bài 6 (Phân tử – Đơn chất – Hợp chất, Giới thiệu về liên kết hóa học)',
      biology: 'Sinh học: Bài 33 – Bài 37 (Tập tính ở động vật, Sinh trưởng và phát triển ở sinh vật & ứng dụng)',
    },
    questions: [
      // --- HÓA HỌC: BÀI 5 - BÀI 6 (6 CÂU) ---
      {
        id: 'gk2-chem-1',
        subject: 'chemistry',
        topic: 'Bài 5: Phân tử – Đơn chất – Hợp chất',
        level: 'Nhận biết',
        question:
          'Dãy chất nào sau đây chỉ gồm các ĐƠN CHẤT (Bài 5)?',
        options: [
          'Khí Oxygen (O₂), khí Hydrogen (H₂), kim loại Copper (Cu)',
          'Nước (H₂O), muối ăn (NaCl), khí Carbon dioxide (CO₂)',
          'Khí Nitrogen (N₂), nước (H₂O), kim loại Iron (Fe)',
          'Đường glucose (C₆H₁₂O₆), khí Methane (CH₄), khí Chlorine (Cl₂)',
        ],
        correctIndex: 0,
        explanation:
          'Đơn chất là những chất được tạo nên từ một nguyên tố hóa học (O₂, H₂, Cu). Hợp chất được tạo nên từ hai nguyên tố hóa học trở lên (H₂O, NaCl, CO₂).',
        formulaHint: 'Bài 5 KNTT: Đơn chất (1 nguyên tố) · Hợp chất (≥ 2 nguyên tố)',
      },
      {
        id: 'gk2-chem-2',
        subject: 'chemistry',
        topic: 'Bài 5: Phân tử – Đơn chất – Hợp chất',
        level: 'Vận dụng',
        question:
          'Cho khối lượng nguyên tử: H = 1 amu, C = 12 amu, O = 16 amu. Khối lượng phân tử của hợp chất nước (H₂O) và khí Carbon dioxide (CO₂) lần lượt là:',
        options: [
          '17 amu và 28 amu',
          '18 amu và 44 amu',
          '18 amu và 32 amu',
          '20 amu và 44 amu',
        ],
        correctIndex: 1,
        explanation:
          'M(H₂O) = 2 · 1 + 16 = 18 amu; M(CO₂) = 12 + 2 · 16 = 44 amu.',
        formulaHint: 'Bài 5 KNTT: Khối lượng phân tử bằng tổng khối lượng các nguyên tử trong phân tử',
      },
      {
        id: 'gk2-chem-3',
        subject: 'chemistry',
        topic: 'Bài 5: Phân tử – Đơn chất – Hợp chất',
        level: 'Thông hiểu',
        question:
          'Phân tử Methane gồm 1 nguyên tử Carbon (12 amu) và 4 nguyên tử Hydrogen (1 amu) liên kết với nhau. Khối lượng phân tử Methane là bao nhiêu?',
        options: ['13 amu', '15 amu', '16 amu', '20 amu'],
        correctIndex: 2,
        explanation:
          'Khối lượng phân tử Methane (CH₄) = 12 + 4 × 1 = 16 amu.',
        formulaHint: 'Bài 5 KNTT: M(CH₄) = 12 + 4·1 = 16 amu',
      },
      {
        id: 'gk2-chem-4',
        subject: 'chemistry',
        topic: 'Bài 6: Giới thiệu về liên kết hóa học',
        level: 'Nhận biết',
        question:
          'Liên kết hóa học được hình thành do lực hút tĩnh điện giữa các ion mang điện tích trái dấu (thường giữa kim loại điển hình và phi kim điển hình) được gọi là gì (Bài 6)?',
        options: [
          'Liên kết cộng hóa trị',
          'Liên kết ion',
          'Liên kết kim loại',
          'Liên kết hydrogen',
        ],
        correctIndex: 1,
        explanation:
          'Liên kết ion là liên kết được hình thành bởi lực hút tĩnh điện giữa ion dương (cation kim loại) và ion âm (anion phi kim), ví dụ NaCl, MgO.',
        formulaHint: 'Bài 6 KNTT: Liên kết ion = Lực hút tĩnh điện giữa ion dương và ion âm',
      },
      {
        id: 'gk2-chem-5',
        subject: 'chemistry',
        topic: 'Bài 6: Giới thiệu về liên kết hóa học',
        level: 'Thông hiểu',
        question:
          'Liên kết cộng hóa trị trong các phân tử như H₂, O₂, H₂O, CO₂ được hình thành bằng cách nào (Bài 6)?',
        options: [
          'Bằng sự nhường hẳn electron từ nguyên tử này sang nguyên tử khác',
          'Bằng một hay nhiều cặp electron dùng chung giữa hai nguyên tử',
          'Bằng lực hút từ trường giữa hai hạt nhân',
          'Bằng sự trao đổi hạt proton giữa hai nguyên tử',
        ],
        correctIndex: 1,
        explanation:
          'Liên kết cộng hóa trị là liên kết được tạo nên giữa hai nguyên tử bằng một hay nhiều cặp electron dùng chung để đạt cấu hình bền của khí hiếm.',
        formulaHint: 'Bài 6 KNTT: Liên kết cộng hóa trị = Cặp electron dùng chung',
      },
      {
        id: 'gk2-chem-6',
        subject: 'chemistry',
        topic: 'Bài 6: Giới thiệu về liên kết hóa học',
        level: 'Vận dụng',
        question:
          'Dãy chất nào sau đây đều là các chất Cộng Hóa Trị (ở điều kiện thường có thể là chất khí, chất lỏng hoặc chất rắn có nhiệt độ nóng chảy thấp)?',
        options: [
          'Nước (H₂O), khí Carbon dioxide (CO₂), khí Ammonia (NH₃)',
          'Muối ăn (NaCl), Magnesium oxide (MgO), Calcium chloride (CaCl₂)',
          'Sodium chloride (NaCl), nước (H₂O), Potassium oxide (K₂O)',
          'Magnesium oxide (MgO), Sodium oxide (Na₂O), Calcium oxide (CaO)',
        ],
        correctIndex: 0,
        explanation:
          'H₂O, CO₂, NH₃ đều được tạo bởi các nguyên tố phi kim liên kết với nhau bằng cặp electron dùng chung nên là các chất cộng hóa trị.',
        formulaHint: 'Bài 6 KNTT: Phân biệt chất ion (NaCl, MgO) và chất cộng hóa trị (H₂O, CO₂, NH₃)',
      },

      // --- VẬT LÍ: BÀI 15 - BÀI 17 (7 CÂU) ---
      {
        id: 'gk2-phys-1',
        subject: 'physics',
        topic: 'Bài 15: Năng lượng ánh sáng. Tia sáng, vùng tối',
        level: 'Nhận biết',
        question:
          'Trong thí nghiệm thu năng lượng ánh sáng mặt trời bằng pin quang điện (pin mặt trời) gắn với bóng đèn LED (Bài 15), năng lượng ánh sáng đã chuyển hóa thành dạng năng lượng nào trước khi làm đèn sáng?',
        options: [
          'Hóa năng',
          'Điện năng',
          'Cơ năng',
          'Năng lượng âm thanh',
        ],
        correctIndex: 1,
        explanation:
          'Pin mặt trời (pin quang điện) chuyển hóa trực tiếp năng lượng ánh sáng (quang năng) thành điện năng thắp sáng đèn LED.',
        formulaHint: 'Bài 15 KNTT: Ánh sáng mang năng lượng (Quang năng → Điện năng / Nhiệt năng)',
      },
      {
        id: 'gk2-phys-2',
        subject: 'physics',
        topic: 'Bài 15: Năng lượng ánh sáng. Tia sáng, vùng tối',
        level: 'Thông hiểu',
        question:
          'Khi dùng một nguồn sáng rộng chiếu vào một vật cản sáng, phía sau vật cản xuất hiện vùng không nhận được ánh sáng nào và vùng chỉ nhận được một phần ánh sáng từ nguồn sáng truyền tới. Hai vùng này lần lượt gọi là:',
        options: [
          'Vùng sáng và vùng phản xạ',
          'Vùng tối và vùng nửa tối',
          'Vùng khúc xạ và vùng tán sắc',
          'Vùng hội tụ và vùng phân kì',
        ],
        correctIndex: 1,
        explanation:
          'Phía sau vật cản sáng được chiếu bởi nguồn sáng rộng sẽ có vùng tối hoàn toàn và vùng nửa tối bao quanh.',
        formulaHint: 'Bài 15 KNTT: Vùng tối và vùng nửa tối do nguồn sáng rộng tạo ra',
      },
      {
        id: 'gk2-phys-3',
        subject: 'physics',
        topic: 'Bài 16: Sự phản xạ ánh sáng',
        level: 'Nhận biết',
        question:
          'Theo định luật phản xạ ánh sáng (Bài 16), mối quan hệ giữa góc phản xạ (i\') và góc tới (i) là:',
        options: [
          'Góc phản xạ luôn lớn hơn góc tới (i\' > i)',
          'Góc phản xạ luôn bằng góc tới (i\' = i)',
          'Góc phản xạ luôn nhỏ hơn góc tới (i\' < i)',
          'Tổng góc tới và góc phản xạ luôn bằng 90°',
        ],
        correctIndex: 1,
        explanation:
          'Định luật phản xạ ánh sáng: Tia phản xạ nằm trong mặt phẳng tới, ở bên kia pháp tuyến so với tia tới và góc phản xạ luôn bằng góc tới (i\' = i).',
        formulaHint: 'Bài 16 KNTT: Định luật phản xạ ánh sáng i\' = i',
      },
      {
        id: 'gk2-phys-4',
        subject: 'physics',
        topic: 'Bài 16: Sự phản xạ ánh sáng',
        level: 'Vận dụng',
        question:
          'Chiếu một tia sáng SI tới mặt gương phẳng sao cho tia tới hợp với mặt gương một góc 30°. Hỏi góc tới i và góc phản xạ i\' bằng bao nhiêu độ?',
        options: [
          'i = 30°, i\' = 30°',
          'i = 60°, i\' = 60°',
          'i = 60°, i\' = 30°',
          'i = 45°, i\' = 45°',
        ],
        correctIndex: 1,
        explanation:
          'Pháp tuyến IN vuông góc với mặt gương (90°). Tia tới hợp với mặt gương góc 30° nên góc tới i = 90° - 30° = 60°. Theo định luật phản xạ ánh sáng, i\' = i = 60°.',
        formulaHint: 'Bài 16 KNTT: i = 90° - góc hợp bởi tia tới và mặt gương; i\' = i',
      },
      {
        id: 'gk2-phys-5',
        subject: 'physics',
        topic: 'Bài 16: Sự phản xạ ánh sáng',
        level: 'Thông hiểu',
        question:
          'Khi các tia sáng song song chiếu tới một mặt phẳng nhẵn bóng (như mặt gương, mặt nước tĩnh lặng) thì các tia phản xạ vẫn song song với nhau. Hiện tượng này gọi là gì?',
        options: [
          'Phản xạ khuếch tán (phản xạ không gương)',
          'Phản xạ gương (phản xạ đều)',
          'Khúc xạ ánh sáng',
          'Hấp thụ ánh sáng hoàn toàn',
        ],
        correctIndex: 1,
        explanation:
          'Phản xạ trên bề mặt nhẵn bóng là phản xạ gương (nhìn thấy ảnh rõ nét); phản xạ trên bề mặt gồ ghề là phản xạ khuếch tán (không thấy ảnh).',
        formulaHint: 'Bài 16 KNTT: Phân biệt phản xạ gương và phản xạ khuếch tán',
      },
      {
        id: 'gk2-phys-6',
        subject: 'physics',
        topic: 'Bài 17: Ảnh của vật tạo bởi gương phẳng',
        level: 'Nhận biết',
        question:
          'Tính chất ảnh của một vật tạo bởi gương phẳng (Bài 17) là:',
        options: [
          'Ảnh thật, hứng được trên màn chắn và nhỏ hơn vật',
          'Ảnh ảo, không hứng được trên màn chắn, có độ lớn bằng vật và khoảng cách từ ảnh đến gương bằng khoảng cách từ vật đến gương',
          'Ảnh ảo, lớn gấp đôi vật và cách gương một khoảng bằng nửa khoảng cách từ vật tới gương',
          'Ảnh thật, cùng chiều với vật và lớn bằng vật',
        ],
        correctIndex: 1,
        explanation:
          'Ảnh của vật tạo bởi gương phẳng là ảnh ảo, lớn bằng vật và đối xứng với vật qua mặt gương phẳng (d\' = d).',
        formulaHint: 'Bài 17 KNTT: Ảnh ảo, lớn bằng vật, khoảng cách d\' = d',
      },
      {
        id: 'gk2-phys-7',
        subject: 'physics',
        topic: 'Bài 17: Ảnh của vật tạo bởi gương phẳng',
        level: 'Vận dụng',
        question:
          'Một học sinh đứng trước một gương phẳng và cách mặt gương 1,5 m. Khoảng cách từ học sinh đó đến ảnh của mình trong gương là bao nhiêu?',
        options: ['1,5 m', '2,0 m', '3,0 m', '0,75 m'],
        correctIndex: 2,
        explanation:
          'Ảnh ảo cách gương một khoảng bằng khoảng cách từ vật đến gương (1,5 m). Vậy khoảng cách từ học sinh đến ảnh của mình là 1,5 + 1,5 = 3,0 m.',
        formulaHint: 'Bài 17 KNTT: Khoảng cách từ vật đến ảnh = 2 · d',
      },

      // --- SINH HỌC: BÀI 33 - BÀI 37 (7 CÂU) ---
      {
        id: 'gk2-bio-1',
        subject: 'biology',
        topic: 'Bài 33: Tập tính ở động vật',
        level: 'Nhận biết',
        question:
          'Tập tính nào sau đây ở động vật là tập tính BẨM SINH (sinh ra đã có, được di truyền từ bố mẹ, đặc trưng cho loài – Bài 33)?',
        options: [
          'Nhện giăng tơ và tò vò đào hố làm tổ',
          'Chó chạy tới khi nghe tiếng kẻng gọi ăn của chủ',
          'Khỉ con học cách dùng đá đập vỡ hạt cứng từ khỉ mẹ',
          'Học sinh dừng xe trước vạch khi thấy đèn giao thông chuyển sang màu đỏ',
        ],
        correctIndex: 0,
        explanation:
          'Nhện giăng tơ là tập tính bẩm sinh (sinh ra đã biết làm, không cần học tập). Các ví dụ còn lại là tập tính học được trong đời sống cá thể.',
        formulaHint: 'Bài 33 KNTT: Phân biệt tập tính bẩm sinh và tập tính học được',
      },
      {
        id: 'gk2-bio-2',
        subject: 'biology',
        topic: 'Bài 33: Tập tính ở động vật',
        level: 'Thông hiểu',
        question:
          'Người nông dân sử dụng bù nhìn rơm trên đồng ruộng để xua đuổi chim ăn lúa, hoặc dùng đèn bẫy côn trùng ban đêm là ứng dụng kiến thức sinh học nào (Bài 33)?',
        options: [
          'Ứng dụng quang hợp của cây lúa',
          'Ứng dụng cảm ứng và tập tính của động vật vào sản xuất nông nghiệp',
          'Ứng dụng hô hấp tế bào ở côn trùng',
          'Ứng dụng sinh sản hữu tính ở thực vật',
        ],
        correctIndex: 1,
        explanation:
          'Hiểu rõ tập tính kiếm ăn, tập tính hướng sáng và lẩn tránh kẻ thù của côn trùng/chim giúp con người bảo vệ mùa màng hiệu quả.',
        formulaHint: 'Bài 33 KNTT: Ứng dụng tập tính động vật trong nông nghiệp và đời sống',
      },
      {
        id: 'gk2-bio-3',
        subject: 'biology',
        topic: 'Bài 34: Sinh trưởng và phát triển ở sinh vật',
        level: 'Nhận biết',
        question:
          'Trong quá trình sống của sinh vật (Bài 34), sự tăng lên về kích thước và khối lượng cơ thể do tăng số lượng và kích thước tế bào được gọi là gì?',
        options: [
          'Sự phát triển',
          'Sự sinh trưởng',
          'Sự cảm ứng',
          'Sự trao đổi khí',
        ],
        correctIndex: 1,
        explanation:
          'Sinh trưởng là sự tăng lên về kích thước và khối lượng cơ thể do sự tăng lên về số lượng và kích thước tế bào.',
        formulaHint: 'Bài 34 KNTT: Sinh trưởng (tăng kích thước, khối lượng) · Phát triển (phân hóa, tạo cơ quan mới)',
      },
      {
        id: 'gk2-bio-4',
        subject: 'biology',
        topic: 'Bài 34: Sinh trưởng và phát triển ở sinh vật',
        level: 'Thông hiểu',
        question:
          'Ở thực vật, mô phân sinh đỉnh nằm ở vị trí nào và có chức năng gì đối với sự sinh trưởng của cây (Bài 34)?',
        options: [
          'Nằm ở thân cây gỗ trưởng thành, giúp thân cây to ra về đường kính',
          'Nằm ở chồi đỉnh, chồi nách và đỉnh rễ, giúp thân và rễ cây dài ra',
          'Nằm ở phiến lá già, giúp lá rụng vào mùa đông',
          'Nằm ở vỏ hạt khô, giúp hạt dự trữ tinh bột',
        ],
        correctIndex: 1,
        explanation:
          'Mô phân sinh đỉnh có ở đỉnh thân, chồi nách và đỉnh rễ giúp thân, cành và rễ dài ra; mô phân sinh bên giúp thân và rễ cây Hai lá mầm to ra.',
        formulaHint: 'Bài 34 KNTT: Mô phân sinh đỉnh (làm dài thân/rễ) · Mô phân sinh bên (làm to đường kính)',
      },
      {
        id: 'gk2-bio-5',
        subject: 'biology',
        topic: 'Bài 35: Thực hành quan sát sinh trưởng và phát triển ở sinh vật',
        level: 'Thông hiểu',
        question:
          'Vòng đời phát triển của bướm (hoặc ếch đồng) trải qua giai đoạn ấu trùng (sâu bướm / nòng nọc) có hình thái, cấu tạo và sinh lí rất khác với con trưởng thành. Kiểu phát triển này gọi là (Bài 34–35):',
        options: [
          'Phát triển không qua biến thái',
          'Phát triển qua biến thái hoàn toàn',
          'Phát triển trực tiếp không có ấu trùng',
          'Sinh trưởng sơ cấp',
        ],
        correctIndex: 1,
        explanation:
          'Bướm (Trứng → Sâu bướm → Nhộng → Bướm) và ếch (Trứng → Nòng nọc → Ếch con → Ếch trưởng thành) có ấu trùng khác hẳn con trưởng thành nên là phát triển qua biến thái hoàn toàn.',
        formulaHint: 'Bài 34–35 KNTT: Vòng đời bướm & ếch (Biến thái hoàn toàn)',
      },
      {
        id: 'gk2-bio-6',
        subject: 'biology',
        topic: 'Bài 36: Các nhân tố ảnh hưởng đến sinh trưởng và phát triển của sinh vật',
        level: 'Thông hiểu',
        question:
          'Vì sao trẻ em cần tắm nắng sớm hợp lí để phòng tránh bệnh còi xương và giúp hệ xương sinh trưởng tốt (Bài 36)?',
        options: [
          'Ánh nắng mặt trời cung cấp trực tiếp chất đạm cho cơ bắp',
          'Tia tử ngoại trong ánh nắng sớm giúp cơ thể chuyển hóa tiền vitamin D thành vitamin D, hỗ trợ hấp thụ Calcium tạo xương',
          'Ánh nắng mặt trời làm giảm nhịp thở của trẻ em',
          'Ánh nắng mặt trời thay thế hoàn toàn thức ăn và nước uống',
        ],
        correctIndex: 1,
        explanation:
          'Ánh sáng mặt trời giúp tổng hợp Vitamin D, rất cần thiết cho quá trình hấp thụ và chuyển hóa Calcium để hình thành xương chắc khỏe.',
        formulaHint: 'Bài 36 KNTT: Nhân tố ánh sáng, nhiệt độ, dinh dưỡng đối với sinh trưởng',
      },
      {
        id: 'gk2-bio-7',
        subject: 'biology',
        topic: 'Bài 37: Ứng dụng sinh trưởng và phát triển ở sinh vật vào thực tiễn',
        level: 'Vận dụng',
        question:
          'Người trồng thanh long thường thắp đèn điện vào ban đêm ở vườn thanh long trái vụ nhằm mục đích gì (Bài 37)?',
        options: [
          'Để sưởi ấm cho rễ cây thanh long trong mùa hè',
          'Điều chỉnh thời gian chiếu sáng (quang chu kì) để kích thích cây thanh long ra hoa, kết quả trái vụ mang lại hiệu quả kinh tế cao',
          'Để tiêu diệt toàn bộ vi khuẩn có lợi trong đất',
          'Để làm quả thanh long nhỏ lại',
        ],
        correctIndex: 1,
        explanation:
          'Thanh long là cây ngày dài; thắp đèn ban đêm vào mùa thu – đông giúp kích thích cây ra hoa trái vụ.',
        formulaHint: 'Bài 37 KNTT: Ứng dụng chiếu sáng nhân tạo điều khiển sinh trưởng, phát triển',
      },
    ],
  },

  // ============================================================================
  // 4. ĐỀ KIỂM TRA CUỐI HỌC KÌ 2
  // Phạm vi: Vật lí Bài 15–20 | Hóa học Bài 6–7 | Sinh học Bài 33–42 (KHTN 7 KNTT)
  // ============================================================================
  {
    id: 'exam-hk2-kntt',
    code: 'hk2',
    title: 'Đề Kiểm Tra Cuối Học Kì 2 – KHTN 7 (Kết nối tri thức)',
    shortLabel: 'Đề Học Kì 2',
    durationMinutes: 60,
    scopeSummary: {
      physics: 'Vật lí: Bài 15 – Bài 20 (Chủ đề Ánh sáng Bài 15–17 & Chủ đề Từ Bài 18–20: Nam châm, Từ trường, Nam châm điện)',
      chemistry: 'Hóa học: Bài 6 – Bài 7 (Giới thiệu về liên kết hóa học, Hóa trị và công thức hóa học)',
      biology: 'Sinh học: Bài 33 – Bài 42 (Tập tính, Sinh trưởng phát triển, Sinh sản ở sinh vật, Cơ thể sinh vật là một thể thống nhất)',
    },
    questions: [
      // --- HÓA HỌC: BÀI 6 - BÀI 7 (8 CÂU) ---
      {
        id: 'hk2-chem-1',
        subject: 'chemistry',
        topic: 'Bài 6: Giới thiệu về liên kết hóa học',
        level: 'Nhận biết',
        question:
          'Khi hình thành phân tử Sodium chloride (muối ăn NaCl – Bài 6), nguyên tử Sodium (Na) đã nhường 1 electron lớp ngoài cùng cho nguyên tử Chlorine (Cl) để tạo thành:',
        options: [
          'Ion dương Na⁺ và ion âm Cl⁻ hút nhau bằng liên kết ion',
          'Ion âm Na⁻ và ion dương Cl⁺',
          'Hai nguyên tử khí hiếm Neon và Argon',
          'Liên kết cộng hóa trị không phân cực',
        ],
        correctIndex: 0,
        explanation:
          'Na (có 1e lớp ngoài cùng) nhường 1e tạo ion dương Na⁺; Cl (có 7e lớp ngoài cùng) nhận 1e tạo ion âm Cl⁻. Hai ion trái dấu hút nhau tạo liên kết ion trong NaCl.',
        formulaHint: 'Bài 6 KNTT: Na → Na⁺ + 1e; Cl + 1e → Cl⁻',
      },
      {
        id: 'hk2-chem-2',
        subject: 'chemistry',
        topic: 'Bài 6: Giới thiệu về liên kết hóa học',
        level: 'Thông hiểu',
        question:
          'Trong phân tử khí Oxygen (O₂), mỗi nguyên tử Oxygen có 6 electron ở lớp ngoài cùng nên hai nguyên tử Oxygen đã góp chung bao nhiêu electron để đạt vỏ bền vững 8 electron của khí hiếm?',
        options: [
          'Mỗi nguyên tử góp 1 electron (tạo 1 cặp electron dùng chung)',
          'Mỗi nguyên tử góp 2 electron (tạo 2 cặp electron dùng chung)',
          'Mỗi nguyên tử góp 3 electron (tạo 3 cặp electron dùng chung)',
          'Một nguyên tử nhường hẳn 2 electron cho nguyên tử kia',
        ],
        correctIndex: 1,
        explanation:
          'Mỗi nguyên tử O cần thêm 2e để đủ 8e lớp ngoài cùng, nên mỗi nguyên tử O góp 2e tạo thành 2 cặp electron dùng chung trong phân tử O₂.',
        formulaHint: 'Bài 6 KNTT: Phân tử O₂ có 2 cặp electron dùng chung',
      },
      {
        id: 'hk2-chem-3',
        subject: 'chemistry',
        topic: 'Bài 6: Giới thiệu về liên kết hóa học',
        level: 'Thông hiểu',
        question:
          'Tính chất nào sau đây là đặc điểm chung của các hợp chất ion (như muối ăn NaCl, Magnesium oxide MgO – Bài 6)?',
        options: [
          'Là chất khí ở điều kiện thường, không tan trong nước',
          'Là chất rắn ở điều kiện thường, có nhiệt độ nóng chảy và nhiệt độ sôi khá cao, khi tan trong nước tạo dung dịch dẫn được điện',
          'Rất dễ bay hơi ở nhiệt độ phòng và hoàn toàn không dẫn điện khi hòa tan',
          'Có nhiệt độ nóng chảy dưới 0 °C',
        ],
        correctIndex: 1,
        explanation:
          'Chất ion là chất rắn ở điều kiện thường, khó nóng chảy, khó bay hơi, nhiều chất tan tốt trong nước tạo thành dung dịch dẫn điện.',
        formulaHint: 'Bài 6 KNTT: Đặc điểm của hợp chất ion',
      },
      {
        id: 'hk2-chem-4',
        subject: 'chemistry',
        topic: 'Bài 7: Hóa trị và công thức hóa học',
        level: 'Nhận biết',
        question:
          'Trong hợp chất cộng hóa trị, quy ước nguyên tố Hydrogen (H) luôn có hóa trị bằng bao nhiêu và nguyên tố Oxygen (O) thường có hóa trị bằng bao nhiêu (Bài 7)?',
        options: [
          'H hóa trị I; O hóa trị II',
          'H hóa trị II; O hóa trị I',
          'H hóa trị I; O hóa trị III',
          'H hóa trị II; O hóa trị IV',
        ],
        correctIndex: 0,
        explanation:
          'Theo quy ước trong Bài 7: Hydrogen luôn có hóa trị I, còn Oxygen thường có hóa trị II.',
        formulaHint: 'Bài 7 KNTT: H (hóa trị I) · O (hóa trị II)',
      },
      {
        id: 'hk2-chem-5',
        subject: 'chemistry',
        topic: 'Bài 7: Hóa trị và công thức hóa học',
        level: 'Thông hiểu',
        question:
          'Theo quy tắc hóa trị đối với hợp chất gồm hai nguyên tố AₓBᵧ (với a, b lần lượt là hóa trị của A và B), biểu thức nào sau đây là ĐÚNG (Bài 7)?',
        options: [
          'x · a = y · b',
          'x · b = y · a',
          'x + a = y + b',
          'x / a = y / b',
        ],
        correctIndex: 0,
        explanation:
          'Quy tắc hóa trị: Trong công thức hóa học của hợp chất hai nguyên tố AₓBᵧ, tích của chỉ số và hóa trị của nguyên tố này bằng tích của chỉ số và hóa trị của nguyên tố kia: x · a = y · b.',
        formulaHint: 'Bài 7 KNTT: Quy tắc hóa trị x · a = y · b',
      },
      {
        id: 'hk2-chem-6',
        subject: 'chemistry',
        topic: 'Bài 7: Hóa trị và công thức hóa học',
        level: 'Vận dụng',
        question:
          'Trong công thức hóa học Fe₂O₃ (Iron(III) oxide), biết Oxygen có hóa trị II. Hóa trị của nguyên tố Iron (Fe) trong hợp chất này là:',
        options: ['Hóa trị I', 'Hóa trị II', 'Hóa trị III', 'Hóa trị IV'],
        correctIndex: 2,
        explanation:
          'Áp dụng quy tắc hóa trị cho Fe₂O₃: 2 · a = 3 · II ⇒ a = VI / 2 = III. Vậy Fe có hóa trị III.',
        formulaHint: 'Bài 7 KNTT: 2 · a = 3 · II ⇒ a = III',
      },
      {
        id: 'hk2-chem-7',
        subject: 'chemistry',
        topic: 'Bài 7: Hóa trị và công thức hóa học',
        level: 'Vận dụng',
        question:
          'Lập công thức hóa học của hợp chất tạo bởi Aluminium (Al có hóa trị III) và nhóm Sulfate (SO₄ có hóa trị II):',
        options: ['AlSO₄', 'Al₂(SO₄)₃', 'Al₃(SO₄)₂', 'Al₂SO₄'],
        correctIndex: 1,
        explanation:
          'Gọi công thức là Alₓ(SO₄)ᵧ. Theo quy tắc hóa trị: x · III = y · II ⇒ x/y = 2/3. Vậy công thức hóa học đúng là Al₂(SO₄)₃.',
        formulaHint: 'Bài 7 KNTT: Al(III) + SO₄(II) → Al₂(SO₄)₃',
      },
      {
        id: 'hk2-chem-8',
        subject: 'chemistry',
        topic: 'Bài 7: Hóa trị và công thức hóa học',
        level: 'Vận dụng',
        question:
          'Cho biết khối lượng nguyên tử Cu = 64 amu, O = 16 amu. Phần trăm khối lượng của nguyên tố Copper (%Cu) trong hợp chất Copper(II) oxide (CuO) là bao nhiêu?',
        options: ['50%', '64%', '80%', '20%'],
        correctIndex: 2,
        explanation:
          'Khối lượng phân tử CuO = 64 + 16 = 80 amu. Phần trăm khối lượng của Cu là: %Cu = (64 / 80) × 100% = 80%.',
        formulaHint: 'Bài 7 KNTT: %Cu = (64 / 80) × 100% = 80%',
      },

      // --- VẬT LÍ: BÀI 15 - BÀI 20 (8 CÂU) ---
      {
        id: 'hk2-phys-1',
        subject: 'physics',
        topic: 'Bài 15: Năng lượng ánh sáng. Tia sáng, vùng tối',
        level: 'Nhận biết',
        question:
          'Để biểu diễn đường truyền của ánh sáng trong môi trường trong suốt và đồng tính (Bài 15), người ta sử dụng hình ảnh nào?',
        options: [
          'Một đường cong bất kì có mũi tên',
          'Một đường thẳng có mũi tên chỉ hướng truyền của ánh sáng, gọi là tia sáng',
          'Các vòng tròn đồng tâm lan rộng',
          'Một đường gấp khúc liên tục',
        ],
        correctIndex: 1,
        explanation:
          'Đường truyền của ánh sáng được biểu diễn bằng một đường thẳng có mũi tên chỉ hướng, gọi là tia sáng.',
        formulaHint: 'Bài 15 KNTT: Khái niệm tia sáng và chùm sáng',
      },
      {
        id: 'hk2-phys-2',
        subject: 'physics',
        topic: 'Bài 16: Sự phản xạ ánh sáng',
        level: 'Vận dụng',
        question:
          'Chiếu một tia sáng vuông góc với mặt một gương phẳng (tia tới trùng với pháp tuyến tại điểm tới). Góc tới i và góc phản xạ i\' khi đó bằng bao nhiêu?',
        options: [
          'i = 90°, i\' = 90°',
          'i = 0°, i\' = 0°',
          'i = 45°, i\' = 45°',
          'i = 0°, i\' = 90°',
        ],
        correctIndex: 1,
        explanation:
          'Khi tia tới vuông góc với mặt gương thì tia tới trùng với pháp tuyến nên góc tới i = 0°. Theo định luật phản xạ ánh sáng, góc phản xạ i\' = i = 0° (tia phản xạ truyền ngược lại theo phương tia tới).',
        formulaHint: 'Bài 16 KNTT: Tia tới vuông góc mặt gương ⇒ i = i\' = 0°',
      },
      {
        id: 'hk2-phys-3',
        subject: 'physics',
        topic: 'Bài 17: Ảnh của vật tạo bởi gương phẳng',
        level: 'Thông hiểu',
        question:
          'Một vật sáng AB cao 12 cm đặt song song trước một gương phẳng và cách gương 20 cm. Ảnh A\'B\' của vật AB tạo bởi gương phẳng có chiều cao bằng bao nhiêu?',
        options: ['6 cm', '12 cm', '20 cm', '24 cm'],
        correctIndex: 1,
        explanation:
          'Độ lớn (chiều cao) của ảnh tạo bởi gương phẳng luôn bằng độ lớn của vật, nên ảnh A\'B\' cao 12 cm.',
        formulaHint: 'Bài 17 KNTT: Độ lớn của ảnh luôn bằng độ lớn của vật',
      },
      {
        id: 'hk2-phys-4',
        subject: 'physics',
        topic: 'Bài 18: Nam châm',
        level: 'Nhận biết',
        question:
          'Nam châm vĩnh cửu có khả năng hút mạnh các vật được làm bằng những kim loại nào sau đây (Bài 18)?',
        options: [
          'Nhôm (Al), đồng (Cu) và bạc (Ag)',
          'Sắt (Fe), thép, niken (Ni) và côban (Co)',
          'Vàng (Au), kẽm (Zn) và nhựa',
          'Gỗ khô, thủy tinh và cao su',
        ],
        correctIndex: 1,
        explanation:
          'Nam châm hút các vật liệu từ như sắt (Fe), thép, niken (Ni), côban (Co) và không hút đồng, nhôm.',
        formulaHint: 'Bài 18 KNTT: Vật liệu từ gồm Sắt, Thép, Niken, Côban',
      },
      {
        id: 'hk2-phys-5',
        subject: 'physics',
        topic: 'Bài 18: Nam châm',
        level: 'Thông hiểu',
        question:
          'Khi đưa hai cực của hai thanh nam châm lại gần nhau (Bài 18), hiện tượng tương tác từ xảy ra như thế nào?',
        options: [
          'Hai cực cùng tên (N–N hoặc S–S) thì đẩy nhau; hai cực khác tên (N–S) thì hút nhau',
          'Hai cực cùng tên thì hút nhau; hai cực khác tên thì đẩy nhau',
          'Mọi cực của nam châm đều chỉ hút nhau chứ không đẩy nhau',
          'Chỉ có cực Bắc (N) mới có lực từ, còn cực Nam (S) không có lực từ',
        ],
        correctIndex: 0,
        explanation:
          'Hai cực từ cùng tên đẩy nhau, hai cực từ khác tên hút nhau.',
        formulaHint: 'Bài 18 KNTT: Cùng cực đẩy nhau · Khác cực hút nhau',
      },
      {
        id: 'hk2-phys-6',
        subject: 'physics',
        topic: 'Bài 19: Từ trường',
        level: 'Nhận biết',
        question:
          'Chiều của đường sức từ ở bên ngoài một thanh nam châm thẳng được quy ước như thế nào (Bài 19)?',
        options: [
          'Đi ra từ cực Nam (S) và đi vào cực Bắc (N)',
          'Đi ra từ cực Bắc (N) và đi vào cực Nam (S) của nam châm',
          'Đi từ chính giữa thanh nam châm ra hai đầu cực',
          'Không có chiều xác định',
        ],
        correctIndex: 1,
        explanation:
          'Bên ngoài thanh nam châm, các đường sức từ là những đường cong có chiều đi ra từ cực Bắc (N) và đi vào cực Nam (S).',
        formulaHint: 'Bài 19 KNTT: Quy ước đường sức từ: Ra Bắc (N) – Vào Nam (S)',
      },
      {
        id: 'hk2-phys-7',
        subject: 'physics',
        topic: 'Bài 19: Từ trường',
        level: 'Thông hiểu',
        question:
          'Vì sao kim nam châm của la bàn đặt trên mặt đất luôn chỉ hướng Bắc – Nam địa lí (Bài 19)?',
        options: [
          'Vì gió trên mặt đất luôn thổi theo hướng Bắc – Nam',
          'Vì Trái Đất là một nam châm khổng lồ có từ trường tác dụng lực từ lên kim nam châm của la bàn',
          'Vì ánh sáng mặt trời đẩy kim nam châm quay về hướng Bắc',
          'Vì vỏ la bàn làm bằng nhựa nhiễm điện',
        ],
        correctIndex: 1,
        explanation:
          'Trái Đất là một nam châm khổng lồ có cực từ Bắc và cực từ Nam, tạo ra từ trường Trái Đất định hướng cho kim la bàn.',
        formulaHint: 'Bài 19 KNTT: Từ trường Trái Đất và nguyên lí hoạt động của la bàn',
      },
      {
        id: 'hk2-phys-8',
        subject: 'physics',
        topic: 'Bài 20: Chế tạo nam châm điện đơn giản',
        level: 'Vận dụng',
        question:
          'Để làm tăng lực từ của một nam châm điện tự chế trong Bài 20 (gồm ống dây đồng quấn quanh lõi sắt non nối với nguồn điện), ta có thể thực hiện biện pháp nào sau đây?',
        options: [
          'Thay lõi sắt non bằng một que nhựa hoặc que gỗ',
          'Tăng số vòng dây của ống dây và tăng cường độ dòng điện (dùng thêm pin nối tiếp) chạy qua ống dây',
          'Giảm số vòng dây và ngắt dòng điện khỏi ống dây',
          'Đổi chiều dòng điện chạy qua ống dây nhưng giữ nguyên số vòng dây',
        ],
        correctIndex: 1,
        explanation:
          'Lực từ của nam châm điện mạnh lên khi tăng cường độ dòng điện chạy qua các vòng dây hoặc tăng số vòng của ống dây. Đổi chiều dòng điện chỉ làm đổi tên hai cực từ chứ không làm tăng độ mạnh lực từ.',
        formulaHint: 'Bài 20 KNTT: Tăng số vòng dây N + Tăng cường độ dòng điện I ⇒ Tăng lực từ nam châm điện',
      },

      // --- SINH HỌC: BÀI 33 - BÀI 42 (8 CÂU) ---
      {
        id: 'hk2-bio-1',
        subject: 'biology',
        topic: 'Bài 33: Tập tính ở động vật',
        level: 'Nhận biết',
        question:
          'Hiện tượng chim én bay về phương Nam tránh rét vào mùa đông và cá hồi vượt thác quay về nơi sinh ra để đẻ trứng thuộc những dạng tập tính nào của động vật (Bài 33)?',
        options: [
          'Tập tính di cư và tập tính sinh sản',
          'Tập tính kiếm ăn và tập tính học tập nhân tạo',
          'Tập tính ngủ đông và tập tính vệ sinh cơ thể',
          'Tập tính bảo vệ lãnh thổ của thú ăn thịt',
        ],
        correctIndex: 0,
        explanation:
          'Chim én bay về phương Nam là tập tính di cư; cá hồi vượt thác về thượng nguồn đẻ trứng là tập tính di cư gắn liền với tập tính sinh sản.',
        formulaHint: 'Bài 33 KNTT: Các dạng tập tính phổ biến ở động vật',
      },
      {
        id: 'hk2-bio-2',
        subject: 'biology',
        topic: 'Bài 34 & 36: Sinh trưởng và phát triển ở sinh vật',
        level: 'Thông hiểu',
        question:
          'Nhân tố bên trong quan trọng nhất quy định tốc độ và giới hạn sinh trưởng, phát triển của mỗi loài sinh vật (ví dụ gà tre lớn hết cỡ chỉ nặng khoảng 1 kg, còn gà Đông Tảo nặng 4–5 kg) là gì?',
        options: [
          'Nhiệt độ chuồng nuôi',
          'Yếu tố di truyền (đặc điểm của loài/giống) và hormone sinh trưởng',
          'Độ ẩm không khí',
          'Lượng nước uống hằng ngày',
        ],
        correctIndex: 1,
        explanation:
          'Mỗi loài và giống sinh vật có giới hạn sinh trưởng do yếu tố di truyền quy định, đồng thời chịu sự điều hòa của hệ thống hormone.',
        formulaHint: 'Bài 36 KNTT: Nhân tố bên trong (Di truyền & Hormone) + Nhân tố bên ngoài',
      },
      {
        id: 'hk2-bio-3',
        subject: 'biology',
        topic: 'Bài 37: Ứng dụng sinh trưởng và phát triển ở sinh vật vào thực tiễn',
        level: 'Vận dụng',
        question:
          'Khi trồng các loại cây lấy quả như bầu, bí, mướp hoặc cà chua, người làm vườn thường tiến hành "bấm ngọn" khi cây đạt chiều dài nhất định nhằm mục đích gì (Bài 37)?',
        options: [
          'Để cây ngừng quang hợp hoàn toàn',
          'Để xóa bỏ ưu thế ngọn, kích thích các chồi nách phát triển thành nhiều nhánh bên giúp cây ra nhiều hoa và đậu nhiều quả hơn',
          'Để rễ cây ngừng hút nước và muối khoáng',
          'Để làm thân cây thẳng đứng không cần giàn leo',
        ],
        correctIndex: 1,
        explanation:
          'Chồi ngọn tiết hormone ức chế chồi bên. Bấm ngọn giúp kích thích các chồi nách phát triển thành nhánh mới, tăng năng suất hoa và quả.',
        formulaHint: 'Bài 37 KNTT: Kĩ thuật bấm ngọn, tỉa cành điều khiển sinh trưởng ở thực vật',
      },
      {
        id: 'hk2-bio-4',
        subject: 'biology',
        topic: 'Bài 38: Các yếu tố ảnh hưởng đến sinh sản và điều hòa sinh sản ở sinh vật',
        level: 'Nhận biết',
        question:
          'Hình thức sinh sản không có sự kết hợp giữa giao tử đực và giao tử cái, cơ thể con được hình thành từ một phần cơ quan sinh dưỡng (rễ, thân, lá) của cơ thể mẹ được gọi là gì (Bài 38–39)?',
        options: [
          'Sinh sản hữu tính',
          'Sinh sản vô tính (sinh sản sinh dưỡng ở thực vật)',
          'Thụ tinh kép ở thực vật có hoa',
          'Phát triển qua biến thái',
        ],
        correctIndex: 1,
        explanation:
          'Sinh sản vô tính là hình thức sinh sản không có sự hợp nhất giao tử đực và cái, con sinh ra có đặc điểm giống hệt cơ thể mẹ.',
        formulaHint: 'Bài 38–39 KNTT: Sinh sản vô tính vs Sinh sản hữu tính',
      },
      {
        id: 'hk2-bio-5',
        subject: 'biology',
        topic: 'Bài 39: Sinh sản vô tính ở sinh vật',
        level: 'Thông hiểu',
        question:
          'Trong sản xuất nông nghiệp, các phương pháp nhân giống vô tính ở cây ăn quả như giâm cành, chiết cành, ghép cây có ưu điểm nổi bật nào so với gieo từ hạt?',
        options: [
          'Tạo ra cây con có bộ rễ cọc ăn rất sâu và tuổi thọ dài hơn cây gieo hạt',
          'Giữ nguyên được các đặc tính tốt của cây mẹ và rút ngắn thời gian cho thu hoạch quả (nhanh ra hoa, kết quả)',
          'Tạo ra nhiều biến dị hoàn toàn mới khác hẳn cây mẹ',
          'Không cần chăm sóc và tưới nước cho cây con',
        ],
        correctIndex: 1,
        explanation:
          'Giâm cành, chiết cành, ghép cây là ứng dụng sinh sản vô tính giúp cây con giữ nguyên phẩm chất tốt của cây mẹ và sớm ra hoa kết quả.',
        formulaHint: 'Bài 39 KNTT: Ứng dụng giâm cành, chiết cành, ghép cây, nuôi cấy mô',
      },
      {
        id: 'hk2-bio-6',
        subject: 'biology',
        topic: 'Bài 40: Sinh sản hữu tính ở sinh vật',
        level: 'Nhận biết',
        question:
          'Ở thực vật có hoa (Bài 40), sau khi quá trình thụ phấn và thụ tinh diễn ra thành công, bộ phận nào của hoa sẽ phát triển thành HẠT và bộ phận nào phát triển thành QUẢ?',
        options: [
          'Noãn đã thụ tinh phát triển thành hạt; Bầu nhụy phát triển thành quả chứa hạt',
          'Hạt phấn phát triển thành quả; Cánh hoa phát triển thành hạt',
          'Đài hoa phát triển thành hạt; Nhị hoa phát triển thành quả',
          'Đầu nhụy phát triển thành hạt; Cuống hoa phát triển thành quả',
        ],
        correctIndex: 0,
        explanation:
          'Sau khi thụ tinh, hợp tử phát triển thành phôi, noãn phát triển thành hạt chứa phôi, còn bầu nhụy sinh trưởng dày lên phát triển thành quả.',
        formulaHint: 'Bài 40 KNTT: Noãn thụ tinh → Hạt · Bầu nhụy → Quả',
      },
      {
        id: 'hk2-bio-7',
        subject: 'biology',
        topic: 'Bài 41: Một số yếu tố ảnh hưởng và điều hòa, điều khiển sinh sản ở sinh vật',
        level: 'Thông hiểu',
        question:
          'Biện pháp thụ phấn nhân tạo cho hoa bầu, bí, dưa hấu hoặc tiêm hormone kích thích sinh sản cho cá mè, cá trắm cỏ trong trại giống nhằm mục đích gì (Bài 41)?',
        options: [
          'Làm giảm số lượng con non sinh ra',
          'Chủ động điều khiển sinh sản giúp tăng tỉ lệ thụ tinh, tăng tỉ lệ đậu quả và nhân giống vật nuôi hiệu quả',
          'Biến sinh sản hữu tính thành sinh sản vô tính',
          'Ngăn cản hoàn toàn sự phát triển của phôi',
        ],
        correctIndex: 1,
        explanation:
          'Con người chủ động thụ phấn bổ sung và sử dụng hormone sinh sản để nâng cao tỉ lệ thụ tinh, đậu quả và hiệu suất nhân giống.',
        formulaHint: 'Bài 41 KNTT: Điều khiển sinh sản ở thực vật và động vật',
      },
      {
        id: 'hk2-bio-8',
        subject: 'biology',
        topic: 'Bài 42: Cơ thể sinh vật là một thể thống nhất',
        level: 'Thông hiểu',
        question:
          'Vì sao khẳng định "Cơ thể sinh vật là một thể thống nhất" (Bài 42)?',
        options: [
          'Vì các cơ quan trong cơ thể hoạt động hoàn toàn tách biệt nhau',
          'Vì có sự phối hợp thống nhất từ cấp độ tế bào – mô – cơ quan – hệ cơ quan – cơ thể thông qua các hoạt động trao đổi chất, cảm ứng, sinh trưởng, phát triển và sinh sản gắn bó mật thiết với môi trường',
          'Vì mọi sinh vật trên Trái Đất đều chỉ cấu tạo từ một tế bào duy nhất',
          'Vì ở thực vật có hệ thần kinh điều khiển còn động vật thì không',
        ],
        correctIndex: 1,
        explanation:
          'Trong cơ thể đa bào, tế bào – cơ quan – cơ thể có mối quan hệ chặt chẽ; mọi hoạt động sống (trao đổi chất, cảm ứng, sinh trưởng, sinh sản) tác động qua lại tạo nên một thể thống nhất.',
        formulaHint: 'Bài 42 KNTT: Tế bào ⇄ Cơ quan ⇄ Hệ cơ quan ⇄ Cơ thể ⇄ Môi trường',
      },
    ],
  },
];

const CUSTOM_TEACHER_EXAMS_KEY = 'khtn7_custom_teacher_exams_v2';

export function loadCustomTeacherExams(): ExamPaperDefinition[] {
  try {
    const raw = localStorage.getItem(CUSTOM_TEACHER_EXAMS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // ignore
  }
  return [];
}

export function saveCustomTeacherExams(exams: ExamPaperDefinition[]): void {
  try {
    localStorage.setItem(CUSTOM_TEACHER_EXAMS_KEY, JSON.stringify(exams));
  } catch {
    // ignore
  }
}
