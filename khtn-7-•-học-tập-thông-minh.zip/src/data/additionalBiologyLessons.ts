import { KhtnLesson, McqItem } from './lessonTypes';

const makeBioMcqs = (
  prefix: string,
  raw: Array<[string, [string, string, string, string], number, string]>
): McqItem[] =>
  raw.map(([question, options, correctIndex, explanation], idx) => ({
    id: `${prefix}-mcq-${idx + 1}`,
    question,
    options,
    correctIndex,
    explanation,
    level: idx < 7 ? 'Nhận biết' : idx < 13 ? 'Thông hiểu' : 'Vận dụng',
  }));

export const ADDITIONAL_BIOLOGY_LESSONS: KhtnLesson[] = [
  // =========================================================================
  // BÀI 27: TRAO ĐỔI KHÍ Ở SINH VẬT
  // =========================================================================
  {
    id: 'kntt-bai-27',
    lessonNumber: 27,
    title: 'Bài 27: Trao đổi khí ở sinh vật',
    chapterTitle: 'Chương VII: Trao đổi chất và chuyển hóa năng lượng',
    subject: 'biology',
    summary:
      'Trao đổi khí là sự trao đổi khí O₂ và CO₂ giữa cơ thể sinh vật với môi trường theo cơ chế khuếch tán. Ở thực vật, trao đổi khí thực hiện chủ yếu qua khí khổng ở lá. Ở động vật, trao đổi khí thực hiện qua bề mặt cơ thể (giun đất), hệ thống ống khí (côn trùng), mang (cá, tôm) hoặc phổi (bò sát, chim, thú, người).',
    keyFormulas: [
      'Cơ chế trao đổi khí: Khuếch tán từ nơi có nồng độ cao đến nơi có nồng độ thấp',
      'Khí khổng ở lá: Gồm 2 tế bào hình hạt đậu (No nước → Khí khổng MỞ; Mất nước → Khí khổng ĐÓNG)',
      'Cơ quan trao đổi khí ở động vật: Qua da ẩm (Giun đất) | Ống khí (Châu chấu) | Mang (Cá) | Phổi (Chim, Thú, Người)',
    ],
    mcqs: makeBioMcqs('b27', [
      ['Trao đổi khí ở sinh vật là quá trình:', ['Cơ thể lấy khí O₂ hoặc CO₂ từ môi trường vào cơ thể và thải khí CO₂ hoặc O₂ từ cơ thể ra môi trường.', 'Chỉ lấy hơi nước từ không khí.', 'Chỉ diễn ra ở động vật mà không diễn ra ở thực vật.', 'Vận chuyển nước trong mạch gỗ.'], 0, 'Thực vật trao đổi khí trong cả quang hợp và hô hấp; động vật lấy O₂ và thải CO₂ trong hô hấp.'],
      ['Các phân tử khí (O₂, CO₂) di chuyển qua bề mặt trao đổi khí dựa theo cơ chế nào?', ['Cơ chế khuếch tán (từ nơi có nồng độ cao đến nơi có nồng độ thấp).', 'Cơ chế đông đặc.', 'Cơ chế nóng chảy.', 'Cơ chế phản xạ ánh sáng.'], 0, 'Các chất khí di chuyển tự nhiên từ vùng có phân áp/nồng độ cao sang vùng có nồng độ thấp.'],
      ['Ở thực vật trên cạn, quá trình trao đổi khí giữa cây với môi trường diễn ra chủ yếu qua bộ phận nào ở biểu bì lá?', ['Gân lá.', 'Khí khổng (lỗ khí).', 'Cuống lá.', 'Chóp rễ.'], 1, 'Khí khổng trên biểu bì lá là cửa ngõ chính để CO₂, O₂ và hơi nước khuếch tán qua lại.'],
      ['Mỗi khí khổng ở lá cây được cấu tạo bởi:', ['Hai tế bào hình hạt đậu nằm áp sát vào nhau (thành trong dày, thành ngoài mỏng).', 'Một tế bào hình cầu duy nhất.', 'Bốn tế bào mạch gỗ.', 'Các tế bào lông hút.'], 0, 'Hai tế bào hình hạt đậu xếp đối diện nhau tạo khe khí khổng ở giữa.'],
      ['Khi hai tế bào hình hạt đậu của khí khổng trương nước (no nước) thì:', ['Thành mỏng phía ngoài căng ra làm thành dày cong theo ⇒ lỗ khí khổng MỞ.', 'Lỗ khí khổng đóng kín hoàn toàn.', 'Khí khổng biến mất.', 'Lá cây rụng ngay.'], 0, 'Khi no nước, thành ngoài mỏng dãn mạnh kéo thành trong cong theo làm mở khe khí khổng.'],
      ['Khi cây bị thiếu nước (tế bào hình hạt đậu mất nước), khí khổng sẽ:', ['Mở rộng tối đa.', 'Đóng lại (khép hờ) để hạn chế sự mất hơi nước của cây.', 'Vỡ tung ra.', 'Chuyển sang màu đỏ.'], 1, 'Khi mất nước, thành mỏng hết căng và thành dày duỗi thẳng làm khe khí khổng khép lại.'],
      ['Ở phần lớn các loài cây gỗ hai lá mầm trên cạn, khí khổng thường phân bố ở đâu nhiều hơn?', ['Mặt dưới của phiến lá nhiều hơn mặt trên (để tránh ánh nắng chiếu trực tiếp làm mất nước quá nhiều).', 'Chỉ có ở rễ cây.', 'Chỉ có ở thân gỗ già.', 'Mặt trên nhiều gấp 100 lần mặt dưới.'], 0, 'Biểu bì mặt dưới lá có nhiều khí khổng hơn mặt trên nhằm giảm bớt sự đốt nóng và thoát hơi nước quá mức dưới nắng.'],
      ['Vào ban ngày khi trời nắng, ở lá cây xanh diễn ra đồng thời cả quang hợp và hô hấp. Khi đó chiều khuếch tán tổng cộng của các khí qua khí khổng là:', ['Lấy vào khí CO₂ và thải ra khí O₂ (vì cường độ quang hợp mạnh hơn nhiều so với hô hấp).', 'Chỉ lấy vào khí N₂.', 'Chỉ thải ra khí CO₂.', 'Không trao đổi khí.'], 0, 'Ban ngày quang hợp mạnh nên lá hấp thụ CO₂ từ không khí và nhả nhiều O₂ ra môi trường.'],
      ['Vào ban đêm (không có ánh sáng), sự trao đổi khí qua khí khổng ở lá cây diễn ra như thế nào?', ['Cây lấy vào khí O₂ và thải ra khí CO₂ (do chỉ có quá trình hô hấp diễn ra).', 'Cây lấy vào CO₂ và thải O₂.', 'Cây ngừng hoàn toàn mọi trao đổi khí.', 'Cây thải ra khí Helium.'], 0, 'Ban đêm không có ánh sáng nên cây ngừng quang hợp, chỉ còn hô hấp tế bào (lấy O₂, thải CO₂).'],
      ['Loài động vật nào sau đây thực hiện trao đổi khí trực tiếp qua bề mặt da ẩm ướt?', ['Châu chấu.', 'Giun đất.', 'Cá chép.', 'Chim bồ câu.'], 1, 'Giun đất, thủy tức trao đổi khí trực tiếp qua bề mặt cơ thể (da mỏng và ẩm ướt).'],
      ['Các loài côn trùng như châu chấu, cào cào, ong, bướm trao đổi khí qua cơ quan nào?', ['Mang.', 'Phổi.', 'Hệ thống ống khí phân nhánh thông ra ngoài qua các lỗ thở ở bụng.', 'Qua da.'], 2, 'Côn trùng có hệ thống ống khí dẫn khí trực tiếp tới từng tế bào trong cơ thể.'],
      ['Các loài động vật sống dưới nước như cá chép, tôm, cua, trai sông trao đổi khí qua cơ quan nào?', ['Mang.', 'Phổi.', 'Hệ thống ống khí.', 'Khí khổng.'], 0, 'Mang gồm các cung mang chứa nhiều phiến mang mỏng giàu mao mạch máu giúp hấp thụ O₂ hòa tan trong nước.'],
      ['Các loài bò sát (thằn lằn, cá sấu), chim (bồ câu, đại bàng) và thú (chó, mèo, con người) trao đổi khí qua cơ quan nào?', ['Mang.', 'Phổi.', 'Qua da.', 'Ống khí.'], 1, 'Bò sát, chim, thú và người đều hô hấp bằng phổi.'],
      ['Tại sao khi bắt giun đất để lên mặt tờ giấy khô dưới nắng một lúc thì giun đất sẽ chết?', ['Vì giun đất bị đói thức ăn.', 'Vì da giun đất bị khô làm khí O₂ và CO₂ không thể khuếch tán qua da được nữa khiến giun bị ngạt thở.', 'Vì giun đất không nhìn thấy đường.', 'Vì giun đất bị gãy xương.'], 1, 'Da giun đất phải luôn ẩm ướt thì chất khí mới hòa tan và khuếch tán qua được; da khô làm giun ngạt thở mà chết.'],
      ['Ở người, khi hít vào, không khí đi qua đường dẫn khí vào đến hai lá phổi. Tại các phế nang của phổi diễn ra quá trình gì?', ['Khí O₂ từ phế nang khuếch tán vào máu và khí CO₂ từ máu khuếch tán vào phế nang để thải ra ngoài.', 'Khí CO₂ từ phế nang đi vào máu.', 'Nước từ phổi chảy vào tim.', 'Thức ăn được tiêu hóa ở phổi.'], 0, 'Tại mạng lưới mao mạch bao quanh phế nang, O₂ khuếch tán vào máu đi nuôi cơ thể, còn CO₂ từ máu khuếch tán vào phế nang để thở ra.'],
      ['Vì sao khi bắt cá lên cạn một thời gian thì cá sẽ bị ngạt thở và chết dù trong không khí có rất nhiều khí Oxygen?', ['Vì trên cạn không có nước làm các phiến mang của cá bị dính bết lại với nhau và khô đi, làm diện tích trao đổi khí giảm mạnh khiến cá không lấy được O₂.', 'Vì trong không khí không có khí O₂.', 'Vì cá bị lạnh khi lên bờ.', 'Vì ánh sáng làm cá chết.'], 0, 'Khi ở dưới nước, dòng nước nâng các phiến mang tách rời nhau; khi lên cạn các phiến mang xẹp dính vào nhau và khô đi nên cá không trao đổi khí được.'],
      ['Hành động nào sau đây giúp bảo vệ hệ hô hấp và tăng cường hiệu quả trao đổi khí ở người?', ['Hút thuốc lá thường xuyên.', 'Tập thể dục thể thao đều đặn, hít thở sâu, trồng nhiều cây xanh và đeo khẩu trang nơi nhiều khói bụi.', 'Đóng kín toàn bộ cửa phòng và đốt than tổ ong khi ngủ.', 'Sống ở nơi có nhiều khí thải công nghiệp.'], 1, 'Tập thể dục, giữ môi trường trong lành và tránh khói thuốc lá giúp bảo vệ phổi khỏe mạnh.'],
      ['Khi lau sạch bụi bám trên mặt lá của các cây cảnh trồng trong nhà, hoạt động nào của cây sẽ được cải thiện rõ rệt?', ['Rễ cây ngừng mọc.', 'Các khí khổng không bị bụi bít kín nên quá trình trao đổi khí và quang hợp diễn ra thuận lợi hơn.', 'Cây không cần tưới nước nữa.', 'Lá cây rụng nhanh hơn.'], 1, 'Lau bụi trên lá giúp thông thoáng các khí khổng, tăng hiệu quả trao đổi khí và hấp thụ ánh sáng.'],
    ]),
    trueFalseList: [
      {
        id: 'b27-tf-1',
        stem: 'Xét cấu tạo và hoạt động của khí khổng ở lá thực vật:',
        statements: [
          { id: 'a', text: 'Khí khổng tập trung chủ yếu ở lớp biểu bì của lá cây, gồm hai tế bào hình hạt đậu tạo nên lỗ khí.', isTrue: true, explanation: 'Đúng cấu tạo khí khổng.' },
          { id: 'b', text: 'Thành trong (phía tiếp giáp lỗ khí) của tế bào hình hạt đậu dày hơn thành ngoài.', isTrue: true, explanation: 'Đúng đặc điểm cấu tạo giúp khí khổng đóng mở khi trương nước.' },
          { id: 'c', text: 'Khi tế bào hình hạt đậu no nước (trương nước), lỗ khí khổng sẽ đóng chặt lại.', isTrue: false, explanation: 'Sai, khi trương nước thì lỗ khí khổng mở rộng ra.' },
          { id: 'd', text: 'Qua khí khổng, cây thực hiện cả sự trao đổi khí (CO₂, O₂) và sự thoát hơi nước.', isTrue: true, explanation: 'Đúng hai chức năng của khí khổng.' },
        ],
      },
      {
        id: 'b27-tf-2',
        stem: 'Xét chiều trao đổi khí trong quang hợp và hô hấp ở thực vật:',
        statements: [
          { id: 'a', text: 'Trong quá trình quang hợp, lá cây lấy khí CO₂ từ không khí qua khí khổng và thải khí O₂ ra môi trường.', isTrue: true, explanation: 'Đúng chiều trao đổi khí của quang hợp.' },
          { id: 'b', text: 'Trong quá trình hô hấp, các cơ quan của cây lấy khí O₂ và thải ra khí CO₂.', isTrue: true, explanation: 'Đúng chiều trao đổi khí của hô hấp.' },
          { id: 'c', text: 'Vào ban đêm, cây xanh vẫn tiếp tục lấy CO₂ và nhả nhiều O₂ giúp phòng ngủ kín thoáng mát hơn.', isTrue: false, explanation: 'Sai, ban đêm cây ngừng quang hợp, chỉ hô hấp lấy O₂ và thải CO₂.' },
          { id: 'd', text: 'Ngoài khí khổng ở lá, ở thân gỗ còn có các lỗ vỏ (bì khổng) và ở rễ sự trao đổi khí diễn ra qua lớp biểu bì rễ.', isTrue: true, explanation: 'Đúng, toàn bộ cơ thể thực vật đều trao đổi khí.' },
        ],
      },
      {
        id: 'b27-tf-3',
        stem: 'Xét cơ quan trao đổi khí của các nhóm động vật khác nhau:',
        statements: [
          { id: 'a', text: 'Thủy tức và giun đất trao đổi khí trực tiếp qua bề mặt cơ thể (da mỏng và ẩm ướt).', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Côn trùng (châu chấu, gián, ong) trao đổi khí qua hệ thống ống khí thông với bên ngoài nhờ các lỗ thở.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Cá voi và cá heo sống dưới biển nên trao đổi khí bằng mang giống như cá chép.', isTrue: false, explanation: 'Sai, cá voi và cá heo thuộc lớp Thú nên hô hấp bằng phổi (phải ngoi lên mặt nước để lấy không khí).' },
          { id: 'd', text: 'Ếch đồng trưởng thành vừa trao đổi khí qua phổi vừa trao đổi khí qua lớp da ẩm ướt.', isTrue: true, explanation: 'Đúng đặc điểm hô hấp của lớp Lưỡng cư.' },
        ],
      },
      {
        id: 'b27-tf-4',
        stem: 'Xét quá trình trao đổi khí ở cơ thể người:',
        statements: [
          { id: 'a', text: 'Hệ hô hấp của người gồm đường dẫn khí (mũi, họng, thanh quản, khí quản, phế quản) và hai lá phổi.', isTrue: true, explanation: 'Đúng cấu tạo hệ hô hấp người.' },
          { id: 'b', text: 'Tại các phế nang trong phổi, khí O₂ khuếch tán từ không khí phế nang vào máu, còn khí CO₂ khuếch tán từ máu ra phế nang.', isTrue: true, explanation: 'Đúng sự trao đổi khí ở phổi.' },
          { id: 'c', text: 'Tại các tế bào mô trong cơ thể, khí O₂ khuếch tán từ máu vào tế bào, còn khí CO₂ từ tế bào khuếch tán vào máu.', isTrue: true, explanation: 'Đúng sự trao đổi khí ở tế bào.' },
          { id: 'd', text: 'Không khí thở ra có tỉ lệ khí O₂ cao hơn và tỉ lệ khí CO₂ thấp hơn so với không khí khi hít vào.', isTrue: false, explanation: 'Sai, không khí thở ra có nồng độ O₂ thấp hơn và nồng độ CO₂ cao hơn so với không khí hít vào.' },
        ],
      },
      {
        id: 'b27-tf-5',
        stem: 'Xét mối liên hệ giữa môi trường sống và hoạt động trao đổi khí:',
        statements: [
          { id: 'a', text: 'Làm đất tơi xốp và thoát nước tốt giúp rễ cây có đủ khí O₂ trong các khe đất để thực hiện trao đổi khí.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Trong bể nuôi cá cảnh hoặc đầm nuôi tôm mật độ cao, người ta lắp máy sục khí để tăng lượng khí O₂ hòa tan trong nước.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Khói bụi ô nhiễm và khói thuốc lá gây tổn thương các phế nang, làm giảm diện tích và hiệu quả trao đổi khí ở phổi người.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Nếu bôi một lớp sáp (vaseline) kín cả hai mặt lá của cây thì cây vẫn trao đổi khí qua lá bình thường.', isTrue: false, explanation: 'Sai, lớp sáp bít kín toàn bộ khí khổng làm lá không thể trao đổi khí và thoát hơi nước.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b27-es-1',
        question: 'Câu 1 [SGK KHTN 7 - KNTT]: Mô tả cấu tạo của khí khổng và giải thích cơ chế đóng – mở khí khổng ở lá cây. Sự đóng – mở khí khổng có ý nghĩa gì đối với thực vật?',
        hint: 'Chú ý độ dày không đều của thành trong và thành ngoài tế bào hình hạt đậu.',
        sampleAnswer: '- Cấu tạo khí khổng: Gồm hai tế bào hình hạt đậu nằm áp sát vào nhau tạo thành lỗ khí ở giữa. Thành trong của tế bào hình hạt đậu dày, thành ngoài mỏng.\n- Cơ chế đóng – mở:\n  + Khi cây đủ nước, tế bào hình hạt đậu trương nước (no nước), thành mỏng căng mạnh kéo thành dày cong theo ⇒ lỗ khí khổng mở.\n  + Khi cây thiếu nước, tế bào hình hạt đậu mất nước, thành mỏng hết căng làm thành dày duỗi thẳng ⇒ lỗ khí khổng đóng lại.\n- Ý nghĩa: Giúp cây chủ động điều tiết sự trao đổi khí (lấy CO₂ cho quang hợp, lấy O₂ cho hô hấp) và kiểm soát sự thoát hơi nước để không bị héo khi khô hạn.',
        rubricPoints: [
          'Mô tả đúng cấu tạo 2 tế bào hình hạt đậu (thành trong dày, thành ngoài mỏng).',
          'Giải thích đúng cơ chế đóng mở khi no nước và mất nước.',
        ],
      },
      {
        id: 'b27-es-2',
        question: 'Câu 2 [SGK KHTN 7 - KNTT]: Kể tên cơ quan trao đổi khí của các loài động vật sau: Giun đất, Châu chấu, Cá chép, Ếch đồng, Chim bồ câu, Con người. Giải thích vì sao khi bắt giun đất để trên mặt đất khô ráo thì giun rất nhanh bị chết?',
        hint: 'Liên hệ điều kiện bề mặt trao đổi khí qua da phải luôn ẩm ướt.',
        sampleAnswer: '- Cơ quan trao đổi khí:\n  + Giun đất: Qua bề mặt da ẩm ướt.\n  + Châu chấu: Hệ thống ống khí.\n  + Cá chép: Mang.\n  + Ếch đồng: Phổi và da ẩm.\n  + Chim bồ câu và Con người: Phổi.\n- Giải thích hiện tượng giun đất chết trên mặt đất khô: Giun đất trao đổi khí qua da. Khi để trên mặt đất khô ráo, da giun bị mất nước và khô đi, làm cho khí O₂ không thể khuếch tán qua da vào máu và CO₂ không thoát ra được ⇒ giun đất bị ngạt thở mà chết.',
        rubricPoints: [
          'Kể đúng cơ quan trao đổi khí của 6 đại diện động vật.',
          'Giải thích đúng da giun bị khô không khuếch tán được khí gây ngạt thở.',
        ],
      },
      {
        id: 'b27-es-3',
        question: 'Câu 3 [SBT KHTN 7 - KNTT]: Tại sao trong các bể nuôi cá cảnh hoặc ao đầm nuôi tôm công nghiệp, người ta thường phải lắp đặt hệ thống máy sục khí (hoặc quạt nước) hoạt động liên tục, đặc biệt là vào ban đêm?',
        hint: 'Hàm lượng O₂ hòa tan trong nước thấp và ban đêm thủy sinh vật đều tiêu thụ O₂.',
        sampleAnswer: '- Khí Oxygen (O₂) ít tan trong nước. Khi nuôi cá cảnh hoặc tôm với mật độ dày, lượng O₂ hòa tan trong nước nhanh chóng bị tiêu thụ hết cho quá trình hô hấp.\n- Đặc biệt vào ban đêm, các loài tảo và cây thủy sinh trong nước ngừng quang hợp và cũng lấy O₂ để hô hấp.\n- Vì vậy, việc bật máy sục khí hoặc quạt nước giúp tăng diện tích tiếp xúc giữa nước và không khí, hòa tan thêm nhiều khí O₂ vào nước để cá, tôm không bị ngạt thở.',
        rubricPoints: [
          'Nêu đúng nguyên nhân O₂ ít tan trong nước và mật độ cá/tôm tiêu thụ nhiều O₂.',
          'Giải thích đúng tác dụng hòa tan thêm O₂ từ không khí vào nước của máy sục khí.',
        ],
      },
      {
        id: 'b27-es-4',
        question: 'Câu 4: Em hãy nêu ít nhất 4 biện pháp thực tế giúp bảo vệ đường hô hấp và giữ cho phổi luôn khỏe mạnh.',
        hint: 'Luyện tập thể thao, đeo khẩu trang, không hút thuốc lá, giữ vệ sinh nhà ở.',
        sampleAnswer: '4 biện pháp bảo vệ hệ hô hấp:\n1. Thường xuyên tập thể dục và rèn luyện hít thở sâu để tăng dung tích sống của phổi.\n2. Không hút thuốc lá và tránh xa nơi có khói thuốc lá thụ động.\n3. Đeo khẩu trang khi ra đường hoặc làm việc ở nơi có nhiều bụi mịn, hóa chất độc hại.\n4. Trồng nhiều cây xanh, thường xuyên vệ sinh nhà cửa, lớp học thông thoáng và giữ ấm cổ – ngực khi trời lạnh.',
        rubricPoints: [
          'Nêu được ít nhất 4 biện pháp thiết thực bảo vệ hệ hô hấp.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 28: VAI TRÒ CỦA NƯỚC VÀ CHẤT DINH DƯỠNG ĐỐI VỚI SINH VẬT
  // =========================================================================
  {
    id: 'kntt-bai-28',
    lessonNumber: 28,
    title: 'Bài 28: Vai trò của nước và chất dinh dưỡng đối với sinh vật',
    chapterTitle: 'Chương VII: Trao đổi chất và chuyển hóa năng lượng',
    subject: 'biology',
    summary:
      'Nước chiếm khoảng 70% khối lượng cơ thể sinh vật, là thành phần cấu tạo tế bào, dung môi hòa tan và vận chuyển các chất, nguyên liệu/môi trường cho các phản ứng chuyển hóa và điều hòa thân nhiệt. Chất dinh dưỡng gồm Carbohydrate, Lipid, Protein, Vitamin và Muối khoáng (ở thực vật là các nguyên tố khoáng đa lượng N, P, K... và vi lượng).',
    keyFormulas: [
      'Cấu tạo phân tử nước (H₂O): Gồm 1 nguyên tử O liên kết cộng hóa trị phân cực với 2 nguyên tử H',
      '4 nhóm chất dinh dưỡng ở người & động vật: Carbohydrate (Đường bột) ·Protein (Đạm) · Lipid (Chất béo) · Vitamin & Muối khoáng',
      'Dinh dưỡng ở thực vật: Nhóm đa lượng (C, H, O, N, P, K, S, Ca, Mg) và Nhóm vi lượng (Fe, Mn, B, Cl, Zn, Cu, Mo)',
    ],
    mcqs: makeBioMcqs('b28', [
      ['Trong cơ thể sinh vật sống, nước thường chiếm khoảng bao nhiêu phần trăm khối lượng cơ thể?', ['Chỉ khoảng 5%.', 'Khoảng 60% – 70% (ở một số loài như sứa, dưa hấu có thể trên 90%).', '100% khối lượng cơ thể.', '0% khối lượng cơ thể.'], 1, 'Nước là thành phần chiếm tỉ lệ lớn nhất trong cơ thể sống (khoảng 70% khối lượng cơ thể người).'],
      ['Phân tử nước (H₂O) có tính chất phân cực là do:', ['Cặp electron dùng chung trong liên kết cộng hóa trị giữa O và H bị lệch về phía nguyên tử Oxygen.', 'Trong phân tử nước có chứa kim loại Sodium.', 'Phân tử nước chỉ có các nguyên tử Hydrogen.', 'Phân tử nước không có electron.'], 0, 'Nguyên tử O kéo cặp electron dùng chung mạnh hơn H nên đầu O tích điện âm nhẹ, đầu H tích điện dương nhẹ (tính phân cực).'],
      ['Nhờ có tính phân cực, nước đóng vai trò đặc biệt quan trọng nào sau đây trong tế bào?', ['Là dung môi hòa tan nhiều chất (muối khoáng, đường, khí O₂, CO₂) và giúp vận chuyển các chất trong cơ thể.', 'Làm cho xương bị gãy.', 'Ngăn cản các phản ứng hóa học.', 'Biến cơ thể thành đá.'], 0, 'Tính phân cực giúp nước hòa tan hầu hết các chất phân cực và ion, đóng vai trò dung môi và môi trường vận chuyển.'],
      ['Nếu cơ thể người bị mất từ 10% đến 20% lượng nước mà không được bù kịp thời thì:', ['Cơ thể sẽ khỏe mạnh hơn.', 'Rối loạn chuyển hóa nghiêm trọng và có thể dẫn đến tử vong.', 'Không có ảnh hưởng gì.', 'Cơ thể sẽ tự tổng hợp ra sắt.'], 1, 'Mất nước 10% – 20% làm máu đặc lại, ngừng tuần hoàn và rối loạn chuyển hóa gây nguy hiểm tính mạng.'],
      ['Khi trời nắng nóng hoặc khi lao động nặng, cơ thể người toát nhiều mồ hôi. Hiện tượng này thể hiện vai trò nào của nước?', ['Điều hòa thân nhiệt (nước bay hơi mang theo nhiệt lượng làm mát cơ thể).', 'Tạo ra xương mới.', 'Tổng hợp chất diệp lục.', 'Làm tăng nhiệt độ cơ thể lên 45°C.'], 0, 'Sự bay hơi của nước trong mồ hôi giúp giải phóng nhiệt lượng dư thừa, giữ thân nhiệt ổn định ở 37°C.'],
      ['Ở người và động vật, nhóm chất dinh dưỡng nào đóng vai trò là nguồn cung cấp năng lượng chủ yếu cho mọi hoạt động của cơ thể?', ['Vitamin.', 'Chất đường bột (Carbohydrate – có nhiều trong gạo, ngô, khoai, bánh mì).', 'Chất xơ.', 'Muối khoáng.'], 1, 'Carbohydrate (tinh bột, đường) dễ phân giải nhất và là nguồn cung cấp năng lượng chính.'],
      ['Nhóm chất dinh dưỡng nào tham gia cấu tạo nên tế bào, cơ bắp, enzyme và kháng thể bảo vệ cơ thể chống lại vi khuẩn, virus?', ['Chất đạm (Protein – có nhiều trong thịt, cá, trứng, sữa, các loại đậu).', 'Nước cất.', 'Khí Carbon dioxide.', 'Muối ăn.'], 0, 'Protein cấu tạo nên chất nguyên sinh, cơ, xương, hormone và kháng thể miễn dịch.'],
      ['Nhóm chất dinh dưỡng nào có vai trò dự trữ năng lượng lớn nhất, giữ ấm cơ thể và là dung môi hòa tan các vitamin A, D, E, K?', ['Chất béo (Lipid – có trong dầu thực vật, mỡ động vật, lạc, vừng).', 'Vitamin C.', 'Chất khoáng Iron (Sắt).', 'Chất xơ.'], 0, 'Lipid vừa cấu tạo màng tế bào, dự trữ năng lượng, vừa hòa tan nhóm vitamin tan trong dầu (A, D, E, K).'],
      ['Nếu trẻ em bị thiếu Vitamin A trong khẩu phần ăn hàng ngày sẽ dễ mắc bệnh gì?', ['Bệnh khô mắt, quáng gà (nhìn kém vào lúc chiều tối) và giảm sức đề kháng.', 'Bệnh bướu cổ.', 'Bệnh gãy xương.', 'Bệnh sâu răng.'], 0, 'Vitamin A rất cần cho tế bào võng mạc mắt và biểu mô; bổ sung qua cà rốt, bí đỏ, gấc, gan, trứng.'],
      ['Để phòng chống bệnh còi xương ở trẻ em và loãng xương ở người lớn, cơ thể cần được cung cấp đủ nguyên tố khoáng nào kết hợp với Vitamin D?', ['Iron (Sắt).', 'Calcium (Canxi).', 'Iodine (I-ốt).', 'Sodium (Natri).'], 1, 'Calcium là thành phần chính của xương và răng; Vitamin D giúp ruột hấp thụ Calcium hiệu quả.'],
      ['Nguyên tố khoáng vi lượng nào là thành phần cấu tạo nên Hemoglobin (huyết sắc tố) trong hồng cầu máu, nếu thiếu sẽ gây bệnh thiếu máu?', ['Iron (Sắt – Fe).', 'Calcium (Ca).', 'Potassium (K).', 'Chlorine (Cl).'], 0, 'Sắt (Fe) cấu tạo nên nhân heme của Hemoglobin giúp vận chuyển O₂ trong máu.'],
      ['Vì sao chúng ta nên sử dụng muối i-ốt (có bổ sung nguyên tố Iodine) trong chế biến thức ăn hàng ngày?', ['Để thức ăn có màu tím.', 'Để phòng tránh bệnh bướu cổ và thiểu năng tuyến giáp do thiếu Iodine.', 'Để thay thế hoàn toàn nước uống.', 'Để làm thức ăn ngọt hơn.'], 1, 'Iodine là thành phần cấu tạo hormone tuyến giáp (thyroxine), thiếu Iodine gây bệnh bướu cổ.'],
      ['Đối với thực vật, chất dinh dưỡng chính mà rễ cây hấp thụ từ đất là:', ['Các muối khoáng hòa tan (chứa các nguyên tố N, P, K, Ca, Mg, S, Fe...).', 'Tinh bột và thịt cá.', 'Protein và dầu ăn.', 'Vitamin C và Vitamin D.'], 0, 'Thực vật tự tổng hợp chất hữu cơ qua quang hợp, còn chất dinh dưỡng lấy từ đất là các ion muối khoáng hòa tan.'],
      ['Ba nguyên tố khoáng đa lượng quan trọng nhất tạo nên loại phân bón tổng hợp NPK trong nông nghiệp là:', ['Nitrogen (Đạm - N), Phosphorus (Lân - P) và Potassium (Kali - K).', 'Natri (Na), Photpho (P) và Kẽm (Zn).', 'Niken (Ni), Chì (Pb) và Kali (K).', 'Nitơ (N), Sắt (Fe) và Đồng (Cu).'], 0, 'N (Nitrogen), P (Phosphorus), K (Potassium) là 3 nguyên tố đa lượng thiết yếu cho sinh trưởng của cây.'],
      ['Khi cây trồng bị thiếu nguyên tố Nitrogen (Đạm - N), biểu hiện điển hình nhất trên cây là:', ['Cây còi cọc, sinh trưởng chậm, lá non nhỏ và lá già chuyển sang màu vàng nhạt.', 'Lá cây chuyển sang màu xanh đậm bất thường và cây cao vọt.', 'Cây ra quá nhiều quả.', 'Rễ cây phát sáng.'], 0, 'Nitrogen là thành phần của protein và diệp lục, thiếu N làm cây còi cọc và lá bị vàng (vàng lá sinh lí).'],
      ['Nguyên tố khoáng nào là thành phần cấu tạo trực tiếp của phân tử chất diệp lục (Chlorophyll) ở lá cây?', ['Magnesium (Mg) và Nitrogen (N).', 'Gold (Au).', 'Silver (Ag).', 'Mercury (Hg).'], 0, 'Nhân của phân tử diệp lục chứa nguyên tử Magnesium (Mg) liên kết với các nguyên tử Nitrogen (N).'],
      ['Tại sao khẩu phần ăn hàng ngày của con người cần phối hợp đa dạng nhiều loại thực phẩm (thịt, cá, trứng, sữa, rau xanh, trái cây, ngũ cốc)?', ['Vì không có một loại thực phẩm đơn lẻ nào chứa đầy đủ tất cả các chất dinh dưỡng, vitamin và chất khoáng theo đúng tỉ lệ cơ thể cần.', 'Chỉ để bữa ăn tốn nhiều tiền hơn.', 'Vì ăn một món sẽ làm hỏng nồi nấu.', 'Vì rau xanh có chứa nhiều chất béo nhất.'], 0, 'Ăn đa dạng thực phẩm giúp cung cấp cân đối cả 4 nhóm chất dinh dưỡng: Đường bột, Đạm, Béo, Vitamin & Khoáng chất.'],
      ['Mặc dù Chất xơ (có nhiều trong rau xanh, củ quả, ngũ cốc nguyên hạt) không được tiêu hóa để tạo năng lượng ở người, nhưng lại rất cần thiết vì:', ['Giúp kích thích nhu động ruột, hỗ trợ tiêu hóa và phòng chống táo bón.', 'Biến thành xương trong cơ thể.', 'Làm tăng huyết áp.', 'Thay thế cho khí Oxygen.'], 0, 'Chất xơ giữ nước, làm mềm phân và kích thích nhu động ruột già giúp ngăn ngừa táo bón.'],
    ]),
    trueFalseList: [
      {
        id: 'b28-tf-1',
        stem: 'Xét cấu trúc phân tử và vai trò của nước đối với cơ thể sinh vật:',
        statements: [
          { id: 'a', text: 'Phân tử nước (H₂O) gồm 1 nguyên tử Oxygen liên kết với 2 nguyên tử Hydrogen bằng liên kết cộng hóa trị phân cực.', isTrue: true, explanation: 'Đúng cấu tạo phân tử nước.' },
          { id: 'b', text: 'Nước là thành phần chủ yếu cấu tạo nên tế bào và cơ thể sinh vật, đồng thời là dung môi hòa tan và vận chuyển các chất.', isTrue: true, explanation: 'Đúng vai trò của nước.' },
          { id: 'c', text: 'Nước còn là nguyên liệu trực tiếp tham gia vào quá trình quang hợp ở cây xanh và nhiều phản ứng thủy phân trong tiêu hóa.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Nếu cây trồng hoặc cơ thể động vật bị thiếu nước kéo dài thì tốc độ trao đổi chất sẽ tăng vọt lên mức cực đại.', isTrue: false, explanation: 'Sai, khi thiếu nước các phản ứng sinh hóa bị đình trệ, cây héo và sinh vật sẽ chết nếu mất nước nặng.' },
        ],
      },
      {
        id: 'b28-tf-2',
        stem: 'Xét vai trò của các nhóm chất dinh dưỡng hữu cơ (Carbohydrate, Protein, Lipid) ở người và động vật:',
        statements: [
          { id: 'a', text: 'Carbohydrate (chất đường bột) là nguồn cung cấp năng lượng chính và nhanh nhất cho các hoạt động sống của cơ thể.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Protein (chất đạm) có vai trò kiến tạo tế bào, xây dựng mô cơ, tổng hợp enzyme, hormone và kháng thể bảo vệ cơ thể.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Lipid (chất béo) vừa dự trữ năng lượng vừa giúp hòa tan và hấp thụ các vitamin tan trong dầu như Vitamin A, D, E, K.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Để giảm cân nhanh, học sinh đang ở tuổi dậy thì nên nhịn ăn hoàn toàn chất đường bột và chất béo trong nhiều tháng.', isTrue: false, explanation: 'Sai, nhịn hoàn toàn đường bột và chất béo gây suy nhược cơ thể, thiếu năng lượng cho não bộ và thiếu hụt các vitamin A, D, E, K.' },
        ],
      },
      {
        id: 'b28-tf-3',
        stem: 'Xét vai trò của Vitamin và Muối khoáng đối với sức khỏe con người:',
        statements: [
          { id: 'a', text: 'Vitamin và muối khoáng tuy cơ thể chỉ cần một lượng nhỏ nhưng không thể thiếu để duy trì hoạt động sinh lí bình thường.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Thiếu Calcium (Ca) và Vitamin D dẫn đến bệnh còi xương ở trẻ nhỏ và loãng xương ở người lớn tuổi.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Thiếu Iron (Sắt - Fe) dẫn đến bệnh bướu cổ, còn thiếu Iodine (I-ốt) dẫn đến bệnh thiếu máu.', isTrue: false, explanation: 'Sai, ngược lại: thiếu Sắt (Fe) gây thiếu máu, còn thiếu Iodine (I) gây bệnh bướu cổ.' },
          { id: 'd', text: 'Ăn nhiều rau xanh, củ quả tươi có màu đỏ, vàng, cam (cà rốt, bí đỏ, gấc, cam) giúp bổ sung tiền chất Vitamin A và Vitamin C cho cơ thể.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b28-tf-4',
        stem: 'Xét vai trò của các nguyên tố khoáng đối với thực vật:',
        statements: [
          { id: 'a', text: 'Các nguyên tố khoáng ở thực vật được chia thành 2 nhóm: nguyên tố đa lượng (N, P, K, Ca, Mg, S) và nguyên tố vi lượng (Fe, Mn, B, Zn, Cu, Mo).', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Nguyên tố Nitrogen (N - Đạm) là thành phần cấu tạo của protein và chất diệp lục, giúp cây sinh trưởng mạnh, ra nhiều lá xanh tốt.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Các nguyên tố vi lượng chỉ chiếm tỉ lệ rất nhỏ nên cây trồng hoàn toàn không cần đến chúng.', isTrue: false, explanation: 'Sai, nguyên tố vi lượng tham gia hoạt hóa enzyme; nếu thiếu cây sẽ bị rối loạn trao đổi chất, rụng hoa quả non và giảm năng suất.' },
          { id: 'd', text: 'Thực vật chỉ hấp thụ được các muối khoáng ở dạng hòa tan trong nước đất.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b28-tf-5',
        stem: 'Xét thói quen uống nước và dinh dưỡng hợp lí hàng ngày:',
        statements: [
          { id: 'a', text: 'Mỗi ngày một học sinh THCS cần cung cấp cho cơ thể khoảng 1,5 – 2 lít nước (từ nước uống, canh, sữa, trái cây).', isTrue: true, explanation: 'Đúng nhu cầu nước hàng ngày.' },
          { id: 'b', text: 'Nên uống nước rải đều trong ngày, đặc biệt bổ sung thêm nước sau khi tập thể dục hoặc khi thời tiết nắng nóng.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Có thể dùng nước ngọt có ga đun sôi để thay thế hoàn toàn cho nước lọc hàng ngày.', isTrue: false, explanation: 'Sai, lạm dụng nước ngọt có ga gây thừa đường, béo phì, hại men răng và không tốt cho thận.' },
          { id: 'd', text: 'Khi bị tiêu chảy cấp gây mất nước và chất điện giải, người bệnh cần được uống dung dịch bù nước và điện giải (Oresol) pha đúng tỉ lệ hướng dẫn.', isTrue: true, explanation: 'Đúng biện pháp y tế bù nước và điện giải.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b28-es-1',
        question: 'Câu 1 [SGK KHTN 7 - KNTT]: Trình bày vai trò của nước đối với cơ thể sinh vật. Điều gì sẽ xảy ra nếu cây trồng hoặc cơ thể động vật bị thiếu nước kéo dài?',
        hint: 'Nêu 4 vai trò chính: cấu tạo tế bào, dung môi hòa tan – vận chuyển, môi trường/nguyên liệu phản ứng sinh hóa, điều hòa thân nhiệt.',
        sampleAnswer: '- 4 vai trò cốt lõi của nước đối với sinh vật:\n  1. Là thành phần chủ yếu cấu tạo nên tế bào và cơ thể sinh vật (chiếm khoảng 70% khối lượng).\n  2. Là dung môi hòa tan nhiều chất và giúp vận chuyển các chất dinh dưỡng, chất thải trong cơ thể (trong máu, dịch mô, dòng mạch gỗ – mạch rây).\n  3. Là nguyên liệu và môi trường cho các phản ứng chuyển hóa vật chất (như quang hợp, tiêu hóa).\n  4. Giúp điều hòa nhiệt độ cơ thể (qua sự thoát hơi nước ở lá và toát mồ hôi ở người).\n- Nếu thiếu nước kéo dài: Các phản ứng trao đổi chất bị ngưng trệ, tế bào mất sức trương (cây bị héo rũ, động vật kiệt sức, rối loạn tuần hoàn – bài tiết) và sẽ dẫn đến chết.',
        rubricPoints: [
          'Nêu đủ 4 vai trò của nước đối với cơ thể sống.',
          'Nêu đúng hậu quả khi sinh vật bị thiếu nước kéo dài.',
        ],
      },
      {
        id: 'b28-es-2',
        question: 'Câu 2 [SGK KHTN 7 - KNTT]: Kể tên các nhóm chất dinh dưỡng chính ở người và động vật. Nêu vai trò và nguồn thực phẩm cung cấp của từng nhóm chất đó.',
        hint: '4 nhóm: Carbohydrate (Đường bột), Protein (Đạm), Lipid (Béo), Vitamin & Chất khoáng.',
        sampleAnswer: '4 nhóm chất dinh dưỡng ở người và động vật:\n1. Carbohydrate (Chất đường bột):\n- Vai trò: Cung cấp năng lượng chủ yếu cho mọi hoạt động sống.\n- Nguồn cung cấp: Gạo, ngô, khoai, sắn, bánh mì, bún.\n2. Protein (Chất đạm):\n- Vai trò: Xây dựng tế bào mới, phát triển cơ bắp, tạo enzyme và kháng thể miễn dịch.\n- Nguồn cung cấp: Thịt, cá, tôm, trứng, sữa, đậu nành.\n3. Lipid (Chất béo):\n- Vai trò: Dự trữ năng lượng, cấu tạo màng tế bào và hòa tan các vitamin A, D, E, K.\n- Nguồn cung cấp: Dầu thực vật, mỡ động vật, bơ, lạc, vừng.\n4. Vitamin và Muối khoáng:\n- Vai trò: Tham gia cấu tạo xương, máu (Ca, Fe), hormone (I) và điều hòa hoạt động trao đổi chất.\n- Nguồn cung cấp: Rau xanh, trái cây tươi, hải sản, sữa.',
        rubricPoints: [
          'Nêu đúng tên, vai trò và nguồn thực phẩm của 4 nhóm chất dinh dưỡng.',
        ],
      },
      {
        id: 'b28-es-3',
        question: 'Câu 3 [SBT KHTN 7 - KNTT]: Giải thích tại sao trẻ em trong giai đoạn phát triển cần được bổ sung đầy đủ Calcium (Ca), Vitamin D và tắm nắng hợp lí vào buổi sáng sớm?',
        hint: 'Mối quan hệ giữa ánh nắng mặt trời, tiền vitamin D dưới da và sự hấp thụ Calcium.',
        sampleAnswer: '- Calcium (Ca) là nguyên tố khoáng chính cấu tạo nên hệ xương và răng, giúp trẻ em phát triển chiều cao và có bộ xương chắc khỏe.\n- Tuy nhiên, cơ thể chỉ hấp thụ được Calcium từ thức ăn vào máu và xương khi có mặt của Vitamin D.\n- Tắm nắng nhẹ vào buổi sáng sớm giúp tiền chất vitamin D dưới da chuyển hóa thành Vitamin D hoạt động, từ đó tăng cường hấp thụ Calcium và phòng chống hiệu quả bệnh còi xương ở trẻ em.',
        rubricPoints: [
          'Giải thích đúng vai trò tạo xương của Calcium.',
          'Giải thích đúng vai trò của Vitamin D và ánh nắng giúp chuyển hóa, hấp thụ Calcium.',
        ],
      },
      {
        id: 'b28-es-4',
        question: 'Câu 4: Ở thực vật, các nguyên tố dinh dưỡng khoáng (như Nitrogen, Phosphorus, Potassium) có vai trò gì? Tại sao người nông dân cần bón phân đúng loại và đúng liều lượng theo từng giai đoạn phát triển của cây?',
        hint: 'Cây con cần nhiều Đạm (N) và Lân (P); giai đoạn tạo củ/quả cần nhiều Kali (K).',
        sampleAnswer: '- Vai trò của các nguyên tố khoáng chính:\n  + Nitrogen (N - Đạm): Cấu tạo protein, diệp lục, giúp cây đẻ nhánh, ra nhiều lá xanh tốt.\n  + Phosphorus (P - Lân): Kích thích bộ rễ phát triển mạnh, thúc đẩy ra hoa, đậu quả.\n  + Potassium (K - Kali): Giúp vận chuyển chất hữu cơ về củ, quả, hạt và tăng khả năng chống chịu sâu bệnh, rét, hạn.\n- Phải bón phân đúng loại và đúng liều lượng vì mỗi giai đoạn sinh trưởng cây có nhu cầu dinh dưỡng khác nhau; nếu bón thiếu cây sẽ còi cọc giảm năng suất, còn nếu bón thừa sẽ gây ngộ độc cho cây, lãng phí kinh tế và gây ô nhiễm đất, nguồn nước.',
        rubricPoints: [
          'Nêu đúng vai trò của N, P, K đối với cây trồng.',
          'Giải thích đúng lí do phải bón phân cân đối theo từng giai đoạn sinh trưởng.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 30: TRAO ĐỔI NƯỚC VÀ CÁC CHẤT DINH DƯỠNG Ở ĐỘNG VẬT
  // =========================================================================
  {
    id: 'kntt-bai-30',
    lessonNumber: 30,
    title: 'Bài 30: Trao đổi nước và các chất dinh dưỡng ở động vật',
    chapterTitle: 'Chương VII: Trao đổi chất và chuyển hóa năng lượng',
    subject: 'biology',
    summary:
      'Ở động vật và người, thức ăn được tiếp nhận và biến đổi trong ống tiêu hóa thành các chất dinh dưỡng đơn giản rồi hấp thụ vào máu tại ruột non. Hệ tuần hoàn (tim và hệ mạch) vận chuyển máu mang chất dinh dưỡng và khí O₂ tới từng tế bào, đồng thời chuyển các chất thải tới cơ quan bài tiết (phổi, thận, da) để đưa ra ngoài.',
    keyFormulas: [
      'Đường đi của thức ăn trong ống tiêu hóa người: Miệng → Thực quản → Dạ dày → Ruột non (tiêu hóa & hấp thụ chính) → Ruột già → Hậu môn',
      'Hai vòng tuần hoàn ở người: Vòng tuần hoàn nhỏ (Tim → Phổi → Tim)  |  Vòng tuần hoàn lớn (Tim → Các cơ quan/tế bào → Tim)',
      'Cân bằng nước = Lượng nước lấy vào (uống, thức ăn) ≈ Lượng nước thải ra (nước tiểu, mồ hôi, hơi thở, phân)',
    ],
    mcqs: makeBioMcqs('b30', [
      ['Con đường thu nhận và tiêu hóa thức ăn trong ống tiêu hóa của người diễn ra theo thứ tự nào sau đây?', ['Khoang miệng → Thực quản → Dạ dày → Ruột non → Ruột già → Trực tràng → Hậu môn.', 'Khoang miệng → Dạ dày → Thực quản → Ruột già → Ruột non.', 'Mũi → Khí quản → Phổi → Dạ dày.', 'Miệng → Gan → Thận → Phổi.'], 0, 'Đúng thứ tự các cơ quan trong ống tiêu hóa của người.'],
      ['Trong ống tiêu hóa của người, bộ phận nào là nơi diễn ra quá trình tiêu hóa hoàn toàn thức ăn và hấp thụ phần lớn các chất dinh dưỡng vào máu?', ['Khoang miệng.', 'Thực quản.', 'Ruột non (nhờ có nhiều nếp gấp, lông ruột và hệ thống mao mạch dày đặc).', 'Ruột già.'], 2, 'Ruột non là cơ quan chủ yếu tiêu hóa triệt để thức ăn thành chất đơn giản và hấp thụ chất dinh dưỡng vào máu.'],
      ['Vai trò chính của ruột già trong hệ tiêu hóa của người là gì?', ['Nghiền nhỏ thức ăn bằng răng.', 'Tái hấp thụ nước và cô đặc chất bã tạo thành phân trước khi thải ra ngoài.', 'Tiết dịch vị tiêu hóa thịt.', 'Bơm máu đi nuôi cơ thể.'], 1, 'Ruột già hấp thụ lại nước và một số muối khoáng từ dịch thức ăn còn lại, tạo phân thải ra ngoài.'],
      ['Cơ quan nào đóng vai trò như một “cái bơm” hút và đẩy máu lưu thông liên tục trong hệ mạch tuần hoàn của người và động vật?', ['Phổi.', 'Dạ dày.', 'Tim.', 'Thận.'], 2, 'Tim co bóp nhịp nhàng tạo lực đẩy máu chảy trong các động mạch, mao mạch và tĩnh mạch.'],
      ['Trong hệ mạch máu của người, loại mạch nào dẫn máu từ tim đi đến các cơ quan trong cơ thể?', ['Động mạch.', 'Tĩnh mạch.', 'Mao mạch.', 'Mạch gỗ.'], 0, 'Động mạch dẫn máu từ tâm thất của tim đi đến các cơ quan.'],
      ['Trong hệ mạch máu của người, loại mạch nào dẫn máu từ các cơ quan trở về tim?', ['Động mạch.', 'Tĩnh mạch.', 'Khí quản.', 'Thực quản.'], 1, 'Tĩnh mạch thu hồi máu từ mao mạch các cơ quan dẫn trở về tâm nhĩ của tim.'],
      ['Loại mạch máu nào rất nhỏ, phân nhánh dày đặc tới tận từng tế bào với thành mạch rất mỏng giúp thực hiện trao đổi chất và khí giữa máu với tế bào?', ['Động mạch chủ.', 'Mao mạch.', 'Tĩnh mạch chủ.', 'Mạch rây.'], 1, 'Mao mạch có thành chỉ gồm 1 lớp tế bào mỏng giúp O₂, chất dinh dưỡng đi vào tế bào và CO₂, chất thải đi vào máu.'],
      ['Hệ tuần hoàn ở người và thú gồm mấy vòng tuần hoàn?', ['1 vòng tuần hoàn đơn.', '2 vòng tuần hoàn: Vòng tuần hoàn nhỏ (qua phổi) và Vòng tuần hoàn lớn (đi khắp cơ thể).', '3 vòng tuần hoàn.', 'Không có vòng tuần hoàn nào.'], 1, 'Người và thú có tim 4 ngăn và 2 vòng tuần hoàn khép kín (vòng tuần hoàn phổi và vòng tuần hoàn hệ thống).'],
      ['Chức năng của vòng tuần hoàn nhỏ (vòng tuần hoàn phổi) ở người là:', ['Đưa máu đỏ thẫm (giàu CO₂) từ tim lên phổi để trao đổi khí (nhận O₂, thải CO₂) rồi trở về tim dưới dạng máu đỏ tươi (giàu O₂).', 'Đưa thức ăn từ miệng xuống dạ dày.', 'Lọc máu tạo nước tiểu ở thận.', 'Đưa máu đi nuôi chân và tay.'], 0, 'Vòng tuần hoàn nhỏ đưa máu từ tâm thất phải lên phổi trao đổi khí thành máu đỏ tươi rồi về tâm nhĩ trái.'],
      ['Chức năng của vòng tuần hoàn lớn ở người là:', ['Đưa máu đỏ tươi (giàu O₂ và chất dinh dưỡng) từ tâm thất trái đi nuôi tất cả các cơ quan, tế bào trong cơ thể rồi nhận CO₂, chất thải trở về tâm nhĩ phải.', 'Chỉ đưa máu lên phổi.', 'Chỉ đưa nước vào dạ dày.', 'Tạo ra dịch mật ở gan.'], 0, 'Vòng tuần hoàn lớn cung cấp O₂ và chất dinh dưỡng cho toàn bộ cơ thể và thu hồi sản phẩm thải.'],
      ['Cơ thể người lấy nước vào qua những con đường nào và thải nước ra ngoài môi trường qua những con đường nào?', ['Lấy vào qua nước uống và thức ăn; thải ra qua nước tiểu, mồ hôi, hơi thở và phân.', 'Chỉ lấy nước qua da.', 'Chỉ thải nước qua tai.', 'Lấy nước qua phổi và thải qua miệng.'], 0, 'Lượng nước đưa vào (uống, ăn) luôn cân bằng với lượng nước bài tiết ra (nước tiểu, mồ hôi, hơi thở, phân).'],
      ['Cơ quan nào trong hệ bài tiết của người có nhiệm vụ lọc máu để loại bỏ các chất thải hòa tan (như urê, axit uric, muối dư thừa) tạo thành nước tiểu?', ['Phổi.', 'Hai quả thận.', 'Dạ dày.', 'Tim.'], 1, 'Thận lọc máu liên tục để tạo nước tiểu, giúp duy trì cân bằng nước và áp suất thẩm thấu của máu.'],
      ['Vì sao chúng ta cần phải nhai kĩ thức ăn ở khoang miệng trước khi nuốt?', ['Giúp thức ăn được nghiền nhỏ và thấm đều enzyme amylase trong nước bọt, giảm tải cho dạ dày và giúp tiêu hóa – hấp thụ hiệu quả hơn.', 'Để làm răng mòn nhanh hơn.', 'Để thức ăn không đi xuống dạ dày.', 'Để không cần uống nước.'], 0, 'Nhai kĩ giúp biến đổi cơ học tốt và tăng diện tích tiếp xúc của thức ăn với các enzyme tiêu hóa.'],
      ['Thói quen nào sau đây có hại cho hệ tiêu hóa và cần phải tránh?', ['Ăn đúng giờ, ăn chín uống sôi.', 'Vừa ăn xong đã chạy nhảy hoặc vận động thể lực quá mạnh ngay lập tức.', 'Rửa tay sạch bằng xà phòng trước khi ăn.', 'Ăn nhiều rau xanh và trái cây.'], 1, 'Vận động mạnh ngay sau khi ăn làm máu dồn về cơ bắp thay vì tập trung ở dạ dày – ruột, gây đau dạ dày và rối loạn tiêu hóa.'],
      ['Bệnh xơ vữa động mạch và cao huyết áp ở người thường liên quan mật thiết đến chế độ ăn uống nào sau đây?', ['Ăn quá nhiều mỡ động vật (chứa nhiều cholesterol xấu), ăn quá mặn (nhiều muối NaCl) và ít vận động.', 'Ăn nhiều rau xanh và cá.', 'Uống đủ nước lọc mỗi ngày.', 'Tập thể dục đi bộ hàng ngày.'], 0, 'Dư thừa cholesterol gây mảng bám làm hẹp lòng động mạch; ăn mặn làm tăng áp lực máu lên thành mạch.'],
      ['Khi cơ thể bị sốt cao hoặc tiêu chảy kéo dài, tại sao người bệnh cần phải uống bổ sung dung dịch Oresol hoặc nước cháo muối?', ['Để bù lại lượng nước và các ion muối khoáng (điện giải) đã bị mất đi, giúp duy trì thể tích máu và hoạt động tế bào.', 'Để làm tăng nhiệt độ cơ thể.', 'Để không cần ăn cơm nữa.', 'Để làm khô họng.'], 0, 'Sốt cao và tiêu chảy làm cơ thể mất nhiều nước và điện giải, cần bù ngay bằng Oresol.'],
      ['Sự phối hợp giữa Hệ tiêu hóa, Hệ hô hấp, Hệ tuần hoàn và Hệ bài tiết trong cơ thể người chứng minh điều gì?', ['Mỗi hệ cơ quan hoạt động hoàn toàn cô lập, không liên quan gì đến nhau.', 'Cơ thể là một khối thống nhất: Hệ tiêu hóa và hô hấp lấy chất dinh dưỡng, O₂; Hệ tuần hoàn vận chuyển đến tế bào; Hệ bài tiết thải chất bã ra ngoài.', 'Chỉ cần hệ tuần hoàn là cơ thể sống được.', 'Hệ bài tiết quan trọng hơn hệ hô hấp.'], 1, 'Các hệ cơ quan phối hợp nhịp nhàng, thống nhất để thực hiện trao đổi chất và chuyển hóa năng lượng nuôi cơ thể.'],
      ['Để phòng tránh các bệnh giun sán kí sinh trong đường ruột, chúng ta cần thực hiện biện pháp nào?', ['Ăn rau sống chưa rửa sạch và uống nước lã.', 'Rửa tay sạch trước khi ăn và sau khi đi vệ sinh, ăn chín uống sôi, tẩy giun định kì 6 tháng/lần.', 'Đi chân đất ở nơi đất bẩn.', 'Không bao giờ rửa trái cây trước khi ăn.'], 1, 'Ăn chín uống sôi, vệ sinh tay sạch sẽ và tẩy giun định kì giúp ngăn chặn trứng giun sán xâm nhập ống tiêu hóa.'],
    ]),
    trueFalseList: [
      {
        id: 'b30-tf-1',
        stem: 'Xét quá trình tiêu hóa và hấp thụ chất dinh dưỡng trong ống tiêu hóa của người:',
        statements: [
          { id: 'a', text: 'Ống tiêu hóa của người gồm: Khoang miệng, hầu, thực quản, dạ dày, ruột non, ruột già, trực tràng và hậu môn.', isTrue: true, explanation: 'Đúng cấu tạo ống tiêu hóa.' },
          { id: 'b', text: 'Tại ruột non, nhờ dịch tụy, dịch mật và dịch ruột, các chất phức tạp (tinh bột, protein, lipid) được biến đổi thành các chất dinh dưỡng đơn giản và hấp thụ qua thành ruột vào máu.', isTrue: true, explanation: 'Đúng chức năng của ruột non.' },
          { id: 'c', text: 'Toàn bộ quá trình hấp thụ chất dinh dưỡng diễn ra ở thực quản, còn ruột non chỉ dùng để chứa nước.', isTrue: false, explanation: 'Sai, thực quản chỉ dẫn thức ăn xuống dạ dày, còn ruột non mới là nơi hấp thụ chất dinh dưỡng chính.' },
          { id: 'd', text: 'Ruột già có vai trò tái hấp thụ nước và thải các chất cặn bã (phân) ra khỏi cơ thể.', isTrue: true, explanation: 'Đúng chức năng ruột già.' },
        ],
      },
      {
        id: 'b30-tf-2',
        stem: 'Xét cấu tạo và hoạt động của hệ tuần hoàn ở người:',
        statements: [
          { id: 'a', text: 'Hệ tuần hoàn gồm tim (4 ngăn: 2 tâm nhĩ, 2 tâm thất) và hệ mạch máu (động mạch, mao mạch, tĩnh mạch).', isTrue: true, explanation: 'Đúng cấu tạo hệ tuần hoàn người.' },
          { id: 'b', text: 'Động mạch dẫn máu từ tim đến các cơ quan; tĩnh mạch dẫn máu từ các cơ quan trở về tim; mao mạch là nơi thực hiện trao đổi chất với tế bào.', isTrue: true, explanation: 'Đúng chức năng 3 loại mạch máu.' },
          { id: 'c', text: 'Vòng tuần hoàn nhỏ đưa máu qua phổi để nhận khí O₂ và thải khí CO₂.', isTrue: true, explanation: 'Đúng chức năng vòng tuần hoàn nhỏ.' },
          { id: 'd', text: 'Máu chảy trong tất cả các động mạch luôn luôn là máu đỏ tươi, còn trong tất cả các tĩnh mạch luôn là máu đỏ thẫm.', isTrue: false, explanation: 'Sai, trong vòng tuần hoàn nhỏ: động mạch phổi chứa máu đỏ thẫm (giàu CO₂) từ tim lên phổi, còn tĩnh mạch phổi chứa máu đỏ tươi (giàu O₂) từ phổi về tim.' },
        ],
      },
      {
        id: 'b30-tf-3',
        stem: 'Xét nhu cầu và sự cân bằng nước trong cơ thể người:',
        statements: [
          { id: 'a', text: 'Cơ thể người tiếp nhận nước thông qua nước uống hàng ngày và nước có sẵn trong các loại thức ăn (cơm, canh, rau, quả).', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Nước được thải ra khỏi cơ thể qua 4 con đường: nước tiểu (qua thận), mồ hôi (qua da), hơi thở (qua phổi) và phân (qua đường tiêu hóa).', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Khi lao động nặng dưới trời nắng nóng, lượng nước mất qua mồ hôi tăng cao nên lượng nước cần uống vào cũng phải tăng lên.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Nhịn uống nước suốt cả ngày khi đi học giúp thận không phải làm việc và tốt cho sức khỏe.', isTrue: false, explanation: 'Sai, nhịn uống nước làm máu đặc, giảm lọc cầu thận và dễ gây sỏi thận, mệt mỏi.' },
        ],
      },
      {
        id: 'b30-tf-4',
        stem: 'Xét vệ sinh an toàn thực phẩm và bảo vệ hệ tiêu hóa:',
        statements: [
          { id: 'a', text: 'Thực hiện ăn chín, uống sôi, rửa sạch tay trước khi ăn giúp phòng ngừa ngộ độc thực phẩm và các bệnh truyền qua đường tiêu hóa.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Không nên ăn các thực phẩm đã bị ôi thiu, nấm mốc hoặc quá hạn sử dụng vì chúng chứa nhiều độc tố nguy hiểm cho gan, thận.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Bổ sung sữa chua và thực phẩm giàu chất xơ giúp cân bằng hệ vi sinh vật có lợi trong đường ruột.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Sau khi ăn no nên lập tức đi bơi hoặc đá bóng ngay để thức ăn tiêu hóa nhanh hơn.', isTrue: false, explanation: 'Sai, vận động mạnh ngay sau khi ăn no gây rối loạn tiêu hóa và đau dạ dày.' },
        ],
      },
      {
        id: 'b30-tf-5',
        stem: 'Xét các biện pháp bảo vệ hệ tuần hoàn và tim mạch:',
        statements: [
          { id: 'a', text: 'Thường xuyên tập luyện thể dục thể thao vừa sức giúp cơ tim khỏe mạnh và mạch máu đàn hồi tốt.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Hạn chế ăn mỡ động vật, thức ăn nhanh chiên rán nhiều dầu mỡ và giảm ăn mặn giúp phòng ngừa bệnh xơ vữa động mạch, tăng huyết áp.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Khói thuốc lá và rượu bia là những tác nhân gây hại trực tiếp làm tăng nguy cơ nhồi máu cơ tim và đột quỵ.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Khi một người bị vết thương chảy máu mạnh ở cổ tay, ta không cần băng bó mà cứ để máu tự chảy hết.', isTrue: false, explanation: 'Sai, phải sơ cứu cầm máu và băng bó ngay để tránh mất máu nguy hiểm tính mạng.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b30-es-1',
        question: 'Câu 1 [SGK KHTN 7 - KNTT]: Mô tả con đường thu nhận, tiêu hóa thức ăn và hấp thụ chất dinh dưỡng trong ống tiêu hóa của người. Tại sao nói ruột non là cơ quan quan trọng nhất trong quá trình tiêu hóa và hấp thụ?',
        hint: 'Nêu đường đi từ miệng → hậu môn và đặc điểm cấu tạo của ruột non.',
        sampleAnswer: '- Con đường đi của thức ăn trong ống tiêu hóa:\n  + Khoang miệng: Răng nghiền nhỏ, lưỡi đảo trộn, nước bọt bước đầu phân giải tinh bột.\n  + Thực quản: Đẩy thức ăn xuống dạ dày.\n  + Dạ dày: Co bóp nhào trộn thức ăn với dịch vị để phân giải bước đầu protein.\n  + Ruột non: Dịch mật, dịch tụy và dịch ruột phân giải hoàn toàn tinh bột, protein, lipid thành các chất dinh dưỡng đơn giản (đường đơn, amino acid, glycerol & acid béo) và hấp thụ qua thành ruột vào máu.\n  + Ruột già & Hậu môn: Hấp thụ lại nước, cô đặc chất bã thành phân và thải ra ngoài.\n- Ruột non là cơ quan quan trọng nhất vì: Ruột non rất dài, có đầy đủ các loại enzyme tiêu hóa hoàn toàn mọi loại thức ăn, và niêm mạc ruột non có nhiều nếp gấp, lông ruột cùng mạng lưới mao mạch dày đặc giúp diện tích hấp thụ chất dinh dưỡng đạt mức cực đại.',
        rubricPoints: [
          'Mô tả đúng lộ trình và chức năng các cơ quan trong ống tiêu hóa.',
          'Giải thích đúng vai trò tiêu hóa triệt để và cấu tạo lông ruột giúp hấp thụ của ruột non.',
        ],
      },
      {
        id: 'b30-es-2',
        question: 'Câu 2 [SGK KHTN 7 - KNTT]: Trình bày đường đi của máu trong vòng tuần hoàn nhỏ và vòng tuần hoàn lớn ở người. Nêu vai trò của hệ tuần hoàn trong quá trình trao đổi chất của cơ thể.',
        hint: 'Vòng tuần hoàn nhỏ đi qua phổi; vòng tuần hoàn lớn đi qua tất cả các mô, cơ quan.',
        sampleAnswer: '- Vòng tuần hoàn nhỏ (qua phổi): Máu đỏ thẫm (giàu CO₂) từ tâm thất phải → theo động mạch phổi lên Phổi. Tại phổi, máu thải CO₂ và nhận O₂ trở thành máu đỏ tươi → theo tĩnh mạch phổi về tâm nhĩ trái.\n- Vòng tuần hoàn lớn (đi khắp cơ thể): Máu đỏ tươi (giàu O₂ và chất dinh dưỡng) từ tâm thất trái → theo động mạch chủ đến mao mạch ở tất cả các cơ quan, tế bào. Tại đây máu giao O₂, chất dinh dưỡng cho tế bào và nhận lại CO₂, chất thải trở thành máu đỏ thẫm → theo tĩnh mạch chủ trở về tâm nhĩ phải.\n- Vai trò của hệ tuần hoàn: Là hệ thống vận chuyển trung gian kết nối hệ hô hấp, hệ tiêu hóa và hệ bài tiết với từng tế bào trong cơ thể.',
        rubricPoints: [
          'Trình bày đúng đường đi và sự đổi màu máu ở vòng tuần hoàn nhỏ.',
          'Trình bày đúng đường đi và sự trao đổi chất ở vòng tuần hoàn lớn.',
        ],
      },
      {
        id: 'b30-es-3',
        question: 'Câu 3 [SBT KHTN 7 - KNTT]: Thế nào là cân bằng nước trong cơ thể người? Em hãy giải thích tại sao vào mùa hè nắng nóng hoặc sau khi chơi thể thao, chúng ta lại thấy khát nước nhiều hơn nhưng lượng nước tiểu thải ra lại ít hơn so với mùa đông?',
        hint: 'Liên hệ lượng nước thoát qua mồ hôi và hơi thở.',
        sampleAnswer: '- Cân bằng nước là trạng thái tổng lượng nước cơ thể lấy vào (qua nước uống và thức ăn) bằng với tổng lượng nước cơ thể thải ra ngoài (qua nước tiểu, mồ hôi, hơi thở và phân).\n- Giải thích: Vào mùa hè nắng nóng hoặc khi chơi thể thao, cơ thể phải tiết rất nhiều mồ hôi qua da và thở nhanh hơn để tỏa nhiệt làm mát cơ thể. Do mất nhiều nước qua mồ hôi nên trung khu thần kinh gây cảm giác khát để nhắc cơ thể uống bù nước, đồng thời thận tăng cường tái hấp thụ nước trả lại máu nên lượng nước tiểu thải ra ít hơn và sẫm màu hơn.',
        rubricPoints: [
          'Nêu đúng khái niệm cân bằng nước (lượng vào = lượng ra).',
          'Giải thích đúng do mùa hè thoát nhiều mồ hôi nên cơ thể khát nước và thận giảm lượng nước tiểu.',
        ],
      },
      {
        id: 'b30-es-4',
        question: 'Câu 4: Em hãy đề xuất 5 biện pháp cụ thể trong ăn uống và sinh hoạt hàng ngày để bảo vệ hệ tiêu hóa và hệ tuần hoàn khỏe mạnh.',
        hint: 'Chế độ ăn, vệ sinh thực phẩm, vận động thể lực, tránh chất kích thích.',
        sampleAnswer: '5 biện pháp bảo vệ hệ tiêu hóa và hệ tuần hoàn:\n1. Ăn chín, uống sôi, rửa tay bằng xà phòng trước khi ăn và sau khi đi vệ sinh.\n2. Ăn đúng giờ, nhai kĩ, ăn đa dạng thực phẩm, tăng cường rau xanh, trái cây và cá; hạn chế mỡ động vật, đồ chiên rán và giảm ăn mặn.\n3. Không vận động thể lực mạnh (chạy nhảy, bơi lội) ngay sau khi vừa ăn no.\n4. Uống đủ 1,5 – 2 lít nước sạch mỗi ngày.\n5. Tập thể dục thể thao đều đặn mỗi ngày và tuyệt đối không hút thuốc lá, không uống rượu bia.',
        rubricPoints: [
          'Nêu được đầy đủ 5 biện pháp thiết thực, khoa học.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 34: SINH TRƯỞNG VÀ PHÁT TRIỂN Ở SINH VẬT
  // =========================================================================
  {
    id: 'kntt-bai-34',
    lessonNumber: 34,
    title: 'Bài 34 & 35: Sinh trưởng và phát triển ở sinh vật',
    chapterTitle: 'Chương IX: Sinh trưởng và phát triển ở sinh vật',
    subject: 'biology',
    summary:
      'Sinh trưởng là sự tăng lên về kích thước và khối lượng cơ thể do tăng số lượng và kích thước tế bào. Phát triển bao gồm sinh trưởng, phân hóa tế bào và phát sinh hình thái cơ quan, cơ thể. Sinh trưởng và phát triển chịu ảnh hưởng của các nhân tố bên trong (di truyền, hormone) và bên ngoài (nhiệt độ, ánh sáng, nước, dinh dưỡng).',
    keyFormulas: [
      'Sinh trưởng: Tăng kích thước & khối lượng cơ thể (nhờ phân chia và lớn lên của tế bào)',
      'Mô phân sinh ở thực vật: Mô phân sinh đỉnh (giúp thân, rễ dài ra)  |  Mô phân sinh bên (giúp thân, rễ cây gỗ to ra)',
      'Các nhân tố ảnh hưởng: Nhiệt độ · Ánh sáng · Nước · Chất dinh dưỡng · Hormone',
    ],
    mcqs: makeBioMcqs('b34only', [
      ['Sinh trưởng ở sinh vật là:', ['Sự tăng lên về kích thước và khối lượng cơ thể do sự tăng lên về số lượng và kích thước của tế bào.', 'Quá trình cơ thể chết đi.', 'Chỉ là sự thay đổi màu sắc lông.', 'Sự di chuyển của động vật.'], 0, 'Định nghĩa sinh trưởng trong SGK KHTN 7 KNTT.'],
      ['Phát triển ở sinh vật là quá trình biến đổi bao gồm:', ['Sinh trưởng, phân hóa tế bào và phát sinh hình thái các cơ quan, cơ thể.', 'Chỉ có sự tăng cân nặng.', 'Chỉ có sự giảm chiều cao.', 'Sự ngừng phân chia tế bào.'], 0, 'Phát triển là khái niệm rộng hơn, bao gồm cả sinh trưởng, phân hóa tế bào và phát sinh hình thái.'],
      ['Biểu hiện nào sau đây là ví dụ về sự SINH TRƯỞNG ở thực vật?', ['Cây đậu tăng chiều cao từ 5 cm lên 25 cm và tăng số lá từ 2 lá lên 10 lá.', 'Nụ hoa hồng nở thành bông hoa.', 'Hoa bưởi kết thành quả bưởi non.', 'Hạt phấn nảy mầm trên đầu nhụy.'], 0, 'Tăng chiều cao thân và tăng diện tích/số lượng lá là biểu hiện của sự sinh trưởng.'],
      ['Biểu hiện nào sau đây là ví dụ về sự PHÁT TRIỂN (phát sinh hình thái cơ quan mới) ở thực vật?', ['Rễ cây dài thêm 2 cm.', 'Cây cam từ giai đoạn chỉ có cành lá bắt đầu phân hóa mầm hoa, ra hoa và kết quả.', 'Thân cây bạch đàn to thêm 1 cm đường kính.', 'Lá cây to ra.'], 1, 'Từ cây chưa có hoa chuyển sang phân hóa mầm hoa, ra hoa, tạo quả là biểu hiện của phát triển.'],
      ['Ở thực vật có mạch, loại mô nào gồm các tế bào có khả năng phân chia liên tục giúp cây sinh trưởng?', ['Mô phân sinh.', 'Mô gỗ chết.', 'Lớp bần vỏ cây.', 'Tế bào lông hút già.'], 0, 'Mô phân sinh gồm các tế bào non chưa phân hóa, có khả năng phân chia mạnh mẽ tạo tế bào mới.'],
      ['Mô phân sinh đỉnh nằm ở vị trí nào trên cây và có chức năng gì?', ['Nằm ở chồi đỉnh, chồi nách và đỉnh rễ; giúp thân, cành và rễ cây dài ra (tăng chiều cao của cây).', 'Nằm ở mặt lá giúp lá rụng.', 'Làm cho thân cây to bề ngang.', 'Chỉ nằm ở trong hạt khô.'], 0, 'Mô phân sinh đỉnh giúp làm tăng chiều dài của thân và rễ.'],
      ['Mô phân sinh bên có ở nhóm thực vật nào và có vai trò gì?', ['Có ở cây Hai lá mầm thân gỗ (như cây nhãn, cây xoài, cây thông); giúp thân và rễ cây to ra theo chiều ngang.', 'Chỉ có ở cây lúa và cây ngô.', 'Giúp hoa nở nhanh hơn.', 'Làm cho rễ cây ngắn lại.'], 0, 'Mô phân sinh bên giúp tăng đường kính (bề ngang) của thân và rễ cây thân gỗ hàng năm.'],
      ['Ở cây Một lá mầm như cây tre, cây mía, cây ngô, các lóng thân vẫn dài ra được khi đã cắt ngọn là nhờ hoạt động của:', ['Mô phân sinh lóng (nằm ở gốc các mắt/lóng thân).', 'Mô phân sinh bên.', 'Khí khổng.', 'Cánh hoa.'], 0, 'Cây Một lá mầm (tre, mía, lúa, ngô) có mô phân sinh lóng giúp các lóng thân vươn dài.'],
      ['Dựa vào đặc điểm nào trên mặt cắt ngang của thân cây gỗ lớn mà các nhà lâm học có thể xác định được số năm tuổi của cây?', ['Đếm số vòng gỗ hàng năm (mỗi năm hình thành 1 vòng sáng và 1 vòng sẫm do mô phân sinh bên tạo ra).', 'Đếm số chiếc lá trên cành.', 'Đo chiều dài của rễ.', 'Cân khối lượng của vỏ cây.'], 0, 'Mỗi năm tầng sinh mạch tạo ra một lớp gỗ mùa xuân (màu sáng, mạch to) và một lớp gỗ mùa đông (màu sẫm, mạch nhỏ) hợp thành 1 vòng năm.'],
      ['Vòng đời phát triển của loài động vật nào sau đây trải qua quá trình BIẾN THÁI HOÀN TOÀN (ấu trùng có hình thái, cấu tạo rất khác với con trưởng thành)?', ['Gà và vịt.', 'Bướm, muỗi, ruồi và ếch đồng.', 'Chó, mèo và lợn.', 'Rắn và thằn lằn.'], 1, 'Sâu bướm → Nhộng → Bướm; Bọ gậy → Cung quăng → Muỗi; Nòng nọc → Ếch là phát triển qua biến thái hoàn toàn.'],
      ['Vòng đời phát triển của loài động vật nào sau đây KHÔNG qua biến thái (con non mới sinh ra hoặc nở ra có cấu tạo cơ bản giống con trưởng thành)?', ['Cá chép, gà, chó, mèo và con người.', 'Bướm cải.', 'Ếch đồng.', 'Muỗi vằn.'], 0, 'Ở cá, bò sát, chim, thú và người, con non có cấu tạo hình thái tương tự con trưởng thành (phát triển không qua biến thái).'],
      ['Sắp xếp đúng thứ tự các giai đoạn trong vòng đời phát triển của loài Bướm:', ['Trứng → Sâu bướm (Ấu trùng) → Nhộng → Bướm trưởng thành.', 'Trứng → Nhộng → Sâu bướm → Bướm trưởng thành.', 'Bướm → Trứng → Bướm con.', 'Nhộng → Trứng → Sâu.'], 0, 'Thứ tự vòng đời bướm: Trứng → Sâu (ăn lá cây) → Nhộng (trong kén) → Bướm trưởng thành.'],
      ['Trong vòng đời của bướm hại rau (bướm cải), giai đoạn nào phá hoại mùa màng mạnh nhất (ăn trụi lá rau)?', ['Giai đoạn trứng.', 'Giai đoạn sâu bướm (ấu trùng).', 'Giai đoạn nhộng.', 'Giai đoạn bướm trưởng thành.'], 1, 'Ấu trùng (sâu non) ăn lá cây rất mạnh để tích lũy chất dinh dưỡng trước khi hóa nhộng.'],
      ['Nhân tố bên ngoài nào sau đây quyết định giới hạn sinh trưởng của cá rô phi ở Việt Nam (chỉ sống và lớn được từ 5,6°C đến 42°C, sinh trưởng tốt nhất ở 30°C)?', ['Nhân tố nhiệt độ môi trường.', 'Nhân tố tiếng ồn.', 'Nhân tố từ trường.', 'Nhân tố gió.'], 0, 'Mỗi loài sinh vật có một giới hạn nhiệt độ sinh trưởng nhất định; ngoài giới hạn đó sinh vật ngừng lớn hoặc chết.'],
      ['Vì sao vào mùa đông giá lạnh, nhiều loài gia súc, gia cầm (như lợn, gà) lại chậm lớn hơn dù vẫn ăn lượng thức ăn như mùa thu?', ['Vì cơ thể động vật hằng nhiệt phải tiêu tốn nhiều năng lượng từ thức ăn để sinh nhiệt giữ ấm cơ thể chống rét.', 'Vì mùa đông không có khí Oxygen.', 'Vì mùa đông động vật không ngủ.', 'Vì nước đóng băng trong dạ dày.'], 0, 'Trời rét làm cơ thể tiêu hao nhiều năng lượng để duy trì thân nhiệt, nên cần che chắn chuồng trại ấm áp và tăng khẩu phần ăn.'],
      ['Tại sao người trồng hoa cúc thường thắp đèn điện chiếu sáng ban đêm vào mùa thu – đông ở các vườn hoa?', ['Để bắt sâu ban đêm.', 'Để điều khiển thời gian chiếu sáng (quang chu kì) nhằm ức chế hoa cúc ra hoa sớm, giúp cây vươn cao hơn và nở hoa đúng vào dịp Tết Nguyên đán.', 'Để sưởi ấm cho đất.', 'Để khách tham quan chụp ảnh.'], 1, 'Hoa cúc là cây ngày ngắn (ra hoa khi đêm dài); thắp đèn ban đêm làm gián đoạn đêm dài giúp kìm hãm ra hoa sớm để bán đúng dịp Tết.'],
      ['Kĩ thuật “bấm ngọn, tỉa cành” khi trồng các loại cây như bầu, bí, mướp, đậu, cà phê, chè nhằm mục đích gì?', ['Làm cho cây chết nhanh.', 'Loại bỏ ưu thế đỉnh của chồi ngọn để kích thích các chồi nách (mô phân sinh ở nách lá) phát triển mạnh, tạo nhiều cành bên giúp tăng số hoa và quả.', 'Để rễ cây ngừng hút nước.', 'Để lá cây chuyển sang màu vàng.'], 1, 'Bấm ngọn giúp phá bỏ sự kìm hãm của chồi đỉnh, kích thích các chồi bên đâm nhánh cho năng suất cao.'],
      ['Ở người, giai đoạn nào có tốc độ sinh trưởng chiều cao và khối lượng cơ thể diễn ra mạnh mẽ và rõ rệt nhất (cùng với sự hoàn thiện cơ quan sinh dục)?', ['Giai đoạn tuổi già (trên 65 tuổi).', 'Giai đoạn dậy thì (thiếu niên khoảng 11 – 16 tuổi) và giai đoạn trẻ sơ sinh.', 'Giai đoạn 40 – 50 tuổi.', 'Giai đoạn 30 – 35 tuổi.'], 1, 'Ở tuổi dậy thì, hormone sinh trưởng (GH) và hormone sinh dục tiết ra mạnh thúc đẩy xương dài ra nhanh chóng.'],
    ]),
    trueFalseList: [
      {
        id: 'b34only-tf-1',
        stem: 'Xét mối quan hệ giữa sinh trưởng và phát triển ở sinh vật:',
        statements: [
          { id: 'a', text: 'Sinh trưởng là sự tăng lên về kích thước và khối lượng của cơ thể do tăng số lượng và kích thước tế bào.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Phát triển bao gồm ba quá trình liên quan mật thiết: sinh trưởng, phân hóa tế bào và phát sinh hình thái các cơ quan, cơ thể.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Sinh trưởng và phát triển là hai quá trình độc lập, tách rời nhau hoàn toàn trong đời sống sinh vật.', isTrue: false, explanation: 'Sai, sinh trưởng và phát triển luôn gắn bó mật thiết, đan xen nhau: sinh trưởng là cơ sở cho phát triển, và phát triển thúc đẩy sinh trưởng.' },
          { id: 'd', text: 'Mỗi loài sinh vật đều có tốc độ và giới hạn sinh trưởng đặc trưng do yếu tố di truyền quy định.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b34only-tf-2',
        stem: 'Xét vai trò của các loại mô phân sinh ở thực vật:',
        statements: [
          { id: 'a', text: 'Mô phân sinh là nhóm các tế bào chưa phân hóa, có khả năng phân chia tạo tế bào mới giúp cây lớn lên.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Mô phân sinh đỉnh có ở chồi đỉnh, chồi nách và đỉnh rễ, giúp thân và rễ cây dài ra.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Mô phân sinh bên giúp làm tăng đường kính (chiều ngang) của thân và rễ ở các cây Hai lá mầm thân gỗ.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Nếu cắt bỏ ngọn của một cây thân gỗ thì cây đó cũng ngừng to ra theo chiều ngang và chết ngay lập tức.', isTrue: false, explanation: 'Sai, cắt ngọn chỉ mất mô phân sinh đỉnh của ngọn đó (cây sẽ đâm chồi nách và vẫn to ra nhờ mô phân sinh bên).' },
        ],
      },
      {
        id: 'b34only-tf-3',
        stem: 'Xét các giai đoạn trong vòng đời phát triển của Ếch đồng và Muỗi:',
        statements: [
          { id: 'a', text: 'Cả ếch đồng và muỗi đều là những loài động vật phát triển qua biến thái hoàn toàn.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Ấu trùng của ếch là nòng nọc sống dưới nước, có đuôi để bơi và thở bằng mang; khi trưởng thành biến đổi thành ếch sống trên cạn/ẩm, có 4 chi và thở bằng phổi, da.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Ấu trùng của muỗi là lăng quăng (bọ gậy) sống trên lá cây khô ngoài nắng.', isTrue: false, explanation: 'Sai, trứng muỗi và bọ gậy/lăng quăng bắt buộc phải sống trong môi trường nước đọng.' },
          { id: 'd', text: 'Để phòng dịch sốt xuất huyết, biện pháp hiệu quả và bền vững nhất là diệt lăng quăng/bọ gậy và loại bỏ các dụng cụ chứa nước đọng quanh nhà.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b34only-tf-4',
        stem: 'Xét ảnh hưởng của các nhân tố môi trường (nhiệt độ, ánh sáng, nước, dinh dưỡng) đến sinh trưởng và phát triển:',
        statements: [
          { id: 'a', text: 'Nhiệt độ quá cao hoặc quá thấp ngoài giới hạn chịu đựng đều làm chậm hoặc ngừng sự sinh trưởng của thực vật và động vật.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Ánh sáng vừa cung cấp năng lượng cho cây quang hợp, vừa ảnh hưởng đến thời gian ra hoa của nhiều loài thực vật và sự tổng hợp Vitamin D ở động vật.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Trong chăn nuôi gia súc vào mùa đông lạnh ở miền Bắc, người nông dân không cần che chắn chuồng trại vì trời càng lạnh vật nuôi càng lớn nhanh.', isTrue: false, explanation: 'Sai, trời lạnh làm vật nuôi mất nhiệt, chậm lớn và dễ mắc bệnh nên phải sưởi ấm và che chắn chuồng trại.' },
          { id: 'd', text: 'Cung cấp đầy đủ nước và các chất dinh dưỡng cân đối giúp cây trồng, vật nuôi đạt tốc độ sinh trưởng tối ưu.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b34only-tf-5',
        stem: 'Xét các ứng dụng điều khiển sinh trưởng và phát triển trong sản xuất nông nghiệp:',
        statements: [
          { id: 'a', text: 'Thắp đèn chiếu sáng ban đêm cho vườn thanh long vào mùa đông giúp kích thích cây thanh long ra hoa trái vụ, mang lại hiệu quả kinh tế cao.', isTrue: true, explanation: 'Đúng (thanh long là cây ngày dài, thắp đèn giúp kích thích ra hoa trái vụ).' },
          { id: 'b', text: 'Ủ ấm hạt giống thóc trong nước ấm (khoảng 35°C – 40°C) giúp hạt hút nước và kích hoạt enzyme nảy mầm nhanh, đều hơn.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Bấm ngọn cây bầu, bí, mướp khi cây đã đủ chiều dài giúp các chồi nách phát triển thành nhiều nhánh mang hoa cái và quả.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Lạm dụng chất kích thích sinh trưởng tổng hợp vượt mức cho phép trên rau ăn lá ngay trước ngày thu hoạch là hoàn toàn an toàn cho người tiêu dùng.', isTrue: false, explanation: 'Sai, tồn dư hóa chất kích thích trên rau thu hoạch ngay gây ngộ độc và ảnh hưởng xấu đến sức khỏe con người.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b34only-es-1',
        question: 'Câu 1 [SGK KHTN 7 - KNTT]: Phân biệt khái niệm Sinh trưởng và Phát triển ở sinh vật. Lấy 2 ví dụ về sinh trưởng và 2 ví dụ về phát triển ở thực vật hoặc động vật.',
        hint: 'Sinh trưởng là tăng kích thước/khối lượng; Phát triển gắn liền với phân hóa tế bào và phát sinh hình thái.',
        sampleAnswer: '- Phân biệt:\n  + Sinh trưởng: Là sự tăng lên về kích thước (chiều cao, chiều dài, bề ngang) và khối lượng của cơ thể do sự tăng số lượng và kích thước của tế bào.\n  + Phát triển: Là toàn bộ những biến đổi diễn ra trong chu kì sống của cá thể, bao gồm sinh trưởng, phân hóa tế bào và phát sinh hình thái các cơ quan, cơ thể.\n- Ví dụ về sinh trưởng:\n  1. Cây ngô sau 1 tháng cao thêm 40 cm.\n  2. Chú gà con sau 2 tháng nuôi tăng cân từ 100 g lên 1,5 kg.\n- Ví dụ về phát triển:\n  1. Cây bưởi từ giai đoạn sinh dưỡng bắt đầu phân hóa mầm hoa, nở hoa và đậu quả.\n  2. Nòng nọc sống dưới nước rụng đuôi, mọc 4 chân và phát triển phổi trở thành ếch con.',
        rubricPoints: [
          'Nêu đúng khái niệm Sinh trưởng và Phát triển.',
          'Lấy đúng 2 ví dụ về sinh trưởng và 2 ví dụ về phát triển.',
        ],
      },
      {
        id: 'b34only-es-2',
        question: 'Câu 2 [SGK KHTN 7 - KNTT]: Mô phân sinh là gì? Phân biệt vị trí và vai trò của mô phân sinh đỉnh và mô phân sinh bên ở cây Hai lá mầm thân gỗ.',
        hint: 'Mô phân sinh đỉnh giúp cây cao lên; mô phân sinh bên giúp thân cây to ra.',
        sampleAnswer: '- Mô phân sinh là nhóm các tế bào chưa phân hóa, duy trì khả năng nguyên phân (phân chia) tạo ra các tế bào mới giúp thực vật sinh trưởng.\n- Phân biệt:\n  + Mô phân sinh đỉnh: Nằm ở đỉnh thân (chồi ngọn), chồi nách và đỉnh rễ (chóp rễ). Vai trò: Giúp thân, cành vươn cao và rễ mọc dài ra.\n  + Mô phân sinh bên: Nằm theo hình trụ dọc thân và rễ của cây Hai lá mầm thân gỗ. Vai trò: Phân chia tế bào theo chiều ngang giúp thân và rễ cây to ra (tăng đường kính và tạo vòng gỗ hàng năm).',
        rubricPoints: [
          'Nêu đúng khái niệm mô phân sinh.',
          'Phân biệt đúng vị trí và chức năng của mô phân sinh đỉnh và mô phân sinh bên.',
        ],
      },
      {
        id: 'b34only-es-3',
        question: 'Câu 3 [SBT KHTN 7 - KNTT]: Vẽ (hoặc viết sơ đồ) các giai đoạn trong vòng đời phát triển của loài Muỗi. Từ sơ đồ đó, hãy giải thích vì sao để phòng chống bệnh sốt xuất huyết hiệu quả, chúng ta cần tích cực diệt lăng quăng (bọ gậy) và khơi thông, dọn dẹp các vũng nước đọng quanh nhà?',
        hint: 'Sơ đồ 4 giai đoạn: Trứng → Ấu trùng (Bọ gậy/Lăng quăng) → Nhộng (Cung quăng) → Muỗi trưởng thành.',
        sampleAnswer: '- Sơ đồ vòng đời phát triển của muỗi:\nTrứng (đẻ trên mặt nước) → Ấu trùng (Bọ gậy / Lăng quăng sống trong nước) → Nhộng (Cung quăng sống trong nước) → Muỗi trưởng thành (bay lên không trung).\n- Giải thích biện pháp diệt bọ gậy:\n  + Trong 4 giai đoạn vòng đời của muỗi thì có tới 3 giai đoạn đầu (Trứng, Bọ gậy, Cung quăng) bắt buộc phải sống tập trung trong các dụng cụ chứa nước đọng và chưa biết bay.\n  + Vì vậy, việc đậy kín dụng cụ chứa nước, lật úp chậu/lọ đọng nước và thả cá ăn bọ gậy sẽ cắt đứt vòng đời phát triển của muỗi một cách dễ dàng, triệt để trước khi chúng kịp hóa thành muỗi trưởng thành bay đi truyền bệnh sốt xuất huyết.',
        rubricPoints: [
          'Viết đúng sơ đồ 4 giai đoạn vòng đời của muỗi.',
          'Giải thích đúng 3 giai đoạn đầu sống trong nước đọng nên diệt bọ gậy và loại bỏ nước đọng là hiệu quả nhất.',
        ],
      },
      {
        id: 'b34only-es-4',
        question: 'Câu 4: Để đạt chiều cao và thể lực tối ưu ở lứa tuổi dậy thì (THCS), học sinh cần thực hiện chế độ dinh dưỡng và sinh hoạt như thế nào? Vì sao thức khuya quá 23 giờ đêm lại làm hạn chế sự phát triển chiều cao?',
        hint: 'Liên hệ thời điểm tuyến yên tiết hormone sinh trưởng (GH) nhiều nhất khi ngủ sâu ban đêm.',
        sampleAnswer: '- Chế độ dinh dưỡng và sinh hoạt giúp phát triển chiều cao tối ưu ở tuổi dậy thì:\n  1. Ăn đủ chất và cân đối 4 nhóm dinh dưỡng, đặc biệt chú trọng thực phẩm giàu Protein, Calcium (sữa, tôm, cua, cá, trứng) và Vitamin D.\n  2. Thường xuyên tập các môn thể thao kích thích sụn tăng trưởng xương như bơi lội, bóng rổ, cầu lông, nhảy dây, chạy bộ dưới ánh nắng sớm.\n  3. Ngủ sớm trước 22 giờ và ngủ đủ 8 – 9 tiếng mỗi đêm.\n- Lý do thức khuya làm hạn chế chiều cao: Hormone sinh trưởng (GH) do tuyến yên tiết ra mạnh nhất vào khoảng từ 22 giờ đêm đến 2 giờ sáng khi cơ thể đang ở trạng thái NGỦ SÂU. Nếu thức khuya qua khung giờ này, lượng hormone GH tiết ra giảm sút mạnh làm xương chậm dài ra.',
        rubricPoints: [
          'Nêu đủ 3 yếu tố: dinh dưỡng giàu Ca/Protein/Vitamin D, vận động thể thao và ngủ đủ giấc.',
          'Giải thích đúng khung giờ vàng tiết hormone sinh trưởng khi ngủ sâu ban đêm.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 37: SINH SẢN Ở SINH VẬT
  // =========================================================================
  {
    id: 'kntt-bai-37',
    lessonNumber: 37,
    title: 'Bài 37 & 38: Sinh sản ở sinh vật',
    chapterTitle: 'Chương X: Sinh sản ở sinh vật',
    subject: 'biology',
    summary:
      'Sinh sản là quá trình tạo ra những cá thể mới đảm bảo sự phát triển liên tục của loài. Có hai hình thức sinh sản: Sinh sản vô tính (không có sự kết hợp giao tử đực – cái, con giống hệt mẹ; ứng dụng trong giâm cành, chiết cành, ghép cành, nuôi cấy mô) và Sinh sản hữu tính (có sự kết hợp giữa giao tử đực và giao tử cái qua thụ tinh tạo hợp tử).',
    keyFormulas: [
      'Sinh sản vô tính: Cơ thể mẹ ──(nguyên phân)──► Cơ thể con (mang đặc điểm giống hệt mẹ)',
      'Nhân giống vô tính ở thực vật: Giâm cành · Chiết cành · Ghép cây (ghép mắt/cành) · Nuôi cấy mô tế bào',
      'Sinh sản hữu tính: Giao tử đực (n) + Giao tử cái (n) ──(Thụ tinh)──► Hợp tử (2n) ──► Phôi ──► Cơ thể mới',
    ],
    mcqs: makeBioMcqs('b37only', [
      ['Sinh sản ở sinh vật là quá trình:', ['Tạo ra những cá thể mới, đảm bảo sự tồn tại và phát triển liên tục của loài.', 'Cơ thể lớn lên về kích thước.', 'Cơ thể phản ứng lại kích thích ánh sáng.', 'Cơ thể thải nước tiểu ra môi trường.'], 0, 'Định nghĩa sinh sản ở sinh vật trong SGK KHTN 7 KNTT.'],
      ['Đặc điểm cơ bản nhất của hình thức SINH SẢN VÔ TÍNH là:', ['Có sự kết hợp giữa tinh trùng và trứng.', 'Không có sự kết hợp giữa giao tử đực và giao tử cái; con sinh ra từ một phần cơ thể mẹ và có đặc điểm giống hệt cơ thể mẹ.', 'Con sinh ra luôn khác hoàn toàn cơ thể mẹ.', 'Chỉ xảy ra ở chim và thú.'], 1, 'Sinh sản vô tính chỉ từ một cá thể mẹ duy nhất, không có sự thụ tinh.'],
      ['Hình thức sinh sản vô tính bằng cách “nảy chồi” gặp ở loài động vật nào sau đây?', ['Thủy tức và san hô.', 'Chó và mèo.', 'Gà và vịt.', 'Cá chép và ếch.'], 0, 'Thủy tức, san hô sinh sản vô tính bằng hình thức mọc chồi trên cơ thể mẹ.'],
      ['Hiện tượng con thạch sùng (hoặc sao biển) khi bị đứt một phần đuôi/cánh có thể mọc lại phần đã mất, hoặc từ mảnh cơ thể tạo thành cá thể mới (ở giun dẹp, sao biển) liên quan đến hình thức nào?', ['Tái sinh (phân mảnh).', 'Thụ tinh kép.', 'Đẻ con.', 'Thụ phấn nhờ gió.'], 0, 'Sao biển, giun dẹp có khả năng sinh sản vô tính bằng phân mảnh và tái sinh.'],
      ['Ở cây thuốc bỏng (cây sống đời), các cây con mới thường mọc lên từ bộ phận nào của cây mẹ?', ['Từ mép của lá già khi rơi xuống đất ẩm.', 'Từ hạt phấn.', 'Từ cánh hoa.', 'Từ quả chín.'], 0, 'Cây thuốc bỏng sinh sản sinh dưỡng tự nhiên từ lá.'],
      ['Cây khoai lang và cây rau má sinh sản sinh dưỡng tự nhiên chủ yếu từ bộ phận nào?', ['Cây khoai lang từ rễ củ (hoặc đoạn thân dây); cây rau má từ thân bò.', 'Từ hoa.', 'Từ quả.', 'Từ bào tử.'], 0, 'Khoai lang nảy chồi từ rễ củ hoặc giâm dây thân; rau má, dâu tây mọc cây con từ thân bò.'],
      ['Kĩ thuật cắt một đoạn cành bánh tẻ (có đủ mắt chồi) của cây sắn, cây mía hoặc rau muống rồi cắm xuống đất ẩm cho ra rễ và phát triển thành cây mới được gọi là:', ['Chiết cành.', 'Giâm cành.', 'Ghép mắt.', 'Gieo hạt.'], 1, 'Giâm cành là cắt rời đoạn cành/thân cắm vào giá thể ẩm cho ra rễ thành cây mới.'],
      ['Đối với các cây ăn quả lâu năm khó ra rễ khi giâm cành (như cây cam, bưởi, nhãn, vải), người ta thường làm cho cành ra rễ ngay trên cây mẹ rồi mới cắt đem trồng. Kĩ thuật đó gọi là:', ['Giâm cành.', 'Chiết cành.', 'Nuôi cấy mô.', 'Thụ phấn nhân tạo.'], 1, 'Chiết cành giúp cành ra rễ ngay trên cây mẹ trước khi cắt hạ thổ, rút ngắn thời gian cho quả và giữ nguyên phẩm chất cây mẹ.'],
      ['Kĩ thuật dùng một mắt ghép hoặc cành ghép của cây có quả ngon gắn vào thân của một cây khác (gốc ghép có bộ rễ khỏe, chống chịu tốt) được gọi là:', ['Giâm cành.', 'Chiết cành.', 'Ghép cây (ghép mắt / ghép cành).', 'Sinh sản hữu tính.'], 2, 'Ghép cây kết hợp được ưu điểm của gốc ghép khỏe mạnh với phẩm chất quả ngon của cành/mắt ghép.'],
      ['Phương pháp nhân giống hiện đại nào cho phép tạo ra hàng vạn cây giống sạch bệnh, đồng đều về mặt di truyền chỉ từ một mẫu mô nhỏ của cây mẹ trong môi trường vô trùng?', ['Giâm cành truyền thống.', 'Chiết cành.', 'Nuôi cấy tế bào và mô thực vật (nhân giống in vitro).', 'Gieo hạt ngoài đồng.'], 2, 'Nuôi cấy mô tế bào có hệ số nhân giống cực cao và tạo cây giống sạch bệnh virus.'],
      ['Đặc điểm cơ bản của hình thức SINH SẢN HỮU TÍNH ở sinh vật là:', ['Không có giao tử đực và cái.', 'Có sự kết hợp giữa giao tử đực (tinh trùng/tinh tử) và giao tử cái (trứng/noãn cầu) thông qua quá trình thụ tinh tạo thành hợp tử.', 'Cơ thể mới mọc ra từ lá.', 'Con sinh ra không có sự đa dạng di truyền.'], 1, 'Bản chất của sinh sản hữu tính là sự giảm phân tạo giao tử và thụ tinh tạo hợp tử.'],
      ['Trong cấu tạo của hoa lưỡng tính ở thực vật có hoa, cơ quan sinh sản đực (Nhị hoa) gồm những bộ phận nào?', ['Chỉ nhị và bao phấn (bên trong bao phấn chứa các hạt phấn mang giao tử đực).', 'Đầu nhụy, vòi nhụy và bầu nhụy.', 'Đài hoa và cánh hoa.', 'Cuống hoa và lá bắc.'], 0, 'Nhị hoa gồm chỉ nhị và bao phấn chứa hạt phấn.'],
      ['Trong cấu tạo của hoa, cơ quan sinh sản cái (Nhụy hoa) gồm những bộ phận nào?', ['Chỉ nhị và bao phấn.', 'Đầu nhụy, vòi nhụy và bầu nhụy (bên trong bầu nhụy chứa noãn mang giao tử cái).', 'Cánh hoa và đài hoa.', 'Gân lá và cuống lá.'], 1, 'Nhụy hoa gồm đầu nhụy, vòi nhụy và bầu nhụy chứa noãn.'],
      ['Hiện tượng hạt phấn từ bao phấn tiếp xúc với đầu nhụy của cùng một hoa hoặc của hoa khác cùng loài được gọi là:', ['Sự thụ tinh.', 'Sự thụ phấn.', 'Sự nảy mầm.', 'Sự tạo quả.'], 1, 'Hạt phấn rơi trên đầu nhụy gọi là sự thụ phấn (có tự thụ phấn và thụ phấn chéo).'],
      ['Sau khi hạt phấn nảy mầm trên đầu nhụy thành ống phấn xuyên vào bầu nhụy, hiện tượng giao tử đực kết hợp với giao tử cái (trứng) trong túi phôi tạo thành hợp tử được gọi là:', ['Sự thụ phấn.', 'Sự thụ tinh.', 'Sự chiết cành.', 'Sự thoát hơi nước.'], 1, 'Giao tử đực kết hợp với giao tử cái tạo thành hợp tử gọi là sự thụ tinh.'],
      ['Ở thực vật có hoa, sau khi thụ tinh xong thì Hợp tử, Noãn và Bầu nhụy sẽ biến đổi thành gì?', ['Hợp tử phát triển thành Phôi; Noãn phát triển thành Hạt; Bầu nhụy phát triển thành Quả chứa hạt.', 'Bầu nhụy biến thành lá cây.', 'Cánh hoa biến thành hạt.', 'Nhị hoa biến thành quả.'], 0, 'Hợp tử → Phôi nằm trong Hạt (do noãn tạo thành); Bầu nhụy phình to thành Quả bảo vệ hạt.'],
      ['Vì sao sinh sản hữu tính lại giúp các loài sinh vật thích nghi tốt hơn với sự thay đổi của điều kiện môi trường sống so với sinh sản vô tính?', ['Vì con sinh ra từ sinh sản hữu tính nhận vật chất di truyền từ cả bố và mẹ nên tạo ra sự đa dạng phong phú về đặc điểm di truyền (biến dị tổ hợp).', 'Vì sinh sản hữu tính không cần năng lượng.', 'Vì sinh sản hữu tính diễn ra nhanh hơn giâm cành.', 'Vì sinh sản hữu tính chỉ tạo ra các cá thể giống hệt nhau.'], 0, 'Sự kết hợp giao tử đực và cái tạo ra thế hệ con đa dạng về di truyền, tăng khả năng thích nghi với môi trường biến đổi.'],
      ['Ở động vật có xương sống, nhóm loài nào sau đây đẻ con và nuôi con bằng sữa mẹ (phôi phát triển trong tử cung của cơ thể mẹ)?', ['Cá chép và ếch đồng.', 'Gà, vịt và chim bồ câu.', 'Lớp Thú (chó, mèo, trâu, bò, cá voi, con người).', 'Thằn lằn và rùa.'], 2, 'Các loài thuộc lớp Thú có hình thức thụ tinh trong, thai sinh (đẻ con) và nuôi con bằng sữa mẹ, đạt hiệu quả bảo vệ phôi và con non cao nhất.'],
    ]),
    trueFalseList: [
      {
        id: 'b37only-tf-1',
        stem: 'So sánh sinh sản vô tính và sinh sản hữu tính ở sinh vật:',
        statements: [
          { id: 'a', text: 'Sinh sản vô tính là hình thức sinh sản không có sự kết hợp giữa giao tử đực và giao tử cái, cơ thể con hình thành từ một phần cơ thể mẹ.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Trong sinh sản vô tính, các cá thể con sinh ra có đặc điểm di truyền giống hệt nhau và giống cơ thể mẹ ban đầu.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Sinh sản hữu tính luôn có quá trình thụ tinh giữa giao tử đực và giao tử cái tạo thành hợp tử.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Thế hệ con của sinh sản vô tính có độ đa dạng di truyền cao hơn và thích nghi với môi trường thay đổi tốt hơn sinh sản hữu tính.', isTrue: false, explanation: 'Sai, sinh sản hữu tính mới tạo ra sự đa dạng di truyền cao và giúp loài thích nghi tốt với môi trường thay đổi.' },
        ],
      },
      {
        id: 'b37only-tf-2',
        stem: 'Xét các phương pháp nhân giống vô tính (sinh sản sinh dưỡng) ở cây trồng:',
        statements: [
          { id: 'a', text: 'Giâm cành được áp dụng phổ biến cho các cây dễ ra rễ phụ từ thân/cành như sắn, mía, khoai lang, rau muống, hoa hồng.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Chiết cành giúp nhân giống các cây ăn quả lâu năm (nhãn, vải, bưởi, cam) cho cây con giữ nguyên đặc tính quả ngon của cây mẹ và sớm ra hoa kết quả hơn so với trồng bằng hạt.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Khi chiết cành, người ta phải cạo sạch cả phần mạch gỗ bên trong cành để nước không thể đi lên nuôi lá của cành chiết.', isTrue: false, explanation: 'Sai, chỉ bóc lớp vỏ (chứa mạch rây) và cạo lớp mô phân sinh bên, tuyệt đối giữ nguyên phần mạch gỗ để nước và khoáng vẫn đi lên nuôi cành chiết tươi sống.' },
          { id: 'd', text: 'Nuôi cấy mô tế bào thực vật giúp nhân nhanh số lượng lớn cây giống sạch bệnh (như hoa phong lan, chuối, khoai tây) trong thời gian ngắn.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b37only-tf-3',
        stem: 'Xét cấu tạo hoa và quá trình thụ phấn – thụ tinh ở thực vật có hoa:',
        statements: [
          { id: 'a', text: 'Nhị hoa là cơ quan sinh sản đực (chứa hạt phấn), còn nhụy hoa là cơ quan sinh sản cái (có bầu nhụy chứa noãn).', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Thụ phấn là hiện tượng hạt phấn tiếp xúc với đầu nhụy; sau đó hạt phấn nảy mầm thành ống phấn dẫn giao tử đực đến kết hợp với trứng trong noãn gọi là thụ tinh.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Những loài hoa thụ phấn nhờ côn trùng (ong, bướm) thường có cánh hoa sặc sỡ, có tuyến mật và hương thơm để thu hút côn trùng.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Sau khi thụ tinh, cánh hoa phát triển thành hạt còn nhị hoa phát triển thành quả.', isTrue: false, explanation: 'Sai, sau thụ tinh: Hợp tử → Phôi; Noãn → Hạt; Bầu nhụy → Quả (còn cánh hoa và nhị hoa thường héo và rụng đi).' },
        ],
      },
      {
        id: 'b37only-tf-4',
        stem: 'Xét sinh sản hữu tính ở động vật (thụ tinh ngoài và thụ tinh trong, đẻ trứng và đẻ con):',
        statements: [
          { id: 'a', text: 'Ở cá chép và ếch đồng, trứng và tinh trùng gặp nhau ở môi trường nước bên ngoài cơ thể con cái nên gọi là thụ tinh ngoài.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Ở bò sát, chim và thú, trứng và tinh trùng kết hợp với nhau trong cơ quan sinh sản của con cái nên gọi là thụ tinh trong (hiệu suất thụ tinh cao hơn nhiều so với thụ tinh ngoài).', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Hình thức đẻ con (thai sinh) ở lớp Thú giúp phôi được bảo vệ an toàn và cung cấp dinh dưỡng trực tiếp qua nhau thai trong cơ thể mẹ.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Tất cả các loài động vật sống dưới nước đều đẻ trứng và thụ tinh ngoài.', isTrue: false, explanation: 'Sai, cá voi, cá heo sống dưới nước nhưng thuộc lớp Thú nên thụ tinh trong và đẻ con.' },
        ],
      },
      {
        id: 'b37only-tf-5',
        stem: 'Xét các yếu tố ảnh hưởng và ứng dụng điều khiển sinh sản trong nông nghiệp:',
        statements: [
          { id: 'a', text: 'Thực hiện thụ phấn nhân tạo cho bầu, bí, mướp, ngô khi thời tiết mưa lạnh ít côn trùng giúp tăng tỉ lệ đậu quả và năng suất hạt.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Trong chăn nuôi bò, lợn và cá, kĩ thuật thụ tinh nhân tạo giúp nhân nhanh các giống vật nuôi có năng suất, chất lượng cao.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Nhiệt độ ấp trứng của một số loài bò sát (như rùa, cá sấu) có thể ảnh hưởng trực tiếp đến tỉ lệ giới tính đực – cái của con non nở ra.', isTrue: true, explanation: 'Đúng hiện tượng sinh học thực tế.' },
          { id: 'd', text: 'Con người có thể đánh bắt tận diệt cá bố mẹ vào đúng mùa cá đẻ trứng mà không làm suy giảm số lượng cá trong tự nhiên.', isTrue: false, explanation: 'Sai, đánh bắt cá vào mùa sinh sản làm cạn kiệt nguồn lợi thủy sản tự nhiên.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b37only-es-1',
        question: 'Câu 1 [SGK KHTN 7 - KNTT]: Phân biệt Sinh sản vô tính và Sinh sản hữu tính ở sinh vật về: Khái niệm, Cơ sở tế bào học, Đặc điểm di truyền của con so với bố mẹ và Khả năng thích nghi với môi trường sống.',
        hint: 'Kẻ bảng hoặc trình bày từng tiêu chí đối chiếu giữa Vô tính và Hữu tính.',
        sampleAnswer: 'Phân biệt Sinh sản vô tính và Sinh sản hữu tính:\n1. Khái niệm:\n- Sinh sản vô tính: Không có sự kết hợp giữa giao tử đực và giao tử cái; con hình thành từ một phần cơ thể mẹ.\n- Sinh sản hữu tính: Có sự kết hợp giữa giao tử đực và giao tử cái thông qua thụ tinh tạo hợp tử.\n2. Đặc điểm di truyền của cơ thể con:\n- Sinh sản vô tính: Con sinh ra giống hệt nhau và giống hệt cơ thể mẹ.\n- Sinh sản hữu tính: Con sinh ra mang đặc điểm di truyền kết hợp từ cả bố và mẹ nên rất đa dạng.\n3. Khả năng thích nghi:\n- Sinh sản vô tính: Thích nghi tốt trong môi trường sống ổn định, nhưng dễ bị diệt vong hàng loạt nếu môi trường biến đổi bất lợi.\n- Sinh sản hữu tính: Thích nghi cao với môi trường sống thay đổi.',
        rubricPoints: [
          'Phân biệt đúng sự có/không có kết hợp giao tử đực và cái.',
          'So sánh đúng đặc điểm di truyền của đời con và khả năng thích nghi môi trường.',
        ],
      },
      {
        id: 'b37only-es-2',
        question: 'Câu 2 [SGK KHTN 7 - KNTT]: Tại sao trong trồng trọt cây ăn quả lâu năm (như cam, bưởi, nhãn, vải, xoài), người nông dân thường nhân giống bằng phương pháp chiết cành hoặc ghép cây mà ít khi nhân giống bằng cách gieo hạt?',
        hint: 'Nêu 2 ưu điểm lớn của chiết/ghép cành: giữ nguyên phẩm chất quả ngon của cây mẹ và rút ngắn thời gian cho thu hoạch.',
        sampleAnswer: 'Người nông dân ưu tiên chiết cành hoặc ghép cây đối với cây ăn quả lâu năm vì 2 lí do chính:\n1. Giữ nguyên được các đặc tính quý (quả to, ngọt, thơm, ít hạt) của cây mẹ vì đây là hình thức sinh sản vô tính; trong khi nếu trồng bằng hạt (sinh sản hữu tính qua thụ phấn chéo) cây con dễ bị phân tính, quả thường chua hoặc kém chất lượng hơn cây mẹ.\n2. Rút ngắn thời gian sinh trưởng: Cây chiết hoặc ghép được lấy từ cành của cây mẹ đã trưởng thành nên chỉ sau 1 – 2 năm trồng đã bắt đầu ra hoa kết quả (trong khi trồng từ hạt phải mất 4 – 6 năm mới có quả).',
        rubricPoints: [
          'Nêu đúng ưu điểm giữ nguyên phẩm chất di truyền tốt của cây mẹ.',
          'Nêu đúng ưu điểm rút ngắn thời gian ra hoa, thu hoạch quả.',
        ],
      },
      {
        id: 'b37only-es-3',
        question: 'Câu 3 [SGK KHTN 7 - KNTT]: Phân biệt quá trình Thụ phấn và quá trình Thụ tinh ở thực vật có hoa. Nêu sự hình thành hạt và quả sau khi thụ tinh.',
        hint: 'Thụ phấn là hạt phấn rơi lên đầu nhụy; Thụ tinh là giao tử đực kết hợp giao tử cái trong noãn.',
        sampleAnswer: '- Phân biệt:\n  + Thụ phấn: Là hiện tượng hạt phấn từ nhị tiếp xúc với đầu nhụy (nhờ gió, côn trùng hoặc con người).\n  + Thụ tinh: Sau khi thụ phấn, hạt phấn nảy mầm thành ống phấn xuyên qua vòi nhụy vào bầu nhụy; tại đây giao tử đực kết hợp với giao tử cái (trứng) trong noãn tạo thành hợp tử.\n- Sự hình thành hạt và quả sau thụ tinh:\n  + Hợp tử phân chia phát triển thành Phôi.\n  + Noãn đã thụ tinh (chứa phôi và chất dinh dưỡng dự trữ) phát triển thành Hạt.\n  + Bầu nhụy sinh trưởng dày lên phát triển thành Quả bao bọc và bảo vệ hạt.',
        rubricPoints: [
          'Phân biệt rõ hiện tượng Thụ phấn và bản chất kết hợp giao tử của Thụ tinh.',
          'Nêu đúng: Hợp tử → Phôi; Noãn → Hạt; Bầu nhụy → Quả.',
        ],
      },
      {
        id: 'b37only-es-4',
        question: 'Câu 4 [SBT KHTN 7 - KNTT]: Giải thích tại sao vào những ngày mưa dầm hoặc trời lạnh ít ong bướm, người trồng bầu, bí, mướp thường phải ngắt hoa đực úp trực tiếp vào đầu nhụy của hoa cái (thụ phấn bổ sung)?',
        hint: 'Hoa bầu, bí, mướp là hoa đơn tính thụ phấn nhờ côn trùng; nếu không được thụ phấn bầu nhụy sẽ héo rụng.',
        sampleAnswer: '- Hoa bầu, bí, mướp là hoa đơn tính (hoa đực và hoa cái riêng biệt), hạt phấn to và dính nên trong tự nhiên chủ yếu thụ phấn nhờ côn trùng (ong, bướm).\n- Vào những ngày mưa dầm hoặc giá lạnh, côn trùng ít bay đi kiếm mật nên hạt phấn từ hoa đực không chuyển sang đầu nhụy hoa cái được.\n- Nếu hoa cái không được thụ phấn và thụ tinh thì bầu nhụy sẽ bị vàng úa và rụng đi (không đậu quả). Do đó, con người chủ động ngắt hoa đực chấm hạt phấn lên đầu nhụy hoa cái để đảm bảo tỉ lệ đậu quả đạt mức cao nhất.',
        rubricPoints: [
          'Giải thích đúng hoa bầu, bí là hoa đơn tính thụ phấn nhờ côn trùng.',
          'Nêu đúng tác dụng của thụ phấn nhân tạo giúp hoa cái được thụ tinh và đậu quả.',
        ],
      },
      {
        id: 'b37only-es-5',
        question: 'Câu 5: Tại sao ở động vật, hình thức thụ tinh trong và đẻ con (như ở lớp Thú) lại tiến hóa và hiệu quả hơn so với hình thức thụ tinh ngoài và đẻ trứng trong nước (như ở Cá, Lưỡng cư)?',
        hint: 'So sánh xác suất gặp nhau của tinh trùng – trứng và mức độ bảo vệ phôi trước kẻ thù, thời tiết.',
        sampleAnswer: '- Về sự thụ tinh: Thụ tinh ngoài diễn ra trong môi trường nước nên tinh trùng và trứng dễ bị dòng nước cuốn trôi, xác suất gặp nhau thấp (con cái phải đẻ hàng nghìn trứng). Ngược lại, thụ tinh trong diễn ra ngay trong đường sinh dục con cái nên tỉ lệ trứng được thụ tinh rất cao.\n- Về sự phát triển phôi và con non: Đẻ trứng trong nước dễ bị các loài khác ăn mất hoặc hỏng do nhiệt độ nước thay đổi. Còn ở hình thức đẻ con (lớp Thú), phôi phát triển an toàn trong tử cung mẹ, được nuôi dưỡng trực tiếp qua nhau thai và sau khi sinh con non còn được nuôi bằng sữa mẹ và được mẹ bảo vệ, dạy tập tính săn mồi nên tỉ lệ sống sót cao vượt trội.',
        rubricPoints: [
          'So sánh đúng hiệu suất thụ tinh trong cao hơn thụ tinh ngoài.',
          'Giải thích đúng sự bảo vệ và nuôi dưỡng phôi trong cơ thể mẹ giúp tỉ lệ sống sót cao.',
        ],
      },
    ],
  },
];
