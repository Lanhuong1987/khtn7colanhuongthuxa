export type SubSubject = 'physics' | 'chemistry' | 'biology';

export type CognitiveLevel = 'Nhận biết' | 'Thông hiểu' | 'Vận dụng';

export interface ElementData {
  z: number;
  symbol: string;
  nameIupac: string;
  nameVi: string;
  neutrons: number;
  mass: number;
  shells: number[];
  period: number;
  group: string;
  valence: string;
  category: 'Phi kim' | 'Kim loại' | 'Khí hiếm';
  application: string;
}

export interface TheoryTopic {
  id: string;
  subject: SubSubject;
  chapterCode: string;
  title: string;
  duration: string;
  coreFormula: string;
  summary: string;
  keyPoints: string[];
  practicalExample: string;
  quickCheckQuestion: {
    prompt: string;
    answer: string;
    explanation: string;
  };
}

export interface QuizQuestion {
  id: string;
  subject: SubSubject;
  topic: string;
  level: CognitiveLevel;
  question: string;
  options: string[];
  correctIndex: number;
  formulaHint?: string;
  explanation: string;
}

export interface ValenceChallenge {
  id: string;
  title: string;
  elementA: { symbol: string; name: string; valence: number };
  elementB: { symbol: string; name: string; valence: number; isGroup?: boolean };
  correctX: number;
  correctY: number;
  formulaDisplay: string;
  molecularMass: number;
  explanation: string;
}

export interface ClassificationItem {
  id: string;
  statement: string;
  subject: SubSubject;
  reason: string;
}

export const SUBJECT_LABELS: Record<SubSubject, { name: string; domain: string; code: string }> = {
  chemistry: {
    name: 'Hóa học 7',
    domain: 'Chất và sự biến đổi của chất',
    code: 'CHM-07',
  },
  physics: {
    name: 'Vật lí 7',
    domain: 'Năng lượng và sự biến đổi',
    code: 'PHY-07',
  },
  biology: {
    name: 'Sinh học 7',
    domain: 'Vật sống và trao đổi chất',
    code: 'BIO-07',
  },
};

export const ELEMENTS_FIRST_20: ElementData[] = [
  { z: 1, symbol: 'H', nameIupac: 'Hydrogen', nameVi: 'Hiđrô', neutrons: 0, mass: 1, shells: [1], period: 1, group: 'IA', valence: 'I', category: 'Phi kim', application: 'Nhiên liệu sạch, cấu tạo phân tử nước và hợp chất hữu cơ.' },
  { z: 2, symbol: 'He', nameIupac: 'Helium', nameVi: 'Hêli', neutrons: 2, mass: 4, shells: [2], period: 1, group: 'VIIIA', valence: 'Không phản ứng', category: 'Khí hiếm', application: 'Bơm khí cầu an toàn, làm lạnh siêu dẫn.' },
  { z: 3, symbol: 'Li', nameIupac: 'Lithium', nameVi: 'Liti', neutrons: 4, mass: 7, shells: [2, 1], period: 2, group: 'IA', valence: 'I', category: 'Kim loại', application: 'Chế tạo pin sạc Li-ion cho điện thoại và xe điện.' },
  { z: 4, symbol: 'Be', nameIupac: 'Beryllium', nameVi: 'Beri', neutrons: 5, mass: 9, shells: [2, 2], period: 2, group: 'IIA', valence: 'II', category: 'Kim loại', application: 'Hợp kim nhẹ siêu bền trong hàng không vũ trụ.' },
  { z: 5, symbol: 'B', nameIupac: 'Boron', nameVi: 'Bo', neutrons: 6, mass: 11, shells: [2, 3], period: 2, group: 'IIIA', valence: 'III', category: 'Phi kim', application: 'Sản xuất thủy tinh chịu nhiệt Pyrex trong phòng thí nghiệm.' },
  { z: 6, symbol: 'C', nameIupac: 'Carbon', nameVi: 'Cacbon', neutrons: 6, mass: 12, shells: [2, 4], period: 2, group: 'IVA', valence: 'IV, II', category: 'Phi kim', application: 'Nền tảng của sự sống hữu cơ, than chì, kim cương.' },
  { z: 7, symbol: 'N', nameIupac: 'Nitrogen', nameVi: 'Nitơ', neutrons: 7, mass: 14, shells: [2, 5], period: 2, group: 'VA', valence: 'III, II, IV', category: 'Phi kim', application: 'Chiếm 78% thể tích không khí, sản xuất phân đạm nuôi cây.' },
  { z: 8, symbol: 'O', nameIupac: 'Oxygen', nameVi: 'Oxi', neutrons: 8, mass: 16, shells: [2, 6], period: 2, group: 'VIA', valence: 'II', category: 'Phi kim', application: 'Duy trì sự hô hấp của sinh vật và sự cháy.' },
  { z: 9, symbol: 'F', nameIupac: 'Fluorine', nameVi: 'Flo', neutrons: 10, mass: 19, shells: [2, 7], period: 2, group: 'VIIA', valence: 'I', category: 'Phi kim', application: 'Hợp chất Fluoride bảo vệ men răng, chất chống dính Teflon.' },
  { z: 10, symbol: 'Ne', nameIupac: 'Neon', nameVi: 'Neon', neutrons: 10, mass: 20, shells: [2, 8], period: 2, group: 'VIIIA', valence: 'Không phản ứng', category: 'Khí hiếm', application: 'Đèn ống phát sáng quảng cáo màu đỏ cam đặc trưng.' },
  { z: 11, symbol: 'Na', nameIupac: 'Sodium', nameVi: 'Natri', neutrons: 12, mass: 23, shells: [2, 8, 1], period: 3, group: 'IA', valence: 'I', category: 'Kim loại', application: 'Thành phần chính của muối ăn (NaCl) và nước muối sinh lí.' },
  { z: 12, symbol: 'Mg', nameIupac: 'Magnesium', nameVi: 'Magiê', neutrons: 12, mass: 24, shells: [2, 8, 2], period: 3, group: 'IIA', valence: 'II', category: 'Kim loại', application: 'Trung tâm phân tử diệp lục ở lá cây; hợp kim vỏ máy tính.' },
  { z: 13, symbol: 'Al', nameIupac: 'Aluminium', nameVi: 'Nhôm', neutrons: 14, mass: 27, shells: [2, 8, 3], period: 3, group: 'IIIA', valence: 'III', category: 'Kim loại', application: 'Vật liệu nhẹ dẫn điện, chế tạo vỏ máy bay và đồ gia dụng.' },
  { z: 14, symbol: 'Si', nameIupac: 'Silicon', nameVi: 'Silic', neutrons: 14, mass: 28, shells: [2, 8, 4], period: 3, group: 'IVA', valence: 'IV', category: 'Phi kim', application: 'Vật liệu bán dẫn chế tạo vi mạch máy tính và pin mặt trời.' },
  { z: 15, symbol: 'P', nameIupac: 'Phosphorus', nameVi: 'Photpho', neutrons: 16, mass: 31, shells: [2, 8, 5], period: 3, group: 'VA', valence: 'III, V', category: 'Phi kim', application: 'Cấu tạo phân tử năng lượng ATP, ADN và sản xuất phân lân.' },
  { z: 16, symbol: 'S', nameIupac: 'Sulfur', nameVi: 'Lưu huỳnh', neutrons: 16, mass: 32, shells: [2, 8, 6], period: 3, group: 'VIA', valence: 'II, IV, VI', category: 'Phi kim', application: 'Lưu hóa cao su, sản xuất Sulfuric acid trong công nghiệp.' },
  { z: 17, symbol: 'Cl', nameIupac: 'Chlorine', nameVi: 'Clo', neutrons: 18, mass: 35.5, shells: [2, 8, 7], period: 3, group: 'VIIA', valence: 'I', category: 'Phi kim', application: 'Khử trùng nước sinh hoạt, sản xuất nhựa PVC.' },
  { z: 18, symbol: 'Ar', nameIupac: 'Argon', nameVi: 'Agon', neutrons: 22, mass: 40, shells: [2, 8, 8], period: 3, group: 'VIIIA', valence: 'Không phản ứng', category: 'Khí hiếm', application: 'Bơm vào bóng đèn sợi đốt để bảo vệ dây tóc khỏi oxi hóa.' },
  { z: 19, symbol: 'K', nameIupac: 'Potassium', nameVi: 'Kali', neutrons: 20, mass: 39, shells: [2, 8, 8, 1], period: 4, group: 'IA', valence: 'I', category: 'Kim loại', application: 'Nguyên tố dinh dưỡng thiết yếu điều hòa đóng mở khí khổng.' },
  { z: 20, symbol: 'Ca', nameIupac: 'Calcium', nameVi: 'Canxi', neutrons: 20, mass: 40, shells: [2, 8, 8, 2], period: 4, group: 'IIA', valence: 'II', category: 'Kim loại', application: 'Thành phần cấu tạo hệ xương, răng và đá vôi (CaCO3).' },
];

export const THEORY_TOPICS: TheoryTopic[] = [
  {
    id: 'chm-1',
    subject: 'chemistry',
    chapterCode: 'Chủ đề 1',
    title: 'Nguyên tử & Mô hình Rutherford–Bohr',
    duration: '15 phút',
    coreFormula: 'Z = p = e  |  A ≈ p + n (amu)',
    summary: 'Nguyên tử là hạt vô cùng nhỏ, trung hòa về điện, gồm hạt nhân mang điện tích dương (chứa proton và neutron) và vỏ nguyên tử chứa các electron mang điện tích âm chuyển động trên các lớp xác định.',
    keyPoints: [
      'Điện tích hạt: Proton (p) mang điện +1; Electron (e) mang điện -1; Neutron (n) không mang điện.',
      'Trong nguyên tử trung hòa: Số đơn vị điện tích hạt nhân Z = số hạt proton (p) = số hạt electron (e).',
      'Khối lượng nguyên tử tập trung hầu hết ở hạt nhân: A ≈ p + n (đơn vị amu, với m_p ≈ m_n ≈ 1 amu, m_e ≈ 0,00055 amu).',
      'Các electron sắp xếp thành từng lớp từ trong ra ngoài: Lớp 1 tối đa 2e; Lớp 2 tối đa 8e; Lớp 3 (với Z ≤ 20) tối đa 8e.',
    ],
    practicalExample: 'Nguyên tử Oxygen (Z = 8) có 8 proton trong hạt nhân, 8 electron ở vỏ chia làm 2 lớp: lớp trong 2e, lớp ngoài cùng 6e. Khối lượng nguyên tử Oxygen là 8 + 8 = 16 amu.',
    quickCheckQuestion: {
      prompt: 'Một nguyên tử Aluminium có 13 proton và 14 neutron. Hỏi nguyên tử này có bao nhiêu electron ở lớp ngoài cùng và khối lượng nguyên tử bằng bao nhiêu amu?',
      answer: '3 electron lớp ngoài cùng (phân bố 2, 8, 3) và khối lượng 27 amu',
      explanation: 'Vì p = e = 13 nên phân bố electron trên 3 lớp là 2 - 8 - 3 (3e lớp ngoài cùng). Khối lượng nguyên tử A = p + n = 13 + 14 = 27 amu.',
    },
  },
  {
    id: 'chm-2',
    subject: 'chemistry',
    chapterCode: 'Chủ đề 2',
    title: 'Bảng tuần hoàn các nguyên tố hóa học',
    duration: '20 phút',
    coreFormula: 'STT ô = Z  |  Số chu kì = Số lớp e  |  Số nhóm A = Số e lớp ngoài cùng',
    summary: 'Bảng tuần hoàn sắp xếp các nguyên tố theo chiều tăng dần của điện tích hạt nhân nguyên tử, giúp dự đoán tính chất kim loại, phi kim hay khí hiếm dựa vào vị trí ô, chu kì và nhóm.',
    keyPoints: [
      'Ô nguyên tố: Số thứ tự của ô nguyên tố bằng số hiệu nguyên tử (Z = số p = số e).',
      'Chu kì (hàng ngang): Tập hợp các nguyên tố có cùng số lớp electron trong nguyên tử (Bảng tuần hoàn có 7 chu kì).',
      'Nhóm A (cột dọc): Các nguyên tố có cùng số electron lớp ngoài cùng nên có tính chất hóa học tương tự nhau.',
      'Nhóm IA, IIA, IIIA (trừ H, B) là kim loại; Nhóm VA, VIA, VIIA thường là phi kim; Nhóm VIIIA là khí hiếm bền vững (8e lớp ngoài cùng, riêng He có 2e).',
    ],
    practicalExample: 'Nguyên tố Magnesium (Z = 12) có phân bố electron (2, 8, 2) → Nằm ở ô số 12, chu kì 3 (vì có 3 lớp e), nhóm IIA (vì có 2e lớp ngoài cùng), thuộc loại kim loại.',
    quickCheckQuestion: {
      prompt: 'Nguyên tố X nằm ở chu kì 3, nhóm VIIA. Hãy xác định số lớp electron và số electron lớp ngoài cùng của X.',
      answer: '3 lớp electron và 7 electron ở lớp ngoài cùng (Chlorine, Z = 17)',
      explanation: 'Số thứ tự chu kì = số lớp electron = 3. Số thứ tự nhóm VIIA = số electron lớp ngoài cùng = 7. Tổng số e = 2 + 8 + 7 = 17 (Chlorine).',
    },
  },
  {
    id: 'chm-3',
    subject: 'chemistry',
    chapterCode: 'Chủ đề 3',
    title: 'Phân tử – Liên kết hóa học – Hóa trị',
    duration: '25 phút',
    coreFormula: 'Quy tắc hóa trị trong AₓBᵧ:  x · a = y · b',
    summary: 'Các nguyên tử liên kết với nhau theo xu hướng đạt lớp vỏ electron bền vững của khí hiếm (bằng cách nhường - nhận electron tạo liên kết ion, hoặc góp chung electron tạo liên kết cộng hóa trị).',
    keyPoints: [
      'Đơn chất tạo nên từ 1 nguyên tố hóa học (VD: O₂, Cu, N₂); Hợp chất tạo nên từ 2 nguyên tố trở lên (VD: H₂O, NaCl, CO₂).',
      'Liên kết ion: Hình thành do lực hút tĩnh điện giữa ion dương (kim loại nhường e) và ion âm (phi kim nhận e), điển hình như NaCl, MgO.',
      'Liên kết cộng hóa trị: Hình thành bằng sự dùng chung một hay nhiều cặp electron giữa các nguyên tử phi kim (VD: H₂O, CO₂, NH₃).',
      'Quy tắc hóa trị: Trong công thức hóa học AₓBᵧ (với a, b là hóa trị của A và B), tích chỉ số và hóa trị của nguyên tố này bằng tích chỉ số và hóa trị của nguyên tố kia: x · a = y · b.',
    ],
    practicalExample: 'Lập CTHH của hợp chất gồm Al (hóa trị III) và O (hóa trị II): Áp dụng x · III = y · II ⇒ x/y = 2/3 ⇒ CTHH là Al₂O₃, khối lượng phân tử = 27·2 + 16·3 = 102 amu.',
    quickCheckQuestion: {
      prompt: 'Lập công thức hóa học và tính khối lượng phân tử của hợp chất tạo bởi Iron(III) (Fe = 56) và nhóm Sulfate SO₄ (hóa trị II, S = 32, O = 16).',
      answer: 'Fe₂(SO₄)₃ — Khối lượng phân tử: 400 amu',
      explanation: 'Fe có hóa trị III, nhóm SO₄ có hóa trị II ⇒ Chỉ số của Fe là 2, của nhóm (SO₄) là 3: Fe₂(SO₄)₃. KLPT = 56·2 + (32 + 16·4)·3 = 112 + 96·3 = 400 amu.',
    },
  },
  {
    id: 'phy-1',
    subject: 'physics',
    chapterCode: 'Chủ đề 4',
    title: 'Tốc độ chuyển động & Đồ thị Quãng đường – Thời gian',
    duration: '20 phút',
    coreFormula: 'v = s / t  |  1 m/s = 3,6 km/h',
    summary: 'Tốc độ cho biết mức độ nhanh hay chậm của chuyển động, được xác định bằng quãng đường đi được trong một đơn vị thời gian. Đồ thị quãng đường - thời gian biểu diễn trực quan hành trình của vật.',
    keyPoints: [
      'Công thức tính tốc độ: v = s / t (trong đó s là quãng đường, t là thời gian đi hết quãng đường đó).',
      'Hệ quả biến đổi: Quãng đường s = v · t; Thời gian t = s / v.',
      'Đổi đơn vị chuẩn: 1 m/s = 3,6 km/h; ngược lại đổi từ km/h sang m/s ta chia cho 3,6 (VD: 36 km/h = 10 m/s; 54 km/h = 15 m/s).',
      'Trên đồ thị s - t: Đường biểu diễn là đường thẳng nằm nghiêng cho biết vật chuyển động với tốc độ không đổi; đường càng dốc thì tốc độ càng lớn; đường nằm ngang song song trục Ot cho biết vật đang đứng yên.',
    ],
    practicalExample: 'Một vận động viên chạy cự li 100 m hết 10 s thì tốc độ trung bình là v = 100 / 10 = 10 m/s = 36 km/h.',
    quickCheckQuestion: {
      prompt: 'Một ô tô đi trên quãng đường 90 km trong 1 giờ 30 phút. Tốc độ của ô tô theo đơn vị km/h và m/s là bao nhiêu?',
      answer: '60 km/h (tương đương 16,67 m/s)',
      explanation: 'Đổi t = 1 giờ 30 phút = 1,5 h. Tốc độ v = s / t = 90 / 1,5 = 60 km/h = 60 / 3,6 ≈ 16,67 m/s.',
    },
  },
  {
    id: 'phy-2',
    subject: 'physics',
    chapterCode: 'Chủ đề 5',
    title: 'Sóng âm – Độ cao, Độ to và Phản xạ âm',
    duration: '18 phút',
    coreFormula: 'f = N / t (Hz)  |  v_rắn > v_lỏng > v_khí',
    summary: 'Âm phát ra từ các nguồn âm đang dao động và truyền được qua môi trường chất rắn, lỏng, khí (không truyền được trong chân không). Tần số quyết định độ cao, biên độ quyết định độ to của âm.',
    keyPoints: [
      'Tần số (f): Số dao động thực hiện trong 1 giây, đơn vị là Héc (Hz). Tần số càng lớn thì âm nghe càng cao (bổng); tần số càng nhỏ thì âm càng thấp (trầm).',
      'Biên độ dao động: Độ lệch lớn nhất của vật dao động so với vị trí cân bằng. Biên độ càng lớn thì âm phát ra càng to.',
      'Tốc độ truyền âm trong chất rắn lớn hơn trong chất lỏng, và trong chất lỏng lớn hơn trong chất khí (VD: trong không khí ≈ 340 m/s, trong nước ≈ 1500 m/s, trong thép ≈ 6100 m/s).',
      'Tiếng vang xuất hiện khi âm phản xạ nghe được cách âm trực tiếp ít nhất 1/15 giây (khoảng cách từ nguồn âm đến vật cản trong không khí tối thiểu khoảng 11,3 m).',
    ],
    practicalExample: 'Con ong mật khi bay đập cánh 330 lần trong 1 giây (f = 330 Hz) phát ra âm thanh cao hơn con muỗi hay thấp hơn? Muỗi đập cánh tới 600 lần/giây (f = 600 Hz) nên tiếng muỗi kêu cao (bổng) hơn tiếng ong.',
    quickCheckQuestion: {
      prompt: 'Tàu thăm dò phát sóng siêu âm xuống đáy biển và nhận được âm phản xạ sau 1,2 giây. Biết tốc độ truyền siêu âm trong nước biển là 1500 m/s. Tính độ sâu đáy biển.',
      answer: '900 m',
      explanation: 'Quãng đường sóng âm đi từ tàu xuống đáy biển rồi phản xạ ngược lại là 2·h = v · t ⇒ Độ sâu h = (v · t) / 2 = (1500 · 1,2) / 2 = 900 m.',
    },
  },
  {
    id: 'phy-3',
    subject: 'physics',
    chapterCode: 'Chủ đề 6',
    title: 'Ánh sáng – Phản xạ ánh sáng & Gương phẳng',
    duration: '20 phút',
    coreFormula: 'Định luật phản xạ ánh sáng: i′ = i  |  d_ảnh = d_vật',
    summary: 'Trong môi trường trong suốt và đồng tính, ánh sáng truyền đi theo đường thẳng. Khi gặp bề mặt nhẵn bóng như gương phẳng, tia sáng bị phản xạ tuân theo định luật phản xạ ánh sáng.',
    keyPoints: [
      'Định luật phản xạ ánh sáng: Tia phản xạ nằm trong mặt phẳng chứa tia tới và pháp tuyến tại điểm tới; Góc phản xạ (i′) luôn bằng góc tới (i).',
      'Lưu ý quan trọng: Góc tới (i) là góc hợp bởi tia tới và đường pháp tuyến (vuông góc với mặt gương), không phải góc hợp bởi tia tới và mặt gương (α = 90° - i).',
      'Tính chất ảnh tạo bởi gương phẳng: Ảnh ảo (không hứng được trên màn chắn), có độ lớn bằng vật, và khoảng cách từ một điểm của vật đến gương bằng khoảng cách từ ảnh của điểm đó đến gương.',
      'Phản xạ gương xảy ra trên bề mặt nhẵn bóng (các tia sáng song song tới cho chùm tia phản xạ song song); phản xạ khuếch tán xảy ra trên bề mặt gồ ghề.',
    ],
    practicalExample: 'Khi chiếu một tia sáng hợp với mặt gương phẳng một góc 30°, góc tới i sẽ bằng 90° - 30° = 60°, do đó góc phản xạ i′ = 60° và góc hợp bởi tia tới với tia phản xạ là i + i′ = 120°.',
    quickCheckQuestion: {
      prompt: 'Chiếu một tia sáng tới gương phẳng sao cho góc hợp bởi tia tới và mặt gương bằng 40°. Tính góc tới i và góc hợp bởi tia tới với tia phản xạ.',
      answer: 'Góc tới i = 50°; Góc giữa tia tới và tia phản xạ = 100°',
      explanation: 'Pháp tuyến vuông góc với mặt gương nên góc tới i = 90° - 40° = 50°. Theo định luật phản xạ ánh sáng, i′ = i = 50° ⇒ Góc hợp bởi tia tới và tia phản xạ là i + i′ = 100°.',
    },
  },
  {
    id: 'bio-1',
    subject: 'biology',
    chapterCode: 'Chủ đề 7',
    title: 'Quang hợp & Hô hấp tế bào ở Sinh vật',
    duration: '22 phút',
    coreFormula: 'Quang hợp: 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂ (Ánh sáng, Diệp lục)',
    summary: 'Quang hợp và hô hấp tế bào là hai quá trình trao đổi chất và chuyển hóa năng lượng trái ngược nhưng gắn bó mật thiết, duy trì cân bằng khí Oxygen - Carbon dioxide và cung cấp năng lượng ATP cho sự sống.',
    keyPoints: [
      'Quang hợp diễn ra ở lục lạp (chứa diệp lục), chuyển hóa quang năng thành hóa năng tích lũy trong hợp chất hữu cơ (Glucose) và giải phóng khí O₂.',
      'Hô hấp tế bào diễn ra ở ti thể: Phân giải chất hữu cơ (C₆H₁₂O₆) khi có O₂ thành CO₂, H₂O và giải phóng năng lượng ATP cung cấp cho mọi hoạt động sống.',
      'Các yếu tố ngoại cảnh ảnh hưởng mạnh đến quang hợp và hô hấp: Ánh sáng, nồng độ CO₂, nước, nhiệt độ và nồng độ O₂.',
      'Ứng dụng bảo quản nông sản: Giảm cường độ hô hấp tế bào (bằng cách phơi sấy khô giảm độ ẩm, bảo quản lạnh hoặc điều chỉnh khí CO₂/O₂) để giữ chất lượng hạt và rau quả lâu dài.',
    ],
    practicalExample: 'Không nên để nhiều chậu cây xanh hoặc hoa tươi trong phòng ngủ đóng kín vào ban đêm vì ban đêm cây ngừng quang hợp nhưng vẫn hô hấp tế bào (hút O₂ và thải CO₂), dễ gây ngạt thở.',
    quickCheckQuestion: {
      prompt: 'Vì sao trước khi đưa hạt thóc, hạt ngô vào kho bảo quản, người nông dân phải phơi khô hạt đến độ ẩm an toàn (khoảng 11% - 13%)?',
      answer: 'Để giảm hàm lượng nước trong hạt, từ đó ức chế hô hấp tế bào xuống mức tối thiểu',
      explanation: 'Nước là môi trường và nguyên liệu trực tiếp cho các phản ứng hô hấp. Khi hạt khô, cường độ hô hấp giảm tối đa giúp hạt không bị tiêu hao chất hữu cơ, không sinh nhiệt ẩm mốc hay nảy mầm sớm.',
    },
  },
  {
    id: 'bio-2',
    subject: 'biology',
    chapterCode: 'Chủ đề 8',
    title: 'Trao đổi nước và chất dinh dưỡng ở Thực vật (Mạch gỗ & Mạch rây)',
    duration: '20 phút',
    coreFormula: 'Mạch gỗ (Xylem): Rễ ↑ Lá (Nước, khoáng)  |  Mạch rây (Phloem): Lá ↓ Cơ quan dự trữ',
    summary: 'Thực vật hấp thụ nước và muối khoáng qua tế bào lông hút ở rễ, vận chuyển lên lá nhờ mạch gỗ (Xylem) với động lực chính là sự thoát hơi nước qua khí khổng, đồng thời vận chuyển chất hữu cơ qua mạch rây (Phloem).',
    keyPoints: [
      'Mạch gỗ (Xylem): Gồm các tế bào chết có thành hóa gỗ dày, vận chuyển dòng nước và muối khoáng hòa tan một chiều từ rễ lên thân và lá.',
      'Mạch rây (Phloem): Gồm các tế bào sống (ống rây), vận chuyển chất hữu cơ (đường sucrose) tổng hợp từ lá đến các cơ quan dự trữ hoặc đang sinh trưởng (quả, củ, rễ non).',
      'Khí khổng ở biểu bì lá: Khi tế bào khí khổng trương nước thì khí khổng mở (cho hơi nước thoát ra và CO₂ khuếch tán vào để quang hợp); khi mất nước thì khí khổng đóng lại.',
      'Ý nghĩa của thoát hơi nước ở lá: Tạo lực hút đầu trên kéo dòng nước và khoáng từ rễ lên lá, làm mát bề mặt lá dưới nắng gắt và mở đường cho khí CO₂ đi vào.',
    ],
    practicalExample: 'Khi bứng cây đi trồng nơi khác, người ta thường tỉa bớt lá hoặc chọn ngày râm mát để giảm sự thoát hơi nước qua lá trong lúc bộ rễ mới bị tổn thương chưa hút đủ nước bù đắp.',
    quickCheckQuestion: {
      prompt: 'Nếu khoanh vỏ một cành cây (bóc bỏ lớp vỏ chứa mạch rây nhưng giữ nguyên phần gỗ bên trong), sau một thời gian mép vỏ phía trên vết cắt sẽ phình to ra. Giải thích vì sao?',
      answer: 'Do mạch rây bị đứt nên chất hữu cơ từ lá vận chuyển xuống bị ứ đọng ở mép trên vết cắt',
      explanation: 'Mạch gỗ nằm sâu bên trong vẫn dẫn nước và muối khoáng lên nuôi cành lá bình thường, nhưng mạch rây nằm ở lớp vỏ đã bị cắt đứt khiến chất hữu cơ từ lá đi xuống bị ứ lại làm mép vỏ phía trên phình to.',
    },
  },
];

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q-1',
    subject: 'chemistry',
    topic: 'Nguyên tử & Bảng tuần hoàn',
    level: 'Nhận biết',
    question: 'Trong nguyên tử trung hòa về điện, loại hạt nào luôn có số lượng bằng số hạt proton (p) trong hạt nhân?',
    options: [
      'Hạt electron (e) ở vỏ nguyên tử',
      'Hạt neutron (n) trong hạt nhân',
      'Tổng số hạt proton và neutron',
      'Chỉ số electron ở lớp ngoài cùng',
    ],
    correctIndex: 0,
    formulaHint: 'Z = p = e',
    explanation: 'Proton mang điện tích +1, electron mang điện tích -1. Vì nguyên tử trung hòa về điện nên số hạt proton luôn bằng số hạt electron (p = e).',
  },
  {
    id: 'q-2',
    subject: 'chemistry',
    topic: 'Nguyên tử & Bảng tuần hoàn',
    level: 'Thông hiểu',
    question: 'Nguyên tử Potassium (K) có số hiệu nguyên tử Z = 19 và số hạt neutron là 20. Số lớp electron và số electron lớp ngoài cùng của K lần lượt là:',
    options: [
      '4 lớp electron; 1 electron lớp ngoài cùng',
      '3 lớp electron; 9 electron lớp ngoài cùng',
      '4 lớp electron; 2 electron lớp ngoài cùng',
      '3 lớp electron; 1 electron lớp ngoài cùng',
    ],
    correctIndex: 0,
    formulaHint: 'Phân bố electron Z = 19: 2 - 8 - 8 - 1',
    explanation: 'Với Z = 19, các electron phân bố vào 4 lớp từ trong ra ngoài theo thứ tự: Lớp 1 (2e), Lớp 2 (8e), Lớp 3 (8e), Lớp 4 (1e). Vậy K thuộc chu kì 4, nhóm IA.',
  },
  {
    id: 'q-3',
    subject: 'chemistry',
    topic: 'Hóa trị & Công thức hóa học',
    level: 'Vận dụng',
    question: 'Hợp chất Copper(II) sulfate có công thức hóa học là CuSO₄ (cho biết Cu = 64, S = 32, O = 16). Khối lượng phân tử và phần trăm khối lượng của nguyên tố Copper (Cu) trong hợp chất này là:',
    options: [
      '160 amu và 40%',
      '160 amu và 64%',
      '144 amu và 44,4%',
      '96 amu và 50%',
    ],
    correctIndex: 0,
    formulaHint: 'KLPT = 64 + 32 + 16·4 = 160 amu; %Cu = (64 / 160)·100%',
    explanation: 'Khối lượng phân tử CuSO₄ = 64 + 32 + 16 × 4 = 160 amu. Phần trăm khối lượng của Cu = (64 / 160) × 100% = 40%.',
  },
  {
    id: 'q-4',
    subject: 'chemistry',
    topic: 'Liên kết hóa học',
    level: 'Thông hiểu',
    question: 'Khi hình thành phân tử Sodium chloride (NaCl) từ nguyên tử Na (Z = 11) và nguyên tử Cl (Z = 17), sự dịch chuyển electron diễn ra như thế nào?',
    options: [
      'Nguyên tử Na nhường 1e tạo ion Na⁺, nguyên tử Cl nhận 1e tạo ion Cl⁻',
      'Nguyên tử Na nhận 1e tạo ion Na⁻, nguyên tử Cl nhường 1e tạo ion Cl⁺',
      'Hai nguyên tử Na và Cl góp chung 2 cặp electron',
      'Nguyên tử Na nhường 2e cho nguyên tử Cl để đạt cấu hình Neon',
    ],
    correctIndex: 0,
    formulaHint: 'Na (2,8,1) → Na⁺ (2,8) + 1e | Cl (2,8,7) + 1e → Cl⁻ (2,8,8)',
    explanation: 'Na có 1e lớp ngoài cùng nên dễ nhường 1e tạo ion dương Na⁺ (cấu hình bền giống Ne). Cl có 7e lớp ngoài cùng nên nhận 1e tạo ion âm Cl⁻ (cấu hình bền giống Ar). Hai ion trái dấu hút nhau tạo liên kết ion.',
  },
  {
    id: 'q-5',
    subject: 'chemistry',
    topic: 'Hóa trị & Công thức hóa học',
    level: 'Vận dụng',
    question: 'Biết Calcium (Ca) có hóa trị II và nhóm Phosphate (PO₄) có hóa trị III. Công thức hóa học đúng của hợp chất Calcium phosphate (thành phần chính của xương và răng) là:',
    options: [
      'Ca₃(PO₄)₂',
      'Ca₂(PO₄)₃',
      'CaPO₄',
      'Ca₃PO₄',
    ],
    correctIndex: 0,
    formulaHint: 'x · II = y · III ⇒ x = 3, y = 2',
    explanation: 'Theo quy tắc hóa trị: x · II = y · III ⇒ x/y = 3/2. Vì PO₄ là nhóm nguyên tử có chỉ số y = 2 > 1 nên phải đặt trong ngoặc đơn: Ca₃(PO₄)₂.',
  },
  {
    id: 'q-6',
    subject: 'physics',
    topic: 'Tốc độ chuyển động',
    level: 'Nhận biết',
    question: 'Một vận động viên chạy đều với tốc độ 5 m/s. Khi quy đổi sang đơn vị km/h, tốc độ của vận động viên này là bao nhiêu?',
    options: [
      '18 km/h',
      '15 km/h',
      '36 km/h',
      '50 km/h',
    ],
    correctIndex: 0,
    formulaHint: '1 m/s = 3,6 km/h ⇒ 5 · 3,6 = 18 km/h',
    explanation: 'Áp dụng quy tắc đổi đơn vị tốc độ: 1 m/s = 3,6 km/h. Vậy 5 m/s = 5 × 3,6 = 18 km/h.',
  },
  {
    id: 'q-7',
    subject: 'physics',
    topic: 'Tốc độ & Đồ thị s - t',
    level: 'Vận dụng',
    question: 'Một người đi xe đạp trên đoạn đường đầu dài 6 km mất 0,5 giờ; sau đó đi tiếp đoạn đường thứ hai dài 12 km mất 1 giờ. Tốc độ trung bình của người đó trên cả hai đoạn đường là:',
    options: [
      '12 km/h',
      '10 km/h',
      '15 km/h',
      '9 km/h',
    ],
    correctIndex: 0,
    formulaHint: 'v_tb = (s₁ + s₂) / (t₁ + t₂)',
    explanation: 'Tổng quãng đường s = s₁ + s₂ = 6 + 12 = 18 km. Tổng thời gian t = t₁ + t₂ = 0,5 + 1 = 1,5 giờ. Tốc độ trung bình v = s / t = 18 / 1,5 = 12 km/h.',
  },
  {
    id: 'q-8',
    subject: 'physics',
    topic: 'Sóng âm',
    level: 'Thông hiểu',
    question: 'Dây đàn bầu thứ nhất thực hiện 440 dao động trong 1 giây; dây đàn thứ hai thực hiện 1000 dao động trong 2 giây. Nhận xét nào sau đây là đúng?',
    options: [
      'Dây thứ hai phát ra âm cao (bổng) hơn dây thứ nhất vì f₂ = 500 Hz > f₁ = 440 Hz',
      'Dây thứ nhất phát ra âm cao hơn vì thời gian dao động ngắn hơn',
      'Hai dây phát ra âm có cùng độ cao vì đều là dây đàn',
      'Dây thứ hai phát ra âm trầm hơn dây thứ nhất',
    ],
    correctIndex: 0,
    formulaHint: 'f = N / t (Hz)',
    explanation: 'Tần số dây 1 là f₁ = 440 / 1 = 440 Hz. Tần số dây 2 là f₂ = 1000 / 2 = 500 Hz. Vì f₂ > f₁ nên âm do dây thứ hai phát ra cao (bổng) hơn âm do dây thứ nhất phát ra.',
  },
  {
    id: 'q-9',
    subject: 'physics',
    topic: 'Phản xạ ánh sáng',
    level: 'Vận dụng',
    question: 'Chiếu một tia sáng SI tới mặt một gương phẳng sao cho tia tới hợp với mặt gương một góc 35°. Góc phản xạ i′ và góc hợp bởi tia tới với tia phản xạ có giá trị lần lượt là:',
    options: [
      'i′ = 55° và góc hợp bởi hai tia là 110°',
      'i′ = 35° và góc hợp bởi hai tia là 70°',
      'i′ = 55° và góc hợp bởi hai tia là 90°',
      'i′ = 65° và góc hợp bởi hai tia là 130°',
    ],
    correctIndex: 0,
    formulaHint: 'i = 90° - α = 90° - 35° = 55°; i′ = i',
    explanation: 'Góc hợp bởi tia tới và mặt gương là α = 35° ⇒ Góc tới i = 90° - 35° = 55°. Theo định luật phản xạ ánh sáng: i′ = i = 55°. Góc hợp bởi tia tới và tia phản xạ là i + i′ = 55° + 55° = 110°.',
  },
  {
    id: 'q-10',
    subject: 'physics',
    topic: 'Từ trường',
    level: 'Thông hiểu',
    question: 'Khi đặt một kim nam châm thử tự do trong từ trường của một thanh nam châm thẳng, cực Bắc (N) của kim nam châm thử luôn hướng theo chiều nào?',
    options: [
      'Hướng theo chiều đường sức từ (đi ra từ cực Bắc và đi vào cực Nam của thanh nam châm)',
      'Hướng về phía cực Bắc của thanh nam châm thẳng',
      'Vuông góc với các đường sức từ tại điểm đặt kim nam châm',
      'Hướng thẳng đứng từ trên xuống dưới',
    ],
    correctIndex: 0,
    formulaHint: 'Chiều đường sức từ: Ra Bắc (N) – Vào Nam (S)',
    explanation: 'Các cực khác tên thì hút nhau nên cực Bắc của kim nam châm thử bị cực Nam của thanh nam châm hút. Quy ước chiều đường sức từ tại một điểm là chiều từ cực Nam đến cực Bắc của kim nam châm thử nằm cân bằng tại điểm đó (ra Bắc, vào Nam).',
  },
  {
    id: 'q-11',
    subject: 'biology',
    topic: 'Quang hợp ở thực vật',
    level: 'Nhận biết',
    question: 'Trong quá trình quang hợp ở cây xanh, nguyên liệu được lấy từ môi trường và sản phẩm tạo ra gồm những chất nào?',
    options: [
      'Nguyên liệu: CO₂ và Nước; Sản phẩm: Chất hữu cơ (Glucose) và O₂',
      'Nguyên liệu: O₂ và Nước; Sản phẩm: Chất hữu cơ và CO₂',
      'Nguyên liệu: Chất hữu cơ và O₂; Sản phẩm: CO₂, Nước và ATP',
      'Nguyên liệu: CO₂ và O₂; Sản phẩm: Nước và muối khoáng',
    ],
    correctIndex: 0,
    formulaHint: '6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂',
    explanation: 'Dưới tác dụng của ánh sáng và chất diệp lục ở lục lạp, cây xanh tổng hợp chất hữu cơ (C₆H₁₂O₆) và giải phóng khí Oxygen (O₂) từ hai nguyên liệu vô cơ là khí Carbon dioxide (CO₂) và Nước (H₂O).',
  },
  {
    id: 'q-12',
    subject: 'biology',
    topic: 'Hô hấp tế bào',
    level: 'Thông hiểu',
    question: 'Bào quan nào trong tế bào nhân thực đóng vai trò là "nhà máy điện" thực hiện quá trình hô hấp tế bào để tạo ra năng lượng ATP?',
    options: [
      'Ti thể (Mitochondria)',
      'Lục lạp (Chloroplast)',
      'Không bào trung tâm',
      'Thành tế bào cellulose',
    ],
    correctIndex: 0,
    formulaHint: 'Hô hấp tế bào diễn ra ở Ti thể',
    explanation: 'Ti thể là bào quan thực hiện quá trình hô hấp tế bào, phân giải Glucose khi có mặt Oxygen để giải phóng năng lượng hóa học dưới dạng phân tử ATP cung cấp cho các hoạt động sống.',
  },
  {
    id: 'q-13',
    subject: 'biology',
    topic: 'Trao đổi nước và dinh dưỡng',
    level: 'Thông hiểu',
    question: 'Ở thực vật có mạch, dòng mạch gỗ (Xylem) và dòng mạch rây (Phloem) khác nhau cơ bản ở đặc điểm nào sau đây?',
    options: [
      'Mạch gỗ vận chuyển nước và muối khoáng từ rễ lên lá; mạch rây vận chuyển chất hữu cơ từ lá xuống các cơ quan',
      'Mạch gỗ vận chuyển chất hữu cơ từ lá xuống rễ; mạch rây vận chuyển nước từ rễ lên lá',
      'Mạch gỗ gồm các tế bào sống; mạch rây gồm các tế bào chết đã hóa gỗ',
      'Cả hai mạch đều chỉ vận chuyển chất dinh dưỡng theo một chiều duy nhất từ rễ lên ngọn',
    ],
    correctIndex: 0,
    formulaHint: 'Xylem: Nước & khoáng (Rễ ↑ Lá) | Phloem: Chất hữu cơ (Lá ↓ Cơ quan dự trữ)',
    explanation: 'Mạch gỗ gồm các tế bào chết hóa gỗ dẫn nước và ion khoáng từ lông hút ở rễ lên lá. Mạch rây gồm các tế bào sống dẫn chất hữu cơ tổng hợp từ quá trình quang hợp ở lá đến nuôi thân, rễ, củ, quả.',
  },
  {
    id: 'q-14',
    subject: 'biology',
    topic: 'Trao đổi khí & Khí khổng',
    level: 'Vận dụng',
    question: 'Vào những trưa hè nắng gắt và nhiệt độ quá cao (trên 40°C), cường độ quang hợp của nhiều loài cây trồng bị giảm mạnh (hiện tượng "ngủ trưa" của thực vật). Nguyên nhân trực tiếp là:',
    options: [
      'Khí khổng đóng lại để hạn chế mất nước làm lượng khí CO₂ khuếch tán vào lá giảm đột ngột',
      'Cây ngừng hấp thụ ánh sáng mặt trời vì diệp lục chuyển sang màu vàng',
      'Lượng khí Oxygen trong không khí vào buổi trưa giảm xuống bằng 0',
      'Mạch rây ngừng hoạt động hoàn toàn vào ban ngày',
    ],
    correctIndex: 0,
    formulaHint: 'Thoát hơi nước quá mạnh → Khí khổng đóng → Thiếu CO₂ cho quang hợp',
    explanation: 'Khi nắng gắt và nhiệt độ cao, cây mất nước nhanh nên tế bào khí khổng giảm sức trương và đóng lại để bảo vệ cây khỏi héo. Khi khí khổng đóng, CO₂ không thể đi vào lá làm quang hợp giảm mạnh.',
  },
  {
    id: 'q-15',
    subject: 'physics',
    topic: 'Liên môn Vật lí - Sinh học',
    level: 'Vận dụng',
    question: 'Loài dơi phát ra sóng siêu âm có tần số 50 000 Hz khi săn mồi trong đêm. Một con dơi phát ra xung siêu âm và nhận lại âm phản xạ từ con côn trùng sau 0,04 giây. Biết tốc độ truyền âm trong không khí là 340 m/s. Khoảng cách từ dơi đến con mồi là:',
    options: [
      '6,8 m',
      '13,6 m',
      '3,4 m',
      '8,5 m',
    ],
    correctIndex: 0,
    formulaHint: 'd = (v · t) / 2 = (340 · 0,04) / 2',
    explanation: 'Trong 0,04 giây, sóng siêu âm truyền từ dơi tới con mồi rồi phản xạ ngược lại tai dơi (quãng đường = 2d). Do đó khoảng cách từ dơi đến con mồi là d = (340 × 0,04) / 2 = 6,8 m.',
  },
];

export const VALENCE_CHALLENGES: ValenceChallenge[] = [
  {
    id: 'vc-1',
    title: 'Aluminium oxide (Thành phần quặng Boxit)',
    elementA: { symbol: 'Al', name: 'Aluminium (M = 27)', valence: 3 },
    elementB: { symbol: 'O', name: 'Oxygen (M = 16)', valence: 2 },
    correctX: 2,
    correctY: 3,
    formulaDisplay: 'Al₂O₃',
    molecularMass: 102,
    explanation: 'Al hóa trị III, O hóa trị II ⇒ x · 3 = y · 2 ⇒ Chọn x = 2, y = 3. Công thức: Al₂O₃ (KLPT = 27·2 + 16·3 = 102 amu).',
  },
  {
    id: 'vc-2',
    title: 'Iron(III) sulfate (Muối sắt sunfat)',
    elementA: { symbol: 'Fe', name: 'Iron(III) (M = 56)', valence: 3 },
    elementB: { symbol: 'SO₄', name: 'Nhóm Sulfate (M = 96)', valence: 2, isGroup: true },
    correctX: 2,
    correctY: 3,
    formulaDisplay: 'Fe₂(SO₄)₃',
    molecularMass: 400,
    explanation: 'Fe hóa trị III, nhóm SO₄ hóa trị II ⇒ x · 3 = y · 2 ⇒ Chọn x = 2, y = 3. Công thức: Fe₂(SO₄)₃ (KLPT = 56·2 + 96·3 = 400 amu).',
  },
  {
    id: 'vc-3',
    title: 'Calcium phosphate (Khoáng chất cấu tạo xương)',
    elementA: { symbol: 'Ca', name: 'Calcium (M = 40)', valence: 2 },
    elementB: { symbol: 'PO₄', name: 'Nhóm Phosphate (M = 95)', valence: 3, isGroup: true },
    correctX: 3,
    correctY: 2,
    formulaDisplay: 'Ca₃(PO₄)₂',
    molecularMass: 310,
    explanation: 'Ca hóa trị II, nhóm PO₄ hóa trị III ⇒ x · 2 = y · 3 ⇒ Chọn x = 3, y = 2. Công thức: Ca₃(PO₄)₂ (KLPT = 40·3 + 95·2 = 310 amu).',
  },
  {
    id: 'vc-4',
    title: 'Carbon dioxide (Khí nguyên liệu quang hợp)',
    elementA: { symbol: 'C', name: 'Carbon(IV) (M = 12)', valence: 4 },
    elementB: { symbol: 'O', name: 'Oxygen (M = 16)', valence: 2 },
    correctX: 1,
    correctY: 2,
    formulaDisplay: 'CO₂',
    molecularMass: 44,
    explanation: 'C hóa trị IV, O hóa trị II ⇒ x · 4 = y · 2 ⇒ Tỉ lệ tối giản x/y = 2/4 = 1/2 ⇒ Chọn x = 1, y = 2. Công thức: CO₂ (KLPT = 12 + 16·2 = 44 amu).',
  },
  {
    id: 'vc-5',
    title: 'Magnesium nitrate (Phân bón vi lượng)',
    elementA: { symbol: 'Mg', name: 'Magnesium (M = 24)', valence: 2 },
    elementB: { symbol: 'NO₃', name: 'Nhóm Nitrate (M = 62)', valence: 1, isGroup: true },
    correctX: 1,
    correctY: 2,
    formulaDisplay: 'Mg(NO₃)₂',
    molecularMass: 148,
    explanation: 'Mg hóa trị II, nhóm NO₃ hóa trị I ⇒ x · 2 = y · 1 ⇒ Chọn x = 1, y = 2. Công thức: Mg(NO₃)₂ (KLPT = 24 + 62·2 = 148 amu).',
  },
];

export const CLASSIFICATION_ITEMS: ClassificationItem[] = [
  {
    id: 'c-1',
    statement: 'Tia sáng mặt trời chiếu tới mặt gương phẳng bị hắt trở lại với góc phản xạ bằng góc tới (i′ = i).',
    subject: 'physics',
    reason: 'Thuộc chủ đề Năng lượng & Sự biến đổi (Quang học - Định luật phản xạ ánh sáng trong Vật lí 7).',
  },
  {
    id: 'c-2',
    statement: 'Nguyên tử Sodium (Na) nhường 1 electron lớp ngoài cùng cho nguyên tử Chlorine (Cl) tạo liên kết ion.',
    subject: 'chemistry',
    reason: 'Thuộc chủ đề Chất & Sự biến đổi của chất (Liên kết hóa học trong Hóa học 7).',
  },
  {
    id: 'c-3',
    statement: 'Tế bào khí khổng ở mặt dưới lá trương nước mở rộng để khí CO₂ khuếch tán vào lục lạp.',
    subject: 'biology',
    reason: 'Thuộc chủ đề Vật sống (Trao đổi khí và Quang hợp ở thực vật trong Sinh học 7).',
  },
  {
    id: 'c-4',
    statement: 'Sóng siêu âm truyền trong nước biển với tốc độ khoảng 1500 m/s, nhanh gấp hơn 4 lần trong không khí.',
    subject: 'physics',
    reason: 'Thuộc chủ đề Âm thanh và sự truyền sóng âm trong các môi trường (Vật lí 7).',
  },
  {
    id: 'c-5',
    statement: 'Mạch gỗ (Xylem) vận chuyển nước và ion khoáng từ lông hút ở rễ lên thân và lá nhờ lực kéo thoát hơi nước.',
    subject: 'biology',
    reason: 'Thuộc chủ đề Trao đổi nước và chất dinh dưỡng ở thực vật (Sinh học 7).',
  },
  {
    id: 'c-6',
    statement: 'Phân tử nước (H₂O) được hình thành bằng 2 cặp electron dùng chung giữa 1 nguyên tử Oxygen và 2 nguyên tử Hydrogen.',
    subject: 'chemistry',
    reason: 'Thuộc chủ đề Liên kết cộng hóa trị và cấu tạo phân tử (Hóa học 7).',
  },
  {
    id: 'c-7',
    statement: 'Đồ thị quãng đường - thời gian (s - t) của vật chuyển động đều là một đường thẳng đi qua gốc tọa độ.',
    subject: 'physics',
    reason: 'Thuộc chủ đề Tốc độ chuyển động và đồ thị quãng đường - thời gian (Vật lí 7).',
  },
  {
    id: 'c-8',
    statement: 'Ti thể phân giải Glucose khi có Oxygen để giải phóng năng lượng ATP cung cấp cho tế bào hoạt động.',
    subject: 'biology',
    reason: 'Thuộc chủ đề Hô hấp tế bào ở sinh vật (Sinh học 7).',
  },
  {
    id: 'c-9',
    statement: 'Các nguyên tố thuộc nhóm VIIIA (He, Ne, Ar) có lớp vỏ electron ngoài cùng bền vững nên hầu như không tham gia phản ứng.',
    subject: 'chemistry',
    reason: 'Thuộc chủ đề Bảng tuần hoàn các nguyên tố hóa học (Hóa học 7).',
  },
];
