import { KhtnLesson, McqItem } from './lessonTypes';

const makeMcqs = (
  prefix: string,
  raw: Array<[string, [string, string, string, string], number, string]>
): McqItem[] =>
  raw.map(([question, options, correctIndex, explanation], idx) => ({
    id: `${prefix}-mcq-${idx + 1}`,
    question,
    options,
    correctIndex,
    explanation,
    level: idx < 12 ? 'Nhận biết' : idx < 22 ? 'Thông hiểu' : 'Vận dụng',
  }));

export const PHYSICS_LESSONS_PART_1: KhtnLesson[] = [
  // =========================================================================
  // BÀI 8: TỐC ĐỘ CHUYỂN ĐỘNG (Tài liệu Chủ đề Tốc độ - Phần A)
  // =========================================================================
  {
    id: 'kntt-bai-8',
    lessonNumber: 8,
    title: 'Bài 8: Tốc độ chuyển động',
    chapterTitle: 'Chương III: Tốc độ',
    subject: 'physics',
    pdfUrl: '/assets/aistudio/_C_p_nh_t_m_i__Ch_____T_c____e8df4bc0.pdf',
    summary:
      'Tốc độ chuyển động là đại lượng đặc trưng cho biết mức độ nhanh hay chậm của chuyển động, được xác định bằng độ dài quãng đường đi được trong một đơn vị thời gian. Đơn vị hợp pháp trong hệ đo lường Việt Nam là m/s và km/h.',
    keyFormulas: [
      'Công thức tính tốc độ:  v = s / t',
      'Công thức tính quãng đường:  s = v · t  |  Thời gian:  t = s / v',
      'Quy đổi đơn vị:  1 m/s = 3,6 km/h  |  1 km/h = (1 / 3,6) m/s',
    ],
    mcqs: makeMcqs('b8', [
      ['Độ lớn của tốc độ cho biết:', ['quỹ đạo của chuyển động.', 'mức độ nhanh hay chậm của chuyển động.', 'hướng của chuyển động.', 'dạng đường đi của chuyển động.'], 1, 'Tốc độ là đại lượng đặc trưng cho mức độ nhanh hay chậm của chuyển động.'],
      ['Chọn phát biểu đúng về tốc độ:', ['Tốc độ là đại lượng cho biết quỹ đạo của chuyển động.', 'Tốc độ là đại lượng đặc trưng cho biết mức độ nhanh hay chậm của chuyển động.', 'Tốc độ là đại lượng đặc trưng mức độ to hay nhỏ của âm thanh.', 'Tốc độ chỉ phụ thuộc vào thời gian chuyển động.'], 1, 'Tốc độ cho biết vật chuyển động nhanh hay chậm.'],
      ['Đại lượng nào sau đây cho biết mức độ nhanh hay chậm của chuyển động?', ['Quãng đường.', 'Thời gian chuyển động.', 'Tốc độ.', 'Tần số.'], 2, 'Tốc độ đặc trưng cho sự nhanh hay chậm của chuyển động.'],
      ['Trong các phát biểu sau về tốc độ, phát biểu đúng là:', ['Tốc độ được xác định bằng quãng đường đi được trong một đơn vị thời gian.', 'Tốc độ luôn bằng quãng đường đi được trong một ngày.', 'Tốc độ luôn bằng quãng đường đi được trong một phút.', 'Tốc độ không phụ thuộc vào quãng đường.'], 0, 'Định nghĩa: Tốc độ bằng thương số giữa quãng đường đi được và thời gian đi hết quãng đường đó.'],
      ['Gọi s là quãng đường đi được, t là thời gian đi hết quãng đường đó, v là tốc độ chuyển động. Công thức tính tốc độ là:', ['v = s / t.', 'v = t / s.', 'v = s · t.', 'v = s + t.'], 0, 'Công thức chuẩn: v = s / t.'],
      ['Gọi s là quãng đường đi được, t là thời gian, v là tốc độ. Công thức tính quãng đường là:', ['s = v / t.', 's = t / v.', 's = v · t.', 's = v² · t.'], 2, 'Từ v = s / t suy ra s = v · t.'],
      ['Gọi s là quãng đường đi được, t là thời gian, v là tốc độ. Công thức tính thời gian là:', ['t = s / v.', 't = v / s.', 't = s · v.', 't = s - v.'], 0, 'Từ v = s / t suy ra t = s / v.'],
      ['Tốc độ của vật chuyển động phụ thuộc vào:', ['chỉ quãng đường chuyển động.', 'chỉ thời gian chuyển động.', 'cả quãng đường đi được và thời gian chuyển động.', 'khối lượng của vật chuyển động.'], 2, 'Vì v = s / t nên tốc độ phụ thuộc vào quãng đường và thời gian đi hết quãng đường đó.'],
      ['Chọn phát biểu đúng về đơn vị tốc độ:', ['Đơn vị của tốc độ phụ thuộc vào đơn vị độ dài và đơn vị thời gian.', 'Cách đổi đơn vị đúng là: 1 km/h = 3,6 m/s.', 'Đơn vị của tốc độ chỉ có thể là km/h.', 'Đơn vị của tốc độ là kg/m³.'], 0, 'Đơn vị tốc độ = đơn vị độ dài / đơn vị thời gian (ví dụ m/s, km/h, m/min).'],
      ['Trong các câu nói về tốc độ dưới đây, câu nào SAI?', ['Tốc độ cho biết mức độ nhanh hay chậm của chuyển động.', 'Độ lớn của tốc độ được tính bằng quãng đường đi được trong một đơn vị thời gian.', 'Công thức tính tốc độ là v = t / s.', 'Một trong các đơn vị hợp pháp của tốc độ là km/h.'], 2, 'Công thức v = t / s là sai, công thức đúng phải là v = s / t.'],
      ['Đơn vị nào sau đây KHÔNG phải là đơn vị của tốc độ?', ['m/s.', 'km/h.', 'kg/m³.', 'm/min.'], 2, 'kg/m³ là đơn vị của khối lượng riêng, không phải đơn vị tốc độ.'],
      ['Đơn vị nào sau đây KHÔNG phải là đơn vị của tốc độ?', ['km/h.', 'cm/s.', 'm·h.', 'm/s.'], 2, 'm·h là tích của mét và giờ, không phải thương số giữa độ dài và thời gian.'],
      ['Đổi đơn vị: 15 m/s bằng bao nhiêu km/h?', ['36 km/h.', '45 km/h.', '72 km/h.', '54 km/h.'], 3, 'Ta có 1 m/s = 3,6 km/h ⇒ 15 m/s = 15 × 3,6 = 54 km/h.'],
      ['Tốc độ của một vật là 10 m/s. Tính tốc độ của vật đó theo đơn vị km/h?', ['36 km/h.', '54 km/h.', '48 km/h.', '60 km/h.'], 0, '10 m/s = 10 × 3,6 = 36 km/h.'],
      ['Đổi đơn vị: 108 km/h bằng bao nhiêu m/s?', ['30 m/s.', '20 m/s.', '15 m/s.', '25 m/s.'], 0, '108 km/h = 108 / 3,6 = 30 m/s.'],
      ['Tốc độ 72 km/h tương ứng với bao nhiêu m/s?', ['15 m/s.', '25 m/s.', '20 m/s.', '30 m/s.'], 2, '72 km/h = 72 / 3,6 = 20 m/s.'],
      ['Cho các tốc độ: (1) Tàu hỏa: 54 km/h; (2) Chim đại bàng: 24 m/s; (3) Cá bơi: 6000 cm/min; (4) Trái Đất quay quanh Mặt Trời: 108 000 km/h. Thứ tự sắp xếp từ nhỏ đến lớn là:', ['(1), (2), (3), (4).', '(3), (2), (1), (4).', '(3), (1), (2), (4).', '(3), (1), (4), (2).'], 2, 'Đổi ra m/s: (3) Cá = 60m/60s = 1 m/s; (1) Tàu = 54/3,6 = 15 m/s; (2) Đại bàng = 24 m/s; (4) Trái Đất = 30 000 m/s ⇒ (3) < (1) < (2) < (4).'],
      ['Tốc độ của ô tô là 40 km/h, của xe máy là 11,6 m/s, của tàu hỏa là 600 m/min. Sắp xếp theo thứ tự tốc độ giảm dần là:', ['Tàu hỏa – ô tô – xe máy.', 'Ô tô – tàu hỏa – xe máy.', 'Tàu hỏa – xe máy – ô tô.', 'Xe máy – ô tô – tàu hỏa.'], 3, 'Đổi ra m/s: Xe máy = 11,6 m/s; Ô tô = 40/3,6 ≈ 11,1 m/s; Tàu hỏa = 600/60 = 10 m/s ⇒ Xe máy > Ô tô > Tàu hỏa.'],
      ['Tốc độ của ô tô là 36 km/h, của người đi xe máy là 18 m/s, của tàu hỏa là 14 m/s. Thứ tự từ nhanh nhất đến chậm nhất là:', ['Ô tô – tàu hỏa – xe máy.', 'Tàu hỏa – ô tô – xe máy.', 'Xe máy – ô tô – tàu hỏa.', 'Xe máy – tàu hỏa – ô tô.'], 3, 'Ô tô = 36/3,6 = 10 m/s ⇒ Xe máy (18 m/s) > Tàu hỏa (14 m/s) > Ô tô (10 m/s).'],
      ['Một người đi xe máy với tốc độ 12 m/s trong thời gian 20 phút (min). Quãng đường người đó đi được là:', ['240 m.', '2 400 m.', '14,4 km.', '4 km.'], 2, 'Đổi t = 20 min = 1200 s ⇒ s = v · t = 12 × 1200 = 14 400 m = 14,4 km.'],
      ['Nói tốc độ của ô tô là 36 km/h có ý nghĩa gì?', ['Ô tô đi được tổng cộng 36 km rồi dừng lại.', 'Ô tô chuyển động trong đúng 1 giờ.', 'Trong mỗi giờ, trung bình ô tô đi được quãng đường 36 km.', 'Ô tô đi 1 km mất 36 giờ.'], 2, '36 km/h có nghĩa là trung bình trong 1 giờ ô tô đi được 36 km.'],
      ['Một học sinh đi bộ từ nhà đến trường trên đoạn đường 3,6 km trong thời gian 40 phút. Tốc độ của học sinh đó là:', ['19,44 m/s.', '15 m/s.', '1,5 m/s.', '0,67 m/s.'], 2, 'Đổi s = 3600 m, t = 40 × 60 = 2400 s ⇒ v = 3600 / 2400 = 1,5 m/s (hay 5,4 km/h).'],
      ['Máy bay bay từ Hà Nội đến TP. Hồ Chí Minh dài 1400 km mất thời gian 1 giờ 45 phút. Tốc độ của máy bay là:', ['700 km/h.', '800 km/h.', '900 km/h.', '1000 km/h.'], 1, 'Đổi t = 1 giờ 45 phút = 1,75 h ⇒ v = s / t = 1400 / 1,75 = 800 km/h.'],
      ['Một người đi bộ với tốc độ 4,4 km/h trong 15 phút từ nhà đến nơi làm việc. Khoảng cách từ nhà đến nơi làm việc là:', ['4,4 km.', '1,1 km.', '1,5 km.', '1,2 km.'], 1, 'Đổi t = 15 phút = 0,25 h ⇒ s = v · t = 4,4 × 0,25 = 1,1 km.'],
      ['Một người đi xe máy trong 6 phút đi được quãng đường 4 km. Tốc độ chuyển động của người đó là:', ['40 km/s.', '400 m/min.', '4 km/min.', '11,1 m/s.'], 3, 's = 4000 m, t = 6 × 60 = 360 s ⇒ v = 4000 / 360 ≈ 11,1 m/s (tương đương 40 km/h).'],
      ['Một đoàn tàu chuyển động trong thời gian 1,5 h đi được đoạn đường dài 81 000 m. Tốc độ của tàu tính ra km/h và m/s là:', ['36 km/h và 10 m/s.', '72 km/h và 20 m/s.', '18 km/h và 5 m/s.', '54 km/h và 15 m/s.'], 3, 'Đổi s = 81 km ⇒ v = 81 / 1,5 = 54 km/h = 54 / 3,6 = 15 m/s.'],
      ['Một người đi quãng đường dài 1,5 km với tốc độ 10 m/s. Thời gian để người đó đi hết quãng đường là:', ['0,15 giờ.', '15 giây.', '2,5 phút (150 giây).', '14,4 phút.'], 2, 'Đổi s = 1500 m ⇒ t = s / v = 1500 / 10 = 150 s = 2,5 phút.'],
      ['Một người đi xe đạp trong 40 phút với tốc độ không đổi 15 km/h. Quãng đường đi được là:', ['10 km.', '15 km.', '20 km.', '16 km.'], 0, 'Đổi t = 40 phút = 2/3 giờ ⇒ s = v · t = 15 × (2/3) = 10 km.'],
      ['Một ô tô rời bến lúc 6 giờ sáng với tốc độ 40 km/h đi từ Quảng Ninh đến Hà Nội cách nhau 150 km. Nếu không dừng nghỉ, ô tô đến Hà Nội lúc mấy giờ?', ['9 giờ 00 phút.', '9 giờ 30 phút.', '9 giờ 45 phút.', '10 giờ 00 phút.'], 2, 'Thời gian đi t = 150 / 40 = 3,75 giờ = 3 giờ 45 phút ⇒ Đến nơi lúc 6h + 3h45p = 9h45p.'],
      ['Một người chạy bộ 5 vòng hồ Hoàn Kiếm, mỗi vòng dài 1,7 km, hết thời gian 40 phút. Tốc độ chạy bộ của người đó là:', ['10 km/h.', '12,75 km/h.', '11,24 km/h.', '15 km/h.'], 1, 'Tổng quãng đường s = 5 × 1,7 = 8,5 km; thời gian t = 40/60 = 2/3 h ⇒ v = 8,5 / (2/3) = 12,75 km/h.'],
    ]),
    trueFalseList: [
      {
        id: 'b8-tf-1',
        stem: 'Xét khái niệm, công thức và đơn vị của tốc độ chuyển động:',
        statements: [
          { id: 'a', text: 'Tốc độ chuyển động cho biết mức độ nhanh hay chậm của chuyển động và được xác định bằng độ dài quãng đường đi được trong một đơn vị thời gian.', isTrue: true, explanation: 'Đúng định nghĩa tốc độ.' },
          { id: 'b', text: 'Trong hệ đo lường chính thức của nước ta, đơn vị tốc độ chỉ có mét trên giây (m/s), không dùng kilômét trên giờ (km/h).', isTrue: false, explanation: 'Sai, cả hai đơn vị m/s và km/h đều là đơn vị đo tốc độ hợp pháp chính thức.' },
          { id: 'c', text: 'Một vật chuyển động với tốc độ 20 m/s thì nhanh hơn vật chuyển động với tốc độ 54 km/h.', isTrue: true, explanation: 'Đúng vì 20 m/s = 72 km/h > 54 km/h.' },
          { id: 'd', text: 'Nếu hai vật đi cùng một quãng đường như nhau, vật nào mất nhiều thời gian hơn thì có tốc độ lớn hơn.', isTrue: false, explanation: 'Sai, cùng quãng đường s thì v tỉ lệ nghịch với t: mất nhiều thời gian hơn nghĩa là chuyển động chậm hơn (tốc độ nhỏ hơn).' },
        ],
      },
      {
        id: 'b8-tf-2',
        stem: 'Cho tốc độ của 4 đối tượng: Vận động viên bơi (5,2 m/s), Xe đạp (18 km/h), Xe máy (18 m/s), Xe buýt đang vào bến (250 m/min):',
        statements: [
          { id: 'a', text: 'Tốc độ của xe đạp khi đổi ra đơn vị m/s là 5 m/s.', isTrue: true, explanation: 'Đúng, 18 / 3,6 = 5 m/s.' },
          { id: 'b', text: 'Tốc độ của vận động viên bơi chậm hơn tốc độ của xe đạp.', isTrue: false, explanation: 'Sai, vận động viên bơi với tốc độ 5,2 m/s > xe đạp (5 m/s).' },
          { id: 'c', text: 'Tốc độ của xe buýt đang vào bến xấp xỉ bằng 4,17 m/s.', isTrue: true, explanation: 'Đúng, 250 m / 60 s ≈ 4,17 m/s.' },
          { id: 'd', text: 'Sắp xếp theo thứ tự tốc độ giảm dần là: Xe máy → Vận động viên bơi → Xe đạp → Xe buýt vào bến.', isTrue: true, explanation: 'Đúng: 18 m/s > 5,2 m/s > 5 m/s > 4,17 m/s.' },
        ],
      },
      {
        id: 'b8-tf-3',
        stem: 'Một ô tô khởi hành từ Hà Nội lúc 8 giờ 00 phút đi Hải Phòng (quãng đường Hà Nội – Hải Phòng dài 100 km). Đến 9 giờ 30 phút, ô tô còn cách Hải Phòng 25 km:',
        statements: [
          { id: 'a', text: 'Khoảng thời gian ô tô đã đi từ 8 giờ 00 đến 9 giờ 30 là 1,5 giờ.', isTrue: true, explanation: 'Đúng, 9h30 - 8h00 = 1h30p = 1,5 h.' },
          { id: 'b', text: 'Quãng đường ô tô đã đi được từ 8 giờ 00 đến 9 giờ 30 là 75 km.', isTrue: true, explanation: 'Đúng, 100 - 25 = 75 km.' },
          { id: 'c', text: 'Tốc độ trung bình của ô tô trên đoạn đường đó là 60 km/h.', isTrue: false, explanation: 'Sai, v = s / t = 75 / 1,5 = 50 km/h.' },
          { id: 'd', text: 'Nếu tiếp tục giữ nguyên tốc độ 50 km/h và không nghỉ, ô tô sẽ đến Hải Phòng lúc 10 giờ 00 phút.', isTrue: true, explanation: 'Đúng, tổng thời gian đi 100 km là 100 / 50 = 2 giờ ⇒ đến nơi lúc 8h + 2h = 10h00.' },
        ],
      },
      {
        id: 'b8-tf-4',
        stem: 'Tại SEA Games 31, đội tuyển điền kinh nữ Việt Nam giành Huy chương Vàng nội dung chạy tiếp sức 4 × 400 m (tổng cự li 1600 m) với thành tích 3 phút 37,99 giây:',
        statements: [
          { id: 'a', text: 'Tổng quãng đường cả 4 vận động viên đã chạy là 1600 m.', isTrue: true, explanation: 'Đúng, 4 × 400 m = 1600 m.' },
          { id: 'b', text: 'Thời gian hoàn thành bài thi đổi ra giây là 217,99 giây.', isTrue: true, explanation: 'Đúng, 3 × 60 + 37,99 = 217,99 giây.' },
          { id: 'c', text: 'Tốc độ trung bình của đội tuyển Việt Nam trên đường đua xấp xỉ bằng 7,34 m/s.', isTrue: true, explanation: 'Đúng, v = 1600 / 217,99 ≈ 7,34 m/s.' },
          { id: 'd', text: 'Đội tuyển Thái Lan về nhì với thời gian 3 phút 42,90 giây nên có tốc độ trung bình lớn hơn đội tuyển Việt Nam.', isTrue: false, explanation: 'Sai, cùng cự li 1600 m, thời gian chạy lâu hơn (222,90 s) nên tốc độ trung bình nhỏ hơn (≈ 7,18 m/s).' },
        ],
      },
      {
        id: 'b8-tf-5',
        stem: 'Một mô tô chuyển động trên quãng đường từ A đến B. Trong trường hợp thứ nhất, mô tô đi nửa thời gian đầu với tốc độ v₁ = 40 km/h và nửa thời gian sau với tốc độ v₂ = 60 km/h:',
        statements: [
          { id: 'a', text: 'Vì hai nửa thời gian bằng nhau (t₁ = t₂ = t/2) nên quãng đường đi được trong nửa thời gian sau lớn gấp 1,5 lần nửa thời gian đầu.', isTrue: true, explanation: 'Đúng vì s₂ / s₁ = v₂ / v₁ = 60 / 40 = 1,5.' },
          { id: 'b', text: 'Tốc độ trung bình của mô tô trên cả quãng đường AB trong trường hợp này là 50 km/h.', isTrue: true, explanation: 'Đúng, khi t₁ = t₂ thì v_tb = (v₁ + v₂) / 2 = (40 + 60) / 2 = 50 km/h.' },
          { id: 'c', text: 'Nếu mô tô đi nửa quãng đường đầu (s₁ = s/2) với tốc độ 60 km/h và nửa quãng đường sau (s₂ = s/2) với tốc độ 40 km/h thì tốc độ trung bình cũng bằng 50 km/h.', isTrue: false, explanation: 'Sai, khi s₁ = s₂ thì v_tb = s / (s/120 + s/80) = 48 km/h (nhỏ hơn 50 km/h).' },
          { id: 'd', text: 'Khi tính tốc độ trung bình trên nhiều chặng đường, ta luôn lấy tổng quãng đường chia cho tổng thời gian: v_tb = (s₁ + s₂) / (t₁ + t₂).', isTrue: true, explanation: 'Đúng nguyên tắc tính tốc độ trung bình.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b8-es-1',
        question: 'Câu 1 [Tài liệu Chủ đề Tốc độ]: Thực hiện đổi các đơn vị tốc độ sau:\n(a) Đổi sang m/s: 54 km/h; 72 km/h; 108 km/h; 0,27 km/h.\n(b) Đổi sang km/h: 15 m/s; 20 m/s; 1,5 m/s; 200 m/s.',
        hint: 'Từ km/h sang m/s chia cho 3,6; từ m/s sang km/h nhân với 3,6.',
        sampleAnswer: '(a) Đổi sang m/s (chia cho 3,6):\n- 54 km/h = 54 / 3,6 = 15 m/s.\n- 72 km/h = 72 / 3,6 = 20 m/s.\n- 108 km/h = 108 / 3,6 = 30 m/s.\n- 0,27 km/h = 0,27 / 3,6 = 0,075 m/s.\n(b) Đổi sang km/h (nhân với 3,6):\n- 15 m/s = 15 × 3,6 = 54 km/h.\n- 20 m/s = 20 × 3,6 = 72 km/h.\n- 1,5 m/s = 1,5 × 3,6 = 5,4 km/h.\n- 200 m/s = 200 × 3,6 = 720 km/h.',
        rubricPoints: [
          'Đổi đúng 4 giá trị ở câu (a) sang m/s.',
          'Đổi đúng 4 giá trị ở câu (b) sang km/h.',
        ],
      },
      {
        id: 'b8-es-2',
        question: 'Câu 2 [Tài liệu Chủ đề Tốc độ]: Đường sắt Hà Nội – Đà Nẵng dài khoảng 880 km. Thời gian tàu hỏa chạy từ Hà Nội đến Đà Nẵng là 16 giờ. Hãy tính tốc độ trung bình của tàu hỏa ra đơn vị km/h và m/s.',
        hint: 'Áp dụng công thức v = s / t.',
        sampleAnswer: 'Tóm tắt: s = 880 km; t = 16 h.\nGiải:\nTốc độ trung bình của tàu hỏa trên tuyến Hà Nội – Đà Nẵng là:\nv = s / t = 880 / 16 = 55 km/h.\nĐổi ra đơn vị m/s: v = 55 / 3,6 ≈ 15,28 m/s.',
        rubricPoints: [
          'Viết đúng công thức v = s / t và tính ra 55 km/h.',
          'Quy đổi đúng sang đơn vị m/s (≈ 15,28 m/s).',
        ],
      },
      {
        id: 'b8-es-3',
        question: 'Câu 3 [Tài liệu Chủ đề Tốc độ]: Tay đua xe đạp Dương Anh Đức thực hiện cuộc đua 10 vòng quanh hồ Hoàn Kiếm. Biết 1 vòng hồ dài 1,7 km và tổng thời gian hoàn thành 10 vòng đua là 20 phút. Tính tốc độ trung bình của tay đua theo đơn vị km/h và m/s.',
        hint: 'Tính tổng quãng đường s = 10 × 1,7 km và đổi t = 20 phút = 1/3 giờ.',
        sampleAnswer: '- Tổng quãng đường 10 vòng hồ là: s = 10 × 1,7 = 17 km.\n- Thời gian đua: t = 20 phút = 20 / 60 = 1/3 giờ.\n- Tốc độ trung bình của tay đua là: v = s / t = 17 / (1/3) = 51 km/h (tương đương 51 / 3,6 ≈ 14,17 m/s).',
        rubricPoints: [
          'Tính đúng tổng quãng đường s = 17 km và thời gian t = 1/3 h.',
          'Tính đúng tốc độ v = 51 km/h (≈ 14,17 m/s).',
        ],
      },
      {
        id: 'b8-es-4',
        question: 'Câu 4 [Tài liệu Chủ đề Tốc độ]: Một ô tô khởi hành từ Hà Nội lúc 8 giờ sáng đi Hải Phòng. Đến 9 giờ 30 phút, ô tô còn cách Hải Phòng 25 km. Biết quãng đường Hà Nội – Hải Phòng dài 100 km.\n(a) Tính tốc độ của ô tô (giả sử ô tô chuyển động đều).\n(b) Nếu ô tô đi liên tục không nghỉ thì sẽ đến Hải Phòng lúc mấy giờ?',
        hint: 'Tính quãng đường đã đi s₁ = 100 - 25 = 75 km trong thời gian t₁ = 1,5 h.',
        sampleAnswer: '(a) Thời gian ô tô đi từ 8h đến 9h30 là: t₁ = 9h30 - 8h = 1h30p = 1,5 h.\nQuãng đường ô tô đã đi được là: s₁ = 100 - 25 = 75 km.\nTốc độ của ô tô là: v = s₁ / t₁ = 75 / 1,5 = 50 km/h.\n(b) Tổng thời gian ô tô đi hết cả quãng đường 100 km là: t = s / v = 100 / 50 = 2 giờ.\nVậy ô tô sẽ đến Hải Phòng lúc: 8 giờ + 2 giờ = 10 giờ 00 phút.',
        rubricPoints: [
          'Tính đúng tốc độ ô tô v = 50 km/h ở câu (a).',
          'Tính đúng thời điểm đến Hải Phòng là 10 giờ 00 phút ở câu (b).',
        ],
      },
      {
        id: 'b8-es-5',
        question: 'Câu 5 [Tài liệu Chủ đề Tốc độ]: Bánh xe của một ô tô du lịch có bán kính r = 25 cm. Nếu xe chạy đều với tốc độ 54 km/h thì trong mỗi giờ bánh xe quay được bao nhiêu vòng? (Lấy π = 3,14).',
        hint: 'Tính chu vi 1 vòng bánh xe C = 2 · π · r (m) và quãng đường đi được trong 1 giờ.',
        sampleAnswer: '- Đổi bán kính bánh xe: r = 25 cm = 0,25 m.\n- Chu vi một vòng quay của bánh xe là: C = 2 · π · r = 2 × 3,14 × 0,25 = 1,57 m.\n- Trong 1 giờ, quãng đường ô tô đi được là: s = v · t = 54 × 1 = 54 km = 54 000 m.\n- Số vòng quay của bánh xe trong 1 giờ là: N = s / C = 54 000 / 1,57 ≈ 34 395 vòng.',
        rubricPoints: [
          'Tính đúng chu vi bánh xe C = 1,57 m.',
          'Tính đúng số vòng quay trong 1 giờ N ≈ 34 395 vòng.',
        ],
      },
      {
        id: 'b8-es-6',
        question: 'Câu 6 [Tài liệu Chủ đề Tốc độ]: Một mô tô chuyển động trên quãng đường s. Trong nửa quãng đường đầu (s₁ = s/2), mô tô đi với tốc độ v₁ = 60 km/h; trong nửa quãng đường còn lại (s₂ = s/2), mô tô đi với tốc độ v₂ = 40 km/h. Hãy tính tốc độ trung bình v của mô tô trên cả quãng đường.',
        hint: 'Dùng công thức t₁ = s / (2·v₁) và t₂ = s / (2·v₂), sau đó tính v = s / (t₁ + t₂).',
        sampleAnswer: 'Gọi tổng quãng đường là s (km), mỗi nửa quãng đường là s₁ = s₂ = 0,5·s.\n- Thời gian đi nửa quãng đường đầu: t₁ = 0,5·s / 60 = s / 120 (h).\n- Thời gian đi nửa quãng đường sau: t₂ = 0,5·s / 40 = s / 80 (h).\n- Tốc độ trung bình trên cả quãng đường là:\nv = s / (t₁ + t₂) = s / (s/120 + s/80) = 1 / (1/120 + 1/80) = 240 / 5 = 48 km/h.',
        rubricPoints: [
          'Biểu diễn đúng t₁ và t₂ theo quãng đường s.',
          'Tính đúng tốc độ trung bình v = 48 km/h.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 9 & 11: ĐO TỐC ĐỘ – TỐC ĐỘ VÀ AN TOÀN GIAO THÔNG (Tài liệu Tốc độ - Phần C)
  // =========================================================================
  {
    id: 'kntt-bai-9',
    lessonNumber: 9,
    title: 'Bài 9 & 11: Đo tốc độ – Tốc độ và an toàn giao thông',
    chapterTitle: 'Chương III: Tốc độ',
    subject: 'physics',
    pdfUrl: '/assets/aistudio/_C_p_nh_t_m_i__Ch_____T_c____e8df4bc0.pdf',
    summary:
      'Để đo tốc độ chuyển động ta đo quãng đường s (bằng thước) và thời gian t (bằng đồng hồ bấm giây hoặc đồng hồ đo thời gian hiện số kết nối cổng quang điện). Khi tham gia giao thông cần tuân thủ tốc độ tối đa và giữ khoảng cách an toàn tối thiểu (quy tắc 3 giây).',
    keyFormulas: [
      'Quy tắc “3 giây” trên cao tốc:  Khoảng cách an toàn (m) = Tốc độ v (m/s) × 3 (s)',
      'Khoảng cách an toàn theo Luật GTĐB: v = 60 km/h → 35 m; 60 < v ≤ 80 → 55 m; 80 < v ≤ 100 → 70 m; 100 < v ≤ 120 → 100 m',
      'Tốc độ trung bình qua 3 lần đo:  v_tb = (v₁ + v₂ + v₃) / 3',
    ],
    mcqs: makeMcqs('b9', [
      ['Để đo tốc độ của một người chạy cự li ngắn trên sân trường, ta cần những dụng cụ đo nào?', ['Thước cuộn và đồng hồ bấm giây.', 'Thước thẳng 20 cm và đồng hồ treo tường.', 'Đồng hồ đo thời gian hiện số kết nối cổng quang điện.', 'Nhiệt kế và cân điện tử.'], 0, 'Đo chạy cự li ngắn ngoài sân trường dùng thước cuộn (đo s) và đồng hồ bấm giây (đo t).'],
      ['Trong phòng thí nghiệm, để đo tốc độ của các vật chuyển động nhanh và có kích thước nhỏ (như viên bi thép), người ta thường dùng:', ['Thước và đồng hồ treo tường.', 'Thước, đồng hồ đo thời gian hiện số kết nối với hai cổng quang điện.', 'Chỉ dùng cổng quang điện mà không cần đồng hồ.', 'Thiết bị bắn tốc độ giao thông.'], 1, 'Cổng quang điện đóng vai trò như nút START và STOP tự động truyền tín hiệu tới đồng hồ hiện số với độ chính xác tới phần nghìn giây.'],
      ['Để kiểm tra tốc độ của các phương tiện giao thông đang lưu thông trên đường, cảnh sát giao thông sử dụng:', ['Đồng hồ bấm giây.', 'Đồng hồ hẹn giờ.', 'Đồng hồ đo thời gian hiện số trong phòng thí nghiệm.', 'Thiết bị “bắn tốc độ” (súng bắn tốc độ).'], 3, 'Thiết bị bắn tốc độ dùng camera/sóng ghi thời gian xe chạy qua hai vạch mốc để tính tốc độ.'],
      ['Bạn Nam đếm được từ nhà đến trường là 984 bước chân, mỗi bước trung bình dài 0,5 m và thời gian đi là 8 phút. Tốc độ đi bộ của Nam là:', ['1,025 m/min.', '3,6 km/min.', '3,69 km/h (tương đương 1,025 m/s).', '5,4 km/h.'], 2, 'Quãng đường s = 984 × 0,5 = 492 m. Thời gian t = 8 × 60 = 480 s ⇒ v = 492 / 480 = 1,025 m/s = 3,69 km/h.'],
      ['Camera của thiết bị “bắn tốc độ” ghi được thời gian một ô tô chạy qua giữa hai vạch mốc cách nhau 10 m là 0,66 s. Tốc độ của ô tô là:', ['15,15 km/h.', '16 km/h.', '15,15 m/s (≈ 54,54 km/h).', '25 m/s.'], 2, 'v = s / t = 10 / 0,66 ≈ 15,15 m/s.'],
      ['Chọn dụng cụ đo thời gian thích hợp nhất để đo tốc độ bơi của một vận động viên tại bể bơi:', ['Đồng hồ bấm giây.', 'Thiết bị “bắn tốc độ”.', 'Đồng hồ cát.', 'Đồng hồ treo tường.'], 0, 'Trong thi đấu bơi lội và điền kinh, người ta dùng đồng hồ bấm giây để đo thời gian.'],
      ['Hãy sắp xếp các thao tác theo đúng thứ tự khi sử dụng đồng hồ bấm giây đo thời gian: (1) Nhấn STOP khi kết thúc; (2) Nhấn RESET đưa về số 0; (3) Nhấn START khi bắt đầu.', ['(1) → (3) → (2).', '(2) → (1) → (3).', '(3) → (1) → (2).', '(2) → (3) → (1).'], 3, 'Thứ tự đúng: Nhấn RESET về 0 (2) → Nhấn START bắt đầu đo (3) → Nhấn STOP kết thúc đo (1).'],
      ['Phát biểu nào sau đây KHÔNG đúng khi nói về khoảng cách an toàn giữa các xe đang lưu thông trên đường?', ['Khoảng cách an toàn là khoảng cách đủ để người lái kịp phản ứng phanh xe khi gặp tình huống bất ngờ.', 'Khoảng cách an toàn tối thiểu được quy định bởi Luật Giao thông đường bộ.', 'Tốc độ chuyển động càng cao thì khoảng cách an toàn phải giữ càng lớn.', 'Khi trời mưa hoặc mặt đường trơn trượt, lái xe nên giảm khoảng cách an toàn xuống nhỏ hơn bình thường.'], 3, 'Khi trời mưa đường trơn, quãng đường phanh dài hơn nên lái xe phải TĂNG khoảng cách an toàn chứ không được giảm.'],
      ['Biển báo giao thông hình tròn viền đỏ có hình 2 ô tô và chữ “8m” ở trên có ý nghĩa gì?', ['Giữ khoảng cách tối đa giữa các xe là 8 m.', 'Cự li tối thiểu giữa hai xe cơ giới là 8 m.', 'Chiều dài tối đa của xe là 8 m.', 'Giữ tốc độ tối thiểu là 8 m/s.'], 1, 'Biển báo quy định cự li (khoảng cách) an toàn tối thiểu giữa các xe cơ giới là 8 m.'],
      ['Cách tính khoảng cách an toàn theo quy tắc “3 giây” khi đi xe trên đường cao tốc là:', ['Khoảng cách an toàn (m) = tốc độ (m/s) + 3 (s).', 'Khoảng cách an toàn (m) = tốc độ (m/s) - 3 (s).', 'Khoảng cách an toàn (m) = tốc độ (m/s) × 3 (s).', 'Khoảng cách an toàn (m) = tốc độ (m/s) : 3 (s).'], 2, 'Theo quy tắc 3 giây: s_an_toàn = v (m/s) × 3 (s).'],
      ['Theo quy định tốc độ tối đa tại Việt Nam, xe ô tô con chạy trên đường đôi (có dải phân cách giữa) trong khu vực đông dân cư được phép chạy tối đa bao nhiêu?', ['50 km/h.', '60 km/h.', '70 km/h.', '80 km/h.'], 1, 'Trong khu vực đông dân cư: đường đôi tối đa 60 km/h; đường hai chiều không dải phân cách tối đa 50 km/h.'],
      ['Xe ô tô con chạy trên đường hai chiều (không có dải phân cách giữa) trong khu vực đông dân cư có tốc độ tối đa là:', ['50 km/h.', '60 km/h.', '70 km/h.', '80 km/h.'], 0, 'Đường hai chiều trong khu đông dân cư quy định tốc độ tối đa 50 km/h.'],
      ['Theo bảng quy định khoảng cách an toàn tối thiểu, đối với xe ô tô chạy với tốc độ 20 m/s (tương đương 72 km/h) thì khoảng cách an toàn tối thiểu là:', ['35 m.', '55 m.', '70 m.', '100 m.'], 1, 'v = 20 m/s = 72 km/h nằm trong khoảng từ trên 60 đến 80 km/h ⇒ khoảng cách an toàn tối thiểu là 55 m.'],
      ['Khoảng cách an toàn tối thiểu 100 m được áp dụng khi xe lưu hành trên đường với tốc độ:', ['60 km/h.', '75 km/h.', '90 km/h.', 'Trên 100 km/h đến 120 km/h (ví dụ 110 km/h).'], 3, 'Với tốc độ trên 100 đến 120 km/h, khoảng cách an toàn tối thiểu là 100 m.'],
      ['Xe ô tô di chuyển trên đường với tốc độ 1 km/min (tương đương 60 km/h) cần giữ khoảng cách an toàn tối thiểu với xe phía trước là:', ['35 m.', '55 m.', '70 m.', '100 m.'], 0, '1 km/min = 60 km/h ⇒ khoảng cách an toàn tối thiểu là 35 m.'],
      ['Khoảng cách an toàn tối thiểu 70 m được áp dụng khi xe lưu hành với tốc độ trong khoảng:', ['Dưới 60 km/h.', 'Từ 60 đến 80 km/h.', 'Trên 80 đến 100 km/h.', 'Trên 120 km/h.'], 2, 'Tốc độ trên 80 đến 100 km/h quy định khoảng cách an toàn tối thiểu là 70 m.'],
      ['Trên biển báo tốc độ đường cao tốc ghi: dòng trên “120” (vòng tròn đỏ) và “70” (nền xanh); dòng dưới kèm hình đám mây mưa ghi “100” (vòng tròn đỏ). Con số 120 có ý nghĩa là:', ['Tốc độ tối đa khi trời mưa là 120 km/h.', 'Tốc độ tối đa khi trời nắng (không mưa) là 120 km/h.', 'Tốc độ tối thiểu khi trời mưa là 120 km/h.', 'Tốc độ tối thiểu khi trời nắng là 120 km/h.'], 1, '120 là tốc độ tối đa cho phép khi điều kiện thời tiết bình thường (không mưa).'],
      ['Trên biển báo cao tốc nói trên, tốc độ tối đa cho phép khi trời mưa là:', ['120 km/h.', '100 km/h.', '80 km/h.', '70 km/h.'], 1, 'Con số 100 cạnh biểu tượng đám mây mưa quy định tốc độ tối đa khi trời mưa là 100 km/h.'],
      ['Trên biển báo cao tốc nói trên, con số 70 (trong hình bầu dục nền xanh) có ý nghĩa là:', ['Tốc độ tối đa khi trời mưa là 70 km/h.', 'Tốc độ tối đa ban đêm là 70 km/h.', 'Tốc độ tối thiểu cho phép trên đường cao tốc khi không mưa là 70 km/h.', 'Khoảng cách tối thiểu giữa hai xe là 70 m.'], 2, 'Con số 70 nền xanh quy định tốc độ tối thiểu cho phép (xe không được chạy chậm hơn 70 km/h).'],
      ['Trên đường cao tốc có biển báo (tối đa 120 km/h khi nắng, 100 km/h khi mưa), xe ô tô chạy dưới trời mưa với tốc độ 30,5 m/s có vi phạm không?', ['Không vi phạm vì 30,5 < 100.', 'Có vi phạm vì 30,5 m/s = 109,8 km/h > 100 km/h.', 'Không vi phạm vì vẫn nhỏ hơn 120 km/h.', 'Không xác định được.'], 1, 'Đổi 30,5 m/s = 30,5 × 3,6 = 109,8 km/h. Trời mưa tốc độ tối đa là 100 km/h nên xe đã vượt quá tốc độ quy định.'],
      ['Một xe ô tô đang chạy trên đường cao tốc với tốc độ 80 km/h. Khoảng cách an toàn của xe tính theo quy tắc “3 giây” xấp xỉ là:', ['240 m.', '240 km.', '66,67 m.', '80 m.'], 2, 'Đổi v = 80 / 3,6 ≈ 22,22 m/s ⇒ Khoảng cách an toàn = 22,22 × 3 ≈ 66,67 m.'],
      ['Trong thí nghiệm đo tốc độ của xe đồ chơi chạy qua hai cổng quang điện cách nhau 30 cm, thời gian hiển thị trên đồng hồ là 1,5 s. Tốc độ của xe là:', ['20 cm/s (0,2 m/s).', '45 cm/s.', '0,5 m/s.', '2 m/s.'], 0, 'v = s / t = 30 cm / 1,5 s = 20 cm/s = 0,2 m/s.'],
      ['Trong thí nghiệm đo tốc độ của viên bi chạy qua hai cổng quang điện cách nhau 2 m, thời gian hiển thị là 1,25 s. Tốc độ của viên bi là:', ['1,6 m/s.', '2,5 m/s.', '16 m/s.', '0,8 m/s.'], 0, 'v = s / t = 2 / 1,25 = 1,6 m/s.'],
      ['Camera bắn tốc độ ghi nhận một ô tô chạy qua 2 vạch mốc cách nhau 10 m trong 0,42 s trên đoạn đường giới hạn 70 km/h. Nhận xét nào đúng?', ['Xe chạy 23,8 km/h nên không vi phạm.', 'Xe chạy 85,7 km/h nên đã vượt quá tốc độ cho phép (70 km/h).', 'Xe chạy đúng 70 km/h.', 'Xe chạy 60 km/h nên an toàn.'], 1, 'v = 10 / 0,42 ≈ 23,81 m/s = 85,7 km/h > 70 km/h ⇒ Xe vượt quá tốc độ quy định.'],
      ['Theo thống kê của Tổ chức An toàn Giao thông Toàn cầu, nếu tốc độ phương tiện tăng lên 1% thì số người tử vong vì tai nạn giao thông tăng tương ứng khoảng:', ['0,5 – 1%.', '1 – 2%.', '3,5 – 4%.', '10 – 15%.'], 2, 'Theo báo cáo an toàn giao thông: tốc độ tăng 1% làm số ca tử vong do tai nạn tăng từ 3,5% đến 4%.'],
      ['Nhận định nào sau đây là ĐÚNG về mối liên hệ giữa tốc độ và tai nạn giao thông?', ['Tốc độ ô tô càng lớn, tỉ lệ thương vong đối với người đi bộ khi xảy ra va chạm càng thấp.', 'Tốc độ ô tô càng lớn, động năng va chạm càng mạnh và tỉ lệ thương vong càng cao.', 'Tốc độ không ảnh hưởng đến mức độ nghiêm trọng của tai nạn.', 'Chỉ cần bấm còi liên tục là có thể chạy vượt quá tốc độ giới hạn.'], 1, 'Tốc độ càng lớn, thời gian phản ứng càng ngắn, quãng đường phanh càng dài và lực va chạm càng lớn.'],
      ['Trong phòng thí nghiệm, tại sao khi đo tốc độ của xe lăn bằng cổng quang điện, người ta thường tiến hành đo 3 lần rồi lấy giá trị trung bình?', ['Để làm cho bảng báo cáo dài hơn.', 'Để giảm thiểu sai số ngẫu nhiên trong quá trình thực hành.', 'Vì đồng hồ hiện số chỉ hoạt động khi đo đủ 3 lần.', 'Để tăng tốc độ của xe lăn.'], 1, 'Đo nhiều lần (thường là 3 lần) rồi lấy trung bình cộng giúp giảm sai số phép đo.'],
      ['Một vận động viên chạy cự li 200 m. Đồng hồ bấm giây ghi nhận lúc xuất phát là 00:00 và lúc chạm đích là 00:25 (25 giây). Tốc độ trung bình của vận động viên là:', ['8 m/s (28,8 km/h).', '4 m/s.', '10 m/s.', '5 m/s.'], 0, 'v = s / t = 200 / 25 = 8 m/s = 28,8 km/h.'],
      ['Để đo tốc độ gió, người ta dùng một chong chóng gió có bán kính 60 cm. Trong 4,2 giây, chong chóng quay được 20 vòng. Tốc độ gió (lấy π = 3,14) xấp xỉ bằng:', ['18 m/s.', '10 m/s.', '25 m/s.', '9 m/s.'], 0, 'Chu vi 1 vòng C = 2 × 3,14 × 0,6 = 3,768 m. Quãng đường 20 vòng s = 20 × 3,768 = 75,36 m ⇒ v = 75,36 / 4,2 ≈ 17,94 ≈ 18 m/s.'],
      ['Tại SEA Games 27, kình ngư Nguyễn Thị Ánh Viên phá kỷ lục 200 m bơi ngửa với thành tích 2 phút 14,80 giây (134,8 s). Tốc độ bơi trung bình của Ánh Viên ở cự li này là:', ['1,48 m/s.', '2,50 m/s.', '1,15 m/s.', '3,20 m/s.'], 0, 'v = s / t = 200 / 134,8 ≈ 1,48 m/s.'],
    ]),
    trueFalseList: [
      {
        id: 'b9-tf-1',
        stem: 'Xét hai phương pháp đo tốc độ trong trường học và trong thực tế:',
        statements: [
          { id: 'a', text: 'Khi đo tốc độ bằng đồng hồ bấm giây, ta dùng thước để đo quãng đường s giữa vạch xuất phát và vạch đích.', isTrue: true, explanation: 'Đúng quy trình đo tốc độ bằng đồng hồ bấm giây.' },
          { id: 'b', text: 'Trong thiết bị đo có cổng quang điện, cổng quang điện đóng vai trò như công tắc tự động bật (START) và dừng (STOP) đồng hồ đo thời gian hiện số.', isTrue: true, explanation: 'Đúng nguyên lí hoạt động của cổng quang điện.' },
          { id: 'c', text: 'Đồng hồ bấm giây cơ học cho độ chính xác cao hơn cổng quang điện khi đo các vật chuyển động rất nhanh.', isTrue: false, explanation: 'Sai, đồng hồ bấm giây phụ thuộc vào phản xạ bấm tay của người đo nên kém chính xác hơn cổng quang điện tự động.' },
          { id: 'd', text: 'Thiết bị “bắn tốc độ” trên đường giao thông xác định tốc độ xe bằng cách đo thời gian xe đi qua hai vạch mốc có khoảng cách xác định.', isTrue: true, explanation: 'Đúng nguyên lí của camera bắn tốc độ.' },
        ],
      },
      {
        id: 'b9-tf-2',
        stem: 'Một học sinh tiến hành đo tốc độ của ô tô đồ chơi chạy trên mặt gỗ nghiêng dài s = 50 cm (0,5 m) qua 3 lần đo với thời gian lần lượt là: t₁ = 1,37 s; t₂ = 1,35 s; t₃ = 1,38 s:',
        statements: [
          { id: 'a', text: 'Quãng đường đi được trong mỗi lần đo là s = 0,5 m.', isTrue: true, explanation: 'Đúng, 50 cm = 0,5 m.' },
          { id: 'b', text: 'Thời gian chuyển động trung bình qua 3 lần đo là 1,367 giây.', isTrue: true, explanation: 'Đúng, t_tb = (1,37 + 1,35 + 1,38) / 3 = 4,10 / 3 ≈ 1,367 s.' },
          { id: 'c', text: 'Tốc độ trung bình của ô tô đồ chơi xấp xỉ bằng 0,366 m/s (tương đương 1,32 km/h).', isTrue: true, explanation: 'Đúng, v_tb = 0,5 / 1,367 ≈ 0,366 m/s.' },
          { id: 'd', text: 'Ở lần đo thứ 2 (t₂ = 1,35 s), xe chạy chậm nhất trong 3 lần đo.', isTrue: false, explanation: 'Sai, ở lần đo thứ 2 thời gian ngắn nhất (1,35 s) nên xe chạy nhanh nhất (v₂ = 0,5 / 1,35 ≈ 0,37 m/s).' },
        ],
      },
      {
        id: 'b9-tf-3',
        stem: 'Xét quy định về khoảng cách an toàn tối thiểu và quy tắc “3 giây” trên đường cao tốc:',
        statements: [
          { id: 'a', text: 'Theo quy tắc “3 giây”, khoảng cách an toàn (m) = tốc độ v (m/s) × 3 (s).', isTrue: true, explanation: 'Đúng công thức quy tắc 3 giây.' },
          { id: 'b', text: 'Nếu một ô tô đang chạy trên cao tốc với tốc độ 30 m/s (108 km/h) thì khoảng cách an toàn theo quy tắc 3 giây là 90 m.', isTrue: true, explanation: 'Đúng, 30 m/s × 3 s = 90 m.' },
          { id: 'c', text: 'Khi trời mưa to, sương mù dày đặc làm tầm nhìn hạn chế, người lái xe vẫn chỉ cần giữ khoảng cách đúng như khi trời nắng khô ráo.', isTrue: false, explanation: 'Sai, khi trời mưa hoặc sương mù phải giảm tốc độ và tăng khoảng cách an toàn lên lớn hơn.' },
          { id: 'd', text: 'Việc giữ đúng khoảng cách an toàn tối thiểu giúp người lái xe có đủ thời gian xử lí phanh khi xe phía trước dừng đột ngột.', isTrue: true, explanation: 'Đúng ý nghĩa của khoảng cách an toàn.' },
        ],
      },
      {
        id: 'b9-tf-4',
        stem: 'Trên đoạn đường có biển báo giới hạn tốc độ tối đa là 60 km/h, camera bắn tốc độ ghi nhận một ô tô đi qua hai vạch mốc cách nhau 10 m hết 2/3 giây:',
        statements: [
          { id: 'a', text: 'Tốc độ của ô tô tính theo đơn vị m/s là 15 m/s.', isTrue: true, explanation: 'Đúng, v = 10 / (2/3) = 15 m/s.' },
          { id: 'b', text: 'Khi đổi sang đơn vị km/h, tốc độ của ô tô này là 54 km/h.', isTrue: true, explanation: 'Đúng, 15 × 3,6 = 54 km/h.' },
          { id: 'c', text: 'Ô tô này đã vi phạm lỗi chạy quá tốc độ tối đa cho phép (60 km/h).', isTrue: false, explanation: 'Sai, vì 54 km/h < 60 km/h nên ô tô không vượt quá tốc độ cho phép.' },
          { id: 'd', text: 'Nếu một ô tô thứ hai chạy qua hai vạch mốc 10 m này chỉ trong 0,5 giây thì ô tô thứ hai đã vượt quá tốc độ giới hạn.', isTrue: true, explanation: 'Đúng, vì v₂ = 10 / 0,5 = 20 m/s = 72 km/h > 60 km/h.' },
        ],
      },
      {
        id: 'b9-tf-5',
        stem: 'Xét các hành vi văn hóa và an toàn khi tham gia giao thông đường bộ:',
        statements: [
          { id: 'a', text: 'Tuân thủ đúng giới hạn tốc độ và đi đúng làn đường, phần đường quy định.', isTrue: true, explanation: 'Đúng quy tắc an toàn giao thông.' },
          { id: 'b', text: 'Cài dây an toàn khi ngồi trên ô tô và đội mũ bảo hiểm đạt chuẩn khi đi xe đạp điện, xe máy.', isTrue: true, explanation: 'Đúng quy định bảo vệ tính mạng khi tham gia giao thông.' },
          { id: 'c', text: 'Khi thấy đường vắng người vào ban đêm thì có thể vượt đèn đỏ và chạy vượt quá tốc độ tối đa.', isTrue: false, explanation: 'Sai, mọi thời điểm đều phải chấp hành tín hiệu đèn giao thông và tốc độ tối đa.' },
          { id: 'd', text: 'Chủ động giảm tốc độ và nhường đường cho người đi bộ tại vạch kẻ đường và nhường đường cho xe ưu tiên.', isTrue: true, explanation: 'Đúng quy tắc ứng xử văn minh và an toàn giao thông.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b9-es-1',
        question: 'Câu 1 [Tài liệu Chủ đề Tốc độ]: Camera của một thiết bị “bắn tốc độ” ghi được thời gian một ô tô chạy từ vạch mốc 1 sang vạch mốc 2 cách nhau 10 m là 2/3 giây. Hỏi ô tô có vượt quá tốc độ cho phép là 60 km/h trên đoạn đường đó không? Hãy trình bày lời giải chi tiết.',
        hint: 'Tính tốc độ v = s / t (m/s), sau đó nhân với 3,6 để đổi sang km/h rồi so sánh với 60 km/h.',
        sampleAnswer: 'Tóm tắt: s = 10 m; t = 2/3 s; v_cho_phép = 60 km/h.\nGiải:\n- Tốc độ chuyển động của ô tô là:\nv = s / t = 10 / (2/3) = 15 m/s.\n- Đổi sang đơn vị km/h: v = 15 × 3,6 = 54 km/h.\n- Vì 54 km/h < 60 km/h nên ô tô KHÔNG vượt quá tốc độ cho phép.',
        rubricPoints: [
          'Tính đúng tốc độ v = 15 m/s.',
          'Đổi đúng sang 54 km/h và kết luận xe không vượt quá tốc độ 60 km/h.',
        ],
      },
      {
        id: 'b9-es-2',
        question: 'Câu 2 [Tài liệu Chủ đề Tốc độ]: Tại SEA Games 27, kình ngư Nguyễn Thị Ánh Viên đã phá 2 kỷ lục SEA Games ở cự li 200 m bơi ngửa (thành tích 2 phút 14,80 giây) và 400 m bơi hỗn hợp (thành tích 4 phút 46,16 giây). Em hãy tính tốc độ bơi trung bình (ra m/s) của Ánh Viên ở 2 lần phá kỷ lục trên.',
        hint: 'Đổi thời gian t₁ và t₂ ra giây trước khi áp dụng v = s / t.',
        sampleAnswer: '- Ở cự li 200 m bơi ngửa:\nĐổi thời gian: t₁ = 2 phút 14,80 giây = 2 × 60 + 14,80 = 134,8 s.\nTốc độ trung bình: v₁ = s₁ / t₁ = 200 / 134,8 ≈ 1,48 m/s.\n- Ở cự li 400 m bơi hỗn hợp:\nĐổi thời gian: t₂ = 4 phút 46,16 giây = 4 × 60 + 46,16 = 286,16 s.\nTốc độ trung bình: v₂ = s₂ / t₂ = 400 / 286,16 ≈ 1,40 m/s.',
        rubricPoints: [
          'Đổi đúng t₁ = 134,8 s và tính đúng v₁ ≈ 1,48 m/s.',
          'Đổi đúng t₂ = 286,16 s và tính đúng v₂ ≈ 1,40 m/s.',
        ],
      },
      {
        id: 'b9-es-3',
        question: 'Câu 3 [Tài liệu Chủ đề Tốc độ]: Để đo tốc độ gió, người ta dùng một chong chóng gió có bán kính r = 60 cm và một đồng hồ bấm giây. Trong một lần đo, người ta đếm được chong chóng quay 20 vòng trong thời gian 4,2 giây. Hãy tính tốc độ gió theo đơn vị m/s và km/h (lấy π = 3,14).',
        hint: 'Quãng đường đầu cánh chong chóng đi được trong 20 vòng là s = 20 × 2πr.',
        sampleAnswer: '- Đổi bán kính: r = 60 cm = 0,6 m.\n- Quãng đường đầu cánh chong chóng đi được trong 20 vòng quay là:\ns = 20 × (2 · π · r) = 20 × 2 × 3,14 × 0,6 = 75,36 m.\n- Tốc độ của gió là:\nv = s / t = 75,36 / 4,2 ≈ 17,94 m/s ≈ 18 m/s (tương đương 18 × 3,6 = 64,8 km/h).',
        rubricPoints: [
          'Tính đúng quãng đường 20 vòng quay s = 75,36 m.',
          'Tính đúng tốc độ gió v ≈ 18 m/s (64,8 km/h).',
        ],
      },
      {
        id: 'b9-es-4',
        question: 'Câu 4 [Tài liệu Chủ đề Tốc độ]: Camera của một thiết bị “bắn tốc độ” ghi hình và tính được thời gian một ô tô chạy qua giữa hai vạch mốc cách nhau 10 m là 0,42 s. Nếu tốc độ giới hạn quy định trên làn đường là 70 km/h thì ô tô này có vượt quá tốc độ cho phép hay không?',
        hint: 'Tính v = 10 / 0,42 (m/s) rồi nhân 3,6 để so sánh với 70 km/h.',
        sampleAnswer: '- Tốc độ của ô tô khi chạy qua hai vạch mốc là:\nv = s / t = 10 / 0,42 ≈ 23,81 m/s.\n- Đổi ra đơn vị km/h: v = 23,81 × 3,6 ≈ 85,7 km/h.\n- Vì 85,7 km/h > 70 km/h nên ô tô này ĐÃ VƯỢT QUÁ tốc độ cho phép.',
        rubricPoints: [
          'Tính đúng v ≈ 23,81 m/s = 85,7 km/h.',
          'So sánh với 70 km/h và kết luận xe vượt quá tốc độ cho phép.',
        ],
      },
      {
        id: 'b9-es-5',
        question: 'Câu 5 [Tài liệu Chủ đề Tốc độ]: Một xe ô tô đang chạy trên đường cao tốc với tốc độ 90 km/h.\n(a) Hãy tính khoảng cách an toàn tối thiểu của xe theo quy tắc “3 giây”.\n(b) Theo quy định của Luật Giao thông đường bộ (với mức tốc độ từ trên 80 đến 100 km/h), khoảng cách an toàn tối thiểu là bao nhiêu mét? So sánh hai giá trị trên.',
        hint: 'Đổi 90 km/h sang m/s rồi nhân với 3 giây.',
        sampleAnswer: '(a) Đổi tốc độ: v = 90 km/h = 90 / 3,6 = 25 m/s.\nTheo quy tắc “3 giây”, khoảng cách an toàn tối thiểu là:\nd = v × 3 = 25 × 3 = 75 m.\n(b) Theo bảng quy định của Luật Giao thông đường bộ, ở tốc độ 80 < v ≤ 100 km/h thì khoảng cách an toàn tối thiểu là 70 m. Giá trị tính theo quy tắc 3 giây (75 m) lớn hơn một chút và hoàn toàn đảm bảo chuẩn an toàn pháp luật (≥ 70 m).',
        rubricPoints: [
          'Đổi đúng 90 km/h = 25 m/s và tính đúng khoảng cách 3 giây là 75 m.',
          'Nêu đúng mức quy định 70 m và so sánh hợp lí.',
        ],
      },
      {
        id: 'b9-es-6',
        question: 'Câu 6 [Tài liệu Chủ đề Tốc độ]: Nêu sự khác nhau cơ bản giữa cách đo tốc độ bằng đồng hồ bấm giây và cách đo tốc độ bằng đồng hồ đo thời gian hiện số dùng cổng quang điện. Tại sao trong phòng thí nghiệm người ta ưu tiên dùng cổng quang điện?',
        hint: 'So sánh cách kích hoạt bấm giờ (bằng tay vs tia hồng ngoại tự động).',
        sampleAnswer: '- Đo bằng đồng hồ bấm giây: Người đo phải quan sát bằng mắt và bấm nút START / STOP bằng tay nên dễ có sai số do thời gian phản xạ của con người.\n- Đo bằng đồng hồ hiện số kết nối cổng quang điện: Khi vật chắn chùm tia sáng ở cổng quang điện thứ nhất, đồng hồ tự động đếm; khi vật qua cổng quang điện thứ hai, đồng hồ tự động dừng.\n- Ưu tiên dùng trong phòng thí nghiệm vì vật thí nghiệm thường chuyển động trên quãng đường ngắn trong thời gian rất nhỏ (vài phần chục giây), cổng quang điện giúp đo chính xác đến 0,001 giây.',
        rubricPoints: [
          'Phân biệt rõ cơ chế bấm tay và cơ chế tự động bằng tia quang học.',
          'Giải thích đúng lí do cổng quang điện chính xác cao đối với quãng đường ngắn, thời gian nhỏ.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 10: ĐỒ THỊ QUÃNG ĐƯỜNG – THỜI GIAN (Tài liệu Chủ đề Tốc độ - Phần B)
  // =========================================================================
  {
    id: 'kntt-bai-10',
    lessonNumber: 10,
    title: 'Bài 10: Đồ thị quãng đường – thời gian',
    chapterTitle: 'Chương III: Tốc độ',
    subject: 'physics',
    pdfUrl: '/assets/aistudio/_C_p_nh_t_m_i__Ch_____T_c____e8df4bc0.pdf',
    summary:
      'Đồ thị quãng đường – thời gian (s – t) mô tả trực quan mối liên hệ giữa quãng đường đi được s (trục tung Os) và thời gian đi t (trục hoành Ot). Từ đồ thị ta xác định được s, t, tốc độ v và trạng thái chuyển động đều hay đang đứng yên.',
    keyFormulas: [
      'Trục tung (thẳng đứng) Os: biểu diễn quãng đường s  |  Trục hoành (nằm ngang) Ot: biểu diễn thời gian t',
      'Đường thẳng nghiêng đi lên: Vật chuyển động với tốc độ không đổi (đường càng dốc ⇒ tốc độ càng lớn)',
      'Đường thẳng nằm ngang (song song trục Ot): Quãng đường không đổi ⇒ Vật đang đứng yên (v = 0)',
    ],
    mcqs: makeMcqs('b10', [
      ['Chọn phát biểu đúng khi nói về đồ thị quãng đường – thời gian:', ['Đồ thị có điểm gốc O ứng với s = 0 và t = 1.', 'Trục tung Os biểu thị thời gian.', 'Đồ thị quãng đường – thời gian mô tả mối liên hệ giữa quãng đường đi được của vật và thời gian.', 'Trục hoành Ot biểu thị quãng đường.'], 2, 'Đồ thị s – t biểu diễn sự phụ thuộc của quãng đường đi được s theo thời gian t.'],
      ['Trong đồ thị quãng đường – thời gian, hai trục tọa độ Os và Ot được vẽ:', ['song song với nhau.', 'tạo thành góc 60°.', 'trùng nhau.', 'vuông góc với nhau tại gốc tọa độ O.'], 3, 'Hai trục Os (thẳng đứng) và Ot (nằm ngang) vuông góc với nhau tại gốc O.'],
      ['Cho các bước: (1) Nối các điểm thành đường biểu diễn; (2) Xác định các điểm biểu diễn cặp (s, t) tương ứng; (3) Lập bảng ghi s theo t; (4) Vẽ hai trục tọa độ Os và Ot. Thứ tự các bước vẽ đồ thị hợp lí nhất là:', ['(3) → (2) → (4) → (1).', '(3) → (4) → (2) → (1).', '(2) → (4) → (3) → (1).', '(4) → (3) → (2) → (1).'], 1, 'Trình tự chuẩn: Lập bảng số liệu (3) → Vẽ hệ trục tọa độ (4) → Chấm các điểm tọa độ (2) → Nối các điểm (1).'],
      ['Từ đồ thị quãng đường – thời gian (s – t), ta KHÔNG thể xác định trực tiếp thông tin nào sau đây?', ['Quãng đường đi được khi biết thời gian.', 'Thời gian chuyển động khi biết quãng đường.', 'Hướng chuyển động (rẽ trái, rẽ phải hay đi vòng) của vật.', 'Tốc độ chuyển động của vật trên từng giai đoạn.'], 2, 'Đồ thị s – t chỉ cho biết độ dài quãng đường theo thời gian, không cho biết hình dạng quỹ đạo hay hướng rẽ của vật.'],
      ['Một ô tô chuyển động đều có bảng số liệu: t = 1h → s = 50km; t = 2h → s = 100km; t = 3h → s = 150km; t = 4h → s = 200km. Quãng đường ô tô đi được trong 2 giờ đầu là:', ['50 km.', '100 km.', '150 km.', '200 km.'], 1, 'Ứng với t = 2 h, quãng đường s = 100 km.'],
      ['Với bảng số liệu ở câu trên, ô tô đi hết quãng đường 150 km trong thời gian bao lâu?', ['1 h.', '2 h.', '3 h.', '4 h.'], 2, 'Ứng với s = 150 km, thời gian t = 3 h.'],
      ['Với bảng số liệu ở câu trên, tốc độ của ô tô là:', ['25 km/h.', '50 km/h.', '75 km/h.', '100 km/h.'], 1, 'v = s / t = 50 / 1 = 50 km/h.'],
      ['Đồ thị quãng đường – thời gian của một vật chuyển động với tốc độ không đổi là:', ['một đường thẳng song song với trục thời gian Ot.', 'một đường thẳng song song với trục quãng đường Os.', 'một đường thẳng nằm nghiêng đi qua gốc tọa độ O (nếu xuất phát từ O).', 'một đường tròn khép kín.'], 2, 'Khi vật chuyển động đều với tốc độ không đổi, s = v · t nên đồ thị là đường thẳng nằm nghiêng.'],
      ['Khi đồ thị quãng đường – thời gian là một đoạn thẳng nằm ngang song song với trục thời gian Ot thì vật đang ở trạng thái nào?', ['Vật chuyển động nhanh dần.', 'Vật đang đứng yên (v = 0).', 'Vật chuyển động với tốc độ không đổi.', 'Vật đang quay đầu đi ngược lại.'], 1, 'Đoạn thẳng nằm ngang cho biết thời gian t tăng nhưng quãng đường s không đổi ⇒ vật đang đứng yên.'],
      ['Trên đồ thị s – t của một vật chuyển động đều, tại thời điểm t = 4 s vật đi được quãng đường s = 12 m. Tốc độ của vật theo đơn vị m/s là:', ['2 m/s.', '3 m/s.', '4 m/s.', '6 m/s.'], 1, 'v = s / t = 12 / 4 = 3 m/s.'],
      ['Một vật chuyển động đều với tốc độ 3 m/s. Thời gian để vật đi được quãng đường 18 m là:', ['2 s.', '4 s.', '6 s.', '8 s.'], 2, 't = s / v = 18 / 3 = 6 s.'],
      ['Một vật chuyển động đều với tốc độ 3 m/s. Trong 2 s đầu vật đi được quãng đường là:', ['6 m.', '12 m.', '6 km.', '1,5 m.'], 0, 's = v · t = 3 × 2 = 6 m.'],
      ['Một vật chuyển động đều với tốc độ 3 m/s. Để đi được quãng đường 24 m thì vật cần thời gian bao lâu?', ['2 s.', '4 s.', '6 s.', '8 s.'], 3, 't = s / v = 24 / 3 = 8 s.'],
      ['Một vật có tốc độ 3 m/s. Khi tính theo đơn vị km/h thì tốc độ của vật là:', ['0,833 km/h.', '12 km/h.', '10,8 km/h.', '1,2 km/h.'], 2, 'v = 3 × 3,6 = 10,8 km/h.'],
      ['Với tốc độ 3 m/s (tương đương 10,8 km/h), trong mỗi phút vật chuyển động được quãng đường là:', ['3 m.', '30 m.', '180 m.', '10,8 km.'], 2, 'Trong 1 phút (60 s), quãng đường đi được là s = 3 × 60 = 180 m.'],
      ['Đồ thị quãng đường – thời gian của một xe đạp gồm 3 đoạn: Đoạn OA từ t = 0 đến t = 1h đi từ s = 0 đến s = 15 km; Đoạn AB từ t = 1h đến t = 1,5h giữ nguyên ở s = 15 km; Đoạn BC từ t = 1,5h đến t = 2,5h đi từ s = 15 km đến s = 25 km. Quãng đường xe đi trong 1 giờ đầu là:', ['5 km.', '15 km.', '20 km.', '25 km.'], 1, 'Tại t = 1 h (điểm A), quãng đường s = 15 km.'],
      ['Dựa vào đồ thị xe đạp ở câu 16, thời gian xe đạp dừng lại nghỉ trong hành trình (đoạn AB) là:', ['1 h.', '1,5 h.', '0,5 h (30 phút).', '2 h.'], 2, 'Đoạn nằm ngang AB kéo dài từ t = 1 h đến t = 1,5 h ⇒ thời gian nghỉ = 1,5 - 1 = 0,5 h.'],
      ['Dựa vào đồ thị xe đạp ở câu 16, tổng thời gian xe đạp đi hết 25 km (kể cả thời gian dừng nghỉ) là:', ['1 h.', '2 h.', '2,5 h.', '3 h.'], 2, 'Điểm C ứng với s = 25 km có hoành độ t = 2,5 h.'],
      ['Dựa vào đồ thị xe đạp ở câu 16, tốc độ của xe đạp trên đoạn đường đầu OA là:', ['10 km/h.', '15 km/h.', '15,5 km/h.', '20 km/h.'], 1, 'Trên đoạn OA: s₁ = 15 km, t₁ = 1 h ⇒ v_OA = 15 / 1 = 15 km/h.'],
      ['Dựa vào đồ thị xe đạp ở câu 16, độ dài đoạn đường BC và thời gian đi trên đoạn BC lần lượt là:', ['10 km và 1 h.', '25 km và 1 h.', '10 km và 1,5 h.', '15 km và 1 h.'], 0, 'Độ dài đoạn BC: s_BC = 25 - 15 = 10 km; Thời gian đi đoạn BC: t_BC = 2,5 - 1,5 = 1 h.'],
      ['Dựa vào đồ thị xe đạp ở câu 16, tốc độ của xe đạp trên đoạn BC là:', ['5 km/h.', '10 km/h.', '15 km/h.', '20 km/h.'], 1, 'v_BC = s_BC / t_BC = 10 / 1 = 10 km/h.'],
      ['So sánh chuyển động của xe đạp trên đoạn OA và đoạn BC ở câu 16, nhận xét nào sau đây là ĐÚNG?', ['Tốc độ trên đoạn OA (15 km/h) lớn hơn tốc độ trên đoạn BC (10 km/h).', 'Tốc độ trên đoạn OA nhỏ hơn tốc độ trên đoạn BC.', 'Xe chuyển động với tốc độ không đổi trên cả 3 đoạn.', 'Trên đoạn AB xe chạy nhanh nhất.'], 0, 'v_OA = 15 km/h > v_BC = 10 km/h (đường OA dốc hơn đường BC).'],
      ['Trên cùng một hệ trục tọa độ s – t, đường biểu diễn (1) của mô tô nằm dốc đứng hơn đường biểu diễn (2) của xe đạp. Điều này chứng tỏ:', ['Xe đạp chuyển động nhanh hơn mô tô.', 'Mô tô có tốc độ lớn hơn xe đạp.', 'Hai xe có cùng tốc độ.', 'Mô tô đang đứng yên.'], 1, 'Trên cùng hệ trục s – t, đường biểu diễn nào có độ dốc lớn hơn thì vật đó có tốc độ lớn hơn.'],
      ['Một con chuột chuyển động theo đồ thị: Từ t = 0 đến t = 1s đi được 2 m (đoạn OA); từ t = 1s đến t = 2s đi từ 2 m đến 6 m (đoạn AB); từ t = 2s đến t = 3s đứng yên ở 6 m (đoạn BC); từ t = 3s đến t = 4,5s đi từ 6 m đến 10 m (đoạn CD). Tốc độ trên đoạn OA là:', ['1,2 m/s.', '2 m/s (tương đương 7,2 km/h).', '3,6 km/h.', '4 m/s.'], 1, 'Trên đoạn OA: v_OA = 2 m / 1 s = 2 m/s = 7,2 km/h.'],
      ['Dựa vào đồ thị con chuột ở câu 24, thời gian con chuột dừng lại trên đoạn BC là:', ['1 s.', '1,5 s.', '0,5 s.', '2 s.'], 0, 'Đoạn BC nằm ngang từ t = 2 s đến t = 3 s ⇒ dừng lại 3 - 2 = 1 s.'],
      ['Dựa vào đồ thị con chuột ở câu 24, tốc độ của con chuột trên đoạn AB (từ t = 1s đến t = 2s, quãng đường từ 2 m lên 6 m) là:', ['1 m/s.', '2 m/s.', '3 m/s.', '4 m/s.'], 3, 's_AB = 6 - 2 = 4 m; t_AB = 2 - 1 = 1 s ⇒ v_AB = 4 / 1 = 4 m/s.'],
      ['Dựa vào đồ thị con chuột ở câu 24, tốc độ của con chuột trên đoạn CD (từ t = 3s đến t = 4,5s, quãng đường từ 6 m lên 10 m) tính ra km/h là:', ['2,67 km/h.', '9,6 m/s.', '9,6 km/h.', '10,8 km/h.'], 2, 's_CD = 10 - 6 = 4 m; t_CD = 4,5 - 3 = 1,5 s ⇒ v_CD = 4 / 1,5 m/s = (4 / 1,5) × 3,6 = 9,6 km/h.'],
      ['Một con rái cá bơi trên sông được 100 m trong 40 s đầu, sau đó thả mình trôi theo dòng nước thêm 50 m trong 40 s tiếp theo. Tốc độ bơi của rái cá trong 40 s đầu và tốc độ dòng nước lần lượt là:', ['2,5 m/s và 1,25 m/s.', '2,5 m/s và 2,5 m/s.', '4 m/s và 2 m/s.', '1,25 m/s và 2,5 m/s.'], 0, 'v₁ = 100 / 40 = 2,5 m/s; v_nước = 50 / 40 = 1,25 m/s.'],
      ['Một người đi xe đạp đi được s₁ = 10 km với tốc độ 14,28 km/h (hết 0,7 h), sau đó dừng lại sửa xe trong 48 phút (0,8 h), rồi đi tiếp s₂ = 15 km với tốc độ 10 km/h (hết 1,5 h). Tốc độ trung bình trên cả quãng đường (kể cả thời gian nghỉ) là:', ['10 km/h.', '8,33 km/h.', '12,5 km/h.', '9,5 km/h.'], 1, 'Tổng quãng đường s = 10 + 15 = 25 km. Tổng thời gian t = 0,7 + 0,8 + 1,5 = 3 h ⇒ v_tb = 25 / 3 ≈ 8,33 km/h.'],
      ['Hai xe xuất phát trên cùng một trục đường: Xe đạp xuất phát tại vị trí cách gốc O là 40 km với tốc độ 20 km/h; Mô tô xuất phát từ gốc O (s = 0) lúc t = 0 với tốc độ 60 km/h đuổi theo xe đạp. Hai đường đồ thị cắt nhau tại thời điểm t bằng bao nhiêu?', ['t = 0,5 h.', 't = 1 h (tại vị trí cách O là 60 km).', 't = 1,5 h.', 't = 2 h.'], 1, 'Sau t = 1 h, mô tô đi được s₁ = 60 × 1 = 60 km; xe đạp ở vị trí s₂ = 40 + 20 × 1 = 60 km ⇒ Hai xe gặp nhau sau 1 giờ.'],
    ]),
    trueFalseList: [
      {
        id: 'b10-tf-1',
        stem: 'Xét cách đọc và phân tích hình dạng đồ thị quãng đường – thời gian (s – t):',
        statements: [
          { id: 'a', text: 'Trục thẳng đứng (trục tung Os) biểu diễn độ dài quãng đường đi được theo một tỉ lệ thích hợp.', isTrue: true, explanation: 'Đúng quy ước vẽ trục tung Os.' },
          { id: 'b', text: 'Trục nằm ngang (trục hoành Ot) biểu diễn thời gian chuyển động theo một tỉ lệ thích hợp.', isTrue: true, explanation: 'Đúng quy ước vẽ trục hoành Ot.' },
          { id: 'c', text: 'Nếu đường biểu diễn trên đồ thị s – t là đường thẳng nằm ngang song song với trục Ot thì vật đang chuyển động đều với tốc độ rất lớn.', isTrue: false, explanation: 'Sai, đường thẳng song song với trục Ot cho biết quãng đường không tăng theo thời gian, tức là vật đang đứng yên (v = 0).' },
          { id: 'd', text: 'Trên cùng một đồ thị s – t, đoạn thẳng nào có độ dốc lớn hơn thì giai đoạn đó vật chuyển động với tốc độ lớn hơn.', isTrue: true, explanation: 'Đúng vì độ dốc (s / t) chính là tốc độ chuyển động.' },
        ],
      },
      {
        id: 'b10-tf-2',
        stem: 'Cho bảng ghi quãng đường đi được theo thời gian của một người đi bộ: t = 0s → s = 0m; t = 10s → s = 12m; t = 20s → s = 24m; t = 30s → s = 36m; t = 40s → s = 48m; t = 50s → s = 60m:',
        statements: [
          { id: 'a', text: 'Trong mỗi khoảng thời gian 10 giây, người đi bộ đều đi được quãng đường như nhau là 12 m.', isTrue: true, explanation: 'Đúng, cứ 10 s quãng đường lại tăng thêm 12 m.' },
          { id: 'b', text: 'Đồ thị quãng đường – thời gian của người đi bộ này là một đường thẳng đi qua gốc tọa độ O.', isTrue: true, explanation: 'Đúng vì chuyển động đều xuất phát từ O(0, 0).' },
          { id: 'c', text: 'Tốc độ đi bộ của người này là 1,2 m/s.', isTrue: true, explanation: 'Đúng, v = 12 / 10 = 1,2 m/s.' },
          { id: 'd', text: 'Khi đổi sang đơn vị km/h, tốc độ của người đi bộ là 12 km/h.', isTrue: false, explanation: 'Sai, 1,2 m/s = 1,2 × 3,6 = 4,32 km/h.' },
        ],
      },
      {
        id: 'b10-tf-3',
        stem: 'Bảng số liệu ghi lại quãng đường đi được của hai học sinh A và B bằng xe đạp: tại t = 5 min (s_A = 1 km, s_B = 0,5 km); tại t = 10 min (s_A = 2 km, s_B = 1 km); tại t = 20 min (s_A = 4 km, s_B = 2 km):',
        statements: [
          { id: 'a', text: 'Cả hai học sinh A và B đều chuyển động với tốc độ không đổi.', isTrue: true, explanation: 'Đúng vì quãng đường tỉ lệ thuận với thời gian.' },
          { id: 'b', text: 'Tốc độ của học sinh A là 12 km/h.', isTrue: true, explanation: 'Đúng, trong 20 phút (1/3 giờ) học sinh A đi được 4 km ⇒ v_A = 4 / (1/3) = 12 km/h.' },
          { id: 'c', text: 'Tốc độ của học sinh B là 6 km/h.', isTrue: true, explanation: 'Đúng, v_B = 2 / (1/3) = 6 km/h.' },
          { id: 'd', text: 'Trên cùng một hệ trục tọa độ s – t, đường biểu diễn của học sinh B nằm cao hơn (dốc hơn) đường biểu diễn của học sinh A.', isTrue: false, explanation: 'Sai, vì v_A > v_B nên đường biểu diễn của học sinh A nằm cao hơn và dốc hơn.' },
        ],
      },
      {
        id: 'b10-tf-4',
        stem: 'Đồ thị quãng đường – thời gian của một con mèo gồm 4 giai đoạn: (1) Từ 0s đến 2s đi từ 0m đến 4m; (2) Từ 2s đến 4s giữ nguyên ở 4m; (3) Từ 4s đến 6s đi từ 4m đến 8m; (4) Từ 6s đến 8s đi từ 8m đến 10m:',
        statements: [
          { id: 'a', text: 'Sau 6 s kể từ lúc xuất phát, con mèo đi được quãng đường là 8 m.', isTrue: true, explanation: 'Đúng, tại t = 6 s thì s = 8 m.' },
          { id: 'b', text: 'Ở giai đoạn (2) từ giây thứ 2 đến giây thứ 4, con mèo đang đứng yên (dừng lại trong 2 giây).', isTrue: true, explanation: 'Đúng vì s không đổi (giữ nguyên ở 4 m).' },
          { id: 'c', text: 'Tốc độ của con mèo ở giai đoạn (1) và giai đoạn (3) bằng nhau và đều bằng 2 m/s.', isTrue: true, explanation: 'Đúng: v₁ = 4 / 2 = 2 m/s; v₃ = (8 - 4) / (6 - 4) = 4 / 2 = 2 m/s.' },
          { id: 'd', text: 'Ở giai đoạn (4) từ giây thứ 6 đến giây thứ 8, con mèo chạy nhanh nhất.', isTrue: false, explanation: 'Sai, ở giai đoạn (4) tốc độ v₄ = (10 - 8) / (8 - 6) = 1 m/s (chậm hơn giai đoạn 1 và 3).' },
        ],
      },
      {
        id: 'b10-tf-5',
        stem: 'Lúc 1 giờ chiều, một đoàn tàu hỏa chạy từ ga A đến ga B với tốc độ 60 km/h, đến ga B lúc 2 giờ chiều và dừng ở ga B trong 30 phút, sau đó tiếp tục chạy với tốc độ 60 km/h đến ga C lúc 3 giờ 30 phút:',
        statements: [
          { id: 'a', text: 'Khoảng cách từ ga A đến ga B là 60 km.', isTrue: true, explanation: 'Đúng, tàu chạy từ 1h đến 2h (1 giờ) với tốc độ 60 km/h nên s_AB = 60 km.' },
          { id: 'b', text: 'Từ 2 giờ đến 2 giờ 30 phút, đường biểu diễn trên đồ thị s – t là đoạn thẳng nằm ngang ở mức s = 60 km.', isTrue: true, explanation: 'Đúng vì tàu dừng ở ga B trong 30 phút.' },
          { id: 'c', text: 'Tổng quãng đường từ ga A đến ga C là 120 km.', isTrue: true, explanation: 'Đúng, từ 2h30 đến 3h30 (1 giờ) tàu đi thêm 60 km nữa ⇒ tổng s = 120 km.' },
          { id: 'd', text: 'Tốc độ trung bình của đoàn tàu trên toàn bộ hành trình từ A đến C (kể cả thời gian dừng ở ga B) là 60 km/h.', isTrue: false, explanation: 'Sai, tổng thời gian cả nghỉ là 2,5 h ⇒ tốc độ trung bình = 120 / 2,5 = 48 km/h.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b10-es-1',
        question: 'Câu 1 [Tài liệu Chủ đề Tốc độ]: Nêu đầy đủ 4 bước vẽ đồ thị quãng đường – thời gian (s – t) từ bảng số liệu thực nghiệm và cho biết ý nghĩa của đồ thị s – t.',
        hint: 'Trình bày lần lượt Bước 1 (Bảng ghi) → Bước 2 (Vẽ hệ trục Os, Ot) → Bước 3 (Xác định điểm) → Bước 4 (Nối điểm).',
        sampleAnswer: '- Các bước vẽ đồ thị quãng đường – thời gian:\n+ Bước 1: Lập bảng ghi quãng đường s đi được theo thời gian t.\n+ Bước 2: Vẽ hai tia Os và Ot vuông góc với nhau tại gốc O (gọi là 2 trục tọa độ): Trục thẳng đứng Os biểu diễn quãng đường s, trục nằm ngang Ot biểu diễn thời gian t theo tỉ lệ thích hợp.\n+ Bước 3: Xác định các điểm biểu diễn cặp giá trị (t, s) tương ứng trong bảng số liệu.\n+ Bước 4: Nối các điểm đã xác định lại với nhau thành đường biểu diễn.\n- Ý nghĩa: Từ đồ thị s – t ta tìm được quãng đường s khi biết thời gian t (và ngược lại), đồng thời xác định được tốc độ v và trạng thái đứng yên hay chuyển động của vật.',
        rubricPoints: [
          'Nêu đầy đủ và đúng thứ tự 4 bước vẽ đồ thị s – t.',
          'Nêu đúng ý nghĩa của đồ thị s – t (tìm s, t, v).',
        ],
      },
      {
        id: 'b10-es-2',
        question: 'Câu 2 [Tài liệu Chủ đề Tốc độ]: Bảng số liệu ghi lại quãng đường đi được theo thời gian của hai học sinh A và B đi xe đạp như sau:\n- Tại t = 0 min: s_A = 0 km; s_B = 0 km.\n- Tại t = 5 min: s_A = 1 km; s_B = 0,5 km.\n- Tại t = 10 min: s_A = 2 km; s_B = 1,0 km.\n- Tại t = 15 min: s_A = 3 km; s_B = 1,5 km.\n- Tại t = 20 min: s_A = 4 km; s_B = 2,0 km.\n(a) Hãy mô tả hình dạng đường biểu diễn đồ thị s – t của hai học sinh (hoặc vẽ ra giấy và chụp ảnh đính kèm).\n(b) Tính tốc độ của mỗi học sinh theo đơn vị km/min và km/h.',
        hint: 'Đổi 1 phút = 1/60 giờ khi tính tốc độ ra km/h.',
        sampleAnswer: '(a) Đồ thị s – t của cả hai học sinh A và B đều là đường thẳng đi qua gốc tọa độ O(0, 0). Đường biểu diễn của học sinh A đi qua điểm (20 min; 4 km) nằm cao hơn và dốc hơn đường của học sinh B đi qua điểm (20 min; 2 km).\n(b) Tính tốc độ:\n- Học sinh A: v_A = s_A / t = 4 km / 20 min = 0,2 km/min = 0,2 × 60 = 12 km/h.\n- Học sinh B: v_B = s_B / t = 2 km / 20 min = 0,1 km/min = 0,1 × 60 = 6 km/h.',
        rubricPoints: [
          'Mô tả hoặc vẽ đúng 2 đường thẳng đi qua gốc O, đường A dốc gấp đôi đường B.',
          'Tính đúng v_A = 12 km/h và v_B = 6 km/h.',
        ],
      },
      {
        id: 'b10-es-3',
        question: 'Câu 3 [Tài liệu Chủ đề Tốc độ]: Một con rái cá bơi trên một dòng sông được quãng đường 100 m trong 40 s đầu, sau đó nó thả mình trôi theo dòng nước thêm 50 m trong 40 s tiếp theo.\n(a) Tính tốc độ bơi của rái cá trong 40 s đầu và tốc độ của dòng nước.\n(b) Nêu tọa độ các điểm mốc để vẽ đồ thị quãng đường – thời gian của rái cá trong cả 80 s.',
        hint: 'Xác định tọa độ tại t = 0 s, t = 40 s và t = 80 s.',
        sampleAnswer: '(a) Tính tốc độ:\n- Tốc độ bơi của rái cá trong 40 s đầu: v₁ = s₁ / t₁ = 100 / 40 = 2,5 m/s.\n- Khi thả mình trôi theo dòng nước, tốc độ của rái cá bằng tốc độ dòng nước: v₂ = s₂ / t₂ = 50 / 40 = 1,25 m/s.\n(b) Đồ thị gồm 2 đoạn thẳng nối tiếp qua 3 điểm mốc:\n- Điểm gốc O(0 s; 0 m).\n- Điểm A(40 s; 100 m) — đoạn OA có độ dốc lớn hơn.\n- Điểm B(80 s; 150 m) — đoạn AB ít dốc hơn đoạn OA.',
        rubricPoints: [
          'Tính đúng v₁ = 2,5 m/s và v₂ = 1,25 m/s.',
          'Xác định đúng 3 điểm mốc O(0; 0), A(40; 100) và B(80; 150).',
        ],
      },
      {
        id: 'b10-es-4',
        question: 'Câu 4 [Tài liệu Chủ đề Tốc độ]: Một người đi xe đạp, sau khi đi được s₁ = 10 km với tốc độ v₁ = 14,28 km/h thì dừng lại để sửa xe và nghỉ ngơi trong 48 phút, sau đó đi tiếp s₂ = 15 km với tốc độ v₂ = 10 km/h.\n(a) Tính thời gian đi trên mỗi chặng và thời gian nghỉ ra đơn vị giờ.\n(b) Xác định tốc độ trung bình của người đi xe đạp trên cả quãng đường (kể cả thời gian sửa xe).',
        hint: 'Tính t₁ = s₁ / v₁; đổi t₂ = 48 phút ra giờ; t₃ = s₂ / v₂.',
        sampleAnswer: '(a) Thời gian trên từng giai đoạn:\n- Thời gian đi 10 km đầu: t₁ = s₁ / v₁ = 10 / 14,28 ≈ 0,7 h.\n- Thời gian dừng sửa xe: t₂ = 48 phút = 48 / 60 = 0,8 h (lúc này t = 0,7 + 0,8 = 1,5 h).\n- Thời gian đi 15 km tiếp theo: t₃ = s₂ / v₂ = 15 / 10 = 1,5 h (kết thúc lúc t = 3,0 h).\n(b) Tổng quãng đường: s = 10 + 15 = 25 km.\nTổng thời gian: t = 0,7 + 0,8 + 1,5 = 3,0 giờ.\nTốc độ trung bình trên cả quãng đường là: v_tb = s / t = 25 / 3 ≈ 8,33 km/h.',
        rubricPoints: [
          'Tính đúng t₁ = 0,7 h; t₂ = 0,8 h; t₃ = 1,5 h.',
          'Tính đúng tốc độ trung bình v_tb = 25 / 3 ≈ 8,33 km/h.',
        ],
      },
      {
        id: 'b10-es-5',
        question: 'Câu 5 [Tài liệu Chủ đề Tốc độ]: Đồ thị quãng đường – thời gian của một con mèo gồm 4 giai đoạn nối tiếp qua các điểm: O(0s; 0m) → A(2s; 4m) → B(4s; 4m) → C(6s; 8m) → D(8s; 10m).\n(a) Mô tả trạng thái chuyển động của con mèo ở từng giai đoạn (1), (2), (3), (4).\n(b) Tính tốc độ của con mèo trong từng giai đoạn.',
        hint: 'Lấy hiệu quãng đường Δs chia cho hiệu thời gian Δt của từng đoạn.',
        sampleAnswer: '(a) Mô tả các giai đoạn:\n- Giai đoạn (1) từ 0s đến 2s: Con mèo chuyển động đều.\n- Giai đoạn (2) từ 2s đến 4s: Con mèo đứng yên (dừng lại trong 2 giây).\n- Giai đoạn (3) từ 4s đến 6s: Con mèo tiếp tục chuyển động đều.\n- Giai đoạn (4) từ 6s đến 8s: Con mèo chuyển động đều chậm lại.\n(b) Tốc độ trên từng giai đoạn:\n- v₁ = 4 / 2 = 2 m/s.\n- v₂ = (4 - 4) / (4 - 2) = 0 m/s.\n- v₃ = (8 - 4) / (6 - 4) = 4 / 2 = 2 m/s.\n- v₄ = (10 - 8) / (8 - 6) = 2 / 2 = 1 m/s.',
        rubricPoints: [
          'Mô tả đúng 4 giai đoạn (trong đó giai đoạn 2 đứng yên 2 giây).',
          'Tính đúng tốc độ: v₁ = 2 m/s; v₂ = 0 m/s; v₃ = 2 m/s; v₄ = 1 m/s.',
        ],
      },
      {
        id: 'b10-es-6',
        question: 'Câu 6 [Tài liệu Chủ đề Tốc độ]: Trên cùng một đồ thị s – t của một người đi xe đạp và một người đi mô tô (biết mô tô nhanh hơn xe đạp): Đường (1) đi từ gốc O(0h; 0km) tới điểm M(1h; 60km); Đường (2) đi từ điểm K(0h; 40km) tới cùng điểm M(1h; 60km).\n(a) Đường biểu diễn nào ứng với xe đạp, đường nào ứng với mô tô?\n(b) Tính tốc độ của mỗi xe và cho biết sau bao lâu kể từ lúc xuất phát thì hai xe gặp nhau?',
        hint: 'Tại điểm giao nhau M(1h; 60km), hai xe có cùng vị trí và thời điểm.',
        sampleAnswer: '(a) Vì mô tô chuyển động nhanh hơn xe đạp nên đường (1) có độ dốc lớn hơn là của mô tô; đường (2) ít dốc hơn là của xe đạp.\n(b) Tính tốc độ:\n- Tốc độ của mô tô (đi từ 0 km đến 60 km trong 1 h): v₁ = 60 / 1 = 60 km/h.\n- Tốc độ của xe đạp (đi từ mốc 40 km đến 60 km trong 1 h): v₂ = (60 - 40) / 1 = 20 km/h.\n- Hai đường biểu diễn cắt nhau tại điểm M(1h; 60km), vậy hai xe gặp nhau sau 1 giờ kể từ lúc xuất phát (tại vị trí cách O là 60 km).',
        rubricPoints: [
          'Xác định đúng đường (1) là mô tô, đường (2) là xe đạp.',
          'Tính đúng v_mô_tô = 60 km/h, v_xe_đạp = 20 km/h và thời gian gặp nhau là sau 1 giờ.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 12: SÓNG ÂM (Tài liệu Chủ đề Âm thanh - Phần A)
  // =========================================================================
  {
    id: 'kntt-bai-12',
    lessonNumber: 12,
    title: 'Bài 12: Sóng âm',
    chapterTitle: 'Chương IV: Âm thanh',
    subject: 'physics',
    pdfUrl: '/assets/aistudio/Ch______m_Thanh_4881f43f.pdf',
    summary:
      'Vật dao động phát ra âm thanh được gọi là nguồn âm. Dao động từ nguồn âm lan truyền trong môi trường (rắn, lỏng, khí) tạo thành sóng âm. Sóng âm không truyền được trong chân không. Tốc độ truyền âm: v_rắn > v_lỏng > v_khí.',
    keyFormulas: [
      'Điều kiện phát ra âm: Vật phải dao động (rung động qua lại quanh vị trí cân bằng)',
      'Tốc độ truyền âm ở 20°C: Không khí ≈ 343 m/s (hoặc 340 m/s)  |  Nước ≈ 1482 m/s (hoặc 1500 m/s)  |  Thép ≈ 6100 m/s',
      'Quy luật tốc độ truyền âm:  v_rắn > v_lỏng > v_khí  ⇒  Thời gian truyền cùng quãng đường:  t_rắn < t_lỏng < t_khí',
    ],
    mcqs: makeMcqs('b12', [
      ['Trong các trường hợp dưới đây, vật phát ra âm thanh khi nào?', ['Khi vật chuyển động thẳng đều.', 'Khi vật đứng yên trên bàn.', 'Khi vật bị uốn cong.', 'Khi vật dao động.'], 3, 'Mọi nguồn âm khi phát ra âm thanh đều dao động.'],
      ['Vật nào sau đây được gọi là nguồn âm?', ['Cây súng để trong tủ.', 'Cái trống để ngoài sân.', 'Cái còi trọng tài đang được thổi.', 'Chiếc âm thoa đặt trên bàn.'], 2, 'Cái còi đang được thổi có luồng khí và viên bi bên trong dao động phát ra âm thanh nên là nguồn âm.'],
      ['Phát biểu nào sau đây KHÔNG đúng khi nói về sóng âm?', ['Dao động từ nguồn âm lan truyền trong môi trường tạo ra sóng âm.', 'Sóng âm được phát ra bởi các vật đang dao động.', 'Sóng âm không truyền được trong chân không.', 'Sóng âm chỉ truyền được trong môi trường chất khí.'], 3, 'Sóng âm truyền được trong cả 3 môi trường: chất rắn, chất lỏng và chất khí.'],
      ['Trường hợp nào sau đây đều là nguồn âm?', ['Nước suối đang chảy róc rách, mặt trống đang được gõ, ống sáo đang được thổi.', 'Cây đàn treo trên tường, cái trống để ngoài sân.', 'Chiếc còi cầm trên tay chưa thổi.', 'Quyển sách nằm yên trên mặt bàn.'], 0, 'Cả 3 vật đều đang dao động và phát ra âm thanh.'],
      ['Chuyển động như thế nào được gọi là dao động?', ['Chuyển động theo một vòng tròn một chiều như kim đồng hồ.', 'Chuyển động của vật được ném thẳng lên cao.', 'Sự rung động (chuyển động lặp đi lặp lại nhiều lần) qua lại quanh vị trí cân bằng.', 'Chuyển động thẳng đều trên đường.'], 2, 'Dao động là sự chuyển động qua lại quanh một vị trí cân bằng.'],
      ['Kéo căng sợi dây cao su rồi dùng tay bật sợi dây cao su đó, ta nghe thấy âm thanh. Nguồn âm là:', ['sợi dây cao su đang dao động.', 'bàn tay người.', 'mặt bàn.', 'đôi tai người nghe.'], 0, 'Sợi dây cao su dao động qua lại quanh vị trí cân bằng và phát ra âm thanh.'],
      ['Khi thổi sáo ta nghe thấy tiếng sáo, bộ phận dao động chính đóng vai trò nguồn âm là:', ['các ngón tay của người thổi.', 'đôi môi của người thổi.', 'cột không khí bên trong ống sáo.', 'vỏ ngoài của ống sáo.'], 2, 'Khi thổi sáo, cột không khí trong ống sáo dao động phát ra âm thanh.'],
      ['Dùng búa gõ xuống mặt bàn, ta nghe thấy âm thanh. Khi đó:', ['mặt bàn không dao động vì ta thấy nó đứng yên.', 'mặt bàn là nguồn âm vì mặt bàn dao động rất nhanh mà mắt thường khó nhận thấy.', 'chỉ có chiếc búa dao động.', 'âm thanh tự sinh ra không cần dao động.'], 1, 'Mặt bàn dao động rất nhanh với biên độ nhỏ tạo ra âm thanh.'],
      ['Khi nghe đài radio, âm thanh phát ra trực tiếp từ bộ phận nào?', ['Từ chiếc loa có màng loa đang dao động.', 'Từ phát thanh viên ngồi trong chiếc đài.', 'Từ nút vặn chỉnh âm lượng.', 'Từ cục pin bên trong đài.'], 0, 'Màng loa của chiếc đài dao động làm lớp không khí tiếp xúc dao động truyền sóng âm tới tai.'],
      ['Khi bay, một số côn trùng như ong, muỗi tạo ra tiếng “vo ve” là vì:', ['chúng vừa bay vừa hát bằng miệng.', 'hơi thở của chúng rất mạnh.', 'đôi cánh của chúng vẫy (dao động) rất nhanh tạo ra sóng âm.', 'chân của chúng va vào nhau.'], 2, 'Đôi cánh của ong, muỗi vẫy hàng trăm lần mỗi giây tạo ra dao động âm.'],
      ['Khi áp tai vào một vỏ ốc biển, ta thường nghe thấy tiếng rì rào như sóng biển. Nguyên nhân là do:', ['dao động của vành tai.', 'dao động cộng hưởng của cột không khí bên trong vỏ ốc.', 'trong vỏ ốc có nước biển đang chảy.', 'vỏ ốc tự phát sáng và phát âm.'], 1, 'Không khí bên trong khoang vỏ ốc dao động cộng hưởng với các âm thanh môi trường xung quanh.'],
      ['Người ta chọn kim loại có tính đàn hồi tốt để chế tạo âm thoa vì:', ['làm cho âm thoa bóng đẹp hơn.', 'giúp âm thoa có thể dao động lâu hơn và ổn định hơn sau khi gõ.', 'làm cho âm thoa không bị dao động.', 'giúp âm thoa nhẹ hơn.'], 1, 'Tính đàn hồi tốt giúp nhánh âm thoa duy trì dao động lâu hơn để thực hiện thí nghiệm.'],
      ['Khi trời mưa dông, có tia sét đánh qua, vật nào đã dao động phát ra tiếng sấm?', ['Các đám mây va đập vào nhau.', 'Lớp không khí xung quanh tia lửa điện bị đốt nóng dãn nở đột ngột tạo ra dao động sóng xung kích.', 'Các hạt mưa va vào nhau.', 'Ánh sáng của tia chớp dao động.'], 1, 'Tia sét làm không khí xung quanh nóng lên hàng chục nghìn độ và dãn nở đột ngột phát ra sóng âm cực mạnh (tiếng sấm).'],
      ['Hộp đàn (thùng đàn) trong đàn guitar, đàn bầu, đàn violon có tác dụng chủ yếu là:', ['tạo kiểu dáng trang trí cho đàn.', 'cộng hưởng và khuếch đại âm thanh do dây đàn phát ra.', 'để cất giữ dây đàn dự phòng.', 'giúp dây đàn không bị đứt.'], 1, 'Hộp đàn giúp cộng hưởng và khuếch đại âm thanh làm tiếng đàn nghe to và vang hơn.'],
      ['Sóng âm có thể truyền được trong các môi trường nào sau đây?', ['Chỉ truyền được trong chất lỏng.', 'Chỉ truyền được trong chất khí.', 'Chỉ truyền được trong chất rắn.', 'Truyền được trong cả chất rắn, chất lỏng và chất khí.'], 3, 'Sóng âm truyền được trong các môi trường vật chất rắn, lỏng, khí.'],
      ['Sóng âm KHÔNG thể truyền được trong môi trường nào dưới đây?', ['Chất rắn (thép, gỗ).', 'Chất lỏng (nước biển).', 'Chất khí (không khí).', 'Chân không.'], 3, 'Chân không không có các hạt vật chất nên không thể truyền dao động sóng âm.'],
      ['Phát biểu nào sau đây là ĐÚNG khi so sánh sự truyền âm trong các môi trường?', ['Khi không khí càng loãng thì âm truyền càng nhanh.', 'Chất rắn truyền âm kém hơn chất lỏng.', 'Trong 3 môi trường rắn, lỏng, khí thì chất khí truyền âm chậm nhất (kém nhất).', 'Sóng âm truyền nhanh nhất trong chân không.'], 2, 'Tốc độ truyền âm: v_rắn > v_lỏng > v_khí.'],
      ['Trong lớp học, học sinh nghe được tiếng giảng bài của thầy cô giáo chủ yếu thông qua môi trường truyền âm nào?', ['Không khí.', 'Bàn ghế gỗ.', 'Nước.', 'Chân không.'], 0, 'Sóng âm truyền từ dây thanh quản của giáo viên qua không khí trong lớp học đến tai học sinh.'],
      ['Tốc độ truyền âm trong các môi trường được sắp xếp theo thứ tự tăng dần là:', ['Rắn, lỏng, khí.', 'Lỏng, khí, rắn.', 'Khí, lỏng, rắn.', 'Rắn, khí, lỏng.'], 2, 'Thứ tự tăng dần: Chất khí < Chất lỏng < Chất rắn.'],
      ['Biết tốc độ truyền âm trong không khí là 343 m/s và trong nước là 1482 m/s. Tốc độ truyền âm trong thanh nhôm (chất rắn) ở cùng nhiệt độ có thể nhận giá trị nào sau đây?', ['340 m/s.', '170 m/s.', '6420 m/s.', '1400 m/s.'], 2, 'Nhôm là chất rắn nên tốc độ truyền âm phải lớn hơn trong nước (> 1482 m/s) ⇒ 6420 m/s.'],
      ['Vì sao khi càng lên núi cao, không khí càng loãng thì nói chuyện càng khó nghe rõ hơn ở đồng bằng?', ['Vì trên núi cao nhiệt độ thấp.', 'Vì không khí loãng (mật độ hạt khí giảm) nên môi trường truyền âm kém hơn.', 'Vì trên núi không có cây cối.', 'Vì trọng lực giảm.'], 1, 'Không khí càng loãng thì sự lan truyền dao động giữa các lớp không khí càng kém.'],
      ['Khi ta nói hoặc hát, bộ phận nào trong cơ thể người dao động trực tiếp phát ra âm thanh?', ['Đầu lưỡi.', 'Hàm răng.', 'Dây thanh đới trong thanh quản.', 'Vành tai.'], 2, 'Luồng không khí từ phổi đi lên làm các dây thanh đới trong thanh quản dao động phát ra tiếng nói.'],
      ['Trong không khí, sóng âm lan truyền từ nguồn âm đến tai người nghe dưới dạng:', ['các tia sáng thẳng.', 'sự dao động (dãn, nén) lan truyền của các lớp không khí.', 'dòng các hạt không khí bay thẳng từ nguồn âm vào tai.', 'sóng điện từ.'], 1, 'Sóng âm trong không khí là sự lan truyền các vùng không khí bị nén và dãn xen kẽ.'],
      ['Một người gõ mạnh búa xuống đường ray xe lửa tại điểm A làm âm thanh truyền trong đường ray thép đến điểm B cách A là 3050 m. Biết tốc độ truyền âm trong thép là 6100 m/s. Thời gian truyền âm trong đường ray từ A đến B là:', ['0,3 s.', '0,5 s.', '2,0 s.', '1,2 s.'], 1, 't = s / v = 3050 / 6100 = 0,5 giây.'],
      ['Gọi t₁, t₂, t₃ lần lượt là thời gian âm thanh truyền đi cùng một quãng đường trong các môi trường rắn, lỏng, khí. Hệ thức so sánh đúng là:', ['t₁ < t₂ < t₃.', 't₃ < t₂ < t₁.', 't₂ < t₁ < t₃.', 't₁ = t₂ = t₃.'], 0, 'Vì v_rắn > v_lỏng > v_khí và t = s / v nên thời gian truyền trong chất rắn là ngắn nhất: t₁ < t₂ < t₃.'],
      ['Khi lặn dưới hồ nước, một thợ lặn nghe được tiếng chuông đồng hồ đặt chìm trong nước sau 1/20 giây kể từ khi chuông reo. Biết tốc độ truyền âm trong nước là 1482 m/s. Khoảng cách từ đồng hồ đến người thợ lặn là:', ['34,1 m.', '17,0 m.', '74,1 m.', '148,2 m.'], 2, 's = v · t = 1482 × (1/20) = 74,1 m.'],
      ['Một đoàn tàu bắt đầu chuyển bánh trong ga. Một người ở cách ga 2 km áp tai vào đường ray thép thì sau bao lâu nghe thấy tiếng tàu chạy? Biết tốc độ truyền âm trong thép là 6100 m/s.', ['1,20 s.', '3,05 s.', '0,328 s.', '5,88 s.'], 2, 'Đổi s = 2 km = 2000 m ⇒ t = s / v = 2000 / 6100 ≈ 0,328 s.'],
      ['Khi nhai kẹo cứng giòn, bản thân ta nghe thấy tiếng động rất to và rõ, nhưng người ngồi bên cạnh lại hầu như không nghe thấy gì. Nguyên nhân là vì:', ['âm thanh truyền qua xương hàm, xương sọ (chất rắn) đến màng nhĩ rất tốt, còn truyền qua không khí sang người bên cạnh kém hơn.', 'kẹo giòn chỉ phát ra siêu âm.', 'tai người bên cạnh bị che khuất.', 'trong miệng không có không khí.'], 0, 'Xương hàm và xương sọ là chất rắn nên dẫn truyền âm thanh trực tiếp đến tai trong tốt hơn rất nhiều so với không khí.'],
      ['Hai bạn Vân và Trang nói chuyện qua một ống thép dài 268 m. Vân gõ búa một lần vào đầu ống, Trang áp tai vào đầu kia nghe thấy 2 tiếng gõ cách nhau một khoảng thời gian Δt. Biết v_kk = 340 m/s và v_thép = 2680 m/s. Giá trị Δt là:', ['0,10 s.', '0,79 s.', '0,69 s.', '0,89 s.'], 2, 't_thép = 268 / 2680 = 0,10 s; t_kk = 268 / 340 ≈ 0,79 s ⇒ Δt = 0,79 - 0,10 = 0,69 s.'],
      ['Vì sao ngày xưa các chiến sĩ trinh sát hoặc kỵ binh thường áp tai xuống mặt đất để phát hiện tiếng xe tăng hoặc tiếng vó ngựa từ xa?', ['Vì mặt đất yên tĩnh hơn không khí.', 'Vì đất đá là chất rắn truyền âm nhanh hơn và tốt hơn không khí rất nhiều.', 'Vì sóng âm không truyền được trong không khí ban đêm.', 'Để tránh gió thổi vào tai.'], 1, 'Chất rắn (đất đá) truyền âm nhanh và ít bị suy giảm hơn không khí nên nghe được âm thanh từ rất xa trước khi nghe qua không khí.'],
    ]),
    trueFalseList: [
      {
        id: 'b12-tf-1',
        stem: 'Xét bản chất của nguồn âm và sự tạo thành sóng âm:',
        statements: [
          { id: 'a', text: 'Mọi vật phát ra âm thanh đều dao động (rung động qua lại quanh vị trí cân bằng).', isTrue: true, explanation: 'Đúng tính chất chung của mọi nguồn âm.' },
          { id: 'b', text: 'Ba chiếc kim đồng hồ đang quay đều quanh trục là một nguồn âm đang dao động.', isTrue: false, explanation: 'Sai, kim đồng hồ quay tròn theo một chiều chứ không rung động qua lại quanh vị trí cân bằng.' },
          { id: 'c', text: 'Khi thổi sáo, nguồn âm chính phát ra tiếng sáo là cột không khí dao động bên trong ống sáo.', isTrue: true, explanation: 'Đúng cơ chế phát âm của nhạc cụ hơi (sáo, kèn).' },
          { id: 'd', text: 'Khi gảy đàn guitar hoặc đàn bầu, nguồn âm là dây đàn đang dao động.', isTrue: true, explanation: 'Đúng cơ chế phát âm của nhạc cụ dây.' },
        ],
      },
      {
        id: 'b12-tf-2',
        stem: 'Xét sự truyền sóng âm trong các môi trường khác nhau:',
        statements: [
          { id: 'a', text: 'Sóng âm truyền được trong các môi trường chất rắn, chất lỏng và chất khí.', isTrue: true, explanation: 'Đúng điều kiện môi trường truyền âm.' },
          { id: 'b', text: 'Trong chân không, sóng âm truyền đi với tốc độ nhanh nhất.', isTrue: false, explanation: 'Sai, sóng âm hoàn toàn không truyền được trong chân không.' },
          { id: 'c', text: 'Nói chung, tốc độ truyền âm trong chất rắn lớn hơn trong chất lỏng, và trong chất lỏng lớn hơn trong chất khí.', isTrue: true, explanation: 'Đúng quy luật v_rắn > v_lỏng > v_khí.' },
          { id: 'd', text: 'Các nhà du hành vũ trụ ngoài khoảng không vũ trụ (chân không) không thể nói chuyện trực tiếp với nhau mà phải dùng bộ đàm sóng vô tuyến.', isTrue: true, explanation: 'Đúng vì ngoài vũ trụ là chân không không truyền được âm thanh.' },
        ],
      },
      {
        id: 'b12-tf-3',
        stem: 'Bạn An lấy một ống thép dài 30,5 m và dùng búa gõ mạnh một lần vào một đầu ống, còn bạn Bình áp sát tai vào đầu kia của ống thép (biết v_kk = 340 m/s, v_thép = 6100 m/s):',
        statements: [
          { id: 'a', text: 'Bạn Bình sẽ nghe thấy 2 tiếng gõ liên tiếp nhau dù bạn An chỉ gõ 1 lần.', isTrue: true, explanation: 'Đúng vì âm truyền qua thép nhanh hơn đến tai trước, âm truyền qua không khí đến tai sau.' },
          { id: 'b', text: 'Tiếng gõ nghe thấy đầu tiên là âm truyền qua không khí, tiếng thứ hai là âm truyền qua ống thép.', isTrue: false, explanation: 'Sai, âm truyền qua thép nhanh gấp gần 18 lần trong không khí nên tiếng gõ qua thép đến tai trước.' },
          { id: 'c', text: 'Thời gian âm truyền qua ống thép là 0,005 giây.', isTrue: true, explanation: 'Đúng, t₁ = 30,5 / 6100 = 0,005 s.' },
          { id: 'd', text: 'Thời gian âm truyền qua không khí là khoảng 0,09 giây.', isTrue: true, explanation: 'Đúng, t₂ = 30,5 / 340 ≈ 0,0897 s ≈ 0,09 s.' },
        ],
      },
      {
        id: 'b12-tf-4',
        stem: 'Đặt một nguồn âm ngay trên mặt nước hồ. Một người đứng trên bờ cách nguồn âm 1,5 km (1500 m) và một người lặn ở dưới nước cũng cách nguồn âm 1,5 km (biết v_kk = 340 m/s, v_nước = 1500 m/s):',
        statements: [
          { id: 'a', text: 'Người ở dưới nước sẽ nghe thấy âm thanh trước người đứng trên bờ.', isTrue: true, explanation: 'Đúng vì tốc độ truyền âm trong nước (1500 m/s) lớn hơn trong không khí (340 m/s).' },
          { id: 'b', text: 'Thời gian âm thanh truyền trong nước tới tai người thợ lặn là 1 giây.', isTrue: true, explanation: 'Đúng, t_nước = 1500 / 1500 = 1 s.' },
          { id: 'c', text: 'Thời gian âm thanh truyền trong không khí tới tai người trên bờ xấp xỉ 4,41 giây.', isTrue: true, explanation: 'Đúng, t_kk = 1500 / 340 ≈ 4,41 s.' },
          { id: 'd', text: 'Hai người nghe thấy âm thanh cùng một lúc vì cách nguồn âm một khoảng bằng nhau (1,5 km).', isTrue: false, explanation: 'Sai, người dưới nước nghe thấy sớm hơn 3,41 giây.' },
        ],
      },
      {
        id: 'b12-tf-5',
        stem: 'Xét các hiện tượng âm thanh trong đời sống hàng ngày:',
        statements: [
          { id: 'a', text: 'Khi rót nước từ ấm ở độ cao lớn xuống cốc thì dòng nước đập mạnh làm mặt nước và không khí dao động mạnh nên phát ra tiếng kêu rõ.', isTrue: true, explanation: 'Đúng cơ chế tạo âm khi rót nước.' },
          { id: 'b', text: 'Khi để vòi ấm sát mặt nước trong cốc rồi rót nhẹ thì dòng nước không đủ làm mặt nước dao động mạnh nên hầu như không phát ra âm thanh.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Cây đàn guitar treo yên trên tường và cái trống để yên trong góc lớp đều là các nguồn âm.', isTrue: false, explanation: 'Sai, khi đứng yên không dao động thì chúng không phát ra âm nên chưa phải là nguồn âm.' },
          { id: 'd', text: 'Khi gõ vào thành cốc thủy tinh mỏng, thành cốc dao động phát ra âm thanh trong trẻo.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b12-es-1',
        question: 'Câu 1 [Tài liệu Chủ đề Âm thanh]: Hãy chỉ ra bộ phận dao động chính phát ra âm thanh trong các nguồn âm sau:\n(a) Đàn bầu và đàn guitar khi đang gảy.\n(b) Sáo trúc khi nghệ sĩ đang thổi.\n(c) Cồng chiêng và trống trường khi đang được gõ.\n(d) Con người khi đang nói hoặc hát.',
        hint: 'Xác định vật thể nào đang rung động qua lại quanh vị trí cân bằng.',
        sampleAnswer: '(a) Đàn bầu và đàn guitar: Dây đàn dao động phát ra âm thanh (hộp đàn giúp khuếch đại âm).\n(b) Sáo trúc: Cột không khí bên trong ống sáo dao động phát ra âm thanh.\n(c) Cồng chiêng và trống: Mặt chiêng và mặt trống dao động phát ra âm thanh.\n(d) Con người khi nói, hát: Luồng không khí từ phổi đi lên làm các dây thanh đới trong thanh quản dao động phát ra âm thanh.',
        rubricPoints: [
          'Nêu đúng dây đàn (a) và cột không khí trong ống sáo (b).',
          'Nêu đúng mặt chiêng/mặt trống (c) và dây thanh đới trong thanh quản (d).',
        ],
      },
      {
        id: 'b12-es-2',
        question: 'Câu 2 [Tài liệu Chủ đề Âm thanh]: Hãy giải thích tại sao cùng là rót nước từ ấm vào cốc nhưng khi rót từ trên cao xuống thì có âm thanh phát ra, còn khi để vòi ấm thật thấp (sát đáy cốc hoặc sát mặt nước trong cốc) thì hầu như không có âm thanh phát ra?',
        hint: 'Liên hệ lực va đập của dòng nước với sự dao động của mặt nước và không khí.',
        sampleAnswer: '- Khi rót nước từ trên cao xuống, dòng nước rơi nhanh và đập mạnh vào mặt nước (hoặc đáy cốc) làm cho nước và lớp không khí xung quanh dao động mạnh, từ đó phát ra âm thanh.\n- Ngược lại, khi để vòi ấm thật thấp sát mặt nước, dòng nước chảy êm và nhẹ, không đủ tạo ra va đập làm nước và không khí dao động nên hầu như không có âm thanh phát ra.',
        rubricPoints: [
          'Giải thích đúng trường hợp rót từ trên cao tạo va đập làm nước và không khí dao động.',
          'Giải thích đúng trường hợp để vòi thấp không tạo được dao động đáng kể.',
        ],
      },
      {
        id: 'b12-es-3',
        question: 'Câu 3 [Tài liệu Chủ đề Âm thanh]: Vân và Trang nói chuyện với nhau qua một ống thép dài 268 m. Vân gõ vào một đầu ống, Trang áp tai vào đầu kia nghe thấy âm thanh từ Vân truyền tới 2 lần cách nhau một khoảng thời gian Δt.\n(a) Giải thích vì sao Trang lại nghe thấy 2 tiếng gõ?\n(b) Tính khoảng thời gian Δt giữa hai lần nghe đó. Biết tốc độ truyền âm trong không khí là 340 m/s và trong thép là 2680 m/s.',
        hint: 'Tính thời gian truyền trong thép t₁ = 268 / 2680 và trong không khí t₂ = 268 / 340.',
        sampleAnswer: '(a) Trang nghe thấy 2 tiếng gõ vì âm thanh truyền từ đầu ống bên kia tới tai Trang theo 2 môi trường khác nhau: truyền qua thành ống thép (chất rắn) nhanh hơn nên đến tai trước, và truyền qua không khí chậm hơn nên đến tai sau.\n(b) Thời gian âm truyền trong ống thép: t₁ = s / v_thép = 268 / 2680 = 0,10 s.\nThời gian âm truyền trong không khí: t₂ = s / v_kk = 268 / 340 ≈ 0,79 s.\nKhoảng thời gian giữa hai lần nghe là: Δt = t₂ - t₁ = 0,79 - 0,10 = 0,69 s.',
        rubricPoints: [
          'Giải thích đúng do tốc độ truyền âm trong thép lớn hơn trong không khí.',
          'Tính đúng t₁ = 0,10 s, t₂ ≈ 0,79 s và Δt = 0,69 s.',
        ],
      },
      {
        id: 'b12-es-4',
        question: 'Câu 4 [Tài liệu Chủ đề Âm thanh]: Đặt một nguồn âm ngay trên mặt nước, một người đứng trên bờ cách nguồn âm 1,5 km và một người thợ lặn ở dưới nước cũng cách nguồn âm 1,5 km. Biết tốc độ truyền âm trong không khí là 340 m/s, trong nước là 1500 m/s.\n(a) Hỏi người nào nghe thấy âm thanh trước? Vì sao?\n(b) Tính thời gian âm thanh đi từ nguồn âm tới tai từng người.',
        hint: 'Đổi s = 1,5 km = 1500 m.',
        sampleAnswer: '(a) Người ở dưới nước sẽ nghe thấy âm thanh trước vì tốc độ truyền âm trong nước (chất lỏng, 1500 m/s) lớn hơn tốc độ truyền âm trong không khí (chất khí, 340 m/s).\n(b) Đổi s = 1,5 km = 1500 m:\n- Thời gian âm truyền trong nước tới người thợ lặn: t_nước = 1500 / 1500 = 1,00 giây.\n- Thời gian âm truyền trong không khí tới người trên bờ: t_kk = 1500 / 340 ≈ 4,41 giây.',
        rubricPoints: [
          'Khẳng định đúng người dưới nước nghe thấy trước và giải thích.',
          'Tính đúng t_nước = 1 s và t_kk ≈ 4,41 s.',
        ],
      },
      {
        id: 'b12-es-5',
        question: 'Câu 5 [Tài liệu Chủ đề Âm thanh]:\n(a) Khi nhai kẹo giòn, cứng, ta nghe thấy tiếng động rất to trong tai, nhưng những người ngồi ngay bên cạnh lại hầu như không nghe thấy gì. Hãy giải thích tại sao?\n(b) Trong kháng chiến, để phát hiện xe tăng địch từ xa, các chiến sĩ trinh sát thường áp tai xuống mặt đất. Tại sao?',
        hint: 'Vận dụng tính chất chất rắn (xương sọ, đất đá) truyền âm tốt hơn chất khí (không khí).',
        sampleAnswer: '(a) Khi nhai kẹo cứng, âm thanh truyền qua xương hàm và xương sọ (là môi trường chất rắn) đến thẳng màng nhĩ và tai trong rất tốt nên ta nghe rất to. Trong khi đó, âm thanh truyền qua không khí ra ngoài tới người bên cạnh bị suy giảm mạnh nên người bên cạnh hầu như không nghe thấy.\n(b) Vì mặt đất là môi trường chất rắn, truyền âm nhanh hơn và xa hơn nhiều so với không khí. Áp tai xuống đất giúp chiến sĩ nghe rõ tiếng xích xe tăng từ rất xa trước khi âm thanh kịp truyền tới qua không khí.',
        rubricPoints: [
          'Giải thích đúng vai trò dẫn âm của xương hàm/xương sọ (chất rắn).',
          'Giải thích đúng mặt đất (chất rắn) truyền âm nhanh và tốt hơn không khí.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 13: ĐỘ TO VÀ ĐỘ CAO CỦA ÂM (Tài liệu Chủ đề Âm thanh - Phần B & C)
  // =========================================================================
  {
    id: 'kntt-bai-13',
    lessonNumber: 13,
    title: 'Bài 13: Độ to và độ cao của âm',
    chapterTitle: 'Chương IV: Âm thanh',
    subject: 'physics',
    pdfUrl: '/assets/aistudio/Ch______m_Thanh_4881f43f.pdf',
    summary:
      'Tần số (f = N / t, đơn vị Hz) là số dao động trong 1 giây: tần số càng lớn thì âm nghe càng cao (bổng), tần số càng nhỏ thì âm càng thấp (trầm). Biên độ dao động là độ lệch lớn nhất của vật so với vị trí cân bằng: biên độ càng lớn thì âm nghe càng to (đơn vị dB).',
    keyFormulas: [
      'Công thức tính tần số:  f = N / t (Hz)  (trong đó N là số dao động, t là thời gian tính bằng giây)',
      'Độ cao của âm phụ thuộc vào Tần số (Hz):  f càng lớn ⇒ âm càng cao (bổng);  f càng nhỏ ⇒ âm càng thấp (trầm)',
      'Độ to của âm phụ thuộc vào Biên độ dao động (đo bằng decibel - dB):  Biên độ càng lớn ⇒ âm càng to',
      'Tai người nghe được âm có tần số từ 20 Hz đến 20 000 Hz  (f < 20 Hz: Hạ âm;  f > 20 000 Hz: Siêu âm)',
    ],
    mcqs: makeMcqs('b13', [
      ['Tần số dao động là:', ['khoảng thời gian vật thực hiện được một dao động.', 'số dao động vật thực hiện được trong một giây.', 'số dao động vật thực hiện được trong một phút.', 'độ lệch lớn nhất của vật khi dao động.'], 1, 'Tần số là số dao động thực hiện được trong 1 giây.'],
      ['Đơn vị của tần số dao động là:', ['giây (s).', 'mét trên giây (m/s).', 'đề-xi-ben (dB).', 'héc (Hz).'], 3, 'Đơn vị của tần số là héc, kí hiệu là Hz.'],
      ['Khi một vật dao động càng nhanh thì tần số dao động của vật:', ['không thay đổi.', 'càng nhỏ.', 'càng lớn.', 'bằng 0.'], 2, 'Dao động càng nhanh nghĩa là số dao động trong 1 giây càng nhiều ⇒ tần số càng lớn.'],
      ['Tần số dao động của nguồn âm càng cao (càng lớn) thì:', ['âm nghe càng trầm (thấp).', 'âm nghe càng to.', 'âm nghe càng vang xa.', 'âm nghe càng bổng (cao).'], 3, 'Tần số quyết định độ cao của âm: tần số càng lớn thì âm phát ra càng cao (càng bổng).'],
      ['Một con lắc thực hiện 40 dao động trong 20 giây. Tần số dao động của con lắc này là:', ['2 Hz.', '0,5 Hz.', '20 Hz.', '800 Hz.'], 0, 'f = N / t = 40 / 20 = 2 Hz.'],
      ['Kết luận nào sau đây là KHÔNG đúng về ngưỡng nghe của tai người?', ['Tai người bình thường nghe được cả hạ âm và siêu âm.', 'Hạ âm là những âm có tần số nhỏ hơn 20 Hz.', 'Siêu âm là những âm có tần số lớn hơn 20 000 Hz.', 'Một số động vật như dơi, cá heo, chó có thể nghe được siêu âm.'], 0, 'Tai người chỉ nghe được âm trong khoảng từ 20 Hz đến 20 000 Hz, không nghe được hạ âm và siêu âm.'],
      ['Trong 20 giây, một lá thép thực hiện được 5000 dao động. Tần số dao động của lá thép là:', ['20 Hz.', '250 Hz.', '5000 Hz.', '100 Hz.'], 1, 'f = N / t = 5000 / 20 = 250 Hz.'],
      ['Trong 2 phút, một vật thực hiện được 4000 dao động. Tần số dao động của vật là:', ['33,3 Hz.', '250 Hz.', '2000 Hz.', '333,3 Hz.'], 0, 'Đổi t = 2 phút = 120 s ⇒ f = 4000 / 120 ≈ 33,3 Hz.'],
      ['Vật nào trong các vật sau đây dao động với tần số lớn nhất?', ['Trong 1 giây, dây đàn thực hiện được 200 dao động.', 'Trong 1 phút (60 s), con lắc thực hiện được 300 dao động.', 'Trong 3 giây, mặt trống thực hiện được 500 dao động.', 'Trong 10 giây, dây chun thực hiện được 650 dao động.'], 0, 'Tính tần số: A = 200 Hz; B = 300/60 = 5 Hz; C = 500/3 ≈ 166,7 Hz; D = 650/10 = 65 Hz ⇒ A lớn nhất (200 Hz).'],
      ['Độ cao (trầm hay bổng) của âm phụ thuộc vào yếu tố nào?', ['Tần số dao động của nguồn âm.', 'Biên độ dao động của nguồn âm.', 'Tốc độ truyền âm trong môi trường.', 'Khoảng cách từ nguồn âm đến tai người nghe.'], 0, 'Độ cao của âm phụ thuộc hoàn toàn vào tần số dao động.'],
      ['Một vật dao động với tần số 8 Hz. Hỏi trong 1 phút (60 giây) vật thực hiện được bao nhiêu dao động?', ['7,5 dao động.', '8 dao động.', '480 dao động.', '60 dao động.'], 2, 'N = f · t = 8 × 60 = 480 dao động.'],
      ['Khi bay, con muỗi thường phát ra âm “vo ve” cao (bổng) hơn tiếng “vù vù” trầm của con ong. Giải thích nào sau đây là đúng?', ['Vì cánh con muỗi dài hơn cánh con ong.', 'Vì tần số vỗ cánh của con muỗi lớn hơn tần số vỗ cánh của con ong.', 'Vì số lần đập cánh của muỗi ít hơn ong.', 'Vì con muỗi bay nhanh hơn con ong.'], 1, 'Cánh muỗi vỗ nhanh hơn (tần số lớn hơn) nên phát ra âm cao (bổng) hơn tiếng ong.'],
      ['Khi lên dây đàn guitar, nếu người nghệ sĩ vặn cho dây đàn càng căng thì khi gảy:', ['dây đàn dao động càng nhanh, tần số càng lớn và âm phát ra càng cao (bổng).', 'dây đàn dao động càng chậm, âm phát ra càng trầm.', 'dây đàn chỉ phát ra âm to hơn chứ không đổi độ cao.', 'tần số dao động giảm xuống bằng 0.'], 0, 'Dây đàn càng căng thì dao động càng nhanh (tần số lớn), âm phát ra càng bổng.'],
      ['Tai con người bình thường có thể nghe được âm có tần số nằm trong khoảng nào?', ['2 Hz – 2000 Hz.', '20 Hz – 20 000 Hz.', '20 Hz – 2000 Hz.', '200 Hz – 200 000 Hz.'], 1, 'Dải tần số âm thanh nghe được của tai người là từ 20 Hz đến 20 000 Hz.'],
      ['Một vật dao động phát ra âm có tần số 50 Hz. Thời gian để vật thực hiện được 200 dao động là:', ['2,5 s.', '4 s.', '5 s.', '0,25 s.'], 1, 't = N / f = 200 / 50 = 4 giây.'],
      ['Trong 7 nốt nhạc cơ bản theo thứ tự từ thấp đến cao: Đồ, Rê, Mi, Fa, Sol, La, Si. So sánh tần số của nốt Rê, Mi và Fa:', ['Tần số nốt Rê nhỏ hơn Mi, và Rê bằng Fa.', 'Tần số nốt Rê nhỏ hơn Mi, và Rê lớn hơn Fa.', 'Tần số nốt Rê lớn hơn Mi, và Rê nhỏ hơn Fa.', 'Tần số nốt Rê nhỏ hơn Mi, và Mi nhỏ hơn Fa (f_Rê < f_Mi < f_Fa).'], 3, 'Theo thứ tự âm cao dần từ Đồ đến Si, tần số tăng dần nên f_Rê < f_Mi < f_Fa.'],
      ['Biên độ dao động của một vật là:', ['tốc độ dao động của vật.', 'số dao động trong 1 giây.', 'độ lệch lớn nhất của vật dao động so với vị trí cân bằng của nó.', 'quãng đường sóng âm truyền đi trong 1 giây.'], 2, 'Định nghĩa: Biên độ dao động là độ lệch lớn nhất của vật so với vị trí cân bằng.'],
      ['Khi biên độ dao động của nguồn âm càng lớn thì:', ['âm phát ra càng to.', 'âm phát ra càng nhỏ.', 'âm phát ra càng bổng.', 'âm phát ra càng trầm.'], 0, 'Biên độ dao động quyết định độ to của âm: biên độ càng lớn ⇒ âm càng to.'],
      ['Độ to của âm được đo bằng đơn vị nào sau đây?', ['Héc (Hz).', 'Mét trên giây (m/s).', 'Đề-xi-ben (dB).', 'Niu-tơn (N).'], 2, 'Độ to của âm được đo bằng đơn vị đề-xi-ben, kí hiệu là dB.'],
      ['Trong các nguồn âm có thông số dưới đây, âm nào vừa trầm nhất vừa to nhất?', ['50 Hz – 100 dB.', '100 Hz – 50 dB.', '50 Hz – 50 dB.', '100 Hz – 100 dB.'], 0, 'Trầm nhất ứng với tần số nhỏ nhất (50 Hz); to nhất ứng với độ to lớn nhất (100 dB) ⇒ 50 Hz – 100 dB.'],
      ['Độ to của tiếng nói chuyện bình thường nằm vào khoảng:', ['10 dB.', '40 dB.', '110 dB.', '140 dB.'], 1, 'Tiếng lá rơi nhẹ ≈ 10 dB; tiếng thì thầm ≈ 20 dB; tiếng nói chuyện bình thường ≈ 40 dB; ngưỡng đau ≈ 130-140 dB.'],
      ['Ngưỡng đau có thể làm đau nhức, tổn thương tai người là khoảng:', ['40 dB.', '60 dB.', '130 dB – 140 dB.', '20 dB.'], 2, 'Âm thanh từ 130 dB trở lên vượt ngưỡng đau gây tổn thương thính giác.'],
      ['Khi sóng âm truyền đi càng xa nguồn âm, đại lượng nào của âm bị giảm dần làm ta nghe nhỏ đi?', ['Tần số dao động của âm.', 'Biên độ dao động (và độ to) của âm.', 'Vận tốc truyền âm trong không khí.', 'Độ cao của âm.'], 1, 'Khi truyền đi xa, năng lượng âm phân tán và bị môi trường hấp thụ nên biên độ giảm làm âm nhỏ đi, còn tần số không đổi.'],
      ['Có 4 con lắc đơn giống nhau, lần lượt kéo lệch khỏi vị trí cân bằng các góc 30°, 40°, 45°, 60° rồi thả nhẹ. Biên độ dao động của con lắc nào lớn nhất?', ['Con lắc lệch 30°.', 'Con lắc lệch 40°.', 'Con lắc lệch 45°.', 'Con lắc lệch 60°.'], 3, 'Góc lệch khỏi vị trí cân bằng càng lớn thì biên độ dao động càng lớn (60°).'],
      ['Rắc một ít cát lên mặt trống rồi dùng dùi gõ vào mặt trống. Trường hợp nào trống phát ra âm to hơn?', ['Khi hạt cát nảy lên cao, rời xa mặt trống (biên độ lớn).', 'Khi hạt cát chỉ rung nhẹ là là trên mặt trống.', 'Khi hạt cát nằm yên không nảy.', 'Độ to của tiếng trống như nhau trong mọi trường hợp.'], 0, 'Hạt cát nảy lên cao chứng tỏ mặt trống dao động với biên độ lớn ⇒ âm phát ra to hơn.'],
      ['Vì sao tàu lá dừa hoặc con lắc dây dao động với biên độ rất lớn mà tai ta lại không nghe thấy âm thanh do chúng phát ra?', ['Vì chúng không phải là vật chất.', 'Vì tần số dao động của chúng quá nhỏ (dưới 20 Hz, thuộc loại hạ âm) nằm ngoài ngưỡng nghe của tai người.', 'Vì chúng phát ra siêu âm trên 20 000 Hz.', 'Vì biên độ lớn làm triệt tiêu âm thanh.'], 1, 'Tàu lá dừa hay con lắc chỉ đung đưa vài lần mỗi giây (f < 20 Hz, hạ âm) nên tai người không nghe được.'],
      ['Ngược lại, vì sao âm thoa khi gõ nhẹ dao động với biên độ rất nhỏ nhưng tai ta vẫn nghe rõ âm thanh do nó phát ra?', ['Vì tần số của âm thoa (ví dụ 440 Hz) nằm trong khoảng 20 Hz – 20 000 Hz mà tai người nghe được.', 'Vì âm thoa phát ra hạ âm.', 'Vì âm thoa có độ to 140 dB.', 'Vì âm thoa làm bằng sắt.'], 0, 'Tần số âm thoa nằm trong dải nghe được của tai người (20 Hz – 20 000 Hz).'],
      ['Khi truyền đi xa, nhận xét nào sau đây là ĐÚNG về tần số và biên độ của sóng âm?', ['Tần số không đổi, biên độ giảm dần.', 'Tần số giảm dần, biên độ không đổi.', 'Cả tần số và biên độ đều tăng.', 'Cả tần số và biên độ đều không đổi.'], 0, 'Khi truyền đi xa, tần số (độ cao) giữ nguyên, còn biên độ (độ to) giảm dần.'],
      ['Khi con ong bay đi tìm mật thì đập cánh 880 lần trong 2 giây; còn khi chở đầy mật bay về tổ thì đập cánh 600 lần trong 2 giây. Tần số vỗ cánh khi đi tìm mật và khi về tổ lần lượt là:', ['440 Hz và 300 Hz.', '880 Hz và 600 Hz.', '300 Hz và 440 Hz.', '220 Hz và 150 Hz.'], 0, 'f_tìm_mật = 880 / 2 = 440 Hz; f_về_tổ = 600 / 2 = 300 Hz (khi đi tìm mật tiếng kêu cao hơn).'],
      ['Trên màn hình dao động kí, nếu sóng âm (2) có các đỉnh sóng mau gấp đôi (số dao động trong cùng thời gian nhiều gấp đôi) nhưng chiều cao đỉnh sóng thấp hơn sóng âm (1) thì:', ['Sóng âm (2) cao (bổng) hơn và nhỏ hơn sóng âm (1).', 'Sóng âm (2) trầm hơn và to hơn sóng âm (1).', 'Sóng âm (2) cao hơn và to hơn sóng âm (1).', 'Sóng âm (2) trầm hơn và nhỏ hơn sóng âm (1).'], 0, 'Số dao động nhiều gấp đôi ⇒ tần số gấp đôi (âm cao hơn); đỉnh sóng thấp hơn ⇒ biên độ nhỏ hơn (âm nhỏ hơn).'],
    ]),
    trueFalseList: [
      {
        id: 'b13-tf-1',
        stem: 'Xét mối liên hệ giữa tần số dao động và độ cao của âm:',
        statements: [
          { id: 'a', text: 'Vật phát ra âm cao (bổng) hơn khi vật dao động nhanh hơn (tần số lớn hơn).', isTrue: true, explanation: 'Đúng, tần số càng lớn thì âm càng cao.' },
          { id: 'b', text: 'Vật phát ra âm cao hơn khi vật bị lệch khỏi vị trí cân bằng nhiều hơn.', isTrue: false, explanation: 'Sai, độ lệch khỏi vị trí cân bằng là biên độ, quyết định độ to chứ không phải độ cao.' },
          { id: 'c', text: 'Tai người bình thường chỉ nghe được các âm có tần số từ 20 Hz đến 20 000 Hz.', isTrue: true, explanation: 'Đúng giới hạn nghe của tai người.' },
          { id: 'd', text: 'Từ nốt Đồ đến nốt Si trong một quãng tám, các âm phát ra đều có cùng một tần số.', isTrue: false, explanation: 'Sai, từ nốt Đồ đến nốt Si độ cao tăng dần nên tần số tăng dần.' },
        ],
      },
      {
        id: 'b13-tf-2',
        stem: 'Vật A trong thời gian 2 phút (120 s) thực hiện được 5400 dao động. Vật B trong thời gian 3 phút (180 s) thực hiện được 8640 dao động:',
        statements: [
          { id: 'a', text: 'Tần số dao động của vật A là 45 Hz.', isTrue: true, explanation: 'Đúng, f_A = 5400 / 120 = 45 Hz.' },
          { id: 'b', text: 'Tần số dao động của vật B là 48 Hz.', isTrue: true, explanation: 'Đúng, f_B = 8640 / 180 = 48 Hz.' },
          { id: 'c', text: 'Vật A phát ra âm cao (bổng) hơn vật B.', isTrue: false, explanation: 'Sai, vì f_B (48 Hz) > f_A (45 Hz) nên vật B phát ra âm cao hơn vật A.' },
          { id: 'd', text: 'Cả hai âm do vật A và vật B phát ra đều nằm trong khoảng tần số tai người nghe được.', isTrue: true, explanation: 'Đúng vì 45 Hz và 48 Hz đều nằm trong khoảng 20 Hz – 20 000 Hz.' },
        ],
      },
      {
        id: 'b13-tf-3',
        stem: 'Xét mối liên hệ giữa biên độ dao động và độ to của âm:',
        statements: [
          { id: 'a', text: 'Biên độ dao động là độ lệch lớn nhất của vật dao động so với vị trí cân bằng.', isTrue: true, explanation: 'Đúng định nghĩa biên độ.' },
          { id: 'b', text: 'Khi gõ mạnh dùi vào mặt trống, biên độ dao động của mặt trống lớn nên âm phát ra to.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Khi gảy nhẹ dây đàn guitar, biên độ dao động của dây đàn nhỏ nên âm phát ra trầm.', isTrue: false, explanation: 'Sai, biên độ nhỏ làm âm phát ra NHỎ (bé), không phải làm âm trầm.' },
          { id: 'd', text: 'Đơn vị đo độ to của âm là đề-xi-ben, kí hiệu là dB.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b13-tf-4',
        stem: 'Một người nghệ sĩ thổi sáo trúc với hai thao tác: Thao tác (a) dùng các ngón tay bịt kín tất cả 6 lỗ trên ống sáo; Thao tác (b) để hở tất cả 6 lỗ trên ống sáo:',
        statements: [
          { id: 'a', text: 'Nguồn âm phát ra tiếng sáo là cột không khí dao động bên trong ống sáo.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Ở thao tác (a) khi bịt kín cả 6 lỗ, cột không khí dao động trong ống sáo dài nhất nên dao động chậm hơn (tần số nhỏ hơn).', isTrue: true, explanation: 'Đúng, cột khí càng dài thì tần số dao động càng nhỏ.' },
          { id: 'c', text: 'Âm phát ra ở thao tác (a) trầm (thấp) hơn âm phát ra ở thao tác (b).', isTrue: true, explanation: 'Đúng vì tần số ở thao tác (a) nhỏ hơn.' },
          { id: 'd', text: 'Việc bịt hay mở các lỗ sáo chỉ làm thay đổi độ to của tiếng sáo chứ không làm thay đổi độ cao.', isTrue: false, explanation: 'Sai, việc bấm các lỗ sáo làm thay đổi chiều dài cột khí để tạo ra các nốt nhạc có độ cao (tần số) khác nhau.' },
        ],
      },
      {
        id: 'b13-tf-5',
        stem: 'Trong dân gian có câu tục ngữ: “Thùng rỗng kêu to”. Xét hai chiếc thùng giống hệt nhau: một thùng rỗng (chỉ chứa không khí) và một thùng đựng đầy gạo, khi gõ cùng một lực như nhau vào thành thùng:',
        statements: [
          { id: 'a', text: 'Về mặt vật lí, câu nói “Thùng rỗng kêu to” là hoàn toàn đúng.', isTrue: true, explanation: 'Đúng theo giải thích vật lí về dao động âm.' },
          { id: 'b', text: 'Ở chiếc thùng đựng đầy gạo, các hạt gạo bên trong cản trở sự dao động của thành thùng làm biên độ dao động giảm nhỏ, nên âm phát ra nhỏ.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Ở chiếc thùng rỗng, thành thùng và khối không khí bên trong ít bị cản trở nên dao động với biên độ lớn và cộng hưởng làm âm phát ra to hơn.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Thùng rỗng kêu to hơn là vì trong thùng rỗng có môi trường chân không.', isTrue: false, explanation: 'Sai, trong thùng rỗng chứa không khí chứ không phải chân không.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b13-es-1',
        question: 'Câu 1 [Tài liệu Chủ đề Âm thanh]: Vật A trong thời gian 2 phút thực hiện được 5400 dao động. Vật B trong thời gian 3 phút thực hiện được 8640 dao động. Hỏi vật nào phát ra âm thanh cao (bổng) hơn? Vì sao?',
        hint: 'Đổi thời gian ra giây rồi tính tần số f_A và f_B theo công thức f = N / t.',
        sampleAnswer: '- Đổi đơn vị thời gian: t_A = 2 phút = 120 giây; t_B = 3 phút = 180 giây.\n- Tần số dao động của vật A là: f_A = N_A / t_A = 5400 / 120 = 45 Hz.\n- Tần số dao động của vật B là: f_B = N_B / t_B = 8640 / 180 = 48 Hz.\n- Vì f_B > f_A (48 Hz > 45 Hz) nên vật B dao động nhanh hơn và phát ra âm thanh cao (bổng) hơn vật A.',
        rubricPoints: [
          'Đổi đúng thời gian ra giây và tính đúng f_A = 45 Hz, f_B = 48 Hz.',
          'So sánh f_B > f_A và kết luận vật B phát ra âm cao hơn.',
        ],
      },
      {
        id: 'b13-es-2',
        question: 'Câu 2 [Tài liệu Chủ đề Âm thanh]: Khi tiến hành thí nghiệm với 4 vật dao động, học sinh ghi được bảng số liệu sau:\n- Vật 1: 150 dao động trong 10 giây.\n- Vật 2: 270 dao động trong 30 giây.\n- Vật 3: 1350 dao động trong 15 giây.\n- Vật 4: 4590 dao động trong 60 giây.\nHãy tính tần số của mỗi vật và sắp xếp các vật theo thứ tự âm phát ra từ trầm nhất đến bổng nhất.',
        hint: 'Tính f₁, f₂, f₃, f₄ rồi xếp theo thứ tự tần số tăng dần.',
        sampleAnswer: 'Tính tần số dao động của 4 vật:\n- Vật 1: f₁ = 150 / 10 = 15 Hz.\n- Vật 2: f₂ = 270 / 30 = 9 Hz.\n- Vật 3: f₃ = 1350 / 15 = 90 Hz.\n- Vật 4: f₄ = 4590 / 60 = 76,5 Hz.\nVì âm có tần số càng nhỏ thì càng trầm, càng lớn thì càng bổng nên thứ tự từ âm trầm đến âm bổng là: Vật 2 (9 Hz) → Vật 1 (15 Hz) → Vật 4 (76,5 Hz) → Vật 3 (90 Hz).',
        rubricPoints: [
          'Tính đúng tần số của cả 4 vật: 15 Hz, 9 Hz, 90 Hz, 76,5 Hz.',
          'Sắp xếp đúng thứ tự từ trầm đến bổng: Vật 2, Vật 1, Vật 4, Vật 3.',
        ],
      },
      {
        id: 'b13-es-3',
        question: 'Câu 3 [Tài liệu Chủ đề Âm thanh]:\n(a) Trong 20 giây, một lá thép thực hiện được 6000 dao động. Hỏi dao động của lá thép có phát ra âm thanh không và tai người có nghe được âm thanh đó không? Tại sao?\n(b) Tại sao ta không nghe được âm thanh do cánh chim bồ câu đang bay tạo ra?',
        hint: 'So sánh tần số dao động với dải tần số nghe được của tai người (20 Hz – 20 000 Hz).',
        sampleAnswer: '(a) Tần số dao động của lá thép là: f = 6000 / 20 = 300 Hz.\nLá thép dao động nên có phát ra âm thanh. Vì tần số 300 Hz nằm trong khoảng từ 20 Hz đến 20 000 Hz nên tai người hoàn toàn cảm nhận (nghe) được âm thanh này.\n(b) Khi chim bồ câu bay, cánh chim vỗ chậm (chỉ vài lần trong 1 giây) nên tần số dao động nhỏ hơn 20 Hz (thuộc vùng hạ âm). Tai người không nghe được hạ âm nên ta không nghe thấy tiếng vỗ cánh này.',
        rubricPoints: [
          'Tính đúng f = 300 Hz và giải thích nằm trong ngưỡng nghe 20 Hz – 20 000 Hz.',
          'Giải thích đúng cánh chim dao động với tần số < 20 Hz (hạ âm).',
        ],
      },
      {
        id: 'b13-es-4',
        question: 'Câu 4 [Tài liệu Chủ đề Âm thanh]: Khi con ong bay đi tìm mật thì đập cánh 880 lần trong 2 s, còn khi đã kiếm đủ mật bay về tổ thì đập cánh 600 lần trong 2 s. Nghe tiếng kêu vo ve của ong, người nuôi ong có thể phân biệt được ong đang đi tìm mật hay đang chở mật về tổ không? Giải thích.',
        hint: 'Tính tần số vỗ cánh trong 2 trường hợp và so sánh độ cao của tiếng kêu.',
        sampleAnswer: '- Tần số dao động của cánh ong khi bay đi tìm mật là: f₁ = 880 / 2 = 440 Hz.\n- Tần số dao động của cánh ong khi chở mật bay về tổ là: f₂ = 600 / 2 = 300 Hz.\n- Khi đi tìm mật, ong nhẹ nên vỗ cánh nhanh hơn (f₁ = 440 Hz > f₂ = 300 Hz), phát ra tiếng kêu cao (bổng) hơn. Khi chở nặng mật về tổ, cánh vỗ chậm hơn nên tiếng kêu trầm hơn. Do đó người nuôi ong có kinh nghiệm có thể nghe tiếng kêu để nhận biết.',
        rubricPoints: [
          'Tính đúng f₁ = 440 Hz và f₂ = 300 Hz.',
          'Giải thích đúng sự khác biệt độ cao (trầm/bổng) giúp nhận biết ong đi tìm mật hay về tổ.',
        ],
      },
      {
        id: 'b13-es-5',
        question: 'Câu 5 [Tài liệu Chủ đề Âm thanh]: Âm thoa khi dao động với biên độ rất nhỏ, ta vẫn nghe thấy âm thanh do nó phát ra (tiếng u… u…), trong khi đó con lắc dây dao động với biên độ rất lớn nhưng ta lại không nghe được âm thanh do nó phát ra. Hãy giải thích tại sao lại có sự khác biệt trên?',
        hint: 'Phân biệt vai trò của biên độ (độ to) và tần số (ngưỡng nghe 20 Hz – 20 000 Hz).',
        sampleAnswer: '- Âm thoa tuy dao động với biên độ nhỏ (âm phát ra nhỏ), nhưng tần số dao động của âm thoa nằm trong khoảng từ 20 Hz đến 20 000 Hz (thường là 440 Hz), thuộc vùng tai người nghe được nên ta nghe rõ tiếng âm thoa.\n- Ngược lại, con lắc dây tuy dao động với biên độ rất lớn nhưng dao động rất chậm, tần số nhỏ hơn 20 Hz (hạ âm), nằm ngoài ngưỡng nghe của tai người nên ta không nghe thấy âm thanh do con lắc phát ra.',
        rubricPoints: [
          'Giải thích đúng tần số âm thoa nằm trong khoảng 20 Hz – 20 000 Hz.',
          'Giải thích đúng tần số con lắc < 20 Hz (hạ âm) nên tai người không nghe được dù biên độ lớn.',
        ],
      },
      {
        id: 'b13-es-6',
        question: 'Câu 6 [Tài liệu Chủ đề Âm thanh]:\n(a) Tại sao khi kiểm tra nhanh lốp xe máy hay ô tô đã bơm căng hay chưa, người thợ thường dùng vật cứng gõ hoặc búng tay vào thành lốp xe?\n(b) Có người khẳng định: “Nghe tiếng sáo diều có thể biết được gió trên trời đang thổi mạnh hay yếu”. Khẳng định đó đúng hay sai? Giải thích.',
        hint: '(a) Lốp căng hay non có tần số dao động khác nhau; (b) Gió mạnh hay yếu làm biên độ dao động cột khí trong sáo diều khác nhau.',
        sampleAnswer: '(a) Khi gõ vào lốp xe làm vỏ lốp và khí bên trong dao động phát ra âm: Nếu lốp đã bơm căng, mặt lốp căng nên dao động nhanh (tần số lớn), phát ra tiếng “bong bong” cao (bổng). Nếu lốp còn non hơi, tần số dao động thấp nên phát ra tiếng “bịch bịch” trầm.\n(b) Khẳng định đó ĐÚNG. Sáo diều phát ra âm nhờ luồng gió trời thổi vào làm cột không khí trong ống sáo dao động. Khi gió to, không khí dao động mạnh với biên độ lớn nên tiếng sáo diều kêu to; khi gió nhẹ, biên độ dao động nhỏ nên tiếng sáo kêu bé.',
        rubricPoints: [
          'Giải thích đúng tiếng lốp căng (tần số cao, âm bổng) và lốp non (tần số thấp, âm trầm).',
          'Giải thích đúng gió mạnh làm biên độ dao động cột khí trong sáo diều lớn nên tiếng sáo to.',
        ],
      },
    ],
  },

  // =========================================================================
  // BÀI 14: PHẢN XẠ ÂM, CHỐNG Ô NHIỄM TIẾNG ỒN (Tài liệu Âm thanh - Phần D & E)
  // =========================================================================
  {
    id: 'kntt-bai-14',
    lessonNumber: 14,
    title: 'Bài 14: Phản xạ âm, chống ô nhiễm tiếng ồn',
    chapterTitle: 'Chương IV: Âm thanh',
    subject: 'physics',
    pdfUrl: '/assets/aistudio/Ch______m_Thanh_4881f43f.pdf',
    summary:
      'Sóng âm dội lại khi gặp vật cản gọi là âm phản xạ. Tiếng vang hình thành khi âm phản xạ đến tai chậm hơn âm trực tiếp ít nhất 1/15 giây. Các vật cứng, nhẵn phản xạ âm tốt; các vật mềm, xốp, gồ ghề phản xạ âm kém (hấp thụ âm tốt).',
    keyFormulas: [
      'Điều kiện nghe được tiếng vang:  t_phản_xạ - t_trực_tiếp ≥ 1/15 giây',
      'Khoảng cách tối thiểu từ nguồn âm đến vật cản trong không khí (v = 340 m/s) để có tiếng vang:  d = (v · t) / 2 = (340 · 1/15) / 2 ≈ 11,33 m',
      'Đo độ sâu đáy biển bằng siêu âm (quãng đường đi và về là 2h):  h = (v · t) / 2',
      '3 nhóm biện pháp chống ô nhiễm tiếng ồn: (1) Tác động vào nguồn âm; (2) Phân tán âm trên đường truyền; (3) Ngăn chặn / hấp thụ âm',
    ],
    mcqs: makeMcqs('b14', [
      ['Ta nghe được tiếng vang khi:', ['âm phản xạ đến tai ta chậm hơn âm trực tiếp một khoảng thời gian ít nhất là 1/15 giây.', 'âm phản xạ đến tai ta chậm hơn âm trực tiếp ít nhất là 15 giây.', 'âm phản xạ đến tai cùng một lúc với âm trực tiếp.', 'âm truyền đi trong chân không.'], 0, 'Tiếng vang xuất hiện khi âm phản xạ nghe được cách âm trực tiếp ít nhất 1/15 giây.'],
      ['Nhận định nào sau đây là đúng nhất về hiện tượng phản xạ âm?', ['Chỉ có âm nằm trong ngưỡng nghe mới phản xạ.', 'Các hạ âm không có hiện tượng phản xạ.', 'Chỉ có siêu âm mới phản xạ.', 'Mọi sóng âm có tần số bất kì khi gặp vật cản đều bị phản xạ ít hay nhiều.'], 3, 'Mọi sóng âm (hạ âm, âm nghe được, siêu âm) gặp mặt chắn đều bị phản xạ.'],
      ['So với âm tới tại nguồn phát, âm phản xạ truyền trở lại bao giờ cũng:', ['lớn hơn âm tới.', 'nhỏ hơn âm tới (do một phần năng lượng bị môi trường và vật cản hấp thụ).', 'có tần số lớn gấp đôi âm tới.', 'truyền nhanh gấp đôi âm tới.'], 1, 'Âm phản xạ đi quãng đường xa hơn và bị hấp thụ một phần nên biên độ (độ to) nhỏ hơn âm tới.'],
      ['Âm phản xạ là:', ['âm dội lại khi gặp một mặt chắn (vật cản).', 'âm đi xuyên qua mọi vật cản.', 'âm đi vòng qua vật cản.', 'âm tự phát ra từ mặt gương.'], 0, 'Âm dội lại khi gặp vật cản được gọi là âm phản xạ.'],
      ['Trong phòng nhỏ, khi nói to ta thường nghe âm thanh to hơn ngoài trời nhưng lại không nghe thấy tiếng vang vì:', ['trong phòng nhỏ không có âm phản xạ.', 'âm phản xạ từ tường dội lại đến tai gần như cùng một lúc với âm truyền trực tiếp (chênh lệch < 1/15 s) nên làm âm nghe to hơn.', 'tường phòng hấp thụ hết âm thanh.', 'trong phòng không có không khí.'], 1, 'Khi khoảng cách đến tường < 11,3 m, âm phản xạ đến tai sớm hơn 1/15 s nên hòa vào âm trực tiếp giúp khuếch đại âm.'],
      ['Vật nào dưới đây là vật phản xạ âm tốt?', ['Miếng xốp.', 'Tấm kính phẳng, nhẵn và cứng.', 'Tường phủ dạ, nhung.', 'Tấm vải bông.'], 1, 'Những vật cứng, có bề mặt phẳng và nhẵn (kính, gạch men, đá hoa, thép) phản xạ âm tốt.'],
      ['Những vật nào sau đây phản xạ âm KÉM (hấp thụ âm tốt)?', ['Mặt gương, tấm kim loại.', 'Mặt đá hoa, tường gạch phẳng.', 'Vải nhung, tấm xốp, rèm bông, cao su xốp (mềm, xốp, gồ ghề).', 'Mặt nước phẳng lặng.'], 2, 'Các vật mềm, xốp, có bề mặt gồ ghề phản xạ âm kém (hấp thụ âm tốt).'],
      ['Trong các rạp chiếu bóng, nhà hát, phòng thu âm, người ta thường làm tường sần sùi hoặc treo rèm nhung dày nhằm mục đích:', ['tạo tiếng vang thật lớn.', 'hấp thụ âm, giảm phản xạ âm để chống tiếng vang và làm âm thanh rõ nét.', 'tăng nhiệt độ cho căn phòng.', 'làm cho ánh sáng phản xạ tốt hơn.'], 1, 'Tường sần sùi và rèm nhung hấp thụ âm tốt, giúp làm giảm tiếng vang trong phòng.'],
      ['Người ta dùng sự phản xạ của sóng siêu âm để đo độ sâu của đáy biển. Giả sử tàu phát ra siêu âm và thu được âm phản xạ sau 1 giây. Biết tốc độ truyền siêu âm trong nước biển là 1500 m/s. Độ sâu đáy biển là:', ['1500 m.', '750 m.', '500 m.', '3000 m.'], 1, 'Quãng đường đi và về là 2h = v · t ⇒ h = (1500 × 1) / 2 = 750 m.'],
      ['Một người đứng cách một vách đá 680 m và hét to. Sau bao lâu kể từ khi hét, người này nghe được âm phản xạ trở lại? Biết tốc độ truyền âm trong không khí là 340 m/s.', ['2 s.', '1 s.', '4 s.', '3 s.'], 2, 'Quãng đường âm đi từ người đến vách đá rồi dội lại là s = 2 × 680 = 1360 m ⇒ t = 1360 / 340 = 4 s.'],
      ['Một tàu thám hiểm trên mặt biển phát ra siêu âm và sau 1,5 giây mới nhận được siêu âm phản xạ từ đáy biển. Biết tốc độ truyền âm trong nước biển là 1500 m/s. Độ sâu của đáy biển là:', ['1500 m.', '1125 m.', '2250 m.', '750 m.'], 1, 'h = (v · t) / 2 = (1500 × 1,5) / 2 = 1125 m.'],
      ['Em phải đứng cách xa một vách núi ít nhất bao nhiêu mét để tại đó nghe được tiếng vang của tiếng nói của mình? Biết tốc độ truyền âm trong không khí là 340 m/s.', ['11,33 m.', '22,67 m.', '34,00 m.', '5,67 m.'], 0, 'Quãng đường cả đi và về tối thiểu là s = 340 × (1/15) ≈ 22,67 m ⇒ Khoảng cách tối thiểu đến vách núi d = s / 2 ≈ 11,33 m.'],
      ['Đứng cách một bức tường lớn 10 m, một học sinh vỗ tay mạnh. Nếu tốc độ truyền âm trong không khí là 340 m/s thì sau bao lâu âm phản xạ truyền trở lại tai học sinh đó?', ['0,015 s.', '0,029 s.', '0,059 s (nhỏ hơn 1/15 s nên không tạo tiếng vang tách biệt).', '1,70 s.'], 2, 'Quãng đường đi và về s = 2 × 10 = 20 m ⇒ t = 20 / 340 ≈ 0,059 s.'],
      ['Loài động vật nào sau đây phát ra sóng siêu âm và thu nhận siêu âm phản xạ để định vị con mồi và vật cản trong đêm tối?', ['Chim cú mèo.', 'Loài dơi (và cá heo dưới biển).', 'Con gà.', 'Con thỏ.'], 1, 'Dơi và cá heo sử dụng định vị bằng tiếng vang siêu âm (echolocation).'],
      ['Ô nhiễm tiếng ồn xảy ra khi nào?', ['Khi có âm thanh nhỏ và ngắn.', 'Khi có tiếng nhạc êm dịu.', 'Khi tiếng ồn to và kéo dài, gây ảnh hưởng xấu đến sức khỏe và hoạt động bình thường của con người.', 'Khi có tiếng chim hót trong vườn.'], 2, 'Ô nhiễm tiếng ồn là tiếng ồn to và kéo dài gây tác hại cho sức khỏe và sinh hoạt của con người.'],
      ['Trường hợp nào sau đây KHÔNG gây ô nhiễm tiếng ồn?', ['Tiếng một chiếc lá hoặc quả chín rơi từ trên cây xuống đất.', 'Tiếng máy cưa, máy khoan bê tông hoạt động liên tục sát khu dân cư.', 'Tiếng hát karaoke mở loa công suất lớn lúc nửa đêm.', 'Tiếng động cơ máy bay phản lực gần khu nhà ở.'], 0, 'Tiếng vật nhỏ rơi diễn ra rất ngắn nên không phải là ô nhiễm tiếng ồn.'],
      ['Để chống ô nhiễm tiếng ồn, biện pháp nào sau đây thuộc nhóm “Tác động vào nguồn âm”?', ['Trồng nhiều cây xanh xung quanh trường học.', 'Làm tường cách âm và đóng kín cửa kính hai lớp.', 'Treo biển báo “Cấm bóp còi” gần bệnh viện, trường học hoặc lắp ống xả giảm thanh cho xe máy.', 'Đeo nút bịt tai chống ồn.'], 2, 'Cấm bóp còi, giảm âm lượng loa, lắp bộ giảm thanh là tác động trực tiếp vào nguồn âm để giảm độ to phát ra.'],
      ['Để chống ô nhiễm tiếng ồn, việc trồng nhiều cây xanh xung quanh trường học, bệnh viện và dọc đường giao thông thuộc biện pháp nào?', ['Tác động vào nguồn âm.', 'Phân tán âm trên đường truyền (làm âm phản xạ theo nhiều hướng khác nhau).', 'Tăng tần số của âm thanh.', 'Triệt tiêu hoàn toàn nguồn âm.'], 1, 'Tán lá cây giúp phản xạ sóng âm theo nhiều hướng khác nhau (phân tán âm trên đường truyền).'],
      ['Vì sao cửa kính hai lớp (ở giữa có một lớp không khí hoặc chân không) lại có khả năng cách âm tốt hơn rất nhiều so với cửa kính một lớp?', ['Vì kính hai lớp trong suốt hơn.', 'Vì lớp không khí (hoặc chân không) ở giữa hai lớp kính truyền âm rất kém (hoặc không truyền âm).', 'Vì cửa kính hai lớp phản xạ ánh sáng tốt hơn.', 'Vì kính hai lớp nhẹ hơn.'], 1, 'Chất khí truyền âm kém hơn chất rắn (và chân không không truyền âm), nên lớp ngăn giữa hai tấm kính giúp chặn sóng âm hiệu quả.'],
      ['Khi xây tường nhà bằng gạch rỗng (gạch có lỗ) thì khả năng cách âm tốt hơn so với gạch đặc vì:', ['gạch có lỗ nặng hơn gạch đặc.', 'các lỗ rỗng trong viên gạch chứa không khí (môi trường truyền âm kém) giúp ngăn chặn âm thanh tốt hơn.', 'gạch có lỗ có bề mặt nhẵn bóng hơn.', 'gạch có lỗ làm tăng tốc độ truyền âm.'], 1, 'Các khoang khí bên trong gạch lỗ làm giảm sự truyền âm qua bức tường.'],
      ['Cách làm nào sau đây là SAI khi muốn chống ô nhiễm tiếng ồn?', ['Giảm độ to của nguồn gây ồn.', 'Ngăn chặn đường truyền âm bằng vật liệu cách âm.', 'Phân tán âm trên đường truyền bằng cây xanh.', 'Chỉ giảm tần số âm mà giữ nguyên độ to 120 dB của tiếng ồn.'], 3, 'Giảm tần số chỉ làm âm trầm xuống chứ không làm giảm độ to (dB) của tiếng ồn.'],
      ['Tiếng ồn to và kéo dài KHÔNG gây ra tác hại nào sau đây đối với sức khỏe con người?', ['Gây suy giảm thính lực, điếc tai.', 'Làm căng thẳng thần kinh, mất ngủ, mệt mỏi.', 'Làm tăng huyết áp và rối loạn nhịp tim.', 'Làm tăng khả năng mắc tật cận thị của mắt.'], 3, 'Ô nhiễm tiếng ồn tác động lên hệ thính giác, thần kinh và tim mạch, không phải nguyên nhân gây cận thị.'],
      ['Một căn nhà lợp mái tôn, khi trời mưa rào phát ra tiếng ồn rất lớn. Nếu làm thêm một lớp trần bằng xốp bên dưới mái tôn thì tiếng ồn giảm hẳn vì:', ['trần xốp phản xạ âm tốt.', 'xốp là vật liệu mềm, xốp có khả năng hấp thụ âm tốt và cách âm hiệu quả.', 'xốp làm nước mưa không rơi xuống mái tôn nữa.', 'xốp làm tăng tần số âm thanh.'], 1, 'Trần xốp hấp thụ âm tốt và ngăn chặn âm thanh truyền từ mái tôn xuống phòng.'],
      ['Một đường cao tốc mới mở chạy gần một trường học. Biện pháp khả thi và hiệu quả lâu dài nhất để giảm tiếng ồn cho học sinh học tập là:', ['Phát nút bịt tai cho tất cả học sinh và giáo viên trong giờ học.', 'Xây tường chắn âm kết hợp trồng dải cây xanh dày ngăn cách và lắp cửa kính cách âm cho phòng học.', 'Mở toang tất cả cửa sổ lớp học.', 'Cấm toàn bộ xe ô tô chạy trên đường cao tốc.'], 1, 'Xây tường chắn âm, trồng cây xanh phân tán âm và lắp cửa kính cách âm là giải pháp đồng bộ, hiệu quả.'],
      ['Sấm rền kéo dài sau một tia sét trong cơn dông là do hiện tượng gì?', ['Do tia sét kéo dài hàng chục giây.', 'Do sự phản xạ liên tiếp của sóng âm (tiếng sấm) từ các đám mây dông và mặt đất đến tai người nghe ở các thời điểm khác nhau.', 'Do ánh sáng truyền chậm hơn âm thanh.', 'Do gió thổi mạnh.'], 1, 'Sóng âm từ tia sét phản xạ nhiều lần qua lại giữa các tầng mây và mặt đất tạo thành tiếng sấm rền vang.'],
      ['Bạn Tài đứng bên bờ sông thấy người chèo thuyền gõ mái chèo vào mạn thuyền, và sau 0,5 giây thì Tài nghe thấy tiếng gõ. Biết tốc độ truyền âm trong không khí là 340 m/s. Khoảng cách từ Tài đến thuyền là:', ['340 m.', '170 m.', '85 m.', '680 m.'], 1, 'Ánh sáng truyền gần như tức thời, âm thanh truyền thẳng từ thuyền đến Tài mất 0,5 s ⇒ s = v · t = 340 × 0,5 = 170 m.'],
      ['Để đo độ sâu đáy biển, máy phát siêu âm trên tàu phát tia siêu âm thẳng đứng xuống đáy biển và thu được âm phản xạ sau 3,5 giây. Biết tốc độ siêu âm trong nước biển là 1500 m/s. Chiều sâu đáy biển là:', ['5250 m.', '2625 m.', '1500 m.', '3500 m.'], 1, 'h = (v · t) / 2 = (1500 × 3,5) / 2 = 2625 m.'],
      ['Long (ở A) và Huy (ở B) đứng trước một bức tường nhà cao. Khoảng cách từ bức tường đến Huy là 150 m, từ Huy đến Long là 200 m (theo thứ tự: Tường — 150m — Huy — 200m — Long). Khi Long thổi còi, Huy nghe thấy 2 tiếng còi cách nhau 1 giây. Tốc độ truyền âm là:', ['340 m/s.', '300 m/s.', '320 m/s.', '150 m/s.'], 1, 'Âm truyền thẳng từ Long đến Huy đi 200 m; âm phản xạ từ tường đi 200 + 2×150 = 500 m. Chênh lệch quãng đường Δs = 500 - 200 = 300 m trong Δt = 1 s ⇒ v = 300 / 1 = 300 m/s.'],
      ['Một người đứng trên mép đảo cách vách núi phía trước 3000 m, ở giữa đảo và vách núi có một chiếc tàu đang neo đậu. Khi tàu hú còi, người trên đảo nghe thấy 2 tiếng còi cách nhau 4 giây. Biết v_kk = 340 m/s. Khoảng cách d từ tàu tới đảo là:', ['2320 m.', '1500 m.', '680 m.', '1360 m.'], 0, 'Ta có ((6000 - d) - d) / 340 = 4 ⇒ 6000 - 2d = 1360 ⇒ 2d = 4640 ⇒ d = 2320 m.'],
      ['Nối cách làm chống tiếng ồn với nguyên lí đúng: “Trồng cây xanh quanh bệnh viện” và “Lắp cửa kính hai lớp cho phòng họp” lần lượt thuộc nguyên lí nào?', ['Phân tán âm trên đường truyền — Ngăn chặn đường truyền âm.', 'Tác động vào nguồn âm — Phân tán âm.', 'Hấp thụ âm — Tác động vào nguồn âm.', 'Cả hai đều là tác động vào nguồn âm.'], 0, 'Cây xanh giúp phân tán âm trên đường truyền; cửa kính hai lớp giúp ngăn chặn đường truyền âm.'],
    ]),
    trueFalseList: [
      {
        id: 'b14-tf-1',
        stem: 'Xét hiện tượng phản xạ âm và điều kiện nghe được tiếng vang:',
        statements: [
          { id: 'a', text: 'Khi sóng âm gặp mặt chắn đều bị phản xạ nhiều hay ít tùy thuộc vào tính chất bề mặt vật chắn.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Những vật cứng, có bề mặt phẳng và nhẵn (mặt gương, mặt kính, đá hoa) phản xạ âm kém và hấp thụ âm tốt.', isTrue: false, explanation: 'Sai, vật cứng, phẳng, nhẵn phản xạ âm TỐT và hấp thụ âm kém.' },
          { id: 'c', text: 'Tiếng vang chỉ nghe được khi âm phản xạ đến tai chậm hơn âm truyền trực tiếp ít nhất là 1/15 giây.', isTrue: true, explanation: 'Đúng điều kiện nghe thấy tiếng vang.' },
          { id: 'd', text: 'Trong không khí (v = 340 m/s), để nghe được tiếng vang của tiếng nói mình thì người nói phải đứng cách vách đá tối thiểu khoảng 11,35 m.', isTrue: true, explanation: 'Đúng vì d_min = (340 × 1/15) / 2 ≈ 11,33 - 11,35 m.' },
        ],
      },
      {
        id: 'b14-tf-2',
        stem: 'Xét ứng dụng của phản xạ sóng siêu âm trong đời sống và kĩ thuật:',
        statements: [
          { id: 'a', text: 'Tàu biển sử dụng máy phát và thu sóng siêu âm (SONAR) theo phương thẳng đứng để đo độ sâu của đáy biển.', isTrue: true, explanation: 'Đúng ứng dụng đo độ sâu biển.' },
          { id: 'b', text: 'Nếu thời gian từ lúc tàu phát tia siêu âm đến khi nhận lại âm phản xạ từ đáy biển là 2 giây (với v = 1500 m/s) thì độ sâu đáy biển là 3000 m.', isTrue: false, explanation: 'Sai, 3000 m là tổng quãng đường cả đi lẫn về; độ sâu đáy biển chỉ bằng một nửa: h = 3000 / 2 = 1500 m.' },
          { id: 'c', text: 'Loài dơi phát ra sóng siêu âm và lắng nghe âm phản xạ để xác định chính xác vị trí con mồi trong bóng tối.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Trong y học, máy siêu âm cũng ứng dụng sự phản xạ của sóng siêu âm để tạo hình ảnh kiểm tra các cơ quan bên trong cơ thể.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b14-tf-3',
        stem: 'Xét hiện tượng ô nhiễm tiếng ồn và tác hại của nó:',
        statements: [
          { id: 'a', text: 'Không nên đùa nghịch, hò hét lớn nơi công cộng (bệnh viện, thư viện) hoặc bấm còi xe inh ỏi khi về đến nhà lúc đêm khuya.', isTrue: true, explanation: 'Đúng ý thức giữ gìn trật tự, tránh gây ô nhiễm tiếng ồn.' },
          { id: 'b', text: 'Tất cả những âm thanh được tạo ra từ dao động có tần số cao (âm bổng) đều gây ra ô nhiễm tiếng ồn.', isTrue: false, explanation: 'Sai, ô nhiễm tiếng ồn phụ thuộc vào độ to (dB) quá lớn và kéo dài, không phải cứ tần số cao là gây ô nhiễm tiếng ồn (ví dụ tiếng chim hót hay tiếng sáo trúc cao nhưng êm dịu).' },
          { id: 'c', text: 'Tất cả những âm thanh to, kéo dài, gây ảnh hưởng xấu đến sức khỏe và hoạt động bình thường của con người được gọi là ô nhiễm tiếng ồn.', isTrue: true, explanation: 'Đúng định nghĩa ô nhiễm tiếng ồn.' },
          { id: 'd', text: 'Làm việc thường xuyên cạnh máy xay xát, máy cưa công nghiệp không có đồ bảo hộ thính giác dễ dẫn đến suy giảm thính lực.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b14-tf-4',
        stem: 'Xét các biện pháp chống ô nhiễm tiếng ồn:',
        statements: [
          { id: 'a', text: 'Trồng nhiều cây xanh xung quanh nhà và trường học giúp lá cây phản xạ âm theo nhiều hướng khác nhau (phân tán âm trên đường truyền).', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Treo rèm nhung dày, phủ dạ sần sùi lên tường phòng thu âm là biện pháp tác động trực tiếp vào nguồn âm.', isTrue: false, explanation: 'Sai, treo rèm nhung và phủ dạ là dùng vật liệu hấp thụ âm để giảm phản xạ âm và ngăn chặn đường truyền âm, không phải tác động vào nguồn âm.' },
          { id: 'c', text: 'Treo biển báo “Đi nhẹ, nói khẽ” trong bệnh viện và “Cấm bóp còi” gần trường học là biện pháp tác động vào nguồn âm.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Sử dụng gạch rỗng (gạch lỗ) và cửa kính hai lớp khi xây nhà mặt phố giúp cách âm tốt hơn.', isTrue: true, explanation: 'Đúng.' },
        ],
      },
      {
        id: 'b14-tf-5',
        stem: 'Xét kinh nghiệm dân gian và thực tế về sự truyền và phản xạ âm:',
        statements: [
          { id: 'a', text: 'Khi tiếng nổ phát ra từ nơi rất xa, sóng âm gặp nhiều vật cản (núi đồi, mặt đất, mây) tạo ra nhiều âm phản xạ nối tiếp nhau nên nghe rền vang và kéo dài.', isTrue: true, explanation: 'Đúng.' },
          { id: 'b', text: 'Khi nguồn nổ ở rất gần, âm trực tiếp đến tai cực nhanh và gần như trùng với âm phản xạ nên ta nghe tiếng nổ rất đanh và gọn.', isTrue: true, explanation: 'Đúng.' },
          { id: 'c', text: 'Trong phòng tắm nhỏ lát gạch men phẳng bóng, khi hát ta nghe tiếng mình to và vang hơn vì gạch men cứng nhẵn phản xạ âm rất tốt.', isTrue: true, explanation: 'Đúng.' },
          { id: 'd', text: 'Mặt nước biển phẳng lặng hấp thụ hoàn toàn sóng âm và không cho âm phản xạ.', isTrue: false, explanation: 'Sai, mặt nước phản xạ âm khá tốt.' },
        ],
      },
    ],
    essays: [
      {
        id: 'b14-es-1',
        question: 'Câu 1 [Tài liệu Chủ đề Âm thanh]: Tính khoảng cách tối thiểu kể từ nguồn âm đến vật cản phẳng để người đứng tại nguồn âm có thể nghe được tiếng vang khi âm truyền trong không khí (biết tốc độ truyền âm trong không khí là 340 m/s).',
        hint: 'Thời gian tối thiểu để nghe được tiếng vang là t = 1/15 giây cho cả quãng đường đi và về (s = 2d).',
        sampleAnswer: '- Điều kiện để nghe được tiếng vang là âm phản xạ phải đến tai chậm hơn âm trực tiếp ít nhất t = 1/15 giây.\n- Trong thời gian t = 1/15 giây, quãng đường sóng âm truyền đi trong không khí là:\ns = v · t = 340 × (1/15) ≈ 22,67 m.\n- Vì sóng âm phải truyền từ nguồn âm đến vật cản rồi phản xạ ngược trở lại tai (s = 2 · d) nên khoảng cách tối thiểu từ nguồn âm đến vật cản là:\nd = s / 2 = 22,67 / 2 ≈ 11,33 m (hoặc 11,35 m).',
        rubricPoints: [
          'Nêu đúng điều kiện t ≥ 1/15 giây và tính đúng tổng quãng đường s ≈ 22,67 m.',
          'Chia đôi quãng đường tìm đúng khoảng cách tối thiểu d ≈ 11,33 m.',
        ],
      },
      {
        id: 'b14-es-2',
        question: 'Câu 2 [Tài liệu Chủ đề Âm thanh]: Để đo độ sâu của biển, người ta dùng máy phát siêu âm đặt trên tàu. Máy phát ra tia siêu âm theo phương thẳng đứng xuống đáy biển, khi gặp đáy biển tia siêu âm phản xạ lại và được máy thu nhận sau 3,5 giây kể từ lúc phát. Biết tốc độ siêu âm trong nước biển là 1500 m/s. Hãy tính chiều sâu của đáy biển tại vị trí đó.',
        hint: 'Quãng đường sóng siêu âm đi trong 3,5 giây bằng 2 lần độ sâu đáy biển (s = 2h).',
        sampleAnswer: '- Quãng đường tia siêu âm truyền trong nước biển (cả lượt đi xuống đáy biển và lượt phản xạ trở lên tàu) trong 3,5 giây là:\ns = v · t = 1500 × 3,5 = 5250 m.\n- Vì quãng đường âm đi được bằng 2 lần độ sâu của đáy biển (s = 2 · h) nên chiều sâu của đáy biển tại vị trí đặt tàu là:\nh = s / 2 = 5250 / 2 = 2625 m.',
        rubricPoints: [
          'Tính đúng tổng quãng đường sóng siêu âm đi được s = 5250 m.',
          'Tính đúng chiều sâu đáy biển h = 2625 m.',
        ],
      },
      {
        id: 'b14-es-3',
        question: 'Câu 3 [Tài liệu Chủ đề Âm thanh]: Ở một căn nhà có mái lợp bằng tôn, khi trời mưa rào người ở trong nhà nghe thấy tiếng mưa đập vào mái tôn rất ồn. Nếu người ta làm thêm một lớp trần bằng chất xốp bên dưới mái tôn thì tiếng ồn gần như mất hẳn. Hãy giải thích tại sao?',
        hint: 'Dựa vào tính chất phản xạ/hấp thụ âm và cách âm của tôn (kim loại cứng) so với xốp (vật mềm, xốp).',
        sampleAnswer: '- Mái tôn là tấm kim loại cứng nên khi hạt mưa rơi đập vào sẽ dao động mạnh, phát ra tiếng ồn lớn truyền xuống không gian trong nhà.\n- Khi lắp thêm một lớp trần bằng chất xốp bên dưới mái tôn: Xốp là vật liệu mềm, xốp, có nhiều lỗ khí nhỏ li ti nên có khả năng hấp thụ âm rất tốt (phản xạ âm kém) và ngăn chặn đường truyền âm từ mái tôn xuống phòng, giúp tiếng ồn giảm hẳn.',
        rubricPoints: [
          'Giải thích đúng mái tôn dao động mạnh khi mưa rơi.',
          'Giải thích đúng lớp trần xốp hấp thụ âm tốt và ngăn chặn đường truyền âm.',
        ],
      },
      {
        id: 'b14-es-4',
        question: 'Câu 4 [Tài liệu Chủ đề Âm thanh]: Long (đứng tại A) và Huy (đứng tại B) ở trước một tòa nhà cao. Khoảng cách từ tòa nhà đến Huy là 150 m, khoảng cách từ Huy đến Long là 200 m (thẳng hàng theo thứ tự: Tòa nhà — 150m — Huy — 200m — Long). Khi Long thổi một tiếng còi thì Huy nghe thấy hai tiếng còi cách nhau 1 giây. Hãy tính tốc độ truyền âm trong không khí.',
        hint: 'Tiếng còi thứ nhất truyền thẳng từ A đến B (200 m); tiếng còi thứ hai đi từ A đến bức tường rồi dội lại B (200 + 2×150 = 500 m).',
        sampleAnswer: '- Tiếng còi thứ nhất Huy nghe thấy là âm truyền thẳng từ Long (A) đến Huy (B) với quãng đường: s₁ = AB = 200 m.\n- Tiếng còi thứ hai là âm phản xạ truyền từ Long (A) đến bức tường tòa nhà rồi phản xạ ngược lại Huy (B) với quãng đường: s₂ = 200 + 150 + 150 = 500 m.\n- Gọi v là tốc độ truyền âm. Vì hai tiếng còi nghe cách nhau Δt = 1 s nên:\nt₂ - t₁ = 1 ⇔ (500 / v) - (200 / v) = 1 ⇔ 300 / v = 1 ⇒ v = 300 m/s.',
        rubricPoints: [
          'Xác định đúng s₁ = 200 m và s₂ = 500 m.',
          'Lập phương trình t₂ - t₁ = 1 s và giải đúng v = 300 m/s.',
        ],
      },
      {
        id: 'b14-es-5',
        question: 'Câu 5 [Tài liệu Chủ đề Âm thanh]: Giả sử nhà em ở sát mặt đường giao thông gần chợ, nơi thường xuyên có xe ô tô, xe máy qua lại gây ồn ào (khoảng 80 dB vào ban ngày). Hãy đề xuất 3 biện pháp cụ thể thuộc 3 nhóm cách chống ô nhiễm tiếng ồn để giảm tiếng ồn cho ngôi nhà của em.',
        hint: 'Nêu đủ 3 nhóm: (1) Tác động nguồn âm, (2) Phân tán âm trên đường truyền, (3) Ngăn chặn/hấp thụ âm.',
        sampleAnswer: 'Ba biện pháp chống ô nhiễm tiếng ồn cho ngôi nhà:\n1. Nhóm tác động vào nguồn âm: Nhắc nhở mọi người trong gia đình và hàng xóm không mở loa đài quá to, tắt máy xe khi dừng đỗ lâu trước nhà.\n2. Nhóm phân tán âm trên đường truyền: Trồng cây xanh, giàn dây leo phía trước hiên nhà và ban công để tán lá phân tán sóng âm từ ngoài đường.\n3. Nhóm ngăn chặn và hấp thụ âm: Lắp cửa kính hai lớp (hoặc cửa gỗ kín có gioăng cao su), treo rèm vải dày ở cửa sổ để ngăn chặn và hấp thụ âm thanh truyền vào phòng học, phòng ngủ.',
        rubricPoints: [
          'Đề xuất đúng biện pháp tác động vào nguồn âm.',
          'Đề xuất đúng biện pháp trồng cây xanh phân tán âm.',
          'Đề xuất đúng biện pháp lắp cửa kính cách âm / treo rèm dày hấp thụ âm.',
        ],
      },
    ],
  },
];
